const fs = require('node:fs');
const path = require('node:path');
(async () => {
	const endpoints = await (await fetch('http://127.0.0.1:38463/json/list')).json();
	const socket = new WebSocket(endpoints[0].webSocketDebuggerUrl);
	await new Promise((resolve, reject) => { socket.onopen = resolve; socket.onerror = reject; });
	let result;
	try {
		result = await new Promise((resolve, reject) => {
			socket.onmessage = event => {
				const message = JSON.parse(event.data);
				if (message.id === 1) message.error ? reject(Error(JSON.stringify(message.error))) : resolve(message.result);
			};
			socket.send(JSON.stringify({ id: 1, method: 'Runtime.evaluate', params: {
				expression: '({pid:process.pid,engineHome:process.env.UNIVERSE_AGENT_HOME,argv:process.argv.filter(x=>/^--(?:user-data-dir|extensions-dir|shared-data-dir|new-window|agents)/.test(x))})',
				returnByValue: true
			} }));
		});
	} finally { socket.close(); }
	const value = result.result.value;
	if (value.pid !== 1931833 || value.engineHome !== '/tmp/vscode-e-after-home-rj0yzdkr' || value.argv.includes('--agents')) throw Error('current owned main mismatch');
	const record = { at: new Date().toISOString(), runId: 'sources-m01-after-20261027-r2', method: 'own main inspector read-only selected current process fields', ...value, rawEvaluation: result };
	fs.writeFileSync(path.join(__dirname, 'main-runtime-before-E.json'), JSON.stringify(record, null, 2) + '\n');
	console.log(JSON.stringify(value));
})().catch(error => { console.error(error); process.exitCode = 1; });
