from pathlib import Path
import json, subprocess, time
base=Path(__file__).resolve().parent
session='D-E-attempt2-controlled-session'
a='D-E-A2-concurrent-permission-A'
b='D-E-A2-concurrent-question-B'
number=46
records=[]
def control(value):
    with (base/'fake-control.jsonl').open('a') as f: f.write(json.dumps(value)+'\n')
    time.sleep(.2)
def held(id):
    return [v for v in map(json.loads,(base/'fake-io.jsonl').read_text().splitlines()) if v.get('type')=='response-held' and v.get('id')==id]
def step(stage,**action):
    global number
    label=f'{number:02}-A2-concurrent-{stage}'; number+=1
    action['label']=label
    r=subprocess.run(['rtk','proxy','node',str(base/'driver.cjs'),json.dumps(action)],capture_output=True,text=True)
    with (base/'driver-stdout.jsonl').open('a') as f: f.write(json.dumps({'action':action,'exit':r.returncode,'stdout':r.stdout,'stderr':r.stderr})+'\n')
    records.append(label)
    if r.returncode: raise RuntimeError(r.stdout+r.stderr)
    value=json.loads((base/'steps'/(label+'.json')).read_text())
    print(json.dumps({'label':label,'result':value.get('result')}),flush=True)
    return value
def seats(value,id): return [s for s in value['state']['seats'] if s.get('sessionKey')==session and s.get('turnId')==id]
def projections(value,id): return [next((p for p in pane['responseProjection']['byRequest'].values() if p['identity']['requestId']==id),None) for pane in value['state']['actualPaneDiagnostics']]
def sel(id,suffix): return f'[data-session-key="{session}"] [data-turn-id="{id}"] '+suffix
try:
    control({'op':'emit','kind':'permission','id':a})
    control({'op':'emit','kind':'question','id':b,'itemId':'choose'})
    initial=step('both-pending',type='inspect')
    assert len(seats(initial,a))==len(seats(initial,b))==2
    step('question-select-Alpha',type='click',selector=sel(b,'[role="checkbox"]'),index=0)
    step('question-custom-text',type='fill',selector=sel(b,'.conversation-lens-question-custom'),index=0,value='Concurrent B preserved draft')
    first=step('permission-A-held',type='click',selector=sel(a,'[role="button"]'),index=0)
    assert all(s['busy']=='true' for s in seats(first,a))
    assert all(s['busy']!='true' for s in seats(first,b))
    both=step('question-B-held-both-busy',type='click',selector=sel(b,'.conversation-lens-question-actions [role="button"]'),index=0)
    assert all(s['busy']=='true' for s in seats(both,a)+seats(both,b))
    assert len(held(a))==len(held(b))==1
    control({'op':'settle','token':held(a)[0]['token'],'outcome':'false'})
    fail=step('only-A-failed-B-still-busy',type='inspect')
    assert all(s['busy']!='true' and "Couldn't send this response:" in s['text'] for s in seats(fail,a))
    assert all(s['busy']=='true' and "Couldn't send" not in s['text'] for s in seats(fail,b))
    assert all(p['inFlight'] and not p.get('failure') for p in projections(fail,b))
    retry=step('A-unchanged-keyboard-retry-B-held',type='keyboardClick',selector=sel(a,'[role="button"]'),index=0)
    assert all(s['busy']=='true' for s in seats(retry,a)+seats(retry,b))
    assert len(held(a))==2 and held(a)[0]['requestHex']==held(a)[1]['requestHex']
    assert len(held(b))==1
    control({'op':'settle','token':held(a)[1]['token'],'outcome':'success'})
    successA=step('A-cleaned-B-still-busy-before-publish',type='inspect')
    assert not seats(successA,a)
    assert len(seats(successA,b))==2 and all(s['busy']=='true' for s in seats(successA,b))
    assert all(p['inFlight'] and not p.get('failure') for p in projections(successA,b))
    assert all([q['requestId'] for q in pane['snapshot']['pendingActions']]==[b] for pane in successA['state']['actualPaneDiagnostics'])
    control({'op':'settle','token':held(b)[0]['token'],'outcome':'success'})
    successB=step('B-local-answered-before-publish',type='inspect')
    assert all('Answered' in s['text'] and s['busy']!='true' and not s['controls'] for s in seats(successB,b))
    assert all(not p['inFlight'] and not p.get('failure') and not p['pendingAliases'] and p['blocked'] for p in projections(successB,b))
    assert all(not pane['snapshot']['pendingActions'] for pane in successB['state']['actualPaneDiagnostics'])
    assert successB['state']['uiErrors']==[]
    control({'op':'publish'})
    result={'state':'PASS','steps':records,'differentRequestIds':[a,b],'permissionAttempts':2,'permissionRetryPayloadEqual':True,'questionAttempts':1,'isolation':'A false/retry/success did not clear B busy, failure or pending state','nextNumber':number}
    (base/'concurrency-result.json').write_text(json.dumps(result,indent=2)+'\n')
    print(json.dumps(result),flush=True)
except Exception as error:
    (base/'concurrency-failure.json').write_text(json.dumps({'error':str(error),'steps':records,'nextNumber':number},indent=2)+'\n')
    raise
