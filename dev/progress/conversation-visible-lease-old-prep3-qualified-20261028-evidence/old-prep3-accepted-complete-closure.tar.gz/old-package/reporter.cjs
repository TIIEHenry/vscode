// Observer adapter only. Official full-json-stream and Mocha JSON reporters unchanged.
const fs = require('node:fs'), path = require('node:path'), crypto = require('node:crypto');
const scratch = __dirname, repo = '/home/clarence/Projects/Agents/vscode-WorkTrees/merge';
const read = name => JSON.parse(fs.readFileSync(path.join(scratch, name)));
const release = read('execution-release.json'), manifest = read('input-manifest.json'), policy = read('policy.json'), profile = read('business-profile.json');
const fail = message => { throw Error(message); };
const fixed = profile.modes[manifest.mode];
if (!(fixed && release.executionAuthorized === true && release.state === 'AUTHORIZED_BUSINESS_ONCE' && release.authorizedBy === '/root' && typeof release.authorizationMessage === 'string' && release.authorizationMessage.trim() && release.protocolId === profile.protocolId && profile.protocolId === 'conversation-visible-lease-business-v1' && release.scope === fixed.scope && release.mode === manifest.mode && policy.mode === manifest.mode && release.packageId === manifest.packageId && policy.packageId === manifest.packageId && release.packageRoot === scratch && manifest.packageRoot === scratch && policy.packageRoot === scratch && release.expectedHead === manifest.expectedHead && release.sourceTree === manifest.sourceTree && process.env.VSCODE_LEASE_DIAGNOSTIC_STAGE === 'test:official' && process.env.VSCODE_LEASE_DIAGNOSTIC_STAGE_TOKEN?.includes(':') && /^[0-9a-f]{64}$/.test(process.env.VSCODE_LEASE_DIAGNOSTIC_DRIVER_NONCE ?? '') && JSON.stringify(read('selection.json')) === JSON.stringify(fixed.selection))) fail('FAIL CLOSED: reporter requires exact independently released business mode/package/HEAD/stage/selection');
const names = read('pin-names.json');
if (JSON.stringify(Object.keys(release.pinnedFilesSha256).sort()) !== JSON.stringify([...names].sort())) fail('Expanded/incomplete reporter pins');
for (const [name, digest] of Object.entries(release.pinnedFilesSha256)) if (crypto.createHash('sha256').update(fs.readFileSync(path.join(scratch, name))).digest('hex') !== digest) fail('Unpinned reporter preparation ' + name);
const FullJsonStreamReporter = require(path.join(repo, 'test/unit/fullJsonStreamReporter.js'));
const JSONReporter = require(path.join(repo, 'node_modules/mocha/lib/reporters/json.js'));
module.exports = class OfficialReporterObserver {
 constructor(runner, options) {
  if (Object.keys(options?.reporterOptions ?? {}).length || options?.reporterOption?.output) fail('Reporter output-file/options expansion forbidden; stdout only');
  this.stream = new FullJsonStreamReporter(runner, options);
  this.json = new JSONReporter(runner, options);
  const clean = runnable => ({ title: runnable.title, fullTitle: runnable.fullTitle(), duration: runnable.duration, currentRetry: runnable.currentRetry() });
  const emit = (event, value) => { this.last = new Promise(resolve => process.stdout.write(JSON.stringify([event, value]) + '\n', resolve)); };
  for (const [event, label] of [['pending', 'pendingObserved'], ['test end', 'testEndObserved'], ['hook', 'hookStartObserved'], ['hook end', 'hookEndObserved']]) runner.on(event, runnable => emit(label, clean(runnable)));
  runner.once('end', () => { process.stdout.write('\n'); emit('observerEnd', { officialJSONAvailable: !!runner.testResults, stats: runner.stats }); });
 }
 async drain() { await this.stream.drain(); await this.last; }
};
