const fs = require('node:fs'), path = require('node:path');
const { chromium } = require('/home/clarence/Projects/Agents/vscode-WorkTrees/merge/node_modules/playwright-core');
const base = __dirname, action = JSON.parse(process.argv[2] || '{"type":"inspect","label":"inspect"}');
(async () => {
	const launch = JSON.parse(fs.readFileSync(path.join(base, 'launch.json')));
	const auth = JSON.parse(fs.readFileSync(path.join(base, 'e-attempt2-authorization.json')));
	const browser = await chromium.connectOverCDP('http://127.0.0.1:' + launch.cdpPort);
	try {
		const page = browser.contexts().flatMap(context => context.pages()).find(page => page.url().includes(launch.repo + '/out/') && page.url().includes('/workbench-dev.html'));
		if (!page) throw Error('owned default editor absent');
		await page.evaluate(auth => {
			const b = window.__eAfter;
			if (!b || b.runId !== auth.runId || b.frozenSourceHead !== auth.sourceHead || b.frozenOutputsSha256 !== auth.frozenOutputsSha256 || b.environment.isSessionsWindow) throw Error('run/window identity mismatch');
		}, auth);
		let result;
		if (action.type === 'session') await page.evaluate(id => window.__eAfter.roster.switchSession(id), action.id);
		else if (action.type === 'openBeside') await page.evaluate(id => window.__eAfter.windows.openSessionBeside(id), action.id);
		else if (action.type === 'hideSession') await page.evaluate(id => window.__eAfter.windows.hideSessionWindow(id), action.id);
		else if (action.type === 'restoreSession') await page.evaluate(id => window.__eAfter.windows.restoreSessionWindow(id), action.id);
		else if (action.type === 'revealSession') await page.evaluate(action => window.__eAfter.windows.revealSessionWindow(action.id, action.options), action);
		else if (action.type === 'focusGroup') await page.evaluate(action => { const part = window.__eAfter.groups.conversationParts.find(part => part.sessionKey === action.session); const group = part?.getGroups().find(group => group.id === action.id); if (!group) throw Error('owned target group absent'); group.focus(); }, action);
		else if (action.type === 'evenGroups') await page.evaluate(session => { const part = window.__eAfter.groups.conversationParts.find(part => part.sessionKey === session); if (!part) throw Error('owned part absent'); part.arrangeGroups(2); }, action.session);
		else if (action.type === 'layoutHide') result = await page.evaluate(async () => { const b=window.__eAfter,root=location.href.split('/out/')[0]+'/out/'; const {IWorkbenchLayoutService,Parts}=await import(root+'vs/workbench/services/layout/browser/layoutService.js'); let result; b.inst.invokeFunction(accessor=>{const layout=accessor.get(IWorkbenchLayoutService),parts=[Parts.EDITOR_PART,Parts.PANEL_PART,Parts.SIDEBAR_PART,Parts.SOURCES_PART];const before=Object.fromEntries(parts.map(part=>[part,layout.isVisible(part)]));for(const part of parts)layout.setPartHidden(true,part);result={before,after:Object.fromEntries(parts.map(part=>[part,layout.isVisible(part)]))};});return result; });
		else if (action.type === 'command') await page.evaluate(async action => { await window.__eAfter.commands.executeCommand(action.id, ...(action.args || [])); }, action);
		else if (action.type === 'click') await page.locator(action.selector).nth(action.index || 0).click({ timeout: 3000 });
		else if (action.type === 'keyboardClick') {
			const target = page.locator(action.selector).nth(action.index || 0);
			await target.focus();
			result = await target.evaluate(node => { const b=window.__eAfter; const member=b.groups.conversationParts.flatMap(part=>part.getGroups().map(group=>({part,group}))).find(({group})=>group.element?.contains(node)); return { method:'normal keyboard focus + Enter', focused:document.activeElement===node, tag:node.tagName, label:node.getAttribute('aria-label'), disabled:node.getAttribute('aria-disabled'), groupId:member?.group.id, sessionKey:member?.part.sessionKey, turnId:node.closest('[data-turn-id]')?.getAttribute('data-turn-id') }; });
			if (!result.focused || result.disabled === 'true') throw Error('keyboard retry must focus an enabled real control');
			await page.keyboard.press('Enter');
		}
		else if (action.type === 'attemptDisabledClick') {
			const target = page.locator(action.selector).nth(action.index || 0);
			if (await target.getAttribute('aria-disabled') !== 'true') throw Error('duplicate control must already be disabled');
			try { await target.click({ timeout: 600 }); result = { blocked: false, normalClick: true }; }
			catch (error) { if (!String(error).includes('Timeout')) throw error; result = { blocked: true, normalClick: true, error: String(error) }; }
		}
		else if (action.type === 'fill') await page.locator(action.selector).nth(action.index || 0).fill(action.value);
		else if (action.type === 'repeatClientTool') result = await page.evaluate(action => window.__eAfter.roster.respondClientTool(action.session, action.id), action);
		else if (action.type !== 'inspect') throw Error('unknown action');
		await page.waitForTimeout(action.waitMs ?? 350);
		const state = await page.evaluate(() => {
			const b = window.__eAfter;
			const project = (value, depth = 0) => {
				if (value === null || value === undefined || ['string', 'number', 'boolean'].includes(typeof value)) return value;
				if (depth > 30) return { unserialized: 'depth limit' };
				if (Array.isArray(value)) return value.map(item => project(item, depth + 1));
				if (value instanceof Map) return Object.fromEntries([...value.entries()].map(([key, item]) => [String(key), project(item, depth + 1)]));
				if (typeof value === 'object' && [Object.prototype, null].includes(Object.getPrototypeOf(value))) return Object.fromEntries(Object.entries(Object.getOwnPropertyDescriptors(value)).map(([key, descriptor]) => [key, 'value' in descriptor ? project(descriptor.value, depth + 1) : { unserialized: 'accessor' }]));
				return { unserialized: 'non-data', type: typeof value };
			};
			const frameViews = b.roster.getSessions().filter(session => session.id === 'D-E-attempt2-controlled-session').map(session => {
				const lease = b.roster.acquireSessionView(session.id);
				try { return { sessionId: session.id, leaseType: lease.constructor.name, leaseId: lease.leaseId, boundEngineSessionId: lease.boundEngineSessionId, snapshot: project(lease.snapshot), respondFailures: project(lease.respondFailures), responseProjection: project(lease.responseProjection) }; } finally { lease.dispose(); }
			});
			const actualGroups = b.groups.conversationParts.flatMap(part => part.getGroups().map(group => ({ part, group })));
			const nodes = [...document.querySelectorAll('.conversation-lens-confirmation-seat, .conversation-lens-question-seat, .conversation-lens-tool-seat, [data-honest-kind="tool"], .conversation-process-fold-tool-line')];
			return {
				at: Date.now(), viewport: {width:innerWidth,height:innerHeight}, themeClasses:document.querySelector('.monaco-workbench')?.className, activeElement:{tag:document.activeElement?.tagName,label:document.activeElement?.getAttribute('aria-label'),html:document.activeElement?.outerHTML.slice(0,1200)}, isSessionsWindow: b.environment.isSessionsWindow, connected: b.connection.isEngineConnected(), connection: project(b.connection.getConnectionSnapshot()), connectionEvents: project(b.connectionEvents), sessions: project(b.roster.getSessions()), source: b.roster.getSessionSource('D-E-attempt2-controlled-session'), sync: project(b.roster.getSessionSync('D-E-attempt2-controlled-session')), visibleSessions: b.windows.getVisibleSessionKeys(), focusedSession: b.windows.getFocusedLeafSessionKey(),
				parts: b.groups.conversationParts.map(part => ({ id: part.id, sessionKey: part.sessionKey, groups: part.getGroups().map(group => ({ id: group.id, active: b.describe(group.activeEditor), panes: group.activeEditorPane ? { id: group.activeEditorPane.getId(), group: group.activeEditorPane.group?.id, input: b.describe(group.activeEditorPane.input) } : null, editors: group.editors.map(input => ({ ...b.describe(input), pinned: group.isPinned(input) })) })) })),
				frameViews, actualPaneDiagnostics: actualGroups.filter(({part}) => part.sessionKey === 'D-E-attempt2-controlled-session').map(({part,group}) => { const pane=group.activeEditorPane, lens=pane?.lens; return { sessionKey:part.sessionKey, groupId:group.id, paneId:pane?.getId(), input:b.describe(pane?.input), paneDistinctFromOtherGroups:actualGroups.filter(x=>x.group!==group).every(x=>x.group.activeEditorPane!==pane), leaseSessionId:lens?.sessionViewLease?.sessionId, leaseId:lens?.sessionViewLease?.leaseId, snapshot:project(lens?.sessionViewLease?.snapshot), responseProjection:project(lens?.sessionViewLease?.responseProjection), diagnosticMethod:'read-only selected actual Pane fields; no binding/proxy writes' }; }), seats: nodes.map(node => ({ turnId: node.closest('[data-turn-id]')?.getAttribute('data-turn-id'), groupId: actualGroups.find(({group})=>group.element?.contains(node))?.group.id, sessionKey: node.closest('[data-session-key]')?.getAttribute('data-session-key'), className: node.className, text: node.innerText, html: node.outerHTML, busy: node.getAttribute('aria-busy'), rect: { x: node.getBoundingClientRect().x, y: node.getBoundingClientRect().y, width: node.getBoundingClientRect().width, height: node.getBoundingClientRect().height }, controls: [...node.querySelectorAll('button, [role="button"], [role="radio"], [role="checkbox"], input')].map(control => ({ tag: control.tagName, role: control.getAttribute('role'), text: control.textContent, label: control.getAttribute('aria-label'), disabled: control.disabled ?? null, ariaDisabled: control.getAttribute('aria-disabled'), checked: control.getAttribute('aria-checked'), value: control.value ?? null })) })),
				body: document.body.innerText, uiErrors: project(b.uiErrors)
			};
		});
		const label = action.label || action.type;
		fs.mkdirSync(path.join(base, 'steps'), { recursive: true });
		fs.mkdirSync(path.join(base, 'shots'), { recursive: true });
		fs.writeFileSync(path.join(base, 'steps', label + '.json'), JSON.stringify({ runId: auth.runId, sourceHead: auth.sourceHead, eNotice: auth.freezeNoticeSha256, action, result, state }, null, 2) + '\n');
		await page.screenshot({ path: path.join(base, 'shots', label + '.png') });
		console.log(JSON.stringify({ label, result, connected: state.connected, phase: state.connection.phase, source: state.source, sync: state.sync, visibleSessions: state.visibleSessions, frames: state.frameViews, seats: state.seats.map(seat => ({ text: seat.text, busy: seat.busy, controls: seat.controls })), uiErrors: state.uiErrors }));
	} finally { await browser.close(); }
})().catch(error => {
	fs.mkdirSync(path.join(base, 'steps'), { recursive: true });
	fs.writeFileSync(path.join(base, 'steps', (action.label || action.type) + '.failure.json'), JSON.stringify({ at: new Date().toISOString(), action, message: String(error), stack: error.stack }, null, 2) + '\n');
	console.error(error); process.exitCode = 1;
});
