from pathlib import Path
import os,json,hashlib,stat,subprocess,datetime
D=Path('/sdd/tmp/vscode-conversation-visible-lease-old-business-20261028-prep3-review')
ns={'__name__':'own_support'}
exec(compile((D/'static-support-and-protection.py').read_bytes(),str(D/'static-support-and-protection.py'),'exec'),ns)
globals().update({k:v for k,v in ns.items() if not k.startswith('__')})

workspace();assert not list(P.iterdir())
proof=readj(D/'targeted-protection-before-assembly.json');assert proof['combinedImmutableRows']==len(readj(D/'immutable-originals-before.json')['rows'])+len(readj(D/'immutable-originals-before.json')['additionalRootInclusiveRows'])
prefix='dev/progress/conversation-visible-lease-business-consumed-v3-20261028-evidence/'
freeze_raw=git('show',SRC+':'+prefix+'source-v3/source-freeze.json')
assert freeze_raw==(V/'source-freeze.json').read_bytes() and len(freeze_raw)==8084 and sha(freeze_raw)=='ddab6b01d9351bd52e2f61268644d4edd8d9cf5ed69db93060f2bd4b811e28f4'
freeze=json.loads(freeze_raw);assert len(freeze['rows'])==13
paths=git('ls-tree','-r','--name-only',SRC,prefix+'source-v3',prefix+'source-v3-review').decode().splitlines()
assert len(paths)==len(set(paths))
source_rows=[]
for wanted in freeze['rows']:
 name=wanted['name'];rawname=name if name.endswith('.json') else name+'.raw';path=prefix+'source-v3/candidate/'+rawname
 assert path in paths
 raw=git('show',SRC+':'+path)
 assert raw==(V/'candidate'/name).read_bytes() and len(raw)==wanted['bytes'] and sha(raw)==wanted['sha256']
 assert (name=='linter.mjs')==wanted['changed']
 if name!='linter.mjs':assert raw==(OLD/name).read_bytes() and len(raw)==wanted['v2Bytes'] and sha(raw)==wanted['v2Sha256']
 write(P/name,raw)
 source_rows.append(dict(name=name,sourceRef=SRC,sourcePath=path,bytes=len(raw),sha256=sha(raw),v2Bytes=wanted['v2Bytes'],v2Sha256=wanted['v2Sha256'],changedFromV2=wanted['changed'],sourceExecuted=False,mode=0o444))
assert next(x for x in source_rows if x['name']=='linter.mjs')['sha256']=='89908e85de9e4a5b416fb9706f7dfd78155ca03d4c839cbcf2290c0df4e163ca'
for n in ['source-v3-peer-and-root-acceptance-summary.json','old-prep2-whole-peer-root-summary.json','old-failure-recovery-peer-root-summary.json','current-boundaries.json','prior-git-publication-provenance.json','SOURCE_EVIDENCE_NOT_RUNTIME_PACKAGE.json']:paths.append(prefix+n)
copies=[]
for path in paths:
 raw=git('show',SRC+':'+path);dest='reviewed-source-v3-publication/'+path
 write(P/dest,raw);copies.append(dict(sourceRef=SRC,path=path,copyPath=dest,bytes=len(raw),sha256=sha(raw)))
oldinv=readj(OD/'frozen-package-inventory.json');historical=[]
for r in oldinv['rows']:
 path=r['path']
 if r.get('type')!=stat.S_IFREG or not any(path.startswith(p) for p in ['historical-dfe-source-publication/','reviewed-guard-v2-publication/','historical-consumed-diag-support/']):continue
 src=OLD/path;assert row(src,OLD)==r
 raw=src.read_bytes();write(P/path,raw);historical.append(dict(originalPath=str(src),copyPath=path,bytes=len(raw),sha256=sha(raw),historicalInertOnly=True))
assert len(historical)==139+85+3
syntax=VR/'authorized-single-mjs-syntax-20261027T190551935133Z/syntax-receipt.json';syntax_raw=syntax.read_bytes();assert len(syntax_raw)==5972 and sha(syntax_raw)=='5ca196b436a55a8588a10c8e1a09271e87f2ea4b5ea8e07372a244b39856b5c0'
syntax_data=json.loads(syntax_raw);assert syntax_data['actualExitCode']==0 and syntax_data['syntaxInvocationCount']==1
write(P/'source-v3-accepted-syntax-receipt.original.json',syntax_raw)
xjson(P/'source-provenance.json',dict(workspaceHead=H,runtimeSourcePublicationCommit=SRC,sourceTree=T,sourceV3OriginalDirectory=str(V),sourceV3FreezeOriginalPath=str(V/'source-freeze.json'),sourceV3FreezeBytes=len(freeze_raw),sourceV3FreezeSha256=sha(freeze_raw),sourceFreezeOriginalState=freeze['state'],originalSyntaxPendingFreezePreservedUnchanged=True,acceptedUniqueSyntaxReceipt=dict(originalPath=str(syntax),copyPath='source-v3-accepted-syntax-receipt.original.json',bytes=len(syntax_raw),sha256=sha(syntax_raw),actualExitCode=0,priorAuthorizedInvocations=1,currentInvocations=0),runtimeSourceFiles=source_rows,all13SourceAndContractCopiesExact=True,other12ExactV2AndC6Bytes=True,sourceEdits=0,currentSyntaxChecks=0,currentCandidateImports=0,currentCandidateInvocations=0,reviewedV3PublicationCopies=copies,historicalInertPublicationAndSupportCopies=historical,sourceAuthorityIndependentOfWorkspaceHead=True,historyCopiesUseTheirFixedObjectsOrFrozenOriginalsNotLiveSubstitutions=True,sourcePeer='Original Astra source-v3 C0/I0/M0 root adopted; exact committed root-authored attributed summary copied. Not raw/verbatim/original reviewer message bytes.',oldPrep2Consumed='Exactly once driver1, checker0/lint1, no dry/emit/official, empty restoration union; final e182 preserved only as consumed failure provenance, never runtime predecessor.',wholePackagePeer='PENDING_INDEPENDENT_ROOT_AND_ORIGINAL_ASTRA'))
profile=readj(P/'business-profile.json');assert profile['sourceTree']==T
inputs=[]
for wanted in profile['modes']['old']['sourceFiles']:
 raw=git('show',wanted['sourceRef']+':'+wanted['sourcePath']);assert len(raw)==wanted['sourceBytes'] and sha(raw)==wanted['sourceSha256'] and raw.decode('utf-8').encode()==raw
 assert git('rev-parse',wanted['sourceRef']+':'+wanted['sourcePath']).decode().strip()==wanted['sourceBlob']
 dest=P/'inputs'/wanted['sourcePath'];write(dest,raw);inputs.append({**wanted,'inputCopyPath':str(dest),'inputCopyMode':0o444,'workspaceSourceBytesAreDistinctAuthority':True})
assert len(inputs)==2
xjson(P/'source-inputs.json',inputs);xjson(P/'selection.json',profile['modes']['old']['selection'])
write(P/'expected-L1-plus-meta-fullTitles.txt',('\n'.join(profile['modes']['old']['selection']['requiredFullTitles'])+'\n').encode())
anchor=readj(N/'guard-after-restore.json');old=readj(N/'input-manifest.json')
bindings=readj(OLD/'bound-tool-and-config-files.json');assert bindings==old['boundToolAndConfigFiles'] and len(bindings)==149
xjson(P/'bound-tool-and-config-files.json',bindings)
out={p.relative_to(R).as_posix():nmeta(p) for p in [R/'out',*(R/'out').rglob('*')]};assert out==anchor['outMetadata']
xjson(P/'fresh-native-baseline.json',dict(schemaVersion=6,packageId=P.name,capturedAtUtc=now(),freshLiveCapture=True,capturedAfterActual715Protection=True,preparationProtectionFile=str(D/'targeted-protection-before-assembly.json'),preparationProtectionSha256=sha((D/'targeted-protection-before-assembly.json').read_bytes()),outMetadata=dict(sorted(out.items())),sourceNativePairs=anchor['sourceNativePairs'],originalWholeBuildProtectionPassed=False))
tuples={};counts={}
for scope in ['src','.build','node_modules']:
 actual=[]
 for p in sorted([R/scope,*(R/scope).rglob('*')],key=lambda q:q.relative_to(R).as_posix()):
  m=meta(p);actual.append([p.relative_to(R).as_posix(),m['type'],m['fullMode'],m['size'],m['mtimeNs'],m['ctimeNs'],m['symlinkTarget']])
 assert actual==anchor['repositoryMetadata']['tuples'][scope];tuples[scope]=actual;counts[scope]=len(actual)
xjson(P/'repository-metadata-baseline.json',dict(schemaVersion=2,tupleFields=['path','type','fullMode','size','mtimeNs','ctimeNs','symlinkTarget'],includesEachRootAndAllDescendants=True,sort='lexicographic POSIX relative path string',atimeExcluded=True,mtimeCtimeIntegerNanoseconds=True,capturedAtUtc=now(),sourceRef=H,sourceTree=T,tuples=tuples,counts=counts,originalWholeBuildProtectionPassed=False,currentBaselineBindsKnownHistoricalBuildLogDriftWithoutRepair=True))
seals=[]
for phase,path in profile['emissionPhases'].items():
 q=R/path;s=q.stat();raw=q.read_bytes();dest=P/'sealed-originals'/path;write(dest,raw);assert nmeta(q)==anchor['outMetadata'][path]
 seals.append(dict(path=path,emissionPhase=phase,potentialWriteEligibility=True,restoreAuthority=False,writeAuthorizedNow=False,sealedBytesPath=str(dest),sha256=sha(raw),bytes=len(raw),mode=stat.S_IMODE(s.st_mode),atimeNs=s.st_atime_ns,mtimeNs=s.st_mtime_ns,ctimeNs=s.st_ctime_ns,mtimeNsString=str(s.st_mtime_ns),ctimeNsString=str(s.st_ctime_ns),backupCopyMode=0o444))
xjson(P/'sealed-originals.json',seals)
im=readj(D/'immutable-originals-before.json');xjson(P/'immutable-protection-inventory.json',im)
xjson(P/'immutable-protection-contract.json',dict(legacyRoots=8,legacyDescendantsOnlyRows=2018,legacyClassificationPreserved=True,original3238RowsUnchanged=True,originalThreeRootInclusiveCounts={r:sum(Path(x['path']).is_relative_to(r) for x in im['additionalRootInclusiveRows']) for r in im['additionalRootInclusiveRoots'][:3]},nineNewCompleteRootInclusiveCounts=proof['nineFreshRootInclusiveCounts'],combinedRows=proof['combinedImmutableRows'],actualFreshEnumeratedCountNotHardcoded=True,currentPackageAndReviewForbiddenAsOriginalRoots=True,ongoingIWritableAreaNotFrozen=True,noOverlapsAliasesOrDuplicateRoots=True,actualPathsetMetadataAndListedRegularHashesChecked=True,sourceGuardUnchangedDataDrivenExtension=True,consumedOldPrep2NeverRerun=True))
targets=[dict(path=x['outputPath'],role='fresh-'+x['role']+'-required-runtime-observation-after-independent-qualified-phase',writableOnlyAfterSeparatelyAuthorizedExecution=True,potentialWriteEligibility=True,restoreAuthority=False,requiresScriptParsedAndGetScriptSource=True,forceImportForbidden=True,requiresFreshDrySealAndIndependentCompletedPhase=True) for x in inputs]
xjson(P/'observation-targets.json',targets)
raw=(OLD/'native-asset-manifest.json').read_bytes();assert len(raw)==8627331 and sha(raw)=='1139d88acc3f53af2e3656145aac5351815e0afaa83376aa294ec311a1ada538'
write(P/'native-asset-manifest.json',raw)
pv=readj(OLD/'native-asset-manifest-provenance.json');pv.update(capturedAtUtc=now(),expectedHead=H,workspaceSourceRef=H,newManifest=dict(path=str(P/'native-asset-manifest.json'),bytes=len(raw),sha256=sha(raw)),actualFutureRequiredObservationTargets=targets,currentNativeBytesQualifiedByFreshMetadataAndAcceptedContentHashes=True,freshStaticNativeIdentityCount=0,freshMetadataAcceptedNativeIdentityCount=11168,sourceDescriptionSource='Independent current-workspace-source-descriptions.json',candidateInvocations=0,syntaxCalls=0)
xjson(P/'native-asset-manifest-provenance.json',pv);write(P/'native-asset-two-field-replay.json',(OLD/'native-asset-two-field-replay.json').read_bytes())
descriptions=readj(OLD/'current-workspace-source-descriptions.json');descriptions.update(capturedAtUtc=now(),expectedHead=H)
for x in descriptions['rows']:x['workspaceRef']=H
xjson(P/'current-workspace-source-descriptions.json',descriptions)
common=dict(protocolId=profile['protocolId'],mode='old',packageId=P.name,packageRoot=str(P),repo=str(R),expectedHead=H,sourceTree=T)
policy={**common,'stageOrder':profile['stageOrder'],'sourceInputCount':2,'totalAllowedOutPaths':2,'temporaryProductionJs':1,'temporaryTestJs':1,'standaloneMapCount':0,'sourcePaths':profile['sourcePaths'],'outputPaths':profile['outputPaths'],'writableOutputPaths':profile['outputPaths'],'observationTargetPaths':profile['outputPaths'],'emissionPhases':profile['emissionPhases'],'noRetry':True,'noAutomaticNewDispatch':True,'fullCompileOfFinalSourceTree':False,'originalWholeBuildProtectionPassed':False,'runtimeAuthorityFromQualifiedParentGrantAndValidIntentOnly':True}
xjson(P/'policy.json',policy)
lineage=dict(anchorPath=profile['baselineAnchor']['path'],anchorSha256=profile['baselineAnchor']['sha256'],freshCapture=True,captureAfterActual715Restoration=True,noHistorical821Reuse=True,packageId=P.name,predecessorGuardFile=profile['baselineAnchor']['path'],predecessorGuardSha256=profile['baselineAnchor']['sha256'])
esbuild={**old['esbuildPolicy'],'oneInputBytesByRole':{x['role']:x['sourceBytes'] for x in inputs},'dryTotalInputBytes':sum(x['sourceBytes'] for x in inputs)}
manifest={**common,'schemaVersion':6,'sourceOnlyDirectory':'/home/clarence/.codex/tmp/lease-business-semantic-source-v1-20261028','sourceOnlyDirectoryIsActualRuntimeSource':False,'sourceOnlyDirectoryPurpose':'Legacy v1 schema exclusion identity only; independent package root must differ. Actual runtime source is separately bound fixed published v3.','runtimeSourcePublicationCommit':SRC,'runtimeSourceFreezeDirectory':str(V),'sourceFiles':inputs,'boundToolAndConfigFiles':bindings,'boundSourceNativePairs':anchor['sourceNativePairs'],'baselineLineage':lineage,'currentNativeGuardFile':str(P/'fresh-native-baseline.json'),'currentNativeGuardBytes':(P/'fresh-native-baseline.json').stat().st_size,'currentNativeGuardSha256':sha((P/'fresh-native-baseline.json').read_bytes()),'guardSchemaVersion':6,'repositoryMetadataSchemaVersion':2,'repositoryMetadataBaselineFile':str(P/'repository-metadata-baseline.json'),'repositoryMetadataBaselineSha256':sha((P/'repository-metadata-baseline.json').read_bytes()),'baselineFile':old['baselineFile'],'baselineFileBytes':old['baselineFileBytes'],'baselineFileSha256':old['baselineFileSha256'],'oldD8ePreservationInventory':old['oldD8ePreservationInventory'],'oldF33PreservationInventory':old['oldF33PreservationInventory'],'oldOwnedReport':old['oldOwnedReport'],'immutableProtectionInventoryFile':str(P/'immutable-protection-inventory.json'),'immutableProtectionInventorySha256':sha((P/'immutable-protection-inventory.json').read_bytes()),'esbuildPolicy':esbuild,'pythonExecutable':'/usr/bin/python3.10','preparationDoesNotGrantExecution':True,'fullCompileOfFinalSourceTree':False,'originalWholeBuildProtectionPassed':False}
xjson(P/'input-manifest.json',manifest)
xjson(P/'legacy-source-directory-field-explanation.json',dict(field='input-manifest.sourceOnlyDirectory',value=manifest['sourceOnlyDirectory'],reason=manifest['sourceOnlyDirectoryPurpose'],actualRuntimePublicationCommit=SRC,actualRuntimeFreezeDirectory=str(V),sourceAndContractEdited=False))
xjson(P/'consumed-old-prep2-provenance.json',dict(consumedRoot=str(OLD),consumedMarkerPath=str(OLD/'execution-consumed.json'),consumedMarkerSha256=sha((OLD/'execution-consumed.json').read_bytes()),runtimeReleaseOriginallyActivatedAndConsumed=True,actualInvocations=1,actualDriverExitCode=1,checkerExitCode=0,lintExitCode=1,dryEmitOfficialReached=False,restorationUnion=[],actualRestorePaths=[],finalGuardPath=str(OLD/'guard-after-restore.json'),finalGuardBytes=20158278,finalGuardSha256='e182d89f5c85fe1ae57df4d5190d15f1590929b9713a6e18247213cd431798d4',rootAcceptedPeer='Root-authored attributed Original Astra C0/I0/M0 summary preserved from fixed5f publication; not raw reviewer message',runtimePredecessorIsStillActual715=True,noNewRecoveryReceiptInvented=True,noRuntimeAuthorityConferred=True))
xjson(P/'preparation-authorization.json',readj(D/'exclusive-creation-and-authority.json'))
xjson(P/'preparation-state.json',dict(state='PREPARED0_STATIC_ONLY',executionAuthorized=False,activationAuthorized=False,preparedInvocations=0,candidateInvocations=0,syntaxCalls=0,compilerInvocations=0,checkerInvocations=0,lintInvocations=0,dryInvocations=0,emitterInvocations=0,officialInvocations=0,newModePackageCreated=False,wholePackagePeer='PENDING_INDEPENDENT_ROOT_AND_ORIGINAL_ASTRA'))
summary=dict(capturedAtUtc=now(),workspaceHead=H,sourceTree=T,runtimeSourcePublicationCommit=SRC,runtimeSourceFiles=13,v3PublicationCopies=len(copies),historicalInertCopies=len(historical),inputCopies=2,bound149=True,sourceNative256=True,outMetadataCount=len(out),repositoryCounts=counts,combinedImmutableRows=proof['combinedImmutableRows'],immutableAdditionalRows=len(im['additionalRootInclusiveRows']),candidateInvocations=0,syntaxCalls=0,packageNotFinalYet=True)
xjson(D/'phase1-static-assembly.json',summary);workspace();print(json.dumps(summary))
