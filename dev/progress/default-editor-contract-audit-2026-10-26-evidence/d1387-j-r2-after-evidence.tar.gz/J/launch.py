import json
import os
import pathlib
import select
import subprocess
import time

from prepare import snapshot
from readiness import verify

base = pathlib.Path(__file__).resolve().parent
proof = verify()
assert not (base / 'launch.json').exists(), 'inspect and clean existing owned launch before a new version'
engine_route = json.loads((base.parent / 'e-response-after-m01-20261027-r2' / 'phase-route.json').read_text())
assert engine_route['createdBy'] == '/root/sources_audit'
assert engine_route['runId'] == proof['runId'] == 'sources-m01-after-20261027-r2'
engine_home = pathlib.Path(engine_route['engineHome'])
assert engine_home.parent == pathlib.Path('/tmp') and engine_home.name.startswith('vscode-e-after-home-')
assert not engine_home.is_symlink() and engine_home.is_dir()
engine_stat = engine_home.stat()
assert engine_stat.st_uid == os.getuid() and engine_stat.st_mode & 0o077 == 0
assert not (engine_home / 'server.sock').exists() and not (engine_home / 'server.lock').exists(), 'J requires an empty own engine home; do not start with an E or user engine anchor'
fixture = json.loads((base / 'fixture.json').read_text())
assert fixture['createdBy'] == '/root/sources_audit'
current = [snapshot(pathlib.Path(fixture['fixture']) / name) for name in ['alpha', 'beta']]
assert current == json.loads((base / 'fixture-baseline.json').read_text()), 'own fixture changed; do not reset'
(base / 'readiness-check.json').write_text(json.dumps(proof, indent=2) + '\n')
readfd, writefd = os.pipe()
with open(base / 'xvfb.log', 'w') as log:
    xvfb = subprocess.Popen(['rtk', 'proxy', 'Xvfb', '-displayfd', str(writefd), '-screen', '0', '1920x1200x24', '-nolisten', 'tcp'], pass_fds=(writefd,), stdin=subprocess.DEVNULL, stdout=log, stderr=subprocess.STDOUT, start_new_session=True)
os.close(writefd)
stat = pathlib.Path('/proc', str(xvfb.pid), 'stat').read_text()
lease = {'createdBy': '/root/sources_audit', 'xvfbPid': xvfb.pid, 'xvfbStartTimeTicks': stat[stat.rfind(')') + 2:].split()[19], 'startedAt': time.time(), 'released': False, 'sourceHead': proof['notice']['sourceHead'], 'runId': proof['runId']}
(base / 'lease.json').write_text(json.dumps(lease, indent=2) + '\n')
try:
    assert select.select([readfd], [], [], 8)[0], 'Xvfb did not allocate an independent display'
    display = ':' + os.read(readfd, 128).decode().strip()
    os.close(readfd)
    assert display[1:].isdigit()
    lease['display'] = display
    (base / 'lease.json').write_text(json.dumps(lease, indent=2) + '\n')
    env = os.environ.copy()
    env.update(DISPLAY=display, CODE_OSS_DEV_AUTHED_SHARED_DATA_DIR=str(base / 'empty-shared'), UNIVERSE_AGENT_HOME=str(engine_home), PYTHONDONTWRITEBYTECODE='1')
    env.pop('ELECTRON_RUN_AS_NODE', None)
    launcher = base.parents[1] / '.agents/skills/launch/scripts/launch.sh'
    args = ['rtk', 'proxy', 'bash', str(launcher), '--repo', '/home/clarence/Projects/Agents/vscode-WorkTrees/merge', '--source-user-data-dir', str(base / 'empty-seed'), '--skip-prelaunch', '--disable-workspace-trust', '--', '--new-window', '--enable-smoke-test-driver', '--use-mock-keychain', '--no-sandbox', '--disable-gpu', str(base / 'after.code-workspace')]
    result = subprocess.run(args, env=env, text=True, capture_output=True, start_new_session=True)
    (base / 'launcher.log').write_text(result.stdout + '\n' + result.stderr)
    if result.returncode:
        raise RuntimeError('isolated launcher failed: ' + result.stderr[-2000:])
    info = json.loads(result.stdout.strip().splitlines()[-1])
    assert info['agents'] is False
    info.update(createdBy='/root/sources_audit', display=display, xvfbPid=xvfb.pid, fixture=fixture['fixture'], workspace=str(base / 'after.code-workspace'), engineHome=str(engine_home), explicitReadySource=proof['notice']['sourceHead'], runId=proof['runId'], explicitReadySourceTree=proof['notice']['sourceTree'], freezeNoticeSha256=proof['freezeNoticeSha256'], frozenOutputsSha256=proof['frozenOutputsSha256'])
    (base / 'launch.json').write_text(json.dumps(info, indent=2) + '\n')
    lease.update(runDir=info['runDir'], electronPid=info['pid'])
    (base / 'lease.json').write_text(json.dumps(lease, indent=2) + '\n')
    print(json.dumps({key: info[key] for key in ['pid', 'cdpPort', 'display', 'xvfbPid', 'runDir', 'explicitReadySource']}))
except BaseException:
    if xvfb.poll() is None:
        xvfb.terminate()
    raise
