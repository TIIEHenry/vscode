from pathlib import Path
D=Path('/sdd/tmp/vscode-conversation-visible-lease-old-business-20261028-prep3-review')
ns={'__name__':'own_support'}
exec(compile((D/'static-support-and-protection.py').read_bytes(),str(D/'static-support-and-protection.py'),'exec'),ns)
globals().update({k:v for k,v in ns.items() if not k.startswith('__')})
workspace()
assert readj(D/'phase3-freeze.actual-result.json')['actualExitCode']==0 and readj(D/'after-freeze-protection.actual-result.json')['actualExitCode']==0
anchor=readj(D/'package-final-audit.anchor.json');audit_raw=(P/'package-final-audit.json').read_bytes();audit=json.loads(audit_raw)
inv_raw=(D/'frozen-package-inventory.json').read_bytes();inv=json.loads(inv_raw)
assert len(audit_raw)==anchor['auditBytes'] and sha(audit_raw)==anchor['auditSha256']
assert len(inv_raw)==anchor['frozenInventoryBytes'] and sha(inv_raw)==anchor['frozenInventorySha256']
entries=sorted([P,*P.rglob('*')],key=lambda p:p.relative_to(P).as_posix());actual=[row(p,P) for p in entries]
assert actual==inv['rows'] and len(actual)==inv['entryCount']==555
assert {x['path'] for x in actual}=={x['path'] for x in audit['rows']}
for expected in audit['rows']:
 if expected.get('selfAnchorExcluded'):
  assert expected['path']=='package-final-audit.json';continue
 assert expected==next(x for x in actual if x['path']==expected['path']),expected['path']
assert sum(x['type']==stat.S_IFREG for x in actual)==438 and sum(x['type']==stat.S_IFDIR for x in actual)==117
for x in actual:
 if x['type']==stat.S_IFREG:assert stat.S_IMODE(x['fullMode'])==(0o644 if x['path']=='execution-release.json' else 0o444),x['path']
 elif x['type']==stat.S_IFDIR:assert stat.S_IMODE(x['fullMode'])==0o700,x['path']
 else:raise AssertionError(('unexpected nonregular package entry',x))
release_raw=(P/'execution-release.json').read_bytes();release=json.loads(release_raw)
assert release_raw==(D/'execution-release.prepared0.original.json').read_bytes() and sha(release_raw)==anchor['releaseSha256']==audit['executionReleaseSha256']
assert release['state']=='PREPARED0_NOT_AUTHORIZED' and release['executionAuthorized'] is False and release['activationAuthorized'] is False and release['authorizedBy'] is None and release['authorizationMessage'] is None
assert release['invocations']==release['preparedInvocations']==0 and release['expectedHead']==H and release['sourceTree']==T
activation=readj(P/'activation-contract.json');assert activation['futureActivationFieldsOnly']==['state','executionAuthorized','activationAuthorized','authorizedBy','authorizationMessage']
pins=release['pinnedFilesSha256'];names=readj(P/'pin-names.json');closure=readj(P/'package-static-closure.json')
regular={x['path'] for x in actual if x['type']==stat.S_IFREG};assert set(pins)==set(names)==set(closure['immutableRegularFilePaths'])==regular-{'execution-release.json','package-final-audit.json'}
assert len(pins)==436 and closure['immutablePinCount']==audit['immutablePinCount']==anchor['immutablePinCount']==436
for name,digest_value in pins.items():assert sha((P/name).read_bytes())==digest_value,name
assert closure['combinedImmutableRows']==4169 and closure['original3238RowsUnchanged'] and closure['runtimeSourcePublicationCommit']==SRC
im=readj(P/'immutable-protection-inventory.json');assert im==readj(D/'immutable-originals-before.json')
assert len(im['rows'])==2018 and len(im['additionalRootInclusiveRows'])==2151 and len(im['additionalRootInclusiveRoots'])==12
before=readj(D/'targeted-protection-before-assembly.json');after=readj(D/'targeted-protection-after-freeze.json')
for key in ['runtimePredecessorSha256','consumedFailureProvenanceSha256','nineFreshRootInclusiveCounts','combinedImmutableRows','currentEqualsE182Equals715RelevantDomain','zeroFreshMetadataByteWriteOrCtimeDifferences']:
 assert before[key]==after[key],key
assert after['currentEqualsE182Equals715RelevantDomain'] and after['zeroFreshMetadataByteWriteOrCtimeDifferences']
assert after['runtimePredecessorSha256']=='715f604de0029670e213bf808f20a9b18184d303257d273142003cc5dd119f25' and after['consumedFailureProvenanceSha256']=='e182d89f5c85fe1ae57df4d5190d15f1590929b9713a6e18247213cd431798d4'
manifest=readj(P/'input-manifest.json');assert manifest['expectedHead']==H and manifest['runtimeSourcePublicationCommit']==SRC and manifest['runtimeSourceFreezeDirectory']==str(V)
assert manifest['baselineLineage']['predecessorGuardFile']==str(N/'guard-after-restore.json') and manifest['baselineLineage']['predecessorGuardSha256']==after['runtimePredecessorSha256']
source=readj(P/'source-provenance.json');assert len(source['runtimeSourceFiles'])==13
for x in source['runtimeSourceFiles']:
 b=(P/x['name']).read_bytes();assert b==git('show',SRC+':'+x['sourcePath'])==(V/'candidate'/x['name']).read_bytes() and len(b)==x['bytes'] and sha(b)==x['sha256']
assert readj(V/'source-freeze.json')['state']=='SOURCE_V3_STATIC_FROZEN_SYNTAX_PENDING'
assert sha((V/'source-freeze.json').read_bytes())=='ddab6b01d9351bd52e2f61268644d4edd8d9cf5ed69db93060f2bd4b811e28f4'
assert readj(P/'preparation-final-state.json')['sourcePublicationCommit']==SRC
# A fresh FINAL metadata/pathset comparison is a separate sample; it does not
# rewrite the original phase2 sampling time or rehash the full context content.
context=readj(P/'context-content-inventory.json');oldcontext=readj(OLD/'context-content-inventory.json')
assert context['rows']==oldcontext['rows'];current_names=set()
for scope in ['src','.build','node_modules','out','build']:
 for q in [R/scope,*(R/scope).rglob('*')]:current_names.add(q.relative_to(R).as_posix())
assert current_names=={x['path'] for x in context['rows']} and len(current_names)==119095
for x in context['rows']:assert {'path':x['path'],**meta(R/x['path'])}=={k:v for k,v in x.items() if k!='sha256'},x['path']
ext=readj(P/'external-reference-closure.json');assert ext['continuationDidNotResampleFull119095Or27318']
assert ext['fullContextMetadataSampleCapturedAtUtc']==context['capturedAtUtc']
external_entries=0
for g in ext['externalSymlinkTargets']:
 q=Path(g['target']);paths=[q,*q.rglob('*')] if q.exists() and q.is_dir() else [q] if q.exists() or q.is_symlink() else []
 assert {str(p) for p in paths}=={x['path'] for x in g['rows']}
 for x in g['rows']:assert {'path':x['path'],**meta(Path(x['path']))}=={k:v for k,v in x.items() if k!='sha256'},x['path']
 for alias in g['aliases']:assert meta(Path(alias['path']))==alias['metadata'] and str(Path(alias['path']).resolve())==g['target']
 external_entries+=len(paths)
assert external_entries==27318
for x in ext['directFileReferences']:
 q=Path(x['originalPath']);assert meta(q)==x['originalMetadata'] and q.stat().st_size==x['bytes'] and digest(q)==x['sha256'],str(q)
correction=readj(P/'terminal-reference-correction.json');assert correction['exactCorrectedOutputReferenceCount']==2
assert {x['originalPath'] for x in correction['corrections']}=={str(D/'phase2-continuation.stdout.raw'),str(D/'phase2-continuation.stderr.raw')}
for x in correction['corrections']:
 assert (P/x['originalInFlightCopyPath']).read_bytes()==b''
 terminal=Path(x['newTerminalRow']['originalPath']);b=terminal.read_bytes();assert (P/x['terminalCopyPath']).read_bytes()==b and len(b)==x['newTerminalRow']['bytes'] and sha(b)==x['newTerminalRow']['sha256'] and meta(terminal)==x['newTerminalRow']['originalMetadata']
 stable=next(v for v in ext['directFileReferences'] if v['originalPath']==str(terminal));assert stable==x['newTerminalRow']
archive=P/correction['originalInFlightClosure']['path'] if not Path(correction['originalInFlightClosure']['path']).is_absolute() else Path(correction['originalInFlightClosure']['path'])
assert sha(archive.read_bytes())==correction['originalInFlightClosure']['sha256']
oldext=readj(OLD/'external-reference-closure.json');seven=readj(P/'historical-document-reference-clarification.json')['records'];sevenpaths={x['currentPath'] for x in seven};assert len(sevenpaths)==7 and len(oldext['directFileReferences'])==295
for x in oldext['directFileReferences']:
 q=Path(x['originalPath'])
 if str(q) in sevenpaths:
  note=next(v for v in seven if v['currentPath']==str(q));name=q.relative_to(R).as_posix();b=q.read_bytes();assert b==git('show',H+':'+name) and len(b)==note['currentBytes'] and sha(b)==note['currentSha256'] and meta(q)==note['currentMetadata']
  h=git('show','c6ded6c918c4f69b0e89037e85b8f49ddc5512b4:'+name);assert h==(P/note['historicalExactCopyPath']).read_bytes() and sha(h)==x['sha256']
 else:assert meta(q)==x['originalMetadata'] and q.stat().st_size==x['bytes'] and digest(q)==x['sha256']
for n in ['dry-output-seals.json','execution-consumed.json','generated','dry','stages','runtime','stage-checker','stage-lint','business-report.json','source-checker-report.json','eslint-report.json']:assert not (P/n).exists()
for n in ['phase3-freeze.stdout.raw','phase3-freeze.stderr.raw','phase3-freeze.actual-result.json']:assert not (P/'preparation-evidence'/n).exists()
# The freezer has actually exited: only now bind its final raw streams/receipt.
terminal_freezer={}
for n in ['phase3-freeze.stdout.raw','phase3-freeze.stderr.raw','phase3-freeze.actual-result.json','static-assembly-phase3-freeze.py']:
 q=D/n;b=q.read_bytes();terminal_freezer[n]=dict(path=str(q),bytes=len(b),sha256=sha(b),metadata=meta(q))
assert json.loads((D/'phase3-freeze.stdout.raw').read_bytes())==anchor and readj(D/'phase3-freeze.actual-result.json')['actualExitCode']==0
assert readj(D/'phase2.actual-result.json')['actualExitCode']==1 and readj(D/'phase2-continuation.actual-result.json')['actualExitCode']==0 and readj(D/'phase3.actual-result.json')['actualExitCode']==2
capacities=resources();assert capacities['capacity']['sdd']['availableBytes']>=10200547328 and capacities['capacity']['sdd']['availableInodes']>=200000
assert inv['regularBytes']<=268435456
package_alloc=sum(q.lstat().st_blocks*512 for q in entries);review_entries=[D,*D.rglob('*')];review_bytes=sum(q.stat().st_size for q in review_entries if q.is_file());review_alloc=sum(q.lstat().st_blocks*512 for q in review_entries)
assert review_bytes<=268435456
report=dict(capturedAtUtc=now(),scope='Separate executor-owned final read-only whole-package verifier; no candidate import/parse/execution or syntax check. Historical seven-doc and exact two-terminal-output scopes independently verified.',workspaceHead=H,sourceTree=T,gitClean=True,runtimeSourcePublicationCommit=SRC,all13Fixed5fV3Exact=True,originalFreezePendingLabelPreserved=True,completeAuditAndInventoryExact=True,auditBytes=len(audit_raw),auditSha256=sha(audit_raw),inventoryBytes=len(inv_raw),inventorySha256=sha(inv_raw),packageTotalEntries=555,packageRegularFiles=438,packageDirectoriesIncludingRoot=117,packageRegularBytes=inv['regularBytes'],packageAllocatedBytesIncludingDirectories=package_alloc,all436PinsExactAndComplete=True,allFiles0444ExceptRelease0644AllDirectories0700=True,releaseInactiveExactOriginal=True,unactivatedFiveFields=dict(state=release['state'],executionAuthorized=release['executionAuthorized'],activationAuthorized=release['activationAuthorized'],authorizedBy=release['authorizedBy'],authorizationMessage=release['authorizationMessage']),invocations=0,original3238AndNineFresh931Combined4169Protected=True,currentEqualsE182Equals715RelevantDomain=True,zeroNewWritesOrCtimeDifferences=True,runtime715PredecessorNotE182=True,full119095ContextAnd27318ExternalMetadataPathsetsFinalReadOnlyExact=True,originalPhase2SamplingTimesPreserved=True,fullContextAndExternalContentRehashCount=0,sevenCurrent649BindingsAndHistoricalC6CopiesExact=True,other288OldRefsStrictExact=True,exactTwoContinuationTerminalMappingsAndOriginalInFlightSnapshotsExact=True,originalInFlightClosureArchivedAndPinned=True,sourceNativeManifestOnlyTwoFieldBoundaryFromIndependentStaticCheck=True,phase3FreezerTerminalCapturedOnlyAfterActualExit=terminal_freezer,ownPhase2Actual1AndContinuationActual0Preserved=True,ownWriterErrorAndMissingSourceActual2Preserved=True,noCurrentRuntimeStageDryOrConsumedArtifacts=True,noCurrentProducerOutputIncludedInPackage=True,reviewLogicalBytesAtSample=review_bytes,reviewAllocatedBytesAtSample=review_alloc,capacitiesAtFinalReadOnlySample=capacities,wholePackagePeer='PENDING_INDEPENDENT_ROOT_AND_ORIGINAL_ASTRA',executionAuthorized=False,activationAuthorized=False,candidateInvocations=0,syntaxCalls=0,lockProbePerformed=False,repoDocsOrCommitWritten=False,noNewModeOrAfterIConfiguration=True)
xjson(D/'final-read-only-verification.json',report);workspace();fsyncdir(D);print(json.dumps({'verified':True,'auditSha256':sha(audit_raw),'packageEntries':555,'regularFiles':438,'pins':436,'reviewBytes':review_bytes,'runtimeAuthorized':False}))
