"""Static preparation validation only; never imports or executes a runtime entry point."""
from pathlib import Path
import ast,builtins,datetime,hashlib,json,os,re,subprocess,symtable
ROOT=Path(__file__).resolve().parent.parent
sha=lambda value:hashlib.sha256(value).hexdigest()
read=lambda name:json.loads((ROOT/name).read_text())
def command(*args,cwd=None):
    result=subprocess.run(['rtk','proxy',*args],cwd=cwd,capture_output=True,text=True)
    assert result.returncode==0,result.stderr+result.stdout
    return result.stdout
checks=[]
for p in sorted(ROOT.rglob('*')):
    if not p.is_file() or p.name in ['static-validation.json','static-preparation-manifest.json']:continue
    rel=str(p.relative_to(ROOT))
    if p.suffix=='.py':
        ast.parse(p.read_text(),filename=str(p));table=symtable.symtable(p.read_text(),str(p),'exec')
        known=set(dir(builtins))|{'__file__','__name__','__package__'}|{s.get_name()for s in table.get_symbols()if s.is_assigned()or s.is_imported()or s.is_parameter()}
        def visit(t):
            for symbol in t.get_symbols():
                assert not (symbol.is_referenced()and symbol.is_global()and symbol.get_name()not in known),(rel,t.get_name(),symbol.get_name())
            for child in t.get_children():visit(child)
        visit(table);checks.append({'path':rel,'kind':'python-ast-and-symtable','syntaxPassed':True,'unresolvedGlobalNames':[]})
    elif p.suffix in ['.js','.cjs']:
        command('node','--check',str(p));checks.append({'path':rel,'kind':'node-syntax','syntaxPassed':True})
    elif p.suffix=='.json':
        json.loads(p.read_text());checks.append({'path':rel,'kind':'json-parse','syntaxPassed':True})
config=read('run-config.json');contract=read('contract.json');membership=read('candidate-asset-membership.json');repo=config['runtimeRepo']
assert config['sourceCandidate']==contract['sourceCandidate']==membership['sourceCandidate']
assert config['candidateSourceTree']==contract['candidateSourceTree']==membership['candidateSourceTree']==command('git','rev-parse',config['sourceCandidate']+':src',cwd=repo).strip()
assert contract['requiredCommonPaths']==membership['proposedCommonPaths'] and set(contract['requiredFullPaths'])==set(membership['proposedFullPaths'])|set(contract['allowedTargetedTestPaths'])
assert contract['schemaVersion']==4 and contract['fullCompileOfFinalSourceTree']is False and len(contract['allowedTargetedTestPaths'])==2
assert len(contract['requiredCommonPaths'])==contract['minimumCommonAssets']==membership['proposedCommonMinimum']==138
assert len(contract['requiredFullPaths'])==contract['minimumFullAssets']==248 and membership['proposedFullMinimum']==246
assert len(contract['changedTests'])==2 and all(x['path']in contract['requiredFullPaths']for x in contract['changedTests'])
assert len(contract['mandatoryGateFixProduction'])==4 and all(x['path']in contract['mustObserveRenderer']for x in contract['mandatoryGateFixProduction'])
assert membership['actualNativeHashesRead']is False and membership['actualFrozenSourceHead']is None and membership['actualProducer']is None
for name in ['common/freeze-J.template.json','common/freeze-E.template.json','common/full-freeze.template.json']:
    template=read(name);assert template['outFrozen']is False
    for key in ['sourceHead','sourceTree','finalSourceHead','finalSourceTree']:assert template[key]is None
    assert template['freezeSchemaVersion']==4 and template['fullCompileOfFinalSourceTree']is False
    assert not any(key in template for key in ['nativeProducer','nativeCompileOrdinal','nativeCompileExitCode'])
    assert template['lineage']['fullCompileOfFinalSourceTree']is False
    assert all(value is None for value in template['lineage']['latestFullCompile'].values())
    emitter=template['lineage']['targetedTestsEmitter'];assert all(value is None for key,value in emitter.items()if key!='outputPaths')and emitter['outputPaths']==contract['allowedTargetedTestPaths']
    assert all(all(row[key]is None for key in ['sha256','sourceSha256','sourceBlob','sourceMode','nativeMode','provenanceRef'])for row in template['outputs'])
for phase in ['J','E']:
    auth=read(phase+'/execution-authorization.template.json');assert auth['authorized']is False and auth['allowLaunch']is False and auth['allowControlledFakeUds']is False
    assert auth['freezeSchemaVersion']==4 and auth['finalSourceHead']is None and auth['finalSourceTree']is None and auth['lineageSha256']is None and auth['fullCompileOfFinalSourceTree']is False
    assert not any(key in auth for key in ['nativeProducer','nativeCompileOrdinal','nativeCompileExitCode'])
    assert (ROOT/phase/'empty-shared').is_dir() and not list((ROOT/phase/'empty-shared').iterdir())
    assert (ROOT/phase/'empty-seed/User/settings.json').is_file()
actualFiles=['common/freeze-J.json','common/freeze-E.json','common/full-freeze.json','common/lane-provenance.json','J/execution-authorization.json','E/execution-authorization.json','J/phase-complete.json']
for phase in ['J','E']:
    actualFiles.extend(phase+'/'+name for name in ['launch.json','lease.json','probe.json','main-runtime.json','main-runtime-before-fake.json','server-started.json','assertions.json','case-results.jsonl','disconnect-negative-result.json','grpc-full-lifetime-summary.json','cleanup.json'])
assert not any((ROOT/name).exists()for name in actualFiles),'Actual runtime artifacts must not be precreated'
assert not any(p.suffix in ['.log','.jsonl','.png','.pyc']or p.name=='__pycache__' for p in ROOT.rglob('*'))
actions=read('J/actions.template.json')['actions'];assert len(actions)==67 and len({a['label']for a in actions})==67
assert any(a['type']=='conversationPreviewButton'for a in actions) and not any('group'in a for a in actions)
jmatrix=read('J/matrix.template.json');ematrix=read('E/matrix.template.json')
assert len(jmatrix['cases'])==18 and all(row['status']=='NOT_RUN'for row in jmatrix['cases'])
assert sum(row['state']=='NOT_RUN'for row in ematrix['cases'])==8 and sum(row['state']=='BOUNDARY'for row in ematrix['cases'])==1
script=(ROOT/'E/fake-uds-engine.cjs').read_text();pairs=re.findall(r"(?:unary|add)\('([^']+)', '([^']+)'",script)
assert pairs==[tuple(p)for p in contract['fakeRpcSurface']['registrationPairs']] and len(pairs)==13
assert contract['fakeRpcSurface']['methodsDeclaration']in script and contract['fakeRpcSurface']['advertisedCount']==12
assert not any(method in ['GetQueue','SaveSkillContent']for _,method in pairs)
assert not re.search(r"activeGroup['\"]?\]?\s*==\s*(?:8|9|10)\b",(ROOT/'J/assert-observations.py').read_text())
assert not any(needle in (ROOT/'common/collect-runtime-assets.cjs').read_text()for needle in ['m01Required','jnotice','compile8'])
finalScript=(ROOT/'E/run-final-disconnect.py').read_text()
assert all(text in finalScript for text in ["len(cached)==3","len(panes)==2","len(set(groupIds))==2","len(timeline)==3","same(afterTarget,baseline)","responseControl","absenceBoundary"])
assert "bool(baseline['cachedModelTurns'])"not in finalScript
assert "--runtime-context"in(ROOT/'common/gate.cjs').read_text()and "lineage_records"in(ROOT/'common/gates.py').read_text()
assert not any(key in read('common/lane-provenance.template.json')for key in ['nativeProducer','nativeCompileOrdinal','nativeCompileExitCode'])
for row in read('static-script-origins.json'):
    if not (ROOT/row['to']).exists():assert row.get('replacement')and(ROOT/row['replacement']).is_file()and'REMOVED'in row['status']
# ESLint reads source text only. No generated or product module is loaded.
lintScript="""const fs=require('node:fs'),path=require('node:path');const{Linter}=require(path.join(process.argv[2],'node_modules/eslint'));const root=process.argv[3],linter=new Linter(),globals=Object.fromEntries(['require','module','exports','__dirname','__filename','Buffer','process','setTimeout','setInterval','clearTimeout','clearInterval','console','fetch','WebSocket','URL','window','document','location','innerWidth','innerHeight','getComputedStyle','CSSStyleSheet','CSSRule','navigator','performance'].map(n=>[n,'readonly']));const findings=[];let files=0;function scan(dir){for(const item of fs.readdirSync(dir,{withFileTypes:true})){const file=path.join(dir,item.name);if(item.isDirectory())scan(file);else if(/\.(cjs|js)$/.test(file)){files++;for(const m of linter.verify(fs.readFileSync(file,'utf8'),{languageOptions:{ecmaVersion:'latest',sourceType:'commonjs',globals},rules:{'no-undef':'error'}},{filename:file}))findings.push({path:path.relative(root,file),line:m.line,column:m.column,message:m.message,rule:m.ruleId});}}}scan(root);console.log(JSON.stringify({files,findings}));"""
r=subprocess.run(['rtk','proxy','node','-',repo,str(ROOT)],input=lintScript,capture_output=True,text=True);assert r.returncode==0,r.stderr;jsNames=json.loads(r.stdout);assert not jsNames['findings'],jsNames['findings']
homes={}
for phase,previous in read('empty-homes-preparation.json')['homes'].items():
    p=Path(config['engineHomes'][phase]);st=p.lstat();assert p.is_dir()and not p.is_symlink()and st.st_uid==os.getuid()and st.st_mode&0o777==0o700 and st.st_ino==previous['inode']and not list(p.iterdir())
    homes[phase]={'path':str(p),'uid':st.st_uid,'inode':st.st_ino,'mode':'0o700','empty':True,'socketAbsent':not(p/'server.sock').exists(),'lockAbsent':not(p/'server.lock').exists()}
seals=[]
for row in read('old-seals-preservation.json')['files']:
    digest=sha(Path(row['path']).read_bytes());assert digest==row['sha256'];seals.append({'path':row['path'],'expectedSha256':row['sha256'],'actualSha256':digest,'byteUnchanged':True})
history=ROOT.parent/'sources-e-gate-after-20261027-r3-static-v1-sealed';historySeal=history/'historical-static-seal.json'
assert sha(historySeal.read_bytes())=='b62452b02e082334347ba4bc9800a3c29bb3074096ec96e262f46735391187bb'
historyData=json.loads(historySeal.read_text());assert historyData['memberCount']==59
assert all((history/row['path']).stat().st_size==row['bytes']and sha((history/row['path']).read_bytes())==row['sha256']for row in historyData['members'])
assert sha((history/'static-preparation-manifest.json').read_bytes())=='66f9c707e770e9f0d22ca6bbbaff20a613d93abfbc807b317adc7dafaf81cb37'
assert sha((history/'static-validation.json').read_bytes())=='c17d79861f451ca5fb7995b844ed2c098a63ee7ccf60bccf4068b13899a44e2a'
status=command('git','status','--porcelain','--untracked-files=no',cwd=ROOT.parents[1]);assert not status.strip(),'Tracked worktree must remain clean'
validation={'runId':config['runId'],'state':'STATIC_VALIDATED_RUNTIME_NOT_AUTHORIZED','checkedAt':datetime.datetime.now(datetime.timezone.utc).isoformat(),'runtimeStarted':False,'validationScope':'AST/JSON/node --check/ESLint no-undef/Python symtable and static contracts only; no target script import, business test, compile, transpile, native hash read or UI/fake launch','files':checks,'counts':{kind:sum(row['kind']==kind for row in checks)for kind in ['python-ast-and-symtable','node-syntax','json-parse']},'jsStaticNames':jsNames,'structuralChecks':{'candidateMembershipAndTwoRefreshRequirementsAligned':True,'v4MixedLineageWithoutScalarProducer':True,'fullCompileOfFinalSourceTree':False,'bothOriginalChangedTestsAndTwoRefreshedTestsInFull':True,'strictThreeTargetsAndTwoActualPanes':True,'fourChangedProductionRequireActualRendererEvidence':True,'dynamicGroupIds':True,'actualRuntimeAndAuthorizationArtifactsAbsent':True,'J18AndE8PlusBoundaryRemainNotRun':True,'fakeAdvertisements':12,'fakeRegisteredHandlers':13,'noQueueSkillWildcardHandler':True,'templatesHaveNoFrozenHashes':True},'staticCorrections':['V4 per-file compile10/targeted-test lineage with actual raw/pair/blob/hash/mode validation; no scalar whole-final-tree producer','Historical J helper green limited to exact declared inputs; new10 compile10 input mapping and complete refreshed Lens suites kept separate','Final disconnect requires exactly three cached targets and two distinct real Pane/groups with three target timelines before complete state equality','Original59 static files preserved and verified independently before active preparation changes'],'emptyHomes':homes,'oldSealChecks':seals,'historicalStaticV1':{'root':str(history),'sealSha256':sha(historySeal.read_bytes()),'memberCount':59,'allMemberBytesAndShaVerified':True,'originalManifestSha256':historyData['originalManifestSha256']},'trackedGitStatus':status,'currentOutRead':False,'sourceOrOutMutated':False}
(ROOT/'static-validation.json').write_text(json.dumps(validation,indent=2)+'\n')
files=[{'path':str(p.relative_to(ROOT)),'bytes':p.stat().st_size,'sha256':sha(p.read_bytes())}for p in sorted(ROOT.rglob('*'))if p.is_file()and p.name!='static-preparation-manifest.json']
pending=read('pending-inputs.json')
manifest={'runId':config['runId'],'state':'STATIC_READY_RUNTIME_NOT_AUTHORIZED','runtimeStarted':False,'preparedIn':config['preparedIn'],'runtimeRepo':repo,'sourceCandidate':config['sourceCandidate'],'candidateSourceTree':config['candidateSourceTree'],'candidateIsNotFrozenSource':True,'entry':'RUN-ENTRY.md','staticValidation':'static-validation.json','staticValidationSha256':sha((ROOT/'static-validation.json').read_bytes()),'minimumCommonAssets':138,'minimumFullAssets':248,'staticGraphMinimumFullAssets':246,'schemaVersion':4,'fullCompileOfFinalSourceTree':False,'explicitActualSupersetsAllowed':True,'pendingActualInputs':pending['requiredActualFiles'],'actualFrozenSourceHead':None,'actualFrozenSourceTree':None,'actualMixedLineage':None,'actualFreezeHashes':None,'noActualAuthorizationOrFreezeOrLaunchOrCompletion':True,'noCurrentOutReadOrRuntimeOrBusinessTestOrCompileOrTranspile':True,'oldSealsByteUnchanged':True,'oldSealCount':len(seals),'historicalStaticV1':validation['historicalStaticV1'],'emptyHomes':homes,'trackedWorktreeClean':True,'fileCountExcludingSelf':len(files),'files':files,'manifestSelfExcludedToAvoidRecursiveDigest':True,'allPassOrPhaseCompletionPrecreated':False}
target=ROOT/'static-preparation-manifest.json';target.write_text(json.dumps(manifest,indent=2)+'\n')
print(json.dumps({'state':manifest['state'],'manifest':str(target),'manifestSha256':sha(target.read_bytes()),'staticValidationSha256':manifest['staticValidationSha256'],'scriptAndJsonCounts':validation['counts'],'allJsNoUndef':not jsNames['findings'],'filesExcludingManifest':len(files),'oldSealsUnchanged':len(seals),'commonMinimum':138,'fullMinimum':248,'staticGraphFullMinimum':246,'historicalStaticV1SealSha256':sha(historySeal.read_bytes()),'runtimeStarted':False,'trackedClean':True}))
