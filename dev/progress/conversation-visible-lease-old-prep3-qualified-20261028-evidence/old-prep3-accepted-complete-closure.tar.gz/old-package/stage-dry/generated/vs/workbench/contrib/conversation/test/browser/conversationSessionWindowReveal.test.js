import assert from "assert";
import { Dimension, getActiveElement } from "../../../../../base/browser/dom.js";
import { mainWindow } from "../../../../../base/browser/window.js";
import { DeferredPromise, raceTimeout, timeout } from "../../../../../base/common/async.js";
import { errorHandler, getErrorMessage, setUnexpectedErrorHandler } from "../../../../../base/common/errors.js";
import { Emitter, Event } from "../../../../../base/common/event.js";
import { Disposable, toDisposable } from "../../../../../base/common/lifecycle.js";
import { ensureNoDisposablesAreLeakedInTestSuite } from "../../../../../base/test/common/utils.js";
import { SyncDescriptor } from "../../../../../platform/instantiation/common/descriptors.js";
import { ILogService, NullLogService } from "../../../../../platform/log/common/log.js";
import { TestConfigurationService } from "../../../../../platform/configuration/test/common/testConfigurationService.js";
import { Registry } from "../../../../../platform/registry/common/platform.js";
import { ConversationPart, IConversationPartService } from "../../../../browser/parts/conversation/conversationPart.js";
import { IEditorGroupsService } from "../../../../services/editor/common/editorGroupsService.js";
import { EditorService } from "../../../../services/editor/browser/editorService.js";
import { IEditorService } from "../../../../services/editor/common/editorService.js";
import { EditorExtensions } from "../../../../common/editor.js";
import { createEditorParts, registerTestEditor, TestFileEditorInput, workbenchInstantiationService } from "../../../../test/browser/workbenchTestServices.js";
import { SideBySideEditorInput } from "../../../../common/editor/sideBySideEditorInput.js";
import "../../browser/conversationEditor.contribution.js";
import { ConversationEditorPane } from "../../browser/conversationEditorPane.js";
import { ConversationSessionChatContribution } from "../../browser/conversationSessionChat.contribution.js";
import { ConversationNavigationContribution } from "../../browser/conversationNavigation.contribution.js";
import { ConversationNavigationService, IConversationNavigationService } from "../../browser/conversationNavigationService.js";
import { ConversationSessionChatService, IConversationSessionChatService } from "../../browser/conversationSessionChatService.js";
import { switchToSession as switchToSessionHelper } from "../../browser/conversationLensSessionBar.js";
import { ConversationSessionWindowService, IConversationSessionWindowService } from "../../browser/conversationSessionWindowService.js";
import { ConversationStubService, IConversationRosterService } from "../../browser/conversationStubService.js";
import { ConversationWorkRootMountModel, IConversationWorkRootMount } from "../../browser/conversationWorkRootMount.js";
import { IConversationTimelineRevealService } from "../../browser/conversationTimelineRevealService.js";
import { IConversationReviewNavService } from "../../browser/conversationReviewEntry.js";
import { ConversationEngineRosterService, ENGINE_BIND_FAILED_SESSION_ID, isEngineRosterPlaceholderSessionId } from "../../browser/conversationEngineRosterService.js";
import { getConversationSessionReadiness } from "../../browser/conversationSessionAvailability.js";
import { isConversationEngineLive, isConversationPairingHold } from "../../browser/conversationSessionStatus.js";
import { stubTurnsToSnapshot } from "../../browser/conversationSessionView.js";
import { ConversationEditorPaneId, conversationSessionLeafHiddenClass } from "../../common/conversationSessionWindow.js";
import { UA_CLIENT_CHAT_INPUT_AUTO_FOCUS } from "../../common/uaClientSettingsKeys.js";
import { IUniverseAgentConnection } from "../../../../../platform/universeAgent/common/universeAgentConnection.js";
import { ConversationChatInput, getConversationChatResource } from "../../common/conversationChatInput.js";
import { createConversationConnectionTestStub } from "../common/conversationConnectionTestStub.js";
import { stubConversationTimelineLinkServices } from "./conversationTimelineLinkTestStubs.js";
import { installConversationLensResizeObserverHarness } from "./conversationLensLayoutHarness.js";
import { IExplorerService } from "../../../files/browser/files.js";
import { ISCMService } from "../../../scm/common/scm.js";
class QuietRosterService extends ConversationStubService {
  seedSessionQuietly() {
    const previous = this.model.getActiveSessionId();
    const sessionId = this.model.createSession();
    this.model.switchSession(previous);
    this._onDidChangeSession.fire(sessionId);
    return sessionId;
  }
  fireActiveSession(sessionId) {
    this._onDidChangeActiveSession.fire(sessionId);
  }
  fireDeletedSession(sessionId) {
    this._onDidDeleteSession.fire(sessionId);
  }
}
class RevealEngineSessionView extends Disposable {
  constructor() {
    super(...arguments);
    this.acquired = [];
    this.released = /* @__PURE__ */ new Set();
    this.emitters = /* @__PURE__ */ new Map();
    this.versions = /* @__PURE__ */ new Map();
    this.listening = /* @__PURE__ */ new Set();
    this.didListen = this._register(new Emitter());
    this.onDidListen = this.didListen.event;
  }
  onDynamicDidApplyFrame(leaseId) {
    let emitter = this.emitters.get(leaseId);
    if (!emitter) {
      emitter = this._register(new Emitter({
        onDidAddFirstListener: () => queueMicrotask(() => {
          this.emitLease(leaseId);
          this.listening.add(leaseId);
          this.didListen.fire(leaseId);
        })
      }));
      this.emitters.set(leaseId, emitter);
    }
    return emitter.event;
  }
  async acquireLease(sessionId) {
    const leaseId = `reveal:${sessionId}:${this.acquired.length + 1}`;
    this.acquired.push({ leaseId, sessionId });
    return leaseId;
  }
  async whenEngineSessionReady(sessionId) {
    return sessionId;
  }
  async releaseLease(leaseId) {
    this.released.add(leaseId);
  }
  async post() {
    throw new Error("lease recovery must not write");
  }
  async requestResync() {
  }
  async acknowledge() {
  }
  async requestDetail() {
    return { ok: false, reason: "unavailable" };
  }
  hasSessionListener(sessionId) {
    return this.acquired.some((lease) => lease.sessionId === sessionId && this.listening.has(lease.leaseId) && !this.released.has(lease.leaseId));
  }
  emitSession(sessionId, text) {
    for (const lease of this.acquired) {
      if (lease.sessionId === sessionId) {
        this.emitLease(lease.leaseId, text);
      }
    }
  }
  emitLease(leaseId, text) {
    const lease = this.acquired.find((candidate) => candidate.leaseId === leaseId);
    if (!lease || this.released.has(leaseId)) {
      return;
    }
    const projection = stubTurnsToSnapshot(lease.sessionId, text === void 0 ? [] : [
      { id: `${lease.sessionId}-body`, kind: "user", text },
      { id: `${lease.sessionId}-permission`, kind: "confirmation", text: `Permission for ${lease.sessionId}`, status: "pending" }
    ]);
    const version = (this.versions.get(leaseId) ?? 0) + 1;
    this.versions.set(leaseId, version);
    this.emitters.get(leaseId)?.fire({
      leaseId,
      sessionId: lease.sessionId,
      applied: { kind: "baseline" },
      frame: {
        frame: { leaseId, generation: 1, frameId: version, version, body: { kind: "baseline", snapshot: { ...projection.snapshot, sync: { kind: "live" } } } },
        attribution: [...projection.attribution].map(([itemId, attribution]) => ({ op: "upsertAttribution", itemId, attribution }))
      }
    });
  }
}
suite("Conversation session window reveal + leaf SessionBar (C)", () => {
  const TEST_EDITOR_ID = "MyFileEditorForConversationReveal";
  const TEST_EDITOR_INPUT_ID = "testEditorInputForConversationReveal";
  installConversationLensResizeObserverHarness();
  const store = ensureNoDisposablesAreLeakedInTestSuite();
  const disposables = store;
  teardown(async () => {
    await new Promise((resolve) => mainWindow.requestAnimationFrame(() => mainWindow.requestAnimationFrame(() => resolve())));
  });
  setup(function() {
    this.timeout(2e4);
    store.add(registerTestEditor(TEST_EDITOR_ID, [new SyncDescriptor(TestFileEditorInput), new SyncDescriptor(SideBySideEditorInput)], TEST_EDITOR_INPUT_ID));
  });
  function layoutParts(parts) {
    for (const part of parts.conversationParts) {
      part.layout(800, 600, 0, 0);
    }
  }
  function trackEditors(parts) {
    for (const part of parts.conversationParts) {
      for (const editor of part.activeGroup.editors) {
        store.add(editor);
      }
    }
  }
  async function waitForPane(part, openErrors = [], parts) {
    await part.whenReady;
    const deadline = Date.now() + 3e3;
    while (Date.now() < deadline) {
      const pane = part.activeGroup.activeEditorPane;
      if (pane instanceof ConversationEditorPane) {
        if (parts) {
          trackEditors(parts);
        }
        return pane;
      }
      await timeout(20);
    }
    const detail = openErrors.map((error) => error instanceof Error ? error.stack ?? error.message : String(error)).join("\n");
    throw new Error(`ConversationEditorPane not ready for ${part.sessionKey}; got ${part.activeGroup.activeEditorPane?.getId()}${detail ? `
${detail}` : ""}`);
  }
  function partFor(parts, sessionKey) {
    const part = parts.conversationParts.find((candidate) => candidate.sessionKey === sessionKey);
    assert.ok(part, `missing part ${sessionKey}`);
    return part;
  }
  function visibleLeafKeys(windowService) {
    return [...windowService.getVisibleSessionKeys()];
  }
  function hideButton(windowService, sessionKey) {
    return windowService.getLeafSlots(sessionKey)?.sessionBar.querySelector(".conversation-session-leaf-hide");
  }
  async function assertWarnThenRethrowDoesNotLeak(paintBoom, run) {
    const unexpectedWarns = [];
    const unhandledRejections = [];
    const onUnhandledRejection = (reason) => unhandledRejections.push(reason);
    process.on("unhandledRejection", onUnhandledRejection);
    const originalErrorHandler = errorHandler.getUnexpectedErrorHandler();
    setUnexpectedErrorHandler((error) => {
      unexpectedWarns.push(error);
      if (unexpectedWarns.length === 1) {
        throw error;
      }
    });
    try {
      await run();
      await timeout(0);
      assert.deepStrictEqual({ unhandledRejections, unexpectedWarns }, {
        unhandledRejections: [],
        unexpectedWarns: [paintBoom, paintBoom]
      });
    } finally {
      setUnexpectedErrorHandler(originalErrorHandler);
      process.off("unhandledRejection", onUnhandledRejection);
    }
  }
  function createLightweightWindowHarness(options) {
    const rosterService = store.add(new QuietRosterService());
    const gridHost = document.createElement("div");
    document.body.appendChild(gridHost);
    store.add({ dispose: () => gridHost.remove() });
    const onDidCreateSlots = new Emitter();
    store.add(onDidCreateSlots);
    let throwOnCreate = false;
    let rejectWhenReady = false;
    const conversationParts = [];
    const editorGroupsService = {
      createConversationEditorPart: (_parent, sessionKey) => {
        if (throwOnCreate) {
          throw new Error("reveal boom");
        }
        let whenReady = Promise.resolve();
        if (rejectWhenReady) {
          const rejected = Promise.reject(new Error("whenReady boom"));
          void rejected.catch(() => {
          });
          whenReady = rejected;
        }
        const part = { sessionKey, whenReady, activeGroup: { focus: () => {
        }, activeEditorPane: { getId: () => ConversationEditorPaneId } } };
        conversationParts.push(part);
        return part;
      },
      disposeConversationEditorPart: (sessionKey) => {
        const index = conversationParts.findIndex((part) => part.sessionKey === sessionKey);
        if (index >= 0) {
          conversationParts.splice(index, 1);
        }
      },
      setFocusedConversationLeaf: () => {
      },
      getFocusedConversationLeaf: () => void 0,
      get conversationParts() {
        return conversationParts;
      }
    };
    let onNotifyError;
    const sessionWindowService = store.add(new ConversationSessionWindowService(
      {
        onDidCreateSlots: onDidCreateSlots.event,
        onDidFocus: Event.None,
        getSlots: () => options?.delaySlots ? void 0 : { sessionBar: document.createElement("div"), sessionWindowGrid: gridHost, editorPartHost: void 0 },
        setFocusedLeafContainer: () => {
        },
        focus: () => {
        }
      },
      editorGroupsService,
      rosterService,
      new NullLogService(),
      {
        error: (message) => {
          onNotifyError?.(message);
        }
      }
    ));
    return {
      sessionWindowService,
      rosterService,
      conversationParts,
      setThrowOnCreate(value) {
        throwOnCreate = value;
      },
      setRejectWhenReady(value) {
        rejectWhenReady = value;
      },
      setNotifyError(handler) {
        onNotifyError = handler;
      },
      attachSlots() {
        onDidCreateSlots.fire({
          sessionBar: document.createElement("div"),
          sessionWindowGrid: gridHost,
          editorPartHost: void 0
        });
      }
    };
  }
  async function collectLeafConversationLenses(part) {
    const group = part.activeGroup;
    const lenses = [];
    for (const editor of group.editors) {
      await group.openEditor(editor);
      const pane = group.activeEditorPane;
      assert.ok(pane instanceof ConversationEditorPane, `missing ConversationEditorPane for ${editor.resource}`);
      const lens = pane.activeConversationLens;
      assert.ok(lens, `each conversation tab must expose a ConversationLens (${editor.resource})`);
      lenses.push(lens);
    }
    return lenses;
  }
  function countLeafChrome(windowService, conversationPart) {
    let bars = 0;
    let navs = 0;
    for (const key of windowService.getVisibleSessionKeys()) {
      const leaf = windowService.getLeafSlots(key);
      assert.ok(leaf);
      bars += leaf.container.querySelectorAll(".conversation-lens-session-bar").length;
      navs += leaf.container.querySelectorAll(".conversation-window-nav").length;
    }
    const partSlotBars = conversationPart.getSlots()?.sessionBar.querySelectorAll(".conversation-lens-session-bar").length ?? 0;
    return { bars, navs, partSlotBars };
  }
  function stubLensRuntimeServices(instantiationService) {
    instantiationService.stub(IConversationWorkRootMount, store.add(new ConversationWorkRootMountModel()));
    instantiationService.stub(IConversationTimelineRevealService, {
      _serviceBrand: void 0,
      registerLens: () => ({ dispose: () => {
      } }),
      revealItem: () => {
      },
      getAccessibleTurnContent: () => void 0,
      focusAccessibleTurn: () => {
      },
      scrollToFirstPendingConfirmation: () => {
      }
    });
    instantiationService.stub(IConversationReviewNavService, {
      _serviceBrand: void 0,
      onDidChange: Event.None,
      getReviewNavForSession: () => []
    });
    instantiationService.stub(IExplorerService, {
      _serviceBrand: void 0,
      select: async () => {
      }
    });
    instantiationService.stub(ISCMService, {
      _serviceBrand: void 0,
      get repositories() {
        return [];
      },
      get repositoryCount() {
        return 0;
      },
      onDidAddRepository: Event.None,
      onDidRemoveRepository: Event.None,
      registerSCMProvider: () => {
        throw new Error("not implemented");
      },
      getRepository: () => void 0
    });
  }
  async function createRevealHarness() {
    return createRevealHarnessWithRoster(store.add(new QuietRosterService()), createConversationConnectionTestStub());
  }
  async function createRevealHarnessWithRoster(rosterService, connection, engine = false) {
    const openErrors = [];
    const instantiationService = workbenchInstantiationService({
      configurationService: () => new TestConfigurationService({
        workbench: { editor: { enablePreview: false } },
        [UA_CLIENT_CHAT_INPUT_AUTO_FOCUS]: false
      })
    }, store);
    instantiationService.stub(ILogService, {
      error: (error) => {
        openErrors.push(error);
      },
      warn: () => {
      },
      info: () => {
      },
      trace: () => {
      },
      debug: () => {
      },
      flush: () => {
      },
      getLevel: () => 0,
      setLevel: () => {
      },
      onDidChangeLogLevel: Event.None
    });
    instantiationService.stub(IConversationRosterService, rosterService);
    instantiationService.stub(IUniverseAgentConnection, connection);
    stubLensRuntimeServices(instantiationService);
    stubConversationTimelineLinkServices(instantiationService);
    instantiationService.invokeFunction((accessor) => Registry.as(EditorExtensions.EditorFactory).start(accessor));
    const parts = await createEditorParts(instantiationService, disposables);
    store.add(parts);
    instantiationService.stub(IEditorGroupsService, parts);
    const editorService = disposables.add(instantiationService.createInstance(EditorService, void 0));
    instantiationService.stub(IEditorService, editorService);
    const conversationPart = store.add(instantiationService.createInstance(ConversationPart));
    const parent = document.createElement("div");
    document.body.appendChild(parent);
    store.add({ dispose: () => parent.remove() });
    conversationPart.create(parent);
    instantiationService.stub(IConversationPartService, conversationPart);
    const sessionChatService = disposables.add(instantiationService.createInstance(ConversationSessionChatService));
    instantiationService.stub(IConversationSessionChatService, sessionChatService);
    const sessionWindowService = disposables.add(instantiationService.createInstance(ConversationSessionWindowService));
    instantiationService.stub(IConversationSessionWindowService, sessionWindowService);
    const navigationService = disposables.add(instantiationService.createInstance(ConversationNavigationService));
    instantiationService.stub(IConversationNavigationService, navigationService);
    store.add(instantiationService.createInstance(ConversationSessionChatContribution));
    store.add(instantiationService.createInstance(ConversationNavigationContribution));
    const primaryId = rosterService.getActiveSessionId();
    await sessionWindowService.ensurePrimaryWindow(primaryId);
    const primaryPart = partFor(parts, primaryId);
    if (engine) {
      await waitForEnginePane(primaryPart, openErrors);
    } else {
      await waitForPane(primaryPart, openErrors, parts);
    }
    layoutParts(parts);
    trackEditors(parts);
    return { instantiationService, editorService, parts, conversationPart, rosterService, sessionWindowService, sessionChatService, primaryId, openErrors };
  }
  async function bounded(promise, message) {
    const result = await raceTimeout(promise.then((value) => ({ value })), 3e3);
    assert.ok(result, message);
    return result.value;
  }
  async function waitForEnginePane(part, openErrors = []) {
    try {
      await bounded(part.whenReady, "engine leaf part must become ready");
      if (!(part.activeGroup.activeEditorPane instanceof ConversationEditorPane)) {
        const ready = Event.toPromise(Event.filter(
          part.activeGroup.onDidActiveEditorChange,
          () => part.activeGroup.activeEditorPane instanceof ConversationEditorPane
        ));
        try {
          await bounded(ready, "real engine ConversationEditorPane must open");
        } finally {
          ready.cancel();
        }
      }
      const pane = part.activeGroup.activeEditorPane;
      assert.ok(pane instanceof ConversationEditorPane);
      return pane;
    } catch (error) {
      try {
        if (error instanceof Error) {
          const originalStack = error.stack;
          const group = part.activeGroup;
          const activeEditor = group.activeEditor;
          const activePane = group.activeEditorPane;
          const diagnostics = JSON.stringify({
            part: { windowId: part.windowId, sessionKey: part.sessionKey },
            groupId: group.id,
            activeEditorResource: activeEditor?.resource?.toString() ?? null,
            activePaneId: activePane?.getId() ?? null,
            activePaneIsConversationEditorPane: activePane instanceof ConversationEditorPane,
            openErrors: openErrors.map((openError) => openError instanceof Error ? { type: openError.name, message: openError.message, stack: openError.stack ?? null } : { type: typeof openError, message: String(openError), stack: null })
          }, null, 2);
          Object.defineProperty(error, "stack", {
            value: `${originalStack ?? `${error.name}: ${error.message}`}
Engine Pane setup diagnostics: ${diagnostics}`
          });
        }
      } catch {
      }
      throw error;
    }
  }
  async function createEngineRevealHarness(beforePane) {
    const requests = [];
    const allRequests = [];
    let phase = { kind: "disconnected" };
    let pairingPending = false;
    const connectionEmitter = store.add(new Emitter());
    const base = createConversationConnectionTestStub();
    const connection = createConversationConnectionTestStub({
      isEngineConnected: () => isConversationEngineLive(phase, pairingPending),
      getConnectionPhase: () => phase,
      getTransportState: () => "ok",
      getConnectionSnapshot: () => ({ ...base.getConnectionSnapshot(), transport: "ok", channelAlive: phase.kind !== "disconnected", pairingPending, engineIdentityId: "reveal-engine", linkId: 1 }),
      onDidChangeConnection: connectionEmitter.event,
      listSessions: () => {
        const request = requests.shift();
        assert.ok(request, "every real catalog request must have an explicit Deferred");
        void request.started.complete();
        return request.result.p;
      }
    });
    const sessionView = store.add(new RevealEngineSessionView());
    const rosterService = store.add(new ConversationEngineRosterService(connection, sessionView, { _serviceBrand: void 0, shouldAdvertise: () => true }));
    store.add(toDisposable(() => {
      for (const request of allRequests) {
        if (!request.result.isSettled) {
          void request.result.complete({ sessions: [] });
        }
      }
    }));
    const deferCatalog = () => {
      const request = { started: new DeferredPromise(), result: new DeferredPromise() };
      requests.push(request);
      allRequests.push(request);
      return request;
    };
    const notify = (kind) => {
      pairingPending = kind === "connected pairing" || kind === "connecting pairing";
      phase = kind === "disconnected" ? { kind: "disconnected" } : kind === "connecting pairing" ? { kind: "connecting", reason: "initial" } : { kind: "connected", path: "loopback" };
      connectionEmitter.fire(connection.getConnectionSnapshot());
    };
    const catalog = { sessions: [{ sessionId: "lease-s1", title: "Lease s1" }, { sessionId: "lease-s2", title: "Lease s2" }] };
    const initial = deferCatalog();
    notify("live");
    await bounded(initial.started.p, "initial real catalog must start");
    await initial.result.complete(catalog);
    await bounded(rosterService.whenEngineCatalogRefreshComplete(), "initial real catalog must finish");
    assert.strictEqual(getConversationSessionReadiness(rosterService), "ready");
    beforePane?.(rosterService);
    const harness = await createRevealHarnessWithRoster(rosterService, connection, true);
    const pane = await waitForEnginePane(partFor(harness.parts, harness.primaryId), harness.openErrors);
    const lens = pane.activeConversationLens;
    assert.ok(lens);
    assert.ok(lens.sessionViewLease, "initial real visible owner must have a lease");
    if (lens.sessionViewLease.snapshot.sessionId !== harness.primaryId) {
      const baseline = Event.toPromise(lens.sessionViewLease.onDidApplyFrame);
      try {
        await bounded(baseline, "initial host baseline must reach the Pane lease");
      } finally {
        baseline.cancel();
      }
    }
    assert.strictEqual(lens.sessionViewLease.snapshot.sessionId, harness.primaryId);
    return { ...harness, pane, lens, connection, sessionView, deferCatalog, notify, catalog };
  }
  function assertVisibleMissing(harness, pane = harness.pane, key = harness.primaryId) {
    const lens = pane.activeConversationLens;
    assert.ok(lens);
    assert.strictEqual(lens.boundSessionId, key);
    assert.strictEqual(lens.isDisposed, false);
    assert.strictEqual(harness.sessionWindowService.isSessionWindowVisible(key), true);
    assert.strictEqual(lens.sessionViewBindingSuspended, false);
    assert.strictEqual(lens.sessionViewLease, void 0, "real connection/Binding must naturally remove the empty owner lease");
    return lens;
  }
  async function startEmptyCatalogRefresh(harness, reconnect = false) {
    const request = harness.deferCatalog();
    if (reconnect) {
      harness.notify("disconnected");
    }
    harness.notify("live");
    await bounded(request.started.p, "real replacement listSessions must start");
    assert.strictEqual(getConversationSessionReadiness(harness.rosterService), "loading");
    assert.strictEqual(harness.pane.activeConversationLens, harness.lens);
    assertVisibleMissing(harness);
    return request;
  }
  async function completeCatalog(harness, request) {
    await request.result.complete(harness.catalog);
    await bounded(harness.rosterService.whenEngineCatalogRefreshComplete(), "real catalog must settle");
    assert.strictEqual(getConversationSessionReadiness(harness.rosterService), "ready");
  }
  function observePaneBinds(lens) {
    let calls = 0;
    const original = lens.bindSessionView;
    lens.bindSessionView = (sessionId) => {
      calls++;
      original.call(lens, sessionId);
    };
    store.add(toDisposable(() => {
      lens.bindSessionView = original;
    }));
    return () => calls;
  }
  async function assertEngineFramePaints(harness, pane, sessionId, text) {
    const lens = pane.activeConversationLens;
    assert.ok(lens);
    const lease = lens.sessionViewLease;
    assert.ok(lease, "this actual Pane must own the recovered lease");
    assert.strictEqual(lease.sessionId, sessionId);
    if (!harness.sessionView.hasSessionListener(sessionId)) {
      const listening = Event.toPromise(Event.filter(harness.sessionView.onDidListen, () => harness.sessionView.hasSessionListener(sessionId)));
      try {
        await bounded(listening, "actual host lease acquire and frame listener must complete");
      } finally {
        listening.cancel();
      }
    }
    const column = pane.getReadingColumn();
    assert.ok(column);
    const painted = new DeferredPromise();
    const check = () => {
      const body = column.querySelector(`.conversation-lens-turn[data-turn-id="${sessionId}-body"] .conversation-lens-turn-body`);
      const pending = column.querySelector(`.conversation-lens-confirmation-seat[data-turn-id="${sessionId}-permission"]`);
      if (body?.textContent === text && pending?.textContent?.includes(`Permission for ${sessionId}`)) {
        void painted.complete();
      }
    };
    const observer = new MutationObserver(check);
    observer.observe(column, { childList: true, characterData: true, subtree: true });
    const admitted = Event.toPromise(lease.onDidApplyFrame);
    try {
      harness.sessionView.emitSession(sessionId, text);
      await bounded(admitted, "frame must be admitted by the actual Pane lease");
      pane.layout({ width: 800, height: 600 });
      check();
      await bounded(painted.p, "actual Pane turn and pending seat must paint through TimelineHost");
      assert.strictEqual(lens.sessionViewLease, lease);
      assert.strictEqual(lease.snapshot.timeline.length, 2);
      assert.strictEqual(lease.snapshot.pendingActions.length, 1);
    } finally {
      observer.disconnect();
      admitted.cancel();
    }
  }
  async function waitForSessionPane(harness, sessionKey) {
    return waitForPane(partFor(harness.parts, sessionKey), harness.openErrors, harness.parts);
  }
  suite("visible engine lease recovery", () => {
    test("L1 same visible empty owner recovers its own lease after same-session catalog ready without reveal", async () => {
      const harness = await createEngineRevealHarness();
      const { pane, lens, primaryId, rosterService } = harness;
      const input = pane.input;
      assert.ok(input);
      assert.strictEqual(lens.lastAttachedEntries.length, 0);
      assert.strictEqual(lens.sessionViewLease?.snapshot.timeline.length, 0);
      const pending = await startEmptyCatalogRefresh(harness, true);
      assert.strictEqual(pane.input, input);
      let activeChanges = 0;
      const activeListener = store.add(rosterService.onDidChangeActiveSession(() => {
        activeChanges++;
      }));
      await completeCatalog(harness, pending);
      assert.strictEqual(rosterService.getActiveSessionId(), primaryId);
      assert.strictEqual(activeChanges, 0, "same-session recovery must not rely on an active-id event");
      assert.strictEqual(pane.input, input);
      assert.strictEqual(pane.activeConversationLens, lens);
      assert.strictEqual(lens.boundSessionId, primaryId);
      assert.strictEqual(lens.isDisposed, false);
      assert.strictEqual(isConversationEngineLive(harness.connection.getConnectionPhase(), harness.connection.getConnectionSnapshot().pairingPending), true);
      assert.strictEqual(isConversationPairingHold(harness.connection), false);
      assert.ok(lens.sessionViewLease, "catalog ready must restore this visible Pane lease without hide/reveal");
      assert.strictEqual(lens.sessionViewLease.sessionId, primaryId);
      activeListener.dispose();
      await assertEngineFramePaints(harness, pane, primaryId, "L1 recovered Pane body");
    });
    test("L2 continuously live nonempty owner keeps lease snapshot entries and text through catalog pending failure and ready", async () => {
      const harness = await createEngineRevealHarness();
      await assertEngineFramePaints(harness, harness.pane, harness.primaryId, "L2 keep this body");
      const lease = harness.lens.sessionViewLease;
      assert.ok(lease);
      const snapshot = lease.snapshot;
      const entries = harness.lens.lastAttachedEntries;
      const input = harness.pane.input;
      const assertKept = () => {
        assert.strictEqual(harness.pane.input, input);
        assert.strictEqual(harness.pane.activeConversationLens, harness.lens);
        assert.strictEqual(harness.connection.getConnectionSnapshot().engineIdentityId, "reveal-engine");
        assert.strictEqual(isConversationEngineLive(harness.connection.getConnectionPhase(), harness.connection.getConnectionSnapshot().pairingPending), true);
        assert.strictEqual(isConversationPairingHold(harness.connection), false);
        assert.strictEqual(harness.rosterService.getActiveSessionId(), harness.primaryId);
        assert.strictEqual(harness.lens.boundSessionId, harness.primaryId);
        assert.strictEqual(harness.lens.sessionViewLease, lease);
        assert.strictEqual(lease.snapshot, snapshot);
        assert.strictEqual(harness.lens.lastAttachedEntries, entries);
        assert.strictEqual(harness.pane.getReadingColumn()?.querySelector(`.conversation-lens-turn[data-turn-id="${harness.primaryId}-body"] .conversation-lens-turn-body`)?.textContent, "L2 keep this body");
      };
      const failed = harness.deferCatalog();
      harness.notify("live");
      await bounded(failed.started.p, "same-live catalog refresh must start");
      assert.strictEqual(getConversationSessionReadiness(harness.rosterService), "loading");
      assertKept();
      await failed.result.error(new Error("catalog unavailable"));
      await bounded(harness.rosterService.whenEngineCatalogRefreshComplete(), "failed real list must settle");
      assert.strictEqual(getConversationSessionReadiness(harness.rosterService), "unavailable");
      assertKept();
      const recovered = harness.deferCatalog();
      harness.notify("live");
      await bounded(recovered.started.p, "same-live recovery list must start");
      assertKept();
      await completeCatalog(harness, recovered);
      assertKept();
    });
    test("L3 loading and real list rejection leave a visible empty owner missing until successful ready", async () => {
      const harness = await createEngineRevealHarness();
      const failed = await startEmptyCatalogRefresh(harness);
      const binds = observePaneBinds(harness.lens);
      assertVisibleMissing(harness);
      await failed.result.error(new Error("listSessions rejected"));
      await bounded(harness.rosterService.whenEngineCatalogRefreshComplete(), "real rejected list must settle");
      assert.strictEqual(getConversationSessionReadiness(harness.rosterService), "unavailable");
      assertVisibleMissing(harness);
      assert.strictEqual(binds(), 0);
      const recovery = await startEmptyCatalogRefresh(harness);
      const beforeReady = binds();
      await completeCatalog(harness, recovery);
      assert.strictEqual(binds() - beforeReady, 1, "the session-ready listener must call the real Pane bind once");
      await assertEngineFramePaints(harness, harness.pane, harness.primaryId, "L3 catalog recovery");
    });
    for (const state of ["disconnected", "connected pairing", "connecting pairing"]) {
      test(`L3 ${state} QueueReader session window keeps a naturally missing visible owner unbound`, async () => {
        let harness;
        let armed = false;
        let binds;
        const order = [];
        const capture = (position) => {
          assert.ok(harness);
          assert.ok(binds);
          const lens = harness.pane.activeConversationLens;
          assert.ok(lens);
          return {
            position,
            pane: harness.pane,
            input: harness.pane.input,
            lens,
            bound: lens.boundSessionId,
            visible: harness.sessionWindowService.isSessionWindowVisible(harness.primaryId),
            suspended: lens.sessionViewBindingSuspended,
            disposed: lens.isDisposed,
            lease: lens.sessionViewLease,
            phase: harness.connection.getConnectionPhase().kind,
            pairing: harness.connection.getConnectionSnapshot().pairingPending,
            connected: harness.rosterService.isEngineConnected(),
            readiness: getConversationSessionReadiness(harness.rosterService),
            queue: harness.rosterService.getMessageQueueState(harness.primaryId).readState,
            bindCalls: binds()
          };
        };
        const samples = [];
        harness = await createEngineRevealHarness((roster) => {
          store.add(roster.onDidChangeSession((id) => {
            if (armed && id === "lease-s1" && samples.length === 0 && roster.getMessageQueueState(id).readState === "stale") {
              order.push("session before");
              samples.push(capture("before"));
            }
          }));
        });
        const current = harness;
        binds = observePaneBinds(current.lens);
        store.add(current.rosterService.onDidChangeSession((id) => {
          if (armed && id === current.primaryId && samples.length === 1) {
            order.push("session after");
            samples.push(capture("after"));
          }
        }));
        const pending = await startEmptyCatalogRefresh(current);
        assert.strictEqual(current.rosterService.getMessageQueueState(current.primaryId).readState, "unsupported");
        const beforeCalls = binds();
        const input = current.pane.input;
        armed = true;
        order.push("UA start");
        current.notify(state);
        order.push("UA return");
        armed = false;
        assert.deepStrictEqual(order, ["UA start", "session before", "session after", "UA return"], "QueueReader must expose the actual independent callback window");
        assert.strictEqual(samples.length, 2);
        for (const sample of samples) {
          assert.strictEqual(sample.pane, current.pane);
          assert.strictEqual(sample.input, input);
          assert.strictEqual(sample.lens, current.lens);
          assert.strictEqual(sample.bound, current.primaryId);
          assert.strictEqual(sample.visible, true);
          assert.strictEqual(sample.suspended, false);
          assert.strictEqual(sample.disposed, false);
          assert.strictEqual(sample.lease, void 0);
          assert.strictEqual(sample.phase, state === "disconnected" ? "disconnected" : state === "connecting pairing" ? "connecting" : "connected");
          assert.strictEqual(sample.pairing, state !== "disconnected");
          assert.strictEqual(sample.connected, false);
          assert.strictEqual(sample.readiness, "ready");
          assert.strictEqual(sample.queue, "stale");
          assert.strictEqual(sample.bindCalls, beforeCalls, "new reconcile must not bind within the non-live callback window");
        }
        await pending.result.complete(current.catalog);
        await bounded(current.rosterService.whenEngineCatalogRefreshComplete(), "stale pending catalog must drain");
        const recovery = await startEmptyCatalogRefresh(current);
        await completeCatalog(current, recovery);
        await assertEngineFramePaints(current, current.pane, current.primaryId, `L3 ${state} restored`);
      });
    }
    test("L4 hidden suspended owner stays unbound through failed and ready catalogs until public restore", async () => {
      const harness = await createEngineRevealHarness();
      await harness.sessionWindowService.openSessionBeside("lease-s2");
      const pane = await waitForEnginePane(partFor(harness.parts, "lease-s2"));
      trackEditors(harness.parts);
      const lens = pane.activeConversationLens;
      assert.ok(lens?.sessionViewLease);
      harness.sessionWindowService.hideSessionWindow("lease-s2");
      assert.strictEqual(lens.sessionViewBindingSuspended, true);
      assert.strictEqual(lens.sessionViewLease, void 0);
      const binds = observePaneBinds(lens);
      const failed = harness.deferCatalog();
      harness.notify("live");
      await bounded(failed.started.p, "hidden control real list must start");
      await failed.result.error(new Error("hidden catalog failure"));
      await bounded(harness.rosterService.whenEngineCatalogRefreshComplete(), "hidden failure must settle");
      assert.strictEqual(lens.sessionViewLease, void 0);
      assert.strictEqual(binds(), 0);
      const ready = harness.deferCatalog();
      harness.notify("live");
      await bounded(ready.started.p, "hidden recovery list must start");
      await completeCatalog(harness, ready);
      assert.strictEqual(harness.sessionWindowService.isSessionWindowVisible("lease-s2"), false);
      assert.strictEqual(lens.sessionViewBindingSuspended, true);
      assert.strictEqual(lens.sessionViewLease, void 0);
      assert.strictEqual(binds(), 0);
      harness.sessionWindowService.restoreSessionWindow("lease-s2");
      assert.strictEqual(lens.sessionViewBindingSuspended, false);
      const restoredLens = pane.activeConversationLens;
      assert.ok(restoredLens);
      assert.strictEqual(restoredLens, lens);
      assert.strictEqual(restoredLens.sessionViewLease?.sessionId, "lease-s2");
      await assertEngineFramePaints(harness, pane, "lease-s2", "L4 public restore");
      const retiredLease = restoredLens.sessionViewLease;
      assert.ok(retiredLease);
      const retainedObserver = store.add(harness.rosterService.acquireSessionView("lease-s2"));
      assert.notStrictEqual(retainedObserver, retiredLease);
      const hostLease = harness.sessionView.acquired.find((lease) => lease.sessionId === "lease-s2" && !harness.sessionView.released.has(lease.leaseId));
      assert.ok(hostLease, "the restored Pane and observer must share an acquired s2 host lease");
      let retiredFrames = 0;
      store.add(retiredLease.onDidApplyFrame(() => {
        retiredFrames++;
      }));
      const removed = harness.deferCatalog();
      harness.notify("live");
      await bounded(removed.started.p, "public removal catalog must start");
      const survivingCatalog = { sessions: harness.catalog.sessions.filter((session) => session.sessionId !== "lease-s2") };
      await removed.result.complete(survivingCatalog);
      await bounded(harness.rosterService.whenEngineCatalogRefreshComplete(), "public prune must settle");
      assert.strictEqual(harness.sessionWindowService.getLeafSlots("lease-s2"), void 0);
      assert.strictEqual(harness.sessionWindowService.isSessionWindowHidden("lease-s2"), false);
      assert.strictEqual(harness.sessionWindowService.isSessionWindowVisible("lease-s2"), false);
      assert.strictEqual(lens.isDisposed, true);
      const retiredSnapshot = retiredLease.snapshot;
      const framesAfterRemoval = retiredFrames;
      const observed = Event.toPromise(retainedObserver.onDidApplyFrame);
      try {
        harness.sessionView.emitSession("lease-s2", "L4 retained observer only");
        await bounded(observed, "the live retained observer must admit the post-prune host frame");
        assert.notStrictEqual(retainedObserver.snapshot, retiredSnapshot);
        assert.strictEqual(retiredLease.snapshot, retiredSnapshot, "the disposed Pane lease must no longer receive shared host snapshots");
        assert.strictEqual(retiredFrames, framesAfterRemoval);
      } finally {
        observed.cancel();
        retainedObserver.dispose();
      }
      assert.strictEqual(harness.sessionView.released.has(hostLease.leaseId), true, "the retired Pane and roster must release their ownership before the final observer releases the host");
      const afterRemoval = binds();
      const late = harness.deferCatalog();
      harness.notify("live");
      await bounded(late.started.p, "post-removal catalog must start");
      await late.result.complete(survivingCatalog);
      await bounded(harness.rosterService.whenEngineCatalogRefreshComplete(), "post-removal catalog must settle");
      assert.strictEqual(binds(), afterRemoval, "later ready notices cannot revive the removed non-hidden leaf");
      assert.strictEqual(retiredLease.snapshot, retiredSnapshot);
      assert.strictEqual(retiredFrames, framesAfterRemoval);
      assert.strictEqual(harness.sessionView.released.has(hostLease.leaseId), true);
      await assertEngineFramePaints(harness, harness.pane, harness.primaryId, "L4 surviving owner");
    });
    test("L4 an unmounted non-hidden bound key cannot reconcile before its public leaf exists", async () => {
      const harness = await createEngineRevealHarness();
      const pending = await startEmptyCatalogRefresh(harness);
      const input = store.add(new ConversationChatInput(getConversationChatResource("lease-s2", "unmounted")));
      const part = partFor(harness.parts, harness.primaryId);
      await harness.editorService.openEditor(input, void 0, part.activeGroup);
      const pane = part.activeGroup.activeEditorPane;
      assert.ok(pane instanceof ConversationEditorPane);
      const lens = pane.activeConversationLens;
      assert.ok(lens);
      assert.strictEqual(pane.input, input);
      assert.strictEqual(lens.boundSessionId, "lease-s2");
      assert.strictEqual(lens.sessionViewLease, void 0);
      assert.strictEqual(lens.sessionViewBindingSuspended, false);
      assert.strictEqual(harness.sessionWindowService.isSessionWindowHidden("lease-s2"), false);
      assert.strictEqual(harness.sessionWindowService.isSessionWindowVisible("lease-s2"), false);
      const binds = observePaneBinds(lens);
      await completeCatalog(harness, pending);
      assert.strictEqual(lens.sessionViewLease, void 0);
      assert.strictEqual(binds(), 0, "not-hidden is not evidence of a visible leaf");
      await harness.sessionWindowService.openSessionBeside("lease-s2");
      const mounted = await waitForEnginePane(partFor(harness.parts, "lease-s2"));
      trackEditors(harness.parts);
      await assertEngineFramePaints(harness, mounted, "lease-s2", "L4 mounted successor");
    });
    for (const action of ["clearInput", "dispose", "switch input"]) {
      test(`L5 ${action} during real catalog pending cannot revive the captured owner`, async () => {
        const harness = await createEngineRevealHarness();
        const pending = await startEmptyCatalogRefresh(harness);
        const oldInput = harness.pane.input;
        const oldLens = harness.lens;
        const oldBinds = observePaneBinds(oldLens);
        if (action === "clearInput") {
          harness.pane.clearInput();
        } else if (action === "dispose") {
          harness.pane.dispose();
        } else {
          const input = store.add(new ConversationChatInput(getConversationChatResource(harness.primaryId, "successor")));
          await harness.editorService.openEditor(input, void 0, partFor(harness.parts, harness.primaryId).activeGroup);
          assert.strictEqual(harness.pane.input, input);
          assert.notStrictEqual(harness.pane.input, oldInput);
        }
        const beforeReady = oldBinds();
        await completeCatalog(harness, pending);
        if (action === "switch input") {
          assert.strictEqual(harness.pane.activeConversationLens?.boundSessionId, harness.primaryId);
          assert.strictEqual(oldBinds() - beforeReady, 1, "only the current input listener may reconcile");
          assert.strictEqual(harness.pane.activeConversationLens?.sessionViewLease?.sessionId, harness.primaryId);
        } else {
          assert.strictEqual(harness.pane.activeConversationLens, void 0);
          assert.strictEqual(oldLens.isDisposed, true);
          assert.strictEqual(oldBinds(), beforeReady, "late catalog/session notices cannot bind the retired owner");
        }
      });
    }
    test("L6 repeated real session notices keep the recovered lease and continue delivering frames", async () => {
      const harness = await createEngineRevealHarness();
      const pending = await startEmptyCatalogRefresh(harness);
      await completeCatalog(harness, pending);
      await assertEngineFramePaints(harness, harness.pane, harness.primaryId, "L6 first frame");
      const lease = harness.lens.sessionViewLease;
      assert.ok(lease);
      const count = harness.sessionView.acquired.length;
      for (let i = 0; i < 2; i++) {
        const refresh = harness.deferCatalog();
        harness.notify("live");
        await bounded(refresh.started.p, "duplicate real refresh must start");
        await completeCatalog(harness, refresh);
        assert.strictEqual(harness.lens.sessionViewLease, lease);
        assert.strictEqual(harness.sessionView.acquired.length, count, "observation owners must not imply a new physical acquisition");
      }
      await assertEngineFramePaints(harness, harness.pane, harness.primaryId, "L6 later frame");
      assert.strictEqual(harness.lens.sessionViewLease, lease);
    });
    test("L7 two pinned visible owners recover their own bounds from one active-session catalog notice", async () => {
      const harness = await createEngineRevealHarness();
      await harness.sessionWindowService.openSessionBeside("lease-s2");
      const second = await waitForEnginePane(partFor(harness.parts, "lease-s2"));
      trackEditors(harness.parts);
      const lens2 = second.activeConversationLens;
      assert.ok(lens2?.sessionViewLease);
      await harness.sessionWindowService.revealSessionWindow(harness.primaryId);
      assert.strictEqual(harness.sessionWindowService.isSessionWindowVisible(harness.primaryId), true);
      assert.strictEqual(harness.sessionWindowService.isSessionWindowVisible("lease-s2"), true);
      const pending = await startEmptyCatalogRefresh(harness);
      assertVisibleMissing(harness, second, "lease-s2");
      const active = harness.rosterService.getActiveSessionId();
      const notified = [];
      store.add(harness.rosterService.onDidChangeSession((id) => {
        notified.push(id);
      }));
      await completeCatalog(harness, pending);
      assert.ok(notified.includes(active));
      assert.ok(!notified.includes("lease-s2"), "the inactive pinned leaf cannot rely on its own event id");
      assert.strictEqual(harness.pane.activeConversationLens, harness.lens);
      assert.strictEqual(second.activeConversationLens, lens2);
      assert.strictEqual(harness.lens.sessionViewLease?.sessionId, harness.primaryId);
      assert.strictEqual(lens2.sessionViewLease?.sessionId, "lease-s2");
      assert.notStrictEqual(harness.lens.sessionViewLease, lens2.sessionViewLease);
      await assertEngineFramePaints(harness, harness.pane, harness.primaryId, "L7 first leaf only");
      await assertEngineFramePaints(harness, second, "lease-s2", "L7 second leaf only");
      assert.ok(!harness.pane.getReadingColumn()?.textContent?.includes("L7 second leaf only"));
      assert.ok(!second.getReadingColumn()?.textContent?.includes("L7 first leaf only"));
    });
  });
  test("8 single-leaf reveal A\u2192B\u2192A keeps one visible primary without hide button", async () => {
    const harness = await createRevealHarness();
    const { parts, sessionWindowService, rosterService, primaryId } = harness;
    const b = rosterService.seedSessionQuietly();
    await sessionWindowService.revealSessionWindow(b);
    const partB = partFor(parts, b);
    await waitForSessionPane(harness, b);
    assert.deepStrictEqual(visibleLeafKeys(sessionWindowService), [b]);
    assert.strictEqual(sessionWindowService.getPrimarySessionKey(), b);
    assert.strictEqual(partB.sessionKey, b);
    assert.strictEqual(parts.getActiveConversationEditorPart()?.sessionKey, b);
    assert.ok(sessionWindowService.isSessionWindowHidden(primaryId));
    assert.strictEqual(partFor(parts, primaryId).sessionKey, primaryId);
    assert.strictEqual(hideButton(sessionWindowService, b)?.hidden, true);
    await sessionWindowService.revealSessionWindow(primaryId);
    await waitForSessionPane(harness, primaryId);
    assert.deepStrictEqual(visibleLeafKeys(sessionWindowService), [primaryId]);
    assert.strictEqual(sessionWindowService.getPrimarySessionKey(), primaryId);
    assert.strictEqual(hideButton(sessionWindowService, primaryId)?.hidden, true);
  });
  test("hide focused secondary leaf moves focus to primary", async () => {
    const harness = createLightweightWindowHarness();
    await timeout(0);
    const primaryId = harness.rosterService.getActiveSessionId();
    await harness.sessionWindowService.ensurePrimaryWindow(primaryId);
    const secondaryId = harness.rosterService.seedSessionQuietly();
    await harness.sessionWindowService.openSessionBeside(secondaryId);
    await harness.sessionWindowService.revealSessionWindow(secondaryId);
    assert.strictEqual(harness.sessionWindowService.getFocusedLeafSessionKey(), secondaryId);
    harness.sessionWindowService.hideSessionWindow(secondaryId);
    assert.strictEqual(harness.sessionWindowService.isSessionWindowHidden(secondaryId), true);
    assert.strictEqual(harness.sessionWindowService.getFocusedLeafSessionKey(), primaryId);
    const primaryLeaf = harness.sessionWindowService.getLeafSlots(primaryId);
    const active = getActiveElement();
    assert.ok(
      primaryLeaf.container === active || primaryLeaf.container.contains(active),
      "focus must leave the hidden leaf and land on the visible primary"
    );
  });
  test("8 two visible leaves: reveal already-visible leaf focuses it", async () => {
    const harness = await createRevealHarness();
    const { parts, sessionWindowService, rosterService, primaryId, conversationPart } = harness;
    const b = rosterService.seedSessionQuietly();
    await sessionWindowService.openSessionBeside(b);
    await waitForSessionPane(harness, b);
    assert.strictEqual(sessionWindowService.getVisibleWindowCount(), 2);
    await sessionWindowService.revealSessionWindow(b);
    assert.strictEqual(sessionWindowService.getVisibleWindowCount(), 2);
    assert.strictEqual(sessionWindowService.getFocusedLeafSessionKey(), b);
    assert.strictEqual(rosterService.getActiveSessionId(), b);
    assert.strictEqual(parts.getActiveConversationEditorPart()?.sessionKey, b);
    const leafB = sessionWindowService.getLeafSlots(b);
    assert.ok(leafB);
    const active = getActiveElement();
    assert.ok(
      leafB.container === active || leafB.container.contains(active),
      "focus must stay in the revealed leaf, not snap back to primary"
    );
    const chrome = countLeafChrome(sessionWindowService, conversationPart);
    assert.strictEqual(chrome.bars, 2);
    assert.strictEqual(partFor(parts, primaryId).sessionKey, primaryId);
    assert.strictEqual(partFor(parts, b).sessionKey, b);
  });
  test("cancelled already-visible reveal does not switch the active session back", async () => {
    const harness = await createRevealHarness();
    const { parts, sessionWindowService, rosterService, primaryId } = harness;
    const b = rosterService.seedSessionQuietly();
    await sessionWindowService.openSessionBeside(b);
    const paneA = await waitForSessionPane(harness, primaryId);
    const paneB = await waitForSessionPane(harness, b);
    assert.ok(paneA.leafSessionBarHost);
    assert.ok(paneB.leafSessionBarHost);
    assert.strictEqual(sessionWindowService.getVisibleWindowCount(), 2);
    let releaseA = () => {
    };
    const gate = new Promise((resolve) => {
      releaseA = resolve;
    });
    partFor(parts, primaryId).whenReady = gate;
    const switched = [];
    const originalSwitch = rosterService.switchSession.bind(rosterService);
    rosterService.switchSession = (sessionId) => {
      switched.push(sessionId);
      originalSwitch(sessionId);
    };
    const first = paneA.leafSessionBarHost.switchLeafSession(primaryId);
    try {
      await timeout(0);
      await paneB.leafSessionBarHost.switchLeafSession(b);
      assert.strictEqual(sessionWindowService.getFocusedLeafSessionKey(), b);
      assert.strictEqual(rosterService.getActiveSessionId(), b);
      switched.length = 0;
      releaseA();
      await first;
      assert.deepStrictEqual(switched, []);
      assert.strictEqual(sessionWindowService.getFocusedLeafSessionKey(), b);
      assert.strictEqual(rosterService.getActiveSessionId(), b);
    } finally {
      releaseA();
    }
  });
  test("hide during pane-less reveal wait does not steal focus or the active session", async function() {
    this.timeout(15e3);
    const harness = createLightweightWindowHarness();
    await timeout(0);
    const { sessionWindowService, rosterService, conversationParts } = harness;
    const primaryId = rosterService.getActiveSessionId();
    await sessionWindowService.ensurePrimaryWindow(primaryId);
    const secondaryId = rosterService.seedSessionQuietly();
    await sessionWindowService.openSessionBeside(secondaryId);
    assert.strictEqual(sessionWindowService.isSessionWindowVisible(primaryId), true);
    assert.strictEqual(sessionWindowService.isSessionWindowVisible(secondaryId), true);
    assert.strictEqual(sessionWindowService.getVisibleWindowCount(), 2);
    const secondaryPart = conversationParts.find((part) => part.sessionKey === secondaryId);
    assert.ok(secondaryPart);
    const group = secondaryPart.activeGroup;
    group.activeEditorPane = void 0;
    group.onDidActiveEditorChange = Event.None;
    await sessionWindowService.revealSessionWindow(primaryId);
    assert.strictEqual(sessionWindowService.getFocusedLeafSessionKey(), primaryId);
    assert.strictEqual(rosterService.getActiveSessionId(), primaryId);
    const primaryLeaf = sessionWindowService.getLeafSlots(primaryId);
    const activeBefore = getActiveElement();
    assert.ok(
      primaryLeaf.container === activeBefore || primaryLeaf.container.contains(activeBefore),
      "primary must own focus before the stalled reveal"
    );
    const switched = [];
    const originalSwitch = rosterService.switchSession.bind(rosterService);
    rosterService.switchSession = (sessionId) => {
      switched.push(sessionId);
      originalSwitch(sessionId);
    };
    let settled = false;
    const reveal = sessionWindowService.revealSessionWindow(secondaryId).finally(() => {
      settled = true;
    });
    await timeout(0);
    assert.strictEqual(settled, false, "reveal must still be waiting for an editor pane");
    assert.strictEqual(sessionWindowService.isSessionWindowVisible(secondaryId), true);
    sessionWindowService.hideSessionWindow(secondaryId);
    assert.strictEqual(sessionWindowService.isSessionWindowHidden(secondaryId), true);
    assert.strictEqual(sessionWindowService.getFocusedLeafSessionKey(), primaryId);
    assert.strictEqual(rosterService.getActiveSessionId(), primaryId);
    const activeDuring = getActiveElement();
    assert.ok(
      primaryLeaf.container === activeDuring || primaryLeaf.container.contains(activeDuring),
      "focus must stay on the primary while the hidden leaf is still waiting"
    );
    await reveal;
    assert.strictEqual(settled, true);
    assert.strictEqual(sessionWindowService.isSessionWindowHidden(secondaryId), true);
    assert.strictEqual(sessionWindowService.getFocusedLeafSessionKey(), primaryId);
    assert.strictEqual(rosterService.getActiveSessionId(), primaryId);
    const activeAfter = getActiveElement();
    assert.ok(
      primaryLeaf.container === activeAfter || primaryLeaf.container.contains(activeAfter),
      "focus must stay on the primary after the pane wait ends"
    );
    assert.deepStrictEqual(switched, []);
  });
  test("10 SelectBox path on real pane changes the leaf (PRD-002 #1)", async () => {
    const harness = await createRevealHarness();
    const { parts, sessionWindowService, rosterService, primaryId } = harness;
    const b = rosterService.seedSessionQuietly();
    const pane = await waitForSessionPane(harness, primaryId);
    assert.ok(pane.leafSessionBarHost);
    await pane.leafSessionBarHost.switchLeafSession(b);
    await waitForSessionPane(harness, b);
    assert.strictEqual(sessionWindowService.getPrimarySessionKey(), b);
    assert.strictEqual(sessionWindowService.getVisibleWindowCount(), 1);
    assert.ok(partFor(parts, b).activeGroup.activeEditor);
  });
  test("10 two visible leaves: SelectBox on one leaf replaces that leaf with a third session", async () => {
    const harness = await createRevealHarness();
    const { parts, sessionWindowService, rosterService, primaryId } = harness;
    const b = rosterService.seedSessionQuietly();
    const c = rosterService.seedSessionQuietly();
    await sessionWindowService.openSessionBeside(b);
    const paneB = await waitForSessionPane(harness, b);
    assert.ok(paneB.leafSessionBarHost);
    await paneB.leafSessionBarHost.switchLeafSession(c);
    await waitForSessionPane(harness, c);
    const visible = visibleLeafKeys(sessionWindowService);
    assert.strictEqual(visible.length, 2);
    assert.ok(visible.includes(primaryId), "the other leaf must stay");
    assert.ok(visible.includes(c), "the operated leaf must become the third session");
    assert.ok(!visible.includes(b), "the operated leaf must not remain");
    assert.strictEqual(partFor(parts, primaryId).sessionKey, primaryId);
    assert.strictEqual(partFor(parts, c).sessionKey, c);
    assert.strictEqual(sessionWindowService.isSessionWindowHidden(b), true);
  });
  test("does not leak unhandled rejection when switchToSession switchLeafSession rejects and onUnexpectedError warn-then-rethrows", async () => {
    const harness = await createRevealHarness();
    const pane = await waitForSessionPane(harness, harness.primaryId);
    assert.ok(pane.leafSessionBarHost);
    const paintBoom = new Error("switch boom");
    pane.leafSessionBarHost.switchLeafSession = async () => {
      throw paintBoom;
    };
    await assertWarnThenRethrowDoesNotLeak(paintBoom, () => {
      pane.leafSessionBarHost.switchToSession("other-session");
    });
  });
  test("does not leak unhandled rejection when SelectBox helper switchToSession switchLeafSession rejects and onUnexpectedError warn-then-rethrows", async () => {
    const harness = await createRevealHarness();
    const pane = await waitForSessionPane(harness, harness.primaryId);
    assert.ok(pane.leafSessionBarHost);
    const paintBoom = new Error("switch boom");
    pane.leafSessionBarHost.switchLeafSession = async () => {
      throw paintBoom;
    };
    await assertWarnThenRethrowDoesNotLeak(paintBoom, () => {
      switchToSessionHelper(pane.leafSessionBarHost, "other-session");
    });
  });
  test("SelectBox helper switchToSession fire-and-forget voids double-catch onUnexpectedError", async () => {
    const source = await __readFileInTests(`${process.cwd()}/src/vs/workbench/contrib/conversation/browser/conversationLensSessionBar.ts`);
    const doubleCatch = ".catch(onUnexpectedError).catch(onUnexpectedError)";
    assert.ok(source.includes(`void host.switchLeafSession(sessionId)${doubleCatch}`));
    assert.ok(!source.includes("void host.switchLeafSession(sessionId);"));
  });
  test("10 New Session in stub path becomes the only visible leaf", async () => {
    const harness = await createRevealHarness();
    const { sessionWindowService, rosterService, primaryId } = harness;
    const pane = await waitForSessionPane(harness, primaryId);
    assert.ok(pane.leafSessionBarHost);
    pane.leafSessionBarHost.createNewSession();
    const deadline = Date.now() + 3e3;
    let newId = rosterService.getActiveSessionId();
    while (newId === primaryId && Date.now() < deadline) {
      await timeout(20);
      newId = rosterService.getActiveSessionId();
    }
    assert.notStrictEqual(newId, primaryId);
    await waitForSessionPane(harness, newId);
    assert.strictEqual(sessionWindowService.getVisibleWindowCount(), 1);
    assert.strictEqual(sessionWindowService.getPrimarySessionKey(), newId);
    assert.strictEqual(hideButton(sessionWindowService, newId)?.hidden, true);
    assert.strictEqual(sessionWindowService.isSessionWindowHidden(primaryId), true);
  });
  test("13 each visible leaf has exactly one SessionBar and window-nav; Part slot has none", async () => {
    const harness = await createRevealHarness();
    const { sessionWindowService, rosterService, conversationPart, primaryId } = harness;
    const b = rosterService.seedSessionQuietly();
    const c = rosterService.seedSessionQuietly();
    await sessionWindowService.revealSessionWindow(b);
    await waitForSessionPane(harness, b);
    await sessionWindowService.revealSessionWindow(c);
    await waitForSessionPane(harness, c);
    await sessionWindowService.revealSessionWindow(primaryId);
    await waitForSessionPane(harness, primaryId);
    let chrome = countLeafChrome(sessionWindowService, conversationPart);
    assert.strictEqual(sessionWindowService.getVisibleWindowCount(), 1);
    assert.strictEqual(chrome.bars, 1);
    assert.strictEqual(chrome.navs, 1);
    assert.strictEqual(chrome.partSlotBars, 0);
    await sessionWindowService.openSessionBeside(b);
    await waitForSessionPane(harness, b);
    chrome = countLeafChrome(sessionWindowService, conversationPart);
    assert.strictEqual(sessionWindowService.getVisibleWindowCount(), 2);
    assert.strictEqual(chrome.bars, 2);
    assert.strictEqual(chrome.navs, 2);
    assert.strictEqual(chrome.partSlotBars, 0);
  });
  test("13b leaf SessionBar and container receive is-narrow when pane width is under 450px", async () => {
    const harness = await createRevealHarness();
    const { sessionWindowService, primaryId } = harness;
    const pane = await waitForSessionPane(harness, primaryId);
    const leaf = sessionWindowService.getLeafSlots(primaryId);
    pane.layout(new Dimension(500, 600));
    assert.ok(leaf.sessionBar.classList.contains("is-medium"));
    assert.ok(!leaf.sessionBar.classList.contains("is-narrow"));
    pane.layout(new Dimension(400, 600));
    assert.ok(leaf.sessionBar.classList.contains("is-narrow"));
    assert.ok(leaf.container.classList.contains("is-narrow"));
    assert.ok(!leaf.sessionBar.classList.contains("is-compact"));
    pane.layout(new Dimension(250, 600));
    assert.ok(leaf.sessionBar.classList.contains("is-narrow"));
    assert.ok(leaf.sessionBar.classList.contains("is-compact"));
    pane.layout(new Dimension(950, 600));
    assert.ok(!leaf.sessionBar.classList.contains("is-narrow"));
    assert.ok(!leaf.container.classList.contains("is-narrow"));
    assert.ok(!leaf.sessionBar.classList.contains("is-compact"));
  });
  test("14 reveal mounts overlay so openSubAgent does not throw", async () => {
    const harness = await createRevealHarness();
    const { sessionWindowService, sessionChatService, rosterService } = harness;
    const b = rosterService.seedSessionQuietly();
    await sessionWindowService.revealSessionWindow(b);
    await waitForSessionPane(harness, b);
    await sessionChatService.openSubAgent(b, "tool-from-reveal", "Reveal tool");
    assert.strictEqual(sessionChatService.isSubAgentDialogOpen(b), true);
  });
  test("15 latest-wins reveal ends on B; bind-failed sentinel does not create a leaf", async () => {
    const { sessionWindowService, rosterService, primaryId } = await createRevealHarness();
    const a = rosterService.seedSessionQuietly();
    const b = rosterService.seedSessionQuietly();
    const first = sessionWindowService.revealSessionWindow(a);
    const second = sessionWindowService.revealSessionWindow(b);
    await Promise.all([first, second]);
    assert.deepStrictEqual(visibleLeafKeys(sessionWindowService), [b]);
    assert.strictEqual(sessionWindowService.getPrimarySessionKey(), b);
    const keysBefore = [...sessionWindowService.getAllLeafSessionKeys()];
    rosterService.fireActiveSession(ENGINE_BIND_FAILED_SESSION_ID);
    await timeout(20);
    assert.deepStrictEqual([...sessionWindowService.getAllLeafSessionKeys()], keysBefore);
    assert.strictEqual(sessionWindowService.getLeafSlots(ENGINE_BIND_FAILED_SESSION_ID), void 0);
    assert.ok(sessionWindowService.getLeafSlots(primaryId) || sessionWindowService.getLeafSlots(b));
  });
  test("onDidDeleteSession disposes visible leaf when bind-failed skips reveal", async () => {
    const harness = createLightweightWindowHarness();
    await timeout(0);
    const sessionId = harness.rosterService.getActiveSessionId();
    await harness.sessionWindowService.ensurePrimaryWindow(sessionId);
    assert.deepStrictEqual(visibleLeafKeys(harness.sessionWindowService), [sessionId]);
    assert.ok(harness.conversationParts.some((part) => part.sessionKey === sessionId));
    harness.rosterService.fireActiveSession(ENGINE_BIND_FAILED_SESSION_ID);
    harness.rosterService.fireDeletedSession(sessionId);
    assert.deepStrictEqual(visibleLeafKeys(harness.sessionWindowService), []);
    assert.strictEqual(harness.sessionWindowService.getPrimarySessionKey(), void 0);
    assert.ok(!harness.sessionWindowService.getAllLeafSessionKeys().includes(sessionId));
    assert.ok(!harness.conversationParts.some((part) => part.sessionKey === sessionId));
  });
  test("onDidDeleteSession disposes a hidden leaf and its editor part", async () => {
    const harness = await createRevealHarness();
    const { parts, sessionWindowService, rosterService, primaryId } = harness;
    const secondaryId = rosterService.seedSessionQuietly();
    await sessionWindowService.openSessionBeside(secondaryId);
    await waitForSessionPane(harness, secondaryId);
    assert.strictEqual(sessionWindowService.isSessionWindowHidden(primaryId), true);
    assert.ok(sessionWindowService.getLeafSlots(primaryId));
    assert.ok(parts.conversationParts.some((part) => part.sessionKey === primaryId));
    rosterService.fireDeletedSession(primaryId);
    assert.strictEqual(sessionWindowService.getLeafSlots(primaryId), void 0);
    assert.ok(!parts.conversationParts.some((part) => part.sessionKey === primaryId));
    assert.deepStrictEqual(visibleLeafKeys(sessionWindowService), [secondaryId]);
  });
  test("15 stub-seed untitled onDidChangeActiveSession still reveals", async () => {
    const harness = await createRevealHarness();
    const { sessionWindowService, rosterService } = harness;
    assert.ok(isEngineRosterPlaceholderSessionId("untitled"));
    assert.ok(rosterService.getSessions().some((session) => session.id === "untitled"));
    const b = rosterService.seedSessionQuietly();
    await sessionWindowService.revealSessionWindow(b);
    await waitForSessionPane(harness, b);
    assert.strictEqual(sessionWindowService.isSessionWindowHidden("untitled"), true);
    rosterService.fireActiveSession("untitled");
    await waitForSessionPane(harness, "untitled");
    assert.strictEqual(sessionWindowService.isSessionWindowVisible("untitled"), true);
    assert.deepStrictEqual(visibleLeafKeys(sessionWindowService), ["untitled"]);
    assert.strictEqual(sessionWindowService.getPrimarySessionKey(), "untitled");
  });
  test("15 reveal create failure rolls back part + leaf and rebuilds the same key", async () => {
    const rosterService = store.add(new QuietRosterService());
    const gridHost = document.createElement("div");
    document.body.appendChild(gridHost);
    store.add({ dispose: () => gridHost.remove() });
    const conversationParts = [];
    let throwOnCreate = false;
    const editorGroupsService = {
      createConversationEditorPart: (_parent, sessionKey) => {
        if (throwOnCreate) {
          throw new Error("reveal boom");
        }
        const part = { sessionKey, whenReady: Promise.resolve(), activeGroup: { focus: () => {
        }, activeEditorPane: { getId: () => ConversationEditorPaneId } } };
        conversationParts.push(part);
        return part;
      },
      disposeConversationEditorPart: (sessionKey) => {
        const index = conversationParts.findIndex((part) => part.sessionKey === sessionKey);
        if (index >= 0) {
          conversationParts.splice(index, 1);
        }
      },
      setFocusedConversationLeaf: () => {
      },
      getFocusedConversationLeaf: () => void 0,
      get conversationParts() {
        return conversationParts;
      }
    };
    const errors = [];
    const sessionWindowService = store.add(new ConversationSessionWindowService(
      {
        onDidCreateSlots: Event.None,
        onDidFocus: Event.None,
        getSlots: () => ({ sessionBar: document.createElement("div"), sessionWindowGrid: gridHost, editorPartHost: void 0 }),
        setFocusedLeafContainer: () => {
        },
        focus: () => {
        }
      },
      editorGroupsService,
      rosterService,
      new NullLogService(),
      {
        error: (message) => {
          errors.push(typeof message === "string" ? message : getErrorMessage(message));
        }
      }
    ));
    await timeout(0);
    const primaryId = rosterService.getActiveSessionId();
    await sessionWindowService.ensurePrimaryWindow(primaryId);
    const target = rosterService.seedSessionQuietly();
    throwOnCreate = true;
    await sessionWindowService.revealSessionWindow(target);
    assert.ok(errors.some((error) => error.includes("reveal boom")));
    assert.strictEqual(sessionWindowService.getPrimarySessionKey(), primaryId);
    assert.strictEqual(sessionWindowService.getLeafSlots(target), void 0);
    assert.ok(!sessionWindowService.getAllLeafSessionKeys().includes(target));
    assert.ok(!conversationParts.some((part) => part.sessionKey === target));
    throwOnCreate = false;
    await sessionWindowService.revealSessionWindow(target);
    assert.ok(sessionWindowService.getLeafSlots(target));
    assert.ok(conversationParts.some((part) => part.sessionKey === target));
    assert.ok(sessionWindowService.getLeafSlots(target)?.container.isConnected);
  });
  async function openTwoLightweightLeaves() {
    const errors = [];
    const harness = createLightweightWindowHarness();
    harness.setNotifyError((message) => {
      errors.push(typeof message === "string" ? message : getErrorMessage(message));
    });
    await timeout(0);
    const primaryId = harness.rosterService.getActiveSessionId();
    await harness.sessionWindowService.ensurePrimaryWindow(primaryId);
    const secondaryId = harness.rosterService.seedSessionQuietly();
    await harness.sessionWindowService.openSessionBeside(secondaryId);
    assert.strictEqual(harness.sessionWindowService.getVisibleWindowCount(), 2);
    assert.strictEqual(harness.sessionWindowService.isSessionWindowVisible(primaryId), true);
    assert.strictEqual(harness.sessionWindowService.isSessionWindowVisible(secondaryId), true);
    const incomingId = harness.rosterService.seedSessionQuietly();
    return { harness, errors, primaryId, secondaryId, incomingId };
  }
  test("secondary replace create failure restores the outgoing leaf and notifies", async () => {
    const { harness, errors, primaryId, secondaryId, incomingId } = await openTwoLightweightLeaves();
    const { sessionWindowService, conversationParts } = harness;
    harness.setThrowOnCreate(true);
    await sessionWindowService.revealSessionWindow(incomingId, { replace: secondaryId });
    assert.strictEqual(sessionWindowService.isSessionWindowVisible(secondaryId), true);
    assert.strictEqual(sessionWindowService.isSessionWindowVisible(primaryId), true);
    assert.strictEqual(sessionWindowService.getVisibleWindowCount(), 2);
    assert.strictEqual(sessionWindowService.getLeafSlots(incomingId), void 0);
    assert.ok(!sessionWindowService.getAllLeafSessionKeys().includes(incomingId));
    assert.ok(!conversationParts.some((part) => part.sessionKey === incomingId));
    assert.ok(errors.some((error) => error.includes("reveal boom")));
  });
  test("secondary replace whenReady failure restores the outgoing leaf and notifies", async () => {
    const { harness, errors, primaryId, secondaryId, incomingId } = await openTwoLightweightLeaves();
    const { sessionWindowService, conversationParts } = harness;
    harness.setRejectWhenReady(true);
    await sessionWindowService.revealSessionWindow(incomingId, { replace: secondaryId });
    assert.strictEqual(sessionWindowService.isSessionWindowVisible(secondaryId), true);
    assert.strictEqual(sessionWindowService.isSessionWindowVisible(primaryId), true);
    assert.strictEqual(sessionWindowService.getVisibleWindowCount(), 2);
    assert.strictEqual(sessionWindowService.getLeafSlots(incomingId), void 0);
    assert.ok(!sessionWindowService.getAllLeafSessionKeys().includes(incomingId));
    assert.ok(!conversationParts.some((part) => part.sessionKey === incomingId));
    assert.ok(errors.some((error) => error.includes("whenReady boom")));
  });
  test("primary replace create failure does not hide the old primary", async () => {
    const { harness, errors, primaryId, secondaryId, incomingId } = await openTwoLightweightLeaves();
    const { sessionWindowService } = harness;
    harness.setThrowOnCreate(true);
    await sessionWindowService.revealSessionWindow(incomingId, { replace: primaryId });
    assert.strictEqual(sessionWindowService.isSessionWindowVisible(primaryId), true);
    assert.strictEqual(sessionWindowService.isSessionWindowHidden(primaryId), false);
    assert.strictEqual(sessionWindowService.isSessionWindowVisible(secondaryId), true);
    assert.strictEqual(sessionWindowService.getPrimarySessionKey(), primaryId);
    assert.strictEqual(sessionWindowService.getVisibleWindowCount(), 2);
    assert.strictEqual(sessionWindowService.getLeafSlots(incomingId), void 0);
    assert.ok(!sessionWindowService.getAllLeafSessionKeys().includes(incomingId));
    assert.ok(errors.some((error) => error.includes("reveal boom")));
  });
  test("17 hiding a leaf releases its lens lease and restore reacquires it", async () => {
    const harness = await createRevealHarness();
    const { parts, sessionWindowService, rosterService, primaryId, sessionChatService } = harness;
    await sessionChatService.openExtensionTab(primaryId, "fork-lease", { title: "Fork lease" });
    const paneA = await waitForSessionPane(harness, primaryId);
    const partA = partFor(parts, primaryId);
    const tabCount = partA.activeGroup.count;
    assert.ok(tabCount >= 2);
    assert.ok(paneA.activeConversationLens);
    const b = rosterService.seedSessionQuietly();
    await sessionWindowService.revealSessionWindow(b);
    await waitForSessionPane(harness, b);
    assert.strictEqual(sessionWindowService.isSessionWindowHidden(primaryId), true);
    assert.strictEqual(partA.activeGroup.count, tabCount);
    const hiddenLenses = await collectLeafConversationLenses(partA);
    assert.strictEqual(hiddenLenses.length, tabCount);
    for (const lens of hiddenLenses) {
      assert.strictEqual(lens.sessionViewLease, void 0);
    }
    assert.strictEqual(partA.sessionKey, primaryId);
    const hiddenLeaf = sessionWindowService.getLeafSlots(primaryId)?.container;
    assert.ok(hiddenLeaf?.classList.contains(conversationSessionLeafHiddenClass));
    const staleBanner = hiddenLeaf?.querySelector(".conversation-lens-stale-snapshot");
    assert.ok(!staleBanner || staleBanner.hidden || !staleBanner.textContent);
    await sessionWindowService.revealSessionWindow(primaryId);
    const paneA2 = await waitForSessionPane(harness, primaryId);
    const restoredLenses = await collectLeafConversationLenses(partFor(parts, primaryId));
    assert.strictEqual(restoredLenses.length, tabCount);
    for (const lens of restoredLenses) {
      assert.ok(lens.sessionViewLease, "restore must reacquire sessionViewLease on every leaf lens");
    }
    assert.ok(paneA2.activeConversationLens?.sessionViewLease, "restore must reacquire sessionViewLease");
  });
  test("does not leak unhandled rejection when onDidChangeActiveSession reveal catch-path notice throws and onUnexpectedError warn-then-rethrows", async () => {
    const paintBoom = new Error("paint boom");
    const harness = createLightweightWindowHarness();
    await timeout(0);
    const primaryId = harness.rosterService.getActiveSessionId();
    await harness.sessionWindowService.ensurePrimaryWindow(primaryId);
    const target = harness.rosterService.seedSessionQuietly();
    harness.setThrowOnCreate(true);
    await assertWarnThenRethrowDoesNotLeak(paintBoom, () => {
      harness.setNotifyError(() => {
        throw paintBoom;
      });
      harness.rosterService.fireActiveSession(target);
    });
  });
  test("does not leak unhandled rejection when attachGrid pending reveal catch-path notice throws and onUnexpectedError warn-then-rethrows", async () => {
    const paintBoom = new Error("paint boom");
    const harness = createLightweightWindowHarness({ delaySlots: true });
    const target = harness.rosterService.seedSessionQuietly();
    harness.setThrowOnCreate(true);
    await assertWarnThenRethrowDoesNotLeak(paintBoom, () => {
      harness.setNotifyError(() => {
        throw paintBoom;
      });
      void harness.sessionWindowService.revealSessionWindow(target, { replace: harness.rosterService.getActiveSessionId() });
      harness.attachSlots();
    });
  });
  test("session window fire-and-forget voids double-catch onUnexpectedError", async () => {
    const source = await __readFileInTests(`${process.cwd()}/src/vs/workbench/contrib/conversation/browser/conversationSessionWindowService.ts`);
    const doubleCatch = ".catch(onUnexpectedError).catch(onUnexpectedError)";
    assert.ok(source.includes(`void this.revealSessionWindow(sessionKey)${doubleCatch}`));
    assert.ok(source.includes(`void this.revealSessionWindow(pending.sessionKey, pending.options)${doubleCatch}`));
    assert.ok(source.includes(`void this.ensurePrimaryWindow(this.rosterService.getActiveSessionId())${doubleCatch}`));
    assert.ok(!source.includes("void this.revealSessionWindow(sessionKey);"));
    assert.ok(!source.includes("void this.revealSessionWindow(pending.sessionKey, pending.options);"));
    assert.ok(!source.includes("void this.ensurePrimaryWindow(this.rosterService.getActiveSessionId());"));
  });
});
//# sourceMappingURL=data:application/json;base64,ewogICJ2ZXJzaW9uIjogMywKICAic291cmNlcyI6IFsiL2hvbWUvY2xhcmVuY2UvUHJvamVjdHMvQWdlbnRzL3ZzY29kZS1Xb3JrVHJlZXMvbWVyZ2Uvc3JjL3ZzL3dvcmtiZW5jaC9jb250cmliL2NvbnZlcnNhdGlvbi90ZXN0L2Jyb3dzZXIvY29udmVyc2F0aW9uU2Vzc2lvbldpbmRvd1JldmVhbC50ZXN0LnRzIl0sCiAgInNvdXJjZXNDb250ZW50IjogWyIvKi0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLVxuICogIENvcHlyaWdodCAoYykgTWljcm9zb2Z0IENvcnBvcmF0aW9uLiBBbGwgcmlnaHRzIHJlc2VydmVkLlxuICogIExpY2Vuc2VkIHVuZGVyIHRoZSBNSVQgTGljZW5zZS4gU2VlIExpY2Vuc2UudHh0IGluIHRoZSBwcm9qZWN0IHJvb3QgZm9yIGxpY2Vuc2UgaW5mb3JtYXRpb24uXG4gKi0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tKi9cblxuaW1wb3J0IGFzc2VydCBmcm9tICdhc3NlcnQnO1xuaW1wb3J0IHsgRGltZW5zaW9uLCBnZXRBY3RpdmVFbGVtZW50IH0gZnJvbSAnLi4vLi4vLi4vLi4vLi4vYmFzZS9icm93c2VyL2RvbS5qcyc7XG5pbXBvcnQgeyBtYWluV2luZG93IH0gZnJvbSAnLi4vLi4vLi4vLi4vLi4vYmFzZS9icm93c2VyL3dpbmRvdy5qcyc7XG5pbXBvcnQgeyBEZWZlcnJlZFByb21pc2UsIHJhY2VUaW1lb3V0LCB0aW1lb3V0IH0gZnJvbSAnLi4vLi4vLi4vLi4vLi4vYmFzZS9jb21tb24vYXN5bmMuanMnO1xuaW1wb3J0IHsgZXJyb3JIYW5kbGVyLCBnZXRFcnJvck1lc3NhZ2UsIHNldFVuZXhwZWN0ZWRFcnJvckhhbmRsZXIgfSBmcm9tICcuLi8uLi8uLi8uLi8uLi9iYXNlL2NvbW1vbi9lcnJvcnMuanMnO1xuaW1wb3J0IHsgRW1pdHRlciwgRXZlbnQgfSBmcm9tICcuLi8uLi8uLi8uLi8uLi9iYXNlL2NvbW1vbi9ldmVudC5qcyc7XG5pbXBvcnQgeyBEaXNwb3NhYmxlLCBEaXNwb3NhYmxlU3RvcmUsIHRvRGlzcG9zYWJsZSB9IGZyb20gJy4uLy4uLy4uLy4uLy4uL2Jhc2UvY29tbW9uL2xpZmVjeWNsZS5qcyc7XG5pbXBvcnQgeyBlbnN1cmVOb0Rpc3Bvc2FibGVzQXJlTGVha2VkSW5UZXN0U3VpdGUgfSBmcm9tICcuLi8uLi8uLi8uLi8uLi9iYXNlL3Rlc3QvY29tbW9uL3V0aWxzLmpzJztcbmltcG9ydCB7IFN5bmNEZXNjcmlwdG9yIH0gZnJvbSAnLi4vLi4vLi4vLi4vLi4vcGxhdGZvcm0vaW5zdGFudGlhdGlvbi9jb21tb24vZGVzY3JpcHRvcnMuanMnO1xuaW1wb3J0IHsgSUxvZ1NlcnZpY2UsIE51bGxMb2dTZXJ2aWNlIH0gZnJvbSAnLi4vLi4vLi4vLi4vLi4vcGxhdGZvcm0vbG9nL2NvbW1vbi9sb2cuanMnO1xuaW1wb3J0IHsgSU5vdGlmaWNhdGlvblNlcnZpY2UgfSBmcm9tICcuLi8uLi8uLi8uLi8uLi9wbGF0Zm9ybS9ub3RpZmljYXRpb24vY29tbW9uL25vdGlmaWNhdGlvbi5qcyc7XG5pbXBvcnQgeyBUZXN0Q29uZmlndXJhdGlvblNlcnZpY2UgfSBmcm9tICcuLi8uLi8uLi8uLi8uLi9wbGF0Zm9ybS9jb25maWd1cmF0aW9uL3Rlc3QvY29tbW9uL3Rlc3RDb25maWd1cmF0aW9uU2VydmljZS5qcyc7XG5pbXBvcnQgeyBSZWdpc3RyeSB9IGZyb20gJy4uLy4uLy4uLy4uLy4uL3BsYXRmb3JtL3JlZ2lzdHJ5L2NvbW1vbi9wbGF0Zm9ybS5qcyc7XG5pbXBvcnQgeyBDb252ZXJzYXRpb25QYXJ0LCBJQ29udmVyc2F0aW9uUGFydFNlcnZpY2UsIElDb252ZXJzYXRpb25QYXJ0V2luZG93U2xvdHMgfSBmcm9tICcuLi8uLi8uLi8uLi9icm93c2VyL3BhcnRzL2NvbnZlcnNhdGlvbi9jb252ZXJzYXRpb25QYXJ0LmpzJztcbmltcG9ydCB7IElDb252ZXJzYXRpb25FZGl0b3JQYXJ0LCBJRWRpdG9yR3JvdXBzU2VydmljZSB9IGZyb20gJy4uLy4uLy4uLy4uL3NlcnZpY2VzL2VkaXRvci9jb21tb24vZWRpdG9yR3JvdXBzU2VydmljZS5qcyc7XG5pbXBvcnQgeyBFZGl0b3JTZXJ2aWNlIH0gZnJvbSAnLi4vLi4vLi4vLi4vc2VydmljZXMvZWRpdG9yL2Jyb3dzZXIvZWRpdG9yU2VydmljZS5qcyc7XG5pbXBvcnQgeyBJRWRpdG9yU2VydmljZSB9IGZyb20gJy4uLy4uLy4uLy4uL3NlcnZpY2VzL2VkaXRvci9jb21tb24vZWRpdG9yU2VydmljZS5qcyc7XG5pbXBvcnQgeyBFZGl0b3JFeHRlbnNpb25zLCBJRWRpdG9yRmFjdG9yeVJlZ2lzdHJ5IH0gZnJvbSAnLi4vLi4vLi4vLi4vY29tbW9uL2VkaXRvci5qcyc7XG5pbXBvcnQgeyBjcmVhdGVFZGl0b3JQYXJ0cywgcmVnaXN0ZXJUZXN0RWRpdG9yLCBUZXN0RmlsZUVkaXRvcklucHV0LCB3b3JrYmVuY2hJbnN0YW50aWF0aW9uU2VydmljZSB9IGZyb20gJy4uLy4uLy4uLy4uL3Rlc3QvYnJvd3Nlci93b3JrYmVuY2hUZXN0U2VydmljZXMuanMnO1xuaW1wb3J0IHsgU2lkZUJ5U2lkZUVkaXRvcklucHV0IH0gZnJvbSAnLi4vLi4vLi4vLi4vY29tbW9uL2VkaXRvci9zaWRlQnlTaWRlRWRpdG9ySW5wdXQuanMnO1xuaW1wb3J0ICcuLi8uLi9icm93c2VyL2NvbnZlcnNhdGlvbkVkaXRvci5jb250cmlidXRpb24uanMnO1xuaW1wb3J0IHsgQ29udmVyc2F0aW9uRWRpdG9yUGFuZSB9IGZyb20gJy4uLy4uL2Jyb3dzZXIvY29udmVyc2F0aW9uRWRpdG9yUGFuZS5qcyc7XG5pbXBvcnQgeyBDb252ZXJzYXRpb25TZXNzaW9uQ2hhdENvbnRyaWJ1dGlvbiB9IGZyb20gJy4uLy4uL2Jyb3dzZXIvY29udmVyc2F0aW9uU2Vzc2lvbkNoYXQuY29udHJpYnV0aW9uLmpzJztcbmltcG9ydCB7IENvbnZlcnNhdGlvbk5hdmlnYXRpb25Db250cmlidXRpb24gfSBmcm9tICcuLi8uLi9icm93c2VyL2NvbnZlcnNhdGlvbk5hdmlnYXRpb24uY29udHJpYnV0aW9uLmpzJztcbmltcG9ydCB7IENvbnZlcnNhdGlvbk5hdmlnYXRpb25TZXJ2aWNlLCBJQ29udmVyc2F0aW9uTmF2aWdhdGlvblNlcnZpY2UgfSBmcm9tICcuLi8uLi9icm93c2VyL2NvbnZlcnNhdGlvbk5hdmlnYXRpb25TZXJ2aWNlLmpzJztcbmltcG9ydCB7IENvbnZlcnNhdGlvblNlc3Npb25DaGF0U2VydmljZSwgSUNvbnZlcnNhdGlvblNlc3Npb25DaGF0U2VydmljZSB9IGZyb20gJy4uLy4uL2Jyb3dzZXIvY29udmVyc2F0aW9uU2Vzc2lvbkNoYXRTZXJ2aWNlLmpzJztcbmltcG9ydCB7IHN3aXRjaFRvU2Vzc2lvbiBhcyBzd2l0Y2hUb1Nlc3Npb25IZWxwZXIgfSBmcm9tICcuLi8uLi9icm93c2VyL2NvbnZlcnNhdGlvbkxlbnNTZXNzaW9uQmFyLmpzJztcbmltcG9ydCB7IENvbnZlcnNhdGlvblNlc3Npb25XaW5kb3dTZXJ2aWNlLCBJQ29udmVyc2F0aW9uU2Vzc2lvbldpbmRvd1NlcnZpY2UgfSBmcm9tICcuLi8uLi9icm93c2VyL2NvbnZlcnNhdGlvblNlc3Npb25XaW5kb3dTZXJ2aWNlLmpzJztcbmltcG9ydCB7IENvbnZlcnNhdGlvblN0dWJTZXJ2aWNlLCBJQ29udmVyc2F0aW9uUm9zdGVyU2VydmljZSB9IGZyb20gJy4uLy4uL2Jyb3dzZXIvY29udmVyc2F0aW9uU3R1YlNlcnZpY2UuanMnO1xuaW1wb3J0IHsgQ29udmVyc2F0aW9uV29ya1Jvb3RNb3VudE1vZGVsLCBJQ29udmVyc2F0aW9uV29ya1Jvb3RNb3VudCB9IGZyb20gJy4uLy4uL2Jyb3dzZXIvY29udmVyc2F0aW9uV29ya1Jvb3RNb3VudC5qcyc7XG5pbXBvcnQgeyBJQ29udmVyc2F0aW9uVGltZWxpbmVSZXZlYWxTZXJ2aWNlIH0gZnJvbSAnLi4vLi4vYnJvd3Nlci9jb252ZXJzYXRpb25UaW1lbGluZVJldmVhbFNlcnZpY2UuanMnO1xuaW1wb3J0IHsgSUNvbnZlcnNhdGlvblJldmlld05hdlNlcnZpY2UgfSBmcm9tICcuLi8uLi9icm93c2VyL2NvbnZlcnNhdGlvblJldmlld0VudHJ5LmpzJztcbmltcG9ydCB7IENvbnZlcnNhdGlvbkVuZ2luZVJvc3RlclNlcnZpY2UsIEVOR0lORV9CSU5EX0ZBSUxFRF9TRVNTSU9OX0lELCBpc0VuZ2luZVJvc3RlclBsYWNlaG9sZGVyU2Vzc2lvbklkIH0gZnJvbSAnLi4vLi4vYnJvd3Nlci9jb252ZXJzYXRpb25FbmdpbmVSb3N0ZXJTZXJ2aWNlLmpzJztcbmltcG9ydCB7IGdldENvbnZlcnNhdGlvblNlc3Npb25SZWFkaW5lc3MgfSBmcm9tICcuLi8uLi9icm93c2VyL2NvbnZlcnNhdGlvblNlc3Npb25BdmFpbGFiaWxpdHkuanMnO1xuaW1wb3J0IHsgaXNDb252ZXJzYXRpb25FbmdpbmVMaXZlLCBpc0NvbnZlcnNhdGlvblBhaXJpbmdIb2xkIH0gZnJvbSAnLi4vLi4vYnJvd3Nlci9jb252ZXJzYXRpb25TZXNzaW9uU3RhdHVzLmpzJztcbmltcG9ydCB7IHN0dWJUdXJuc1RvU25hcHNob3QgfSBmcm9tICcuLi8uLi9icm93c2VyL2NvbnZlcnNhdGlvblNlc3Npb25WaWV3LmpzJztcbmltcG9ydCB0eXBlIHsgQ29udmVyc2F0aW9uTGVucyB9IGZyb20gJy4uLy4uL2Jyb3dzZXIvY29udmVyc2F0aW9uTGVucy5qcyc7XG5pbXBvcnQgeyBDb252ZXJzYXRpb25FZGl0b3JQYW5lSWQsIGNvbnZlcnNhdGlvblNlc3Npb25MZWFmSGlkZGVuQ2xhc3MgfSBmcm9tICcuLi8uLi9jb21tb24vY29udmVyc2F0aW9uU2Vzc2lvbldpbmRvdy5qcyc7XG5pbXBvcnQgeyBVQV9DTElFTlRfQ0hBVF9JTlBVVF9BVVRPX0ZPQ1VTIH0gZnJvbSAnLi4vLi4vY29tbW9uL3VhQ2xpZW50U2V0dGluZ3NLZXlzLmpzJztcbmltcG9ydCB7IElVbml2ZXJzZUFnZW50Q29ubmVjdGlvbiB9IGZyb20gJy4uLy4uLy4uLy4uLy4uL3BsYXRmb3JtL3VuaXZlcnNlQWdlbnQvY29tbW9uL3VuaXZlcnNlQWdlbnRDb25uZWN0aW9uLmpzJztcbmltcG9ydCB7IElVbml2ZXJzZUFnZW50U2Vzc2lvblZpZXcsIHR5cGUgSVVuaXZlcnNlQWdlbnRTZXNzaW9uVmlld0ZyYW1lRXZlbnQgfSBmcm9tICcuLi8uLi8uLi8uLi8uLi9wbGF0Zm9ybS91bml2ZXJzZUFnZW50L2NvbW1vbi91bml2ZXJzZUFnZW50U2Vzc2lvblZpZXcuanMnO1xuaW1wb3J0IHR5cGUgeyBWaWV3TGVhc2VJZCB9IGZyb20gJy4uLy4uLy4uLy4uLy4uL3BsYXRmb3JtL3VuaXZlcnNlQWdlbnQvY29tbW9uL3Nlc3Npb25WaWV3L3R5cGVzLmpzJztcbmltcG9ydCB0eXBlIHsgQ29ubmVjdGlvblBoYXNlIH0gZnJvbSAnLi4vLi4vLi4vLi4vLi4vcGxhdGZvcm0vdW5pdmVyc2VBZ2VudC9jb21tb24vY29ubmVjdGlvbkh1YlR5cGVzLmpzJztcbmltcG9ydCB7IENvbnZlcnNhdGlvbkNoYXRJbnB1dCwgZ2V0Q29udmVyc2F0aW9uQ2hhdFJlc291cmNlIH0gZnJvbSAnLi4vLi4vY29tbW9uL2NvbnZlcnNhdGlvbkNoYXRJbnB1dC5qcyc7XG5pbXBvcnQgeyBjcmVhdGVDb252ZXJzYXRpb25Db25uZWN0aW9uVGVzdFN0dWIgfSBmcm9tICcuLi9jb21tb24vY29udmVyc2F0aW9uQ29ubmVjdGlvblRlc3RTdHViLmpzJztcbmltcG9ydCB7IHN0dWJDb252ZXJzYXRpb25UaW1lbGluZUxpbmtTZXJ2aWNlcyB9IGZyb20gJy4vY29udmVyc2F0aW9uVGltZWxpbmVMaW5rVGVzdFN0dWJzLmpzJztcbmltcG9ydCB7IGluc3RhbGxDb252ZXJzYXRpb25MZW5zUmVzaXplT2JzZXJ2ZXJIYXJuZXNzIH0gZnJvbSAnLi9jb252ZXJzYXRpb25MZW5zTGF5b3V0SGFybmVzcy5qcyc7XG5pbXBvcnQgeyBJRXhwbG9yZXJTZXJ2aWNlIH0gZnJvbSAnLi4vLi4vLi4vZmlsZXMvYnJvd3Nlci9maWxlcy5qcyc7XG5pbXBvcnQgeyBJU0NNU2VydmljZSB9IGZyb20gJy4uLy4uLy4uL3NjbS9jb21tb24vc2NtLmpzJztcblxuZGVjbGFyZSBmdW5jdGlvbiBfX3JlYWRGaWxlSW5UZXN0cyhwYXRoOiBzdHJpbmcpOiBQcm9taXNlPHN0cmluZz47XG5cbmNsYXNzIFF1aWV0Um9zdGVyU2VydmljZSBleHRlbmRzIENvbnZlcnNhdGlvblN0dWJTZXJ2aWNlIHtcblx0c2VlZFNlc3Npb25RdWlldGx5KCk6IHN0cmluZyB7XG5cdFx0Y29uc3QgcHJldmlvdXMgPSB0aGlzLm1vZGVsLmdldEFjdGl2ZVNlc3Npb25JZCgpO1xuXHRcdGNvbnN0IHNlc3Npb25JZCA9IHRoaXMubW9kZWwuY3JlYXRlU2Vzc2lvbigpO1xuXHRcdHRoaXMubW9kZWwuc3dpdGNoU2Vzc2lvbihwcmV2aW91cyk7XG5cdFx0dGhpcy5fb25EaWRDaGFuZ2VTZXNzaW9uLmZpcmUoc2Vzc2lvbklkKTtcblx0XHRyZXR1cm4gc2Vzc2lvbklkO1xuXHR9XG5cblx0ZmlyZUFjdGl2ZVNlc3Npb24oc2Vzc2lvbklkOiBzdHJpbmcpOiB2b2lkIHtcblx0XHR0aGlzLl9vbkRpZENoYW5nZUFjdGl2ZVNlc3Npb24uZmlyZShzZXNzaW9uSWQpO1xuXHR9XG5cblx0ZmlyZURlbGV0ZWRTZXNzaW9uKHNlc3Npb25JZDogc3RyaW5nKTogdm9pZCB7XG5cdFx0dGhpcy5fb25EaWREZWxldGVTZXNzaW9uLmZpcmUoc2Vzc2lvbklkKTtcblx0fVxufVxuXG4vKiogUHVibGljIFNlc3Npb25WaWV3IGJvdW5kYXJ5OyBwcm9kdWN0aW9uIEZyYW1lU291cmNlIHN0aWxsIG93bnMgcmVwbGljYXMgYW5kIGZhbm91dC4gKi9cbmNsYXNzIFJldmVhbEVuZ2luZVNlc3Npb25WaWV3IGV4dGVuZHMgRGlzcG9zYWJsZSBpbXBsZW1lbnRzIElVbml2ZXJzZUFnZW50U2Vzc2lvblZpZXcge1xuXHRkZWNsYXJlIHJlYWRvbmx5IF9zZXJ2aWNlQnJhbmQ6IHVuZGVmaW5lZDtcblx0cmVhZG9ubHkgYWNxdWlyZWQ6IHsgbGVhc2VJZDogc3RyaW5nOyBzZXNzaW9uSWQ6IHN0cmluZyB9W10gPSBbXTtcblx0cmVhZG9ubHkgcmVsZWFzZWQgPSBuZXcgU2V0PHN0cmluZz4oKTtcblx0cHJpdmF0ZSByZWFkb25seSBlbWl0dGVycyA9IG5ldyBNYXA8c3RyaW5nLCBFbWl0dGVyPElVbml2ZXJzZUFnZW50U2Vzc2lvblZpZXdGcmFtZUV2ZW50Pj4oKTtcblx0cHJpdmF0ZSByZWFkb25seSB2ZXJzaW9ucyA9IG5ldyBNYXA8c3RyaW5nLCBudW1iZXI+KCk7XG5cdHByaXZhdGUgcmVhZG9ubHkgbGlzdGVuaW5nID0gbmV3IFNldDxzdHJpbmc+KCk7XG5cdHByaXZhdGUgcmVhZG9ubHkgZGlkTGlzdGVuID0gdGhpcy5fcmVnaXN0ZXIobmV3IEVtaXR0ZXI8c3RyaW5nPigpKTtcblx0cmVhZG9ubHkgb25EaWRMaXN0ZW4gPSB0aGlzLmRpZExpc3Rlbi5ldmVudDtcblxuXHRvbkR5bmFtaWNEaWRBcHBseUZyYW1lKGxlYXNlSWQ6IHN0cmluZyk6IEV2ZW50PElVbml2ZXJzZUFnZW50U2Vzc2lvblZpZXdGcmFtZUV2ZW50PiB7XG5cdFx0bGV0IGVtaXR0ZXIgPSB0aGlzLmVtaXR0ZXJzLmdldChsZWFzZUlkKTtcblx0XHRpZiAoIWVtaXR0ZXIpIHtcblx0XHRcdGVtaXR0ZXIgPSB0aGlzLl9yZWdpc3RlcihuZXcgRW1pdHRlcjxJVW5pdmVyc2VBZ2VudFNlc3Npb25WaWV3RnJhbWVFdmVudD4oe1xuXHRcdFx0XHRvbkRpZEFkZEZpcnN0TGlzdGVuZXI6ICgpID0+IHF1ZXVlTWljcm90YXNrKCgpID0+IHtcblx0XHRcdFx0XHR0aGlzLmVtaXRMZWFzZShsZWFzZUlkKTtcblx0XHRcdFx0XHR0aGlzLmxpc3RlbmluZy5hZGQobGVhc2VJZCk7XG5cdFx0XHRcdFx0dGhpcy5kaWRMaXN0ZW4uZmlyZShsZWFzZUlkKTtcblx0XHRcdFx0fSksXG5cdFx0XHR9KSk7XG5cdFx0XHR0aGlzLmVtaXR0ZXJzLnNldChsZWFzZUlkLCBlbWl0dGVyKTtcblx0XHR9XG5cdFx0cmV0dXJuIGVtaXR0ZXIuZXZlbnQ7XG5cdH1cblxuXHRhc3luYyBhY3F1aXJlTGVhc2Uoc2Vzc2lvbklkOiBzdHJpbmcpOiBQcm9taXNlPHN0cmluZz4ge1xuXHRcdGNvbnN0IGxlYXNlSWQgPSBgcmV2ZWFsOiR7c2Vzc2lvbklkfToke3RoaXMuYWNxdWlyZWQubGVuZ3RoICsgMX1gO1xuXHRcdHRoaXMuYWNxdWlyZWQucHVzaCh7IGxlYXNlSWQsIHNlc3Npb25JZCB9KTtcblx0XHRyZXR1cm4gbGVhc2VJZDtcblx0fVxuXHRhc3luYyB3aGVuRW5naW5lU2Vzc2lvblJlYWR5KHNlc3Npb25JZDogc3RyaW5nKTogUHJvbWlzZTxzdHJpbmc+IHsgcmV0dXJuIHNlc3Npb25JZDsgfVxuXHRhc3luYyByZWxlYXNlTGVhc2UobGVhc2VJZDogc3RyaW5nKTogUHJvbWlzZTx2b2lkPiB7IHRoaXMucmVsZWFzZWQuYWRkKGxlYXNlSWQpOyB9XG5cdGFzeW5jIHBvc3QoKTogUHJvbWlzZTxuZXZlcj4geyB0aHJvdyBuZXcgRXJyb3IoJ2xlYXNlIHJlY292ZXJ5IG11c3Qgbm90IHdyaXRlJyk7IH1cblx0YXN5bmMgcmVxdWVzdFJlc3luYygpOiBQcm9taXNlPHZvaWQ+IHsgfVxuXHRhc3luYyBhY2tub3dsZWRnZSgpOiBQcm9taXNlPHZvaWQ+IHsgfVxuXHRhc3luYyByZXF1ZXN0RGV0YWlsKCkgeyByZXR1cm4geyBvazogZmFsc2UgYXMgY29uc3QsIHJlYXNvbjogJ3VuYXZhaWxhYmxlJyBhcyBjb25zdCB9OyB9XG5cblx0aGFzU2Vzc2lvbkxpc3RlbmVyKHNlc3Npb25JZDogc3RyaW5nKTogYm9vbGVhbiB7XG5cdFx0cmV0dXJuIHRoaXMuYWNxdWlyZWQuc29tZShsZWFzZSA9PiBsZWFzZS5zZXNzaW9uSWQgPT09IHNlc3Npb25JZCAmJiB0aGlzLmxpc3RlbmluZy5oYXMobGVhc2UubGVhc2VJZCkgJiYgIXRoaXMucmVsZWFzZWQuaGFzKGxlYXNlLmxlYXNlSWQpKTtcblx0fVxuXG5cdGVtaXRTZXNzaW9uKHNlc3Npb25JZDogc3RyaW5nLCB0ZXh0OiBzdHJpbmcpOiB2b2lkIHtcblx0XHRmb3IgKGNvbnN0IGxlYXNlIG9mIHRoaXMuYWNxdWlyZWQpIHtcblx0XHRcdGlmIChsZWFzZS5zZXNzaW9uSWQgPT09IHNlc3Npb25JZCkge1xuXHRcdFx0XHR0aGlzLmVtaXRMZWFzZShsZWFzZS5sZWFzZUlkLCB0ZXh0KTtcblx0XHRcdH1cblx0XHR9XG5cdH1cblxuXHRwcml2YXRlIGVtaXRMZWFzZShsZWFzZUlkOiBzdHJpbmcsIHRleHQ/OiBzdHJpbmcpOiB2b2lkIHtcblx0XHRjb25zdCBsZWFzZSA9IHRoaXMuYWNxdWlyZWQuZmluZChjYW5kaWRhdGUgPT4gY2FuZGlkYXRlLmxlYXNlSWQgPT09IGxlYXNlSWQpO1xuXHRcdGlmICghbGVhc2UgfHwgdGhpcy5yZWxlYXNlZC5oYXMobGVhc2VJZCkpIHtcblx0XHRcdHJldHVybjtcblx0XHR9XG5cdFx0Y29uc3QgcHJvamVjdGlvbiA9IHN0dWJUdXJuc1RvU25hcHNob3QobGVhc2Uuc2Vzc2lvbklkLCB0ZXh0ID09PSB1bmRlZmluZWQgPyBbXSA6IFtcblx0XHRcdHsgaWQ6IGAke2xlYXNlLnNlc3Npb25JZH0tYm9keWAsIGtpbmQ6ICd1c2VyJywgdGV4dCB9LFxuXHRcdFx0eyBpZDogYCR7bGVhc2Uuc2Vzc2lvbklkfS1wZXJtaXNzaW9uYCwga2luZDogJ2NvbmZpcm1hdGlvbicsIHRleHQ6IGBQZXJtaXNzaW9uIGZvciAke2xlYXNlLnNlc3Npb25JZH1gLCBzdGF0dXM6ICdwZW5kaW5nJyB9LFxuXHRcdF0pO1xuXHRcdGNvbnN0IHZlcnNpb24gPSAodGhpcy52ZXJzaW9ucy5nZXQobGVhc2VJZCkgPz8gMCkgKyAxO1xuXHRcdHRoaXMudmVyc2lvbnMuc2V0KGxlYXNlSWQsIHZlcnNpb24pO1xuXHRcdHRoaXMuZW1pdHRlcnMuZ2V0KGxlYXNlSWQpPy5maXJlKHtcblx0XHRcdGxlYXNlSWQsIHNlc3Npb25JZDogbGVhc2Uuc2Vzc2lvbklkLCBhcHBsaWVkOiB7IGtpbmQ6ICdiYXNlbGluZScgfSxcblx0XHRcdGZyYW1lOiB7XG5cdFx0XHRcdGZyYW1lOiB7IGxlYXNlSWQ6IGxlYXNlSWQgYXMgVmlld0xlYXNlSWQsIGdlbmVyYXRpb246IDEsIGZyYW1lSWQ6IHZlcnNpb24sIHZlcnNpb24sIGJvZHk6IHsga2luZDogJ2Jhc2VsaW5lJywgc25hcHNob3Q6IHsgLi4ucHJvamVjdGlvbi5zbmFwc2hvdCwgc3luYzogeyBraW5kOiAnbGl2ZScgfSB9IH0gfSxcblx0XHRcdFx0YXR0cmlidXRpb246IFsuLi5wcm9qZWN0aW9uLmF0dHJpYnV0aW9uXS5tYXAoKFtpdGVtSWQsIGF0dHJpYnV0aW9uXSkgPT4gKHsgb3A6ICd1cHNlcnRBdHRyaWJ1dGlvbicsIGl0ZW1JZCwgYXR0cmlidXRpb24gfSkpLFxuXHRcdFx0fSxcblx0XHR9KTtcblx0fVxufVxuXG5zdWl0ZSgnQ29udmVyc2F0aW9uIHNlc3Npb24gd2luZG93IHJldmVhbCArIGxlYWYgU2Vzc2lvbkJhciAoQyknLCAoKSA9PiB7XG5cblx0Y29uc3QgVEVTVF9FRElUT1JfSUQgPSAnTXlGaWxlRWRpdG9yRm9yQ29udmVyc2F0aW9uUmV2ZWFsJztcblx0Y29uc3QgVEVTVF9FRElUT1JfSU5QVVRfSUQgPSAndGVzdEVkaXRvcklucHV0Rm9yQ29udmVyc2F0aW9uUmV2ZWFsJztcblxuXHRpbnN0YWxsQ29udmVyc2F0aW9uTGVuc1Jlc2l6ZU9ic2VydmVySGFybmVzcygpO1xuXG5cdGNvbnN0IHN0b3JlID0gZW5zdXJlTm9EaXNwb3NhYmxlc0FyZUxlYWtlZEluVGVzdFN1aXRlKCk7XG5cdGNvbnN0IGRpc3Bvc2FibGVzID0gc3RvcmUgYXMgdW5rbm93biBhcyBEaXNwb3NhYmxlU3RvcmU7XG5cblx0dGVhcmRvd24oYXN5bmMgKCkgPT4ge1xuXHRcdGF3YWl0IG5ldyBQcm9taXNlPHZvaWQ+KHJlc29sdmUgPT4gbWFpbldpbmRvdy5yZXF1ZXN0QW5pbWF0aW9uRnJhbWUoKCkgPT4gbWFpbldpbmRvdy5yZXF1ZXN0QW5pbWF0aW9uRnJhbWUoKCkgPT4gcmVzb2x2ZSgpKSkpO1xuXHR9KTtcblxuXHRzZXR1cChmdW5jdGlvbiAoKSB7XG5cdFx0dGhpcy50aW1lb3V0KDIwXzAwMCk7XG5cdFx0c3RvcmUuYWRkKHJlZ2lzdGVyVGVzdEVkaXRvcihURVNUX0VESVRPUl9JRCwgW25ldyBTeW5jRGVzY3JpcHRvcihUZXN0RmlsZUVkaXRvcklucHV0KSwgbmV3IFN5bmNEZXNjcmlwdG9yKFNpZGVCeVNpZGVFZGl0b3JJbnB1dCldLCBURVNUX0VESVRPUl9JTlBVVF9JRCkpO1xuXHR9KTtcblxuXHRmdW5jdGlvbiBsYXlvdXRQYXJ0cyhwYXJ0czogQXdhaXRlZDxSZXR1cm5UeXBlPHR5cGVvZiBjcmVhdGVFZGl0b3JQYXJ0cz4+KTogdm9pZCB7XG5cdFx0Zm9yIChjb25zdCBwYXJ0IG9mIHBhcnRzLmNvbnZlcnNhdGlvblBhcnRzKSB7XG5cdFx0XHRwYXJ0LmxheW91dCg4MDAsIDYwMCwgMCwgMCk7XG5cdFx0fVxuXHR9XG5cblx0ZnVuY3Rpb24gdHJhY2tFZGl0b3JzKHBhcnRzOiBBd2FpdGVkPFJldHVyblR5cGU8dHlwZW9mIGNyZWF0ZUVkaXRvclBhcnRzPj4pOiB2b2lkIHtcblx0XHRmb3IgKGNvbnN0IHBhcnQgb2YgcGFydHMuY29udmVyc2F0aW9uUGFydHMpIHtcblx0XHRcdGZvciAoY29uc3QgZWRpdG9yIG9mIHBhcnQuYWN0aXZlR3JvdXAuZWRpdG9ycykge1xuXHRcdFx0XHRzdG9yZS5hZGQoZWRpdG9yKTtcblx0XHRcdH1cblx0XHR9XG5cdH1cblxuXHRhc3luYyBmdW5jdGlvbiB3YWl0Rm9yUGFuZShwYXJ0OiBJQ29udmVyc2F0aW9uRWRpdG9yUGFydCwgb3BlbkVycm9yczogdW5rbm93bltdID0gW10sIHBhcnRzPzogQXdhaXRlZDxSZXR1cm5UeXBlPHR5cGVvZiBjcmVhdGVFZGl0b3JQYXJ0cz4+KTogUHJvbWlzZTxDb252ZXJzYXRpb25FZGl0b3JQYW5lPiB7XG5cdFx0YXdhaXQgcGFydC53aGVuUmVhZHk7XG5cdFx0Y29uc3QgZGVhZGxpbmUgPSBEYXRlLm5vdygpICsgMzAwMDtcblx0XHR3aGlsZSAoRGF0ZS5ub3coKSA8IGRlYWRsaW5lKSB7XG5cdFx0XHRjb25zdCBwYW5lID0gcGFydC5hY3RpdmVHcm91cC5hY3RpdmVFZGl0b3JQYW5lO1xuXHRcdFx0aWYgKHBhbmUgaW5zdGFuY2VvZiBDb252ZXJzYXRpb25FZGl0b3JQYW5lKSB7XG5cdFx0XHRcdGlmIChwYXJ0cykge1xuXHRcdFx0XHRcdHRyYWNrRWRpdG9ycyhwYXJ0cyk7XG5cdFx0XHRcdH1cblx0XHRcdFx0cmV0dXJuIHBhbmU7XG5cdFx0XHR9XG5cdFx0XHRhd2FpdCB0aW1lb3V0KDIwKTtcblx0XHR9XG5cdFx0Y29uc3QgZGV0YWlsID0gb3BlbkVycm9ycy5tYXAoZXJyb3IgPT4gZXJyb3IgaW5zdGFuY2VvZiBFcnJvciA/IGVycm9yLnN0YWNrID8/IGVycm9yLm1lc3NhZ2UgOiBTdHJpbmcoZXJyb3IpKS5qb2luKCdcXG4nKTtcblx0XHR0aHJvdyBuZXcgRXJyb3IoYENvbnZlcnNhdGlvbkVkaXRvclBhbmUgbm90IHJlYWR5IGZvciAke3BhcnQuc2Vzc2lvbktleX07IGdvdCAke3BhcnQuYWN0aXZlR3JvdXAuYWN0aXZlRWRpdG9yUGFuZT8uZ2V0SWQoKX0ke2RldGFpbCA/IGBcXG4ke2RldGFpbH1gIDogJyd9YCk7XG5cdH1cblxuXHRmdW5jdGlvbiBwYXJ0Rm9yKHBhcnRzOiBBd2FpdGVkPFJldHVyblR5cGU8dHlwZW9mIGNyZWF0ZUVkaXRvclBhcnRzPj4sIHNlc3Npb25LZXk6IHN0cmluZyk6IElDb252ZXJzYXRpb25FZGl0b3JQYXJ0IHtcblx0XHRjb25zdCBwYXJ0ID0gcGFydHMuY29udmVyc2F0aW9uUGFydHMuZmluZChjYW5kaWRhdGUgPT4gY2FuZGlkYXRlLnNlc3Npb25LZXkgPT09IHNlc3Npb25LZXkpO1xuXHRcdGFzc2VydC5vayhwYXJ0LCBgbWlzc2luZyBwYXJ0ICR7c2Vzc2lvbktleX1gKTtcblx0XHRyZXR1cm4gcGFydDtcblx0fVxuXG5cdGZ1bmN0aW9uIHZpc2libGVMZWFmS2V5cyh3aW5kb3dTZXJ2aWNlOiBDb252ZXJzYXRpb25TZXNzaW9uV2luZG93U2VydmljZSk6IHN0cmluZ1tdIHtcblx0XHRyZXR1cm4gWy4uLndpbmRvd1NlcnZpY2UuZ2V0VmlzaWJsZVNlc3Npb25LZXlzKCldO1xuXHR9XG5cblx0ZnVuY3Rpb24gaGlkZUJ1dHRvbih3aW5kb3dTZXJ2aWNlOiBDb252ZXJzYXRpb25TZXNzaW9uV2luZG93U2VydmljZSwgc2Vzc2lvbktleTogc3RyaW5nKTogSFRNTEJ1dHRvbkVsZW1lbnQgfCBudWxsIHtcblx0XHRyZXR1cm4gd2luZG93U2VydmljZS5nZXRMZWFmU2xvdHMoc2Vzc2lvbktleSk/LnNlc3Npb25CYXIucXVlcnlTZWxlY3RvcignLmNvbnZlcnNhdGlvbi1zZXNzaW9uLWxlYWYtaGlkZScpIGFzIEhUTUxCdXR0b25FbGVtZW50IHwgbnVsbDtcblx0fVxuXG5cdGFzeW5jIGZ1bmN0aW9uIGFzc2VydFdhcm5UaGVuUmV0aHJvd0RvZXNOb3RMZWFrKHBhaW50Qm9vbTogRXJyb3IsIHJ1bjogKCkgPT4gdm9pZCB8IFByb21pc2U8dm9pZD4pOiBQcm9taXNlPHZvaWQ+IHtcblx0XHQvLyBBIGxvbmUgYC5jYXRjaChvblVuZXhwZWN0ZWRFcnJvcilgIHN0aWxsIGxlYWtzIHdoZW4gdGhlIGhhbmRsZXIgd2Fybi10aGVuLXJldGhyb3dzLlxuXHRcdGNvbnN0IHVuZXhwZWN0ZWRXYXJuczogdW5rbm93bltdID0gW107XG5cdFx0Y29uc3QgdW5oYW5kbGVkUmVqZWN0aW9uczogdW5rbm93bltdID0gW107XG5cdFx0Y29uc3Qgb25VbmhhbmRsZWRSZWplY3Rpb24gPSAocmVhc29uOiB1bmtub3duKSA9PiB1bmhhbmRsZWRSZWplY3Rpb25zLnB1c2gocmVhc29uKTtcblx0XHRwcm9jZXNzLm9uKCd1bmhhbmRsZWRSZWplY3Rpb24nLCBvblVuaGFuZGxlZFJlamVjdGlvbik7XG5cdFx0Y29uc3Qgb3JpZ2luYWxFcnJvckhhbmRsZXIgPSBlcnJvckhhbmRsZXIuZ2V0VW5leHBlY3RlZEVycm9ySGFuZGxlcigpO1xuXHRcdHNldFVuZXhwZWN0ZWRFcnJvckhhbmRsZXIoZXJyb3IgPT4ge1xuXHRcdFx0dW5leHBlY3RlZFdhcm5zLnB1c2goZXJyb3IpO1xuXHRcdFx0aWYgKHVuZXhwZWN0ZWRXYXJucy5sZW5ndGggPT09IDEpIHtcblx0XHRcdFx0dGhyb3cgZXJyb3I7XG5cdFx0XHR9XG5cdFx0fSk7XG5cdFx0dHJ5IHtcblx0XHRcdGF3YWl0IHJ1bigpO1xuXHRcdFx0YXdhaXQgdGltZW91dCgwKTtcblx0XHRcdGFzc2VydC5kZWVwU3RyaWN0RXF1YWwoeyB1bmhhbmRsZWRSZWplY3Rpb25zLCB1bmV4cGVjdGVkV2FybnMgfSwge1xuXHRcdFx0XHR1bmhhbmRsZWRSZWplY3Rpb25zOiBbXSxcblx0XHRcdFx0dW5leHBlY3RlZFdhcm5zOiBbcGFpbnRCb29tLCBwYWludEJvb21dLFxuXHRcdFx0fSk7XG5cdFx0fSBmaW5hbGx5IHtcblx0XHRcdHNldFVuZXhwZWN0ZWRFcnJvckhhbmRsZXIob3JpZ2luYWxFcnJvckhhbmRsZXIpO1xuXHRcdFx0cHJvY2Vzcy5vZmYoJ3VuaGFuZGxlZFJlamVjdGlvbicsIG9uVW5oYW5kbGVkUmVqZWN0aW9uKTtcblx0XHR9XG5cdH1cblxuXHRmdW5jdGlvbiBjcmVhdGVMaWdodHdlaWdodFdpbmRvd0hhcm5lc3Mob3B0aW9ucz86IHsgZGVsYXlTbG90cz86IGJvb2xlYW4gfSkge1xuXHRcdGNvbnN0IHJvc3RlclNlcnZpY2UgPSBzdG9yZS5hZGQobmV3IFF1aWV0Um9zdGVyU2VydmljZSgpKTtcblx0XHRjb25zdCBncmlkSG9zdCA9IGRvY3VtZW50LmNyZWF0ZUVsZW1lbnQoJ2RpdicpO1xuXHRcdGRvY3VtZW50LmJvZHkuYXBwZW5kQ2hpbGQoZ3JpZEhvc3QpO1xuXHRcdHN0b3JlLmFkZCh7IGRpc3Bvc2U6ICgpID0+IGdyaWRIb3N0LnJlbW92ZSgpIH0pO1xuXG5cdFx0Y29uc3Qgb25EaWRDcmVhdGVTbG90cyA9IG5ldyBFbWl0dGVyPElDb252ZXJzYXRpb25QYXJ0V2luZG93U2xvdHM+KCk7XG5cdFx0c3RvcmUuYWRkKG9uRGlkQ3JlYXRlU2xvdHMpO1xuXG5cdFx0bGV0IHRocm93T25DcmVhdGUgPSBmYWxzZTtcblx0XHRsZXQgcmVqZWN0V2hlblJlYWR5ID0gZmFsc2U7XG5cdFx0Y29uc3QgY29udmVyc2F0aW9uUGFydHM6IElDb252ZXJzYXRpb25FZGl0b3JQYXJ0W10gPSBbXTtcblx0XHRjb25zdCBlZGl0b3JHcm91cHNTZXJ2aWNlID0ge1xuXHRcdFx0Y3JlYXRlQ29udmVyc2F0aW9uRWRpdG9yUGFydDogKF9wYXJlbnQ6IHVua25vd24sIHNlc3Npb25LZXk6IHN0cmluZykgPT4ge1xuXHRcdFx0XHRpZiAodGhyb3dPbkNyZWF0ZSkge1xuXHRcdFx0XHRcdHRocm93IG5ldyBFcnJvcigncmV2ZWFsIGJvb20nKTtcblx0XHRcdFx0fVxuXHRcdFx0XHRsZXQgd2hlblJlYWR5OiBQcm9taXNlPHZvaWQ+ID0gUHJvbWlzZS5yZXNvbHZlKCk7XG5cdFx0XHRcdGlmIChyZWplY3RXaGVuUmVhZHkpIHtcblx0XHRcdFx0XHRjb25zdCByZWplY3RlZCA9IFByb21pc2UucmVqZWN0KG5ldyBFcnJvcignd2hlblJlYWR5IGJvb20nKSk7XG5cdFx0XHRcdFx0Ly8gS2VlcCB0aGUgcmVqZWN0aW9uIG9ic2VydmVkLiBBd2FpdGVycyBzdGlsbCByZWplY3QuXG5cdFx0XHRcdFx0dm9pZCByZWplY3RlZC5jYXRjaCgoKSA9PiB7IH0pO1xuXHRcdFx0XHRcdHdoZW5SZWFkeSA9IHJlamVjdGVkO1xuXHRcdFx0XHR9XG5cdFx0XHRcdGNvbnN0IHBhcnQgPSB7IHNlc3Npb25LZXksIHdoZW5SZWFkeSwgYWN0aXZlR3JvdXA6IHsgZm9jdXM6ICgpID0+IHsgfSwgYWN0aXZlRWRpdG9yUGFuZTogeyBnZXRJZDogKCkgPT4gQ29udmVyc2F0aW9uRWRpdG9yUGFuZUlkIH0gfSB9IGFzIHVua25vd24gYXMgSUNvbnZlcnNhdGlvbkVkaXRvclBhcnQ7XG5cdFx0XHRcdGNvbnZlcnNhdGlvblBhcnRzLnB1c2gocGFydCk7XG5cdFx0XHRcdHJldHVybiBwYXJ0O1xuXHRcdFx0fSxcblx0XHRcdGRpc3Bvc2VDb252ZXJzYXRpb25FZGl0b3JQYXJ0OiAoc2Vzc2lvbktleTogc3RyaW5nKSA9PiB7XG5cdFx0XHRcdGNvbnN0IGluZGV4ID0gY29udmVyc2F0aW9uUGFydHMuZmluZEluZGV4KHBhcnQgPT4gcGFydC5zZXNzaW9uS2V5ID09PSBzZXNzaW9uS2V5KTtcblx0XHRcdFx0aWYgKGluZGV4ID49IDApIHtcblx0XHRcdFx0XHRjb252ZXJzYXRpb25QYXJ0cy5zcGxpY2UoaW5kZXgsIDEpO1xuXHRcdFx0XHR9XG5cdFx0XHR9LFxuXHRcdFx0c2V0Rm9jdXNlZENvbnZlcnNhdGlvbkxlYWY6ICgpID0+IHsgfSxcblx0XHRcdGdldEZvY3VzZWRDb252ZXJzYXRpb25MZWFmOiAoKSA9PiB1bmRlZmluZWQsXG5cdFx0XHRnZXQgY29udmVyc2F0aW9uUGFydHMoKSB7XG5cdFx0XHRcdHJldHVybiBjb252ZXJzYXRpb25QYXJ0cztcblx0XHRcdH0sXG5cdFx0fSBhcyB1bmtub3duIGFzIElFZGl0b3JHcm91cHNTZXJ2aWNlO1xuXG5cdFx0bGV0IG9uTm90aWZ5RXJyb3I6ICgobWVzc2FnZTogc3RyaW5nIHwgRXJyb3IpID0+IHZvaWQpIHwgdW5kZWZpbmVkO1xuXHRcdGNvbnN0IHNlc3Npb25XaW5kb3dTZXJ2aWNlID0gc3RvcmUuYWRkKG5ldyBDb252ZXJzYXRpb25TZXNzaW9uV2luZG93U2VydmljZShcblx0XHRcdHtcblx0XHRcdFx0b25EaWRDcmVhdGVTbG90czogb25EaWRDcmVhdGVTbG90cy5ldmVudCxcblx0XHRcdFx0b25EaWRGb2N1czogRXZlbnQuTm9uZSxcblx0XHRcdFx0Z2V0U2xvdHM6ICgpID0+IG9wdGlvbnM/LmRlbGF5U2xvdHNcblx0XHRcdFx0XHQ/IHVuZGVmaW5lZFxuXHRcdFx0XHRcdDogeyBzZXNzaW9uQmFyOiBkb2N1bWVudC5jcmVhdGVFbGVtZW50KCdkaXYnKSwgc2Vzc2lvbldpbmRvd0dyaWQ6IGdyaWRIb3N0LCBlZGl0b3JQYXJ0SG9zdDogdW5kZWZpbmVkIH0sXG5cdFx0XHRcdHNldEZvY3VzZWRMZWFmQ29udGFpbmVyOiAoKSA9PiB7IH0sXG5cdFx0XHRcdGZvY3VzOiAoKSA9PiB7IH0sXG5cdFx0XHR9IGFzIHVua25vd24gYXMgSUNvbnZlcnNhdGlvblBhcnRTZXJ2aWNlLFxuXHRcdFx0ZWRpdG9yR3JvdXBzU2VydmljZSxcblx0XHRcdHJvc3RlclNlcnZpY2UsXG5cdFx0XHRuZXcgTnVsbExvZ1NlcnZpY2UoKSxcblx0XHRcdHtcblx0XHRcdFx0ZXJyb3I6IChtZXNzYWdlOiBzdHJpbmcgfCBFcnJvcikgPT4ge1xuXHRcdFx0XHRcdG9uTm90aWZ5RXJyb3I/LihtZXNzYWdlKTtcblx0XHRcdFx0fSxcblx0XHRcdH0gYXMgSU5vdGlmaWNhdGlvblNlcnZpY2UsXG5cdFx0KSk7XG5cblx0XHRyZXR1cm4ge1xuXHRcdFx0c2Vzc2lvbldpbmRvd1NlcnZpY2UsXG5cdFx0XHRyb3N0ZXJTZXJ2aWNlLFxuXHRcdFx0Y29udmVyc2F0aW9uUGFydHMsXG5cdFx0XHRzZXRUaHJvd09uQ3JlYXRlKHZhbHVlOiBib29sZWFuKSB7XG5cdFx0XHRcdHRocm93T25DcmVhdGUgPSB2YWx1ZTtcblx0XHRcdH0sXG5cdFx0XHRzZXRSZWplY3RXaGVuUmVhZHkodmFsdWU6IGJvb2xlYW4pIHtcblx0XHRcdFx0cmVqZWN0V2hlblJlYWR5ID0gdmFsdWU7XG5cdFx0XHR9LFxuXHRcdFx0c2V0Tm90aWZ5RXJyb3IoaGFuZGxlcjogKG1lc3NhZ2U6IHN0cmluZyB8IEVycm9yKSA9PiB2b2lkKSB7XG5cdFx0XHRcdG9uTm90aWZ5RXJyb3IgPSBoYW5kbGVyO1xuXHRcdFx0fSxcblx0XHRcdGF0dGFjaFNsb3RzKCkge1xuXHRcdFx0XHRvbkRpZENyZWF0ZVNsb3RzLmZpcmUoe1xuXHRcdFx0XHRcdHNlc3Npb25CYXI6IGRvY3VtZW50LmNyZWF0ZUVsZW1lbnQoJ2RpdicpLFxuXHRcdFx0XHRcdHNlc3Npb25XaW5kb3dHcmlkOiBncmlkSG9zdCxcblx0XHRcdFx0XHRlZGl0b3JQYXJ0SG9zdDogdW5kZWZpbmVkLFxuXHRcdFx0XHR9KTtcblx0XHRcdH0sXG5cdFx0fTtcblx0fVxuXG5cdGFzeW5jIGZ1bmN0aW9uIGNvbGxlY3RMZWFmQ29udmVyc2F0aW9uTGVuc2VzKHBhcnQ6IElDb252ZXJzYXRpb25FZGl0b3JQYXJ0KTogUHJvbWlzZTxDb252ZXJzYXRpb25MZW5zW10+IHtcblx0XHRjb25zdCBncm91cCA9IHBhcnQuYWN0aXZlR3JvdXA7XG5cdFx0Y29uc3QgbGVuc2VzOiBDb252ZXJzYXRpb25MZW5zW10gPSBbXTtcblx0XHRmb3IgKGNvbnN0IGVkaXRvciBvZiBncm91cC5lZGl0b3JzKSB7XG5cdFx0XHRhd2FpdCBncm91cC5vcGVuRWRpdG9yKGVkaXRvcik7XG5cdFx0XHRjb25zdCBwYW5lID0gZ3JvdXAuYWN0aXZlRWRpdG9yUGFuZTtcblx0XHRcdGFzc2VydC5vayhwYW5lIGluc3RhbmNlb2YgQ29udmVyc2F0aW9uRWRpdG9yUGFuZSwgYG1pc3NpbmcgQ29udmVyc2F0aW9uRWRpdG9yUGFuZSBmb3IgJHtlZGl0b3IucmVzb3VyY2V9YCk7XG5cdFx0XHRjb25zdCBsZW5zID0gcGFuZS5hY3RpdmVDb252ZXJzYXRpb25MZW5zO1xuXHRcdFx0YXNzZXJ0Lm9rKGxlbnMsIGBlYWNoIGNvbnZlcnNhdGlvbiB0YWIgbXVzdCBleHBvc2UgYSBDb252ZXJzYXRpb25MZW5zICgke2VkaXRvci5yZXNvdXJjZX0pYCk7XG5cdFx0XHRsZW5zZXMucHVzaChsZW5zKTtcblx0XHR9XG5cdFx0cmV0dXJuIGxlbnNlcztcblx0fVxuXG5cdGZ1bmN0aW9uIGNvdW50TGVhZkNocm9tZSh3aW5kb3dTZXJ2aWNlOiBDb252ZXJzYXRpb25TZXNzaW9uV2luZG93U2VydmljZSwgY29udmVyc2F0aW9uUGFydDogQ29udmVyc2F0aW9uUGFydCk6IHsgYmFyczogbnVtYmVyOyBuYXZzOiBudW1iZXI7IHBhcnRTbG90QmFyczogbnVtYmVyIH0ge1xuXHRcdGxldCBiYXJzID0gMDtcblx0XHRsZXQgbmF2cyA9IDA7XG5cdFx0Zm9yIChjb25zdCBrZXkgb2Ygd2luZG93U2VydmljZS5nZXRWaXNpYmxlU2Vzc2lvbktleXMoKSkge1xuXHRcdFx0Y29uc3QgbGVhZiA9IHdpbmRvd1NlcnZpY2UuZ2V0TGVhZlNsb3RzKGtleSk7XG5cdFx0XHRhc3NlcnQub2sobGVhZik7XG5cdFx0XHRiYXJzICs9IGxlYWYuY29udGFpbmVyLnF1ZXJ5U2VsZWN0b3JBbGwoJy5jb252ZXJzYXRpb24tbGVucy1zZXNzaW9uLWJhcicpLmxlbmd0aDtcblx0XHRcdG5hdnMgKz0gbGVhZi5jb250YWluZXIucXVlcnlTZWxlY3RvckFsbCgnLmNvbnZlcnNhdGlvbi13aW5kb3ctbmF2JykubGVuZ3RoO1xuXHRcdH1cblx0XHRjb25zdCBwYXJ0U2xvdEJhcnMgPSBjb252ZXJzYXRpb25QYXJ0LmdldFNsb3RzKCk/LnNlc3Npb25CYXIucXVlcnlTZWxlY3RvckFsbCgnLmNvbnZlcnNhdGlvbi1sZW5zLXNlc3Npb24tYmFyJykubGVuZ3RoID8/IDA7XG5cdFx0cmV0dXJuIHsgYmFycywgbmF2cywgcGFydFNsb3RCYXJzIH07XG5cdH1cblxuXHRmdW5jdGlvbiBzdHViTGVuc1J1bnRpbWVTZXJ2aWNlcyhpbnN0YW50aWF0aW9uU2VydmljZTogUmV0dXJuVHlwZTx0eXBlb2Ygd29ya2JlbmNoSW5zdGFudGlhdGlvblNlcnZpY2U+KTogdm9pZCB7XG5cdFx0aW5zdGFudGlhdGlvblNlcnZpY2Uuc3R1YihJQ29udmVyc2F0aW9uV29ya1Jvb3RNb3VudCwgc3RvcmUuYWRkKG5ldyBDb252ZXJzYXRpb25Xb3JrUm9vdE1vdW50TW9kZWwoKSkpO1xuXHRcdGluc3RhbnRpYXRpb25TZXJ2aWNlLnN0dWIoSUNvbnZlcnNhdGlvblRpbWVsaW5lUmV2ZWFsU2VydmljZSwge1xuXHRcdFx0X3NlcnZpY2VCcmFuZDogdW5kZWZpbmVkLFxuXHRcdFx0cmVnaXN0ZXJMZW5zOiAoKSA9PiAoeyBkaXNwb3NlOiAoKSA9PiB7IH0gfSksXG5cdFx0XHRyZXZlYWxJdGVtOiAoKSA9PiB7IH0sXG5cdFx0XHRnZXRBY2Nlc3NpYmxlVHVybkNvbnRlbnQ6ICgpID0+IHVuZGVmaW5lZCxcblx0XHRcdGZvY3VzQWNjZXNzaWJsZVR1cm46ICgpID0+IHsgfSxcblx0XHRcdHNjcm9sbFRvRmlyc3RQZW5kaW5nQ29uZmlybWF0aW9uOiAoKSA9PiB7IH0sXG5cdFx0fSk7XG5cdFx0aW5zdGFudGlhdGlvblNlcnZpY2Uuc3R1YihJQ29udmVyc2F0aW9uUmV2aWV3TmF2U2VydmljZSwge1xuXHRcdFx0X3NlcnZpY2VCcmFuZDogdW5kZWZpbmVkLFxuXHRcdFx0b25EaWRDaGFuZ2U6IEV2ZW50Lk5vbmUsXG5cdFx0XHRnZXRSZXZpZXdOYXZGb3JTZXNzaW9uOiAoKSA9PiBbXSxcblx0XHR9KTtcblx0XHRpbnN0YW50aWF0aW9uU2VydmljZS5zdHViKElFeHBsb3JlclNlcnZpY2UsIHtcblx0XHRcdF9zZXJ2aWNlQnJhbmQ6IHVuZGVmaW5lZCxcblx0XHRcdHNlbGVjdDogYXN5bmMgKCkgPT4geyB9LFxuXHRcdH0gYXMgdW5rbm93biBhcyBJRXhwbG9yZXJTZXJ2aWNlKTtcblx0XHRpbnN0YW50aWF0aW9uU2VydmljZS5zdHViKElTQ01TZXJ2aWNlLCB7XG5cdFx0XHRfc2VydmljZUJyYW5kOiB1bmRlZmluZWQsXG5cdFx0XHRnZXQgcmVwb3NpdG9yaWVzKCkgeyByZXR1cm4gW107IH0sXG5cdFx0XHRnZXQgcmVwb3NpdG9yeUNvdW50KCkgeyByZXR1cm4gMDsgfSxcblx0XHRcdG9uRGlkQWRkUmVwb3NpdG9yeTogRXZlbnQuTm9uZSxcblx0XHRcdG9uRGlkUmVtb3ZlUmVwb3NpdG9yeTogRXZlbnQuTm9uZSxcblx0XHRcdHJlZ2lzdGVyU0NNUHJvdmlkZXI6ICgpID0+IHsgdGhyb3cgbmV3IEVycm9yKCdub3QgaW1wbGVtZW50ZWQnKTsgfSxcblx0XHRcdGdldFJlcG9zaXRvcnk6ICgpID0+IHVuZGVmaW5lZCxcblx0XHR9IGFzIHVua25vd24gYXMgSVNDTVNlcnZpY2UpO1xuXHR9XG5cblx0YXN5bmMgZnVuY3Rpb24gY3JlYXRlUmV2ZWFsSGFybmVzcygpIHtcblx0XHRyZXR1cm4gY3JlYXRlUmV2ZWFsSGFybmVzc1dpdGhSb3N0ZXIoc3RvcmUuYWRkKG5ldyBRdWlldFJvc3RlclNlcnZpY2UoKSksIGNyZWF0ZUNvbnZlcnNhdGlvbkNvbm5lY3Rpb25UZXN0U3R1YigpKTtcblx0fVxuXG5cdGFzeW5jIGZ1bmN0aW9uIGNyZWF0ZVJldmVhbEhhcm5lc3NXaXRoUm9zdGVyPFIgZXh0ZW5kcyBDb252ZXJzYXRpb25TdHViU2VydmljZT4ocm9zdGVyU2VydmljZTogUiwgY29ubmVjdGlvbjogSVVuaXZlcnNlQWdlbnRDb25uZWN0aW9uLCBlbmdpbmUgPSBmYWxzZSkge1xuXHRcdGNvbnN0IG9wZW5FcnJvcnM6IHVua25vd25bXSA9IFtdO1xuXHRcdGNvbnN0IGluc3RhbnRpYXRpb25TZXJ2aWNlID0gd29ya2JlbmNoSW5zdGFudGlhdGlvblNlcnZpY2Uoe1xuXHRcdFx0Y29uZmlndXJhdGlvblNlcnZpY2U6ICgpID0+IG5ldyBUZXN0Q29uZmlndXJhdGlvblNlcnZpY2Uoe1xuXHRcdFx0XHR3b3JrYmVuY2g6IHsgZWRpdG9yOiB7IGVuYWJsZVByZXZpZXc6IGZhbHNlIH0gfSxcblx0XHRcdFx0W1VBX0NMSUVOVF9DSEFUX0lOUFVUX0FVVE9fRk9DVVNdOiBmYWxzZSxcblx0XHRcdH0pLFxuXHRcdH0sIHN0b3JlKTtcblx0XHRpbnN0YW50aWF0aW9uU2VydmljZS5zdHViKElMb2dTZXJ2aWNlLCB7XG5cdFx0XHRlcnJvcjogKGVycm9yOiB1bmtub3duKSA9PiB7IG9wZW5FcnJvcnMucHVzaChlcnJvcik7IH0sXG5cdFx0XHR3YXJuOiAoKSA9PiB7IH0sXG5cdFx0XHRpbmZvOiAoKSA9PiB7IH0sXG5cdFx0XHR0cmFjZTogKCkgPT4geyB9LFxuXHRcdFx0ZGVidWc6ICgpID0+IHsgfSxcblx0XHRcdGZsdXNoOiAoKSA9PiB7IH0sXG5cdFx0XHRnZXRMZXZlbDogKCkgPT4gMCxcblx0XHRcdHNldExldmVsOiAoKSA9PiB7IH0sXG5cdFx0XHRvbkRpZENoYW5nZUxvZ0xldmVsOiBFdmVudC5Ob25lLFxuXHRcdH0gYXMgdW5rbm93biBhcyBJTG9nU2VydmljZSk7XG5cdFx0aW5zdGFudGlhdGlvblNlcnZpY2Uuc3R1YihJQ29udmVyc2F0aW9uUm9zdGVyU2VydmljZSwgcm9zdGVyU2VydmljZSk7XG5cdFx0aW5zdGFudGlhdGlvblNlcnZpY2Uuc3R1YihJVW5pdmVyc2VBZ2VudENvbm5lY3Rpb24sIGNvbm5lY3Rpb24pO1xuXHRcdHN0dWJMZW5zUnVudGltZVNlcnZpY2VzKGluc3RhbnRpYXRpb25TZXJ2aWNlKTtcblx0XHRzdHViQ29udmVyc2F0aW9uVGltZWxpbmVMaW5rU2VydmljZXMoaW5zdGFudGlhdGlvblNlcnZpY2UpO1xuXHRcdGluc3RhbnRpYXRpb25TZXJ2aWNlLmludm9rZUZ1bmN0aW9uKGFjY2Vzc29yID0+IFJlZ2lzdHJ5LmFzPElFZGl0b3JGYWN0b3J5UmVnaXN0cnk+KEVkaXRvckV4dGVuc2lvbnMuRWRpdG9yRmFjdG9yeSkuc3RhcnQoYWNjZXNzb3IpKTtcblxuXHRcdGNvbnN0IHBhcnRzID0gYXdhaXQgY3JlYXRlRWRpdG9yUGFydHMoaW5zdGFudGlhdGlvblNlcnZpY2UsIGRpc3Bvc2FibGVzKTtcblx0XHRzdG9yZS5hZGQocGFydHMpO1xuXHRcdGluc3RhbnRpYXRpb25TZXJ2aWNlLnN0dWIoSUVkaXRvckdyb3Vwc1NlcnZpY2UsIHBhcnRzKTtcblx0XHRjb25zdCBlZGl0b3JTZXJ2aWNlID0gZGlzcG9zYWJsZXMuYWRkKGluc3RhbnRpYXRpb25TZXJ2aWNlLmNyZWF0ZUluc3RhbmNlKEVkaXRvclNlcnZpY2UsIHVuZGVmaW5lZCkpO1xuXHRcdGluc3RhbnRpYXRpb25TZXJ2aWNlLnN0dWIoSUVkaXRvclNlcnZpY2UsIGVkaXRvclNlcnZpY2UpO1xuXG5cdFx0Y29uc3QgY29udmVyc2F0aW9uUGFydCA9IHN0b3JlLmFkZChpbnN0YW50aWF0aW9uU2VydmljZS5jcmVhdGVJbnN0YW5jZShDb252ZXJzYXRpb25QYXJ0KSk7XG5cdFx0Y29uc3QgcGFyZW50ID0gZG9jdW1lbnQuY3JlYXRlRWxlbWVudCgnZGl2Jyk7XG5cdFx0ZG9jdW1lbnQuYm9keS5hcHBlbmRDaGlsZChwYXJlbnQpO1xuXHRcdHN0b3JlLmFkZCh7IGRpc3Bvc2U6ICgpID0+IHBhcmVudC5yZW1vdmUoKSB9KTtcblx0XHRjb252ZXJzYXRpb25QYXJ0LmNyZWF0ZShwYXJlbnQpO1xuXHRcdGluc3RhbnRpYXRpb25TZXJ2aWNlLnN0dWIoSUNvbnZlcnNhdGlvblBhcnRTZXJ2aWNlLCBjb252ZXJzYXRpb25QYXJ0KTtcblxuXHRcdGNvbnN0IHNlc3Npb25DaGF0U2VydmljZSA9IGRpc3Bvc2FibGVzLmFkZChpbnN0YW50aWF0aW9uU2VydmljZS5jcmVhdGVJbnN0YW5jZShDb252ZXJzYXRpb25TZXNzaW9uQ2hhdFNlcnZpY2UpKTtcblx0XHRpbnN0YW50aWF0aW9uU2VydmljZS5zdHViKElDb252ZXJzYXRpb25TZXNzaW9uQ2hhdFNlcnZpY2UsIHNlc3Npb25DaGF0U2VydmljZSk7XG5cdFx0Y29uc3Qgc2Vzc2lvbldpbmRvd1NlcnZpY2UgPSBkaXNwb3NhYmxlcy5hZGQoaW5zdGFudGlhdGlvblNlcnZpY2UuY3JlYXRlSW5zdGFuY2UoQ29udmVyc2F0aW9uU2Vzc2lvbldpbmRvd1NlcnZpY2UpKTtcblx0XHRpbnN0YW50aWF0aW9uU2VydmljZS5zdHViKElDb252ZXJzYXRpb25TZXNzaW9uV2luZG93U2VydmljZSwgc2Vzc2lvbldpbmRvd1NlcnZpY2UpO1xuXHRcdGNvbnN0IG5hdmlnYXRpb25TZXJ2aWNlID0gZGlzcG9zYWJsZXMuYWRkKGluc3RhbnRpYXRpb25TZXJ2aWNlLmNyZWF0ZUluc3RhbmNlKENvbnZlcnNhdGlvbk5hdmlnYXRpb25TZXJ2aWNlKSk7XG5cdFx0aW5zdGFudGlhdGlvblNlcnZpY2Uuc3R1YihJQ29udmVyc2F0aW9uTmF2aWdhdGlvblNlcnZpY2UsIG5hdmlnYXRpb25TZXJ2aWNlKTtcblxuXHRcdHN0b3JlLmFkZChpbnN0YW50aWF0aW9uU2VydmljZS5jcmVhdGVJbnN0YW5jZShDb252ZXJzYXRpb25TZXNzaW9uQ2hhdENvbnRyaWJ1dGlvbikpO1xuXHRcdHN0b3JlLmFkZChpbnN0YW50aWF0aW9uU2VydmljZS5jcmVhdGVJbnN0YW5jZShDb252ZXJzYXRpb25OYXZpZ2F0aW9uQ29udHJpYnV0aW9uKSk7XG5cblx0XHRjb25zdCBwcmltYXJ5SWQgPSByb3N0ZXJTZXJ2aWNlLmdldEFjdGl2ZVNlc3Npb25JZCgpO1xuXHRcdGF3YWl0IHNlc3Npb25XaW5kb3dTZXJ2aWNlLmVuc3VyZVByaW1hcnlXaW5kb3cocHJpbWFyeUlkKTtcblx0XHRjb25zdCBwcmltYXJ5UGFydCA9IHBhcnRGb3IocGFydHMsIHByaW1hcnlJZCk7XG5cdFx0aWYgKGVuZ2luZSkge1xuXHRcdFx0YXdhaXQgd2FpdEZvckVuZ2luZVBhbmUocHJpbWFyeVBhcnQsIG9wZW5FcnJvcnMpO1xuXHRcdH0gZWxzZSB7XG5cdFx0XHRhd2FpdCB3YWl0Rm9yUGFuZShwcmltYXJ5UGFydCwgb3BlbkVycm9ycywgcGFydHMpO1xuXHRcdH1cblx0XHRsYXlvdXRQYXJ0cyhwYXJ0cyk7XG5cdFx0dHJhY2tFZGl0b3JzKHBhcnRzKTtcblxuXHRcdHJldHVybiB7IGluc3RhbnRpYXRpb25TZXJ2aWNlLCBlZGl0b3JTZXJ2aWNlLCBwYXJ0cywgY29udmVyc2F0aW9uUGFydCwgcm9zdGVyU2VydmljZSwgc2Vzc2lvbldpbmRvd1NlcnZpY2UsIHNlc3Npb25DaGF0U2VydmljZSwgcHJpbWFyeUlkLCBvcGVuRXJyb3JzIH07XG5cdH1cblxuXHRhc3luYyBmdW5jdGlvbiBib3VuZGVkPFQ+KHByb21pc2U6IFByb21pc2U8VD4sIG1lc3NhZ2U6IHN0cmluZyk6IFByb21pc2U8VD4ge1xuXHRcdGNvbnN0IHJlc3VsdCA9IGF3YWl0IHJhY2VUaW1lb3V0KHByb21pc2UudGhlbih2YWx1ZSA9PiAoeyB2YWx1ZSB9KSksIDMwMDApO1xuXHRcdGFzc2VydC5vayhyZXN1bHQsIG1lc3NhZ2UpO1xuXHRcdHJldHVybiByZXN1bHQudmFsdWU7XG5cdH1cblxuXHRhc3luYyBmdW5jdGlvbiB3YWl0Rm9yRW5naW5lUGFuZShwYXJ0OiBJQ29udmVyc2F0aW9uRWRpdG9yUGFydCwgb3BlbkVycm9yczogcmVhZG9ubHkgdW5rbm93bltdID0gW10pOiBQcm9taXNlPENvbnZlcnNhdGlvbkVkaXRvclBhbmU+IHtcblx0XHR0cnkge1xuXHRcdFx0YXdhaXQgYm91bmRlZChwYXJ0LndoZW5SZWFkeSwgJ2VuZ2luZSBsZWFmIHBhcnQgbXVzdCBiZWNvbWUgcmVhZHknKTtcblx0XHRcdGlmICghKHBhcnQuYWN0aXZlR3JvdXAuYWN0aXZlRWRpdG9yUGFuZSBpbnN0YW5jZW9mIENvbnZlcnNhdGlvbkVkaXRvclBhbmUpKSB7XG5cdFx0XHRcdGNvbnN0IHJlYWR5ID0gRXZlbnQudG9Qcm9taXNlKEV2ZW50LmZpbHRlcihwYXJ0LmFjdGl2ZUdyb3VwLm9uRGlkQWN0aXZlRWRpdG9yQ2hhbmdlLFxuXHRcdFx0XHRcdCgpID0+IHBhcnQuYWN0aXZlR3JvdXAuYWN0aXZlRWRpdG9yUGFuZSBpbnN0YW5jZW9mIENvbnZlcnNhdGlvbkVkaXRvclBhbmUpKTtcblx0XHRcdFx0dHJ5IHtcblx0XHRcdFx0XHRhd2FpdCBib3VuZGVkKHJlYWR5LCAncmVhbCBlbmdpbmUgQ29udmVyc2F0aW9uRWRpdG9yUGFuZSBtdXN0IG9wZW4nKTtcblx0XHRcdFx0fSBmaW5hbGx5IHtcblx0XHRcdFx0XHRyZWFkeS5jYW5jZWwoKTtcblx0XHRcdFx0fVxuXHRcdFx0fVxuXHRcdFx0Y29uc3QgcGFuZSA9IHBhcnQuYWN0aXZlR3JvdXAuYWN0aXZlRWRpdG9yUGFuZTtcblx0XHRcdGFzc2VydC5vayhwYW5lIGluc3RhbmNlb2YgQ29udmVyc2F0aW9uRWRpdG9yUGFuZSk7XG5cdFx0XHRyZXR1cm4gcGFuZTtcblx0XHR9IGNhdGNoIChlcnJvcikge1xuXHRcdFx0dHJ5IHtcblx0XHRcdFx0aWYgKGVycm9yIGluc3RhbmNlb2YgRXJyb3IpIHtcblx0XHRcdFx0XHRjb25zdCBvcmlnaW5hbFN0YWNrID0gZXJyb3Iuc3RhY2s7XG5cdFx0XHRcdFx0Y29uc3QgZ3JvdXAgPSBwYXJ0LmFjdGl2ZUdyb3VwO1xuXHRcdFx0XHRcdGNvbnN0IGFjdGl2ZUVkaXRvciA9IGdyb3VwLmFjdGl2ZUVkaXRvcjtcblx0XHRcdFx0XHRjb25zdCBhY3RpdmVQYW5lID0gZ3JvdXAuYWN0aXZlRWRpdG9yUGFuZTtcblx0XHRcdFx0XHRjb25zdCBkaWFnbm9zdGljcyA9IEpTT04uc3RyaW5naWZ5KHtcblx0XHRcdFx0XHRcdHBhcnQ6IHsgd2luZG93SWQ6IHBhcnQud2luZG93SWQsIHNlc3Npb25LZXk6IHBhcnQuc2Vzc2lvbktleSB9LFxuXHRcdFx0XHRcdFx0Z3JvdXBJZDogZ3JvdXAuaWQsXG5cdFx0XHRcdFx0XHRhY3RpdmVFZGl0b3JSZXNvdXJjZTogYWN0aXZlRWRpdG9yPy5yZXNvdXJjZT8udG9TdHJpbmcoKSA/PyBudWxsLFxuXHRcdFx0XHRcdFx0YWN0aXZlUGFuZUlkOiBhY3RpdmVQYW5lPy5nZXRJZCgpID8/IG51bGwsXG5cdFx0XHRcdFx0XHRhY3RpdmVQYW5lSXNDb252ZXJzYXRpb25FZGl0b3JQYW5lOiBhY3RpdmVQYW5lIGluc3RhbmNlb2YgQ29udmVyc2F0aW9uRWRpdG9yUGFuZSxcblx0XHRcdFx0XHRcdG9wZW5FcnJvcnM6IG9wZW5FcnJvcnMubWFwKG9wZW5FcnJvciA9PiBvcGVuRXJyb3IgaW5zdGFuY2VvZiBFcnJvclxuXHRcdFx0XHRcdFx0XHQ/IHsgdHlwZTogb3BlbkVycm9yLm5hbWUsIG1lc3NhZ2U6IG9wZW5FcnJvci5tZXNzYWdlLCBzdGFjazogb3BlbkVycm9yLnN0YWNrID8/IG51bGwgfVxuXHRcdFx0XHRcdFx0XHQ6IHsgdHlwZTogdHlwZW9mIG9wZW5FcnJvciwgbWVzc2FnZTogU3RyaW5nKG9wZW5FcnJvciksIHN0YWNrOiBudWxsIH0pXG5cdFx0XHRcdFx0fSwgbnVsbCwgMik7XG5cdFx0XHRcdFx0T2JqZWN0LmRlZmluZVByb3BlcnR5KGVycm9yLCAnc3RhY2snLCB7XG5cdFx0XHRcdFx0XHR2YWx1ZTogYCR7b3JpZ2luYWxTdGFjayA/PyBgJHtlcnJvci5uYW1lfTogJHtlcnJvci5tZXNzYWdlfWB9XFxuRW5naW5lIFBhbmUgc2V0dXAgZGlhZ25vc3RpY3M6ICR7ZGlhZ25vc3RpY3N9YFxuXHRcdFx0XHRcdH0pO1xuXHRcdFx0XHR9XG5cdFx0XHR9IGNhdGNoIHtcblx0XHRcdFx0Ly8gS2VlcCB0aGUgb3JpZ2luYWwgZmFpbHVyZSBpZiBkaWFnbm9zdGljcyBjYW5ub3QgYmUgcmVhZCwgZm9ybWF0dGVkLCBvciBhcHBlbmRlZC5cblx0XHRcdH1cblx0XHRcdHRocm93IGVycm9yO1xuXHRcdH1cblx0fVxuXG5cdGFzeW5jIGZ1bmN0aW9uIGNyZWF0ZUVuZ2luZVJldmVhbEhhcm5lc3MoYmVmb3JlUGFuZT86IChyb3N0ZXI6IENvbnZlcnNhdGlvbkVuZ2luZVJvc3RlclNlcnZpY2UpID0+IHZvaWQpIHtcblx0XHR0eXBlIENhdGFsb2cgPSBBd2FpdGVkPFJldHVyblR5cGU8SVVuaXZlcnNlQWdlbnRDb25uZWN0aW9uWydsaXN0U2Vzc2lvbnMnXT4+O1xuXHRcdGNvbnN0IHJlcXVlc3RzOiB7IHN0YXJ0ZWQ6IERlZmVycmVkUHJvbWlzZTx2b2lkPjsgcmVzdWx0OiBEZWZlcnJlZFByb21pc2U8Q2F0YWxvZz4gfVtdID0gW107XG5cdFx0Y29uc3QgYWxsUmVxdWVzdHM6IHR5cGVvZiByZXF1ZXN0cyA9IFtdO1xuXHRcdGxldCBwaGFzZTogQ29ubmVjdGlvblBoYXNlID0geyBraW5kOiAnZGlzY29ubmVjdGVkJyB9O1xuXHRcdGxldCBwYWlyaW5nUGVuZGluZyA9IGZhbHNlO1xuXHRcdGNvbnN0IGNvbm5lY3Rpb25FbWl0dGVyID0gc3RvcmUuYWRkKG5ldyBFbWl0dGVyPFJldHVyblR5cGU8SVVuaXZlcnNlQWdlbnRDb25uZWN0aW9uWydnZXRDb25uZWN0aW9uU25hcHNob3QnXT4+KCkpO1xuXHRcdGNvbnN0IGJhc2UgPSBjcmVhdGVDb252ZXJzYXRpb25Db25uZWN0aW9uVGVzdFN0dWIoKTtcblx0XHRjb25zdCBjb25uZWN0aW9uID0gY3JlYXRlQ29udmVyc2F0aW9uQ29ubmVjdGlvblRlc3RTdHViKHtcblx0XHRcdGlzRW5naW5lQ29ubmVjdGVkOiAoKSA9PiBpc0NvbnZlcnNhdGlvbkVuZ2luZUxpdmUocGhhc2UsIHBhaXJpbmdQZW5kaW5nKSxcblx0XHRcdGdldENvbm5lY3Rpb25QaGFzZTogKCkgPT4gcGhhc2UsXG5cdFx0XHRnZXRUcmFuc3BvcnRTdGF0ZTogKCkgPT4gJ29rJyxcblx0XHRcdGdldENvbm5lY3Rpb25TbmFwc2hvdDogKCkgPT4gKHsgLi4uYmFzZS5nZXRDb25uZWN0aW9uU25hcHNob3QoKSwgdHJhbnNwb3J0OiAnb2snLCBjaGFubmVsQWxpdmU6IHBoYXNlLmtpbmQgIT09ICdkaXNjb25uZWN0ZWQnLCBwYWlyaW5nUGVuZGluZywgZW5naW5lSWRlbnRpdHlJZDogJ3JldmVhbC1lbmdpbmUnLCBsaW5rSWQ6IDEgfSksXG5cdFx0XHRvbkRpZENoYW5nZUNvbm5lY3Rpb246IGNvbm5lY3Rpb25FbWl0dGVyLmV2ZW50LFxuXHRcdFx0bGlzdFNlc3Npb25zOiAoKSA9PiB7XG5cdFx0XHRcdGNvbnN0IHJlcXVlc3QgPSByZXF1ZXN0cy5zaGlmdCgpO1xuXHRcdFx0XHRhc3NlcnQub2socmVxdWVzdCwgJ2V2ZXJ5IHJlYWwgY2F0YWxvZyByZXF1ZXN0IG11c3QgaGF2ZSBhbiBleHBsaWNpdCBEZWZlcnJlZCcpO1xuXHRcdFx0XHR2b2lkIHJlcXVlc3Quc3RhcnRlZC5jb21wbGV0ZSgpO1xuXHRcdFx0XHRyZXR1cm4gcmVxdWVzdC5yZXN1bHQucDtcblx0XHRcdH0sXG5cdFx0fSk7XG5cdFx0Y29uc3Qgc2Vzc2lvblZpZXcgPSBzdG9yZS5hZGQobmV3IFJldmVhbEVuZ2luZVNlc3Npb25WaWV3KCkpO1xuXHRcdGNvbnN0IHJvc3RlclNlcnZpY2UgPSBzdG9yZS5hZGQobmV3IENvbnZlcnNhdGlvbkVuZ2luZVJvc3RlclNlcnZpY2UoY29ubmVjdGlvbiwgc2Vzc2lvblZpZXcsIHsgX3NlcnZpY2VCcmFuZDogdW5kZWZpbmVkLCBzaG91bGRBZHZlcnRpc2U6ICgpID0+IHRydWUgfSkpO1xuXHRcdC8vIEV2ZXJ5IHBlbmRpbmcgbGlzdCBzZXR0bGVzIGJlZm9yZSBzZXJ2aWNlIHRlYXJkb3duLCBpbmNsdWRpbmcgZmFpbGVkIHNldHVwIHBhdGhzLlxuXHRcdHN0b3JlLmFkZCh0b0Rpc3Bvc2FibGUoKCkgPT4ge1xuXHRcdFx0Zm9yIChjb25zdCByZXF1ZXN0IG9mIGFsbFJlcXVlc3RzKSB7XG5cdFx0XHRcdGlmICghcmVxdWVzdC5yZXN1bHQuaXNTZXR0bGVkKSB7XG5cdFx0XHRcdFx0dm9pZCByZXF1ZXN0LnJlc3VsdC5jb21wbGV0ZSh7IHNlc3Npb25zOiBbXSB9KTtcblx0XHRcdFx0fVxuXHRcdFx0fVxuXHRcdH0pKTtcblx0XHRjb25zdCBkZWZlckNhdGFsb2cgPSAoKSA9PiB7XG5cdFx0XHRjb25zdCByZXF1ZXN0ID0geyBzdGFydGVkOiBuZXcgRGVmZXJyZWRQcm9taXNlPHZvaWQ+KCksIHJlc3VsdDogbmV3IERlZmVycmVkUHJvbWlzZTxDYXRhbG9nPigpIH07XG5cdFx0XHRyZXF1ZXN0cy5wdXNoKHJlcXVlc3QpO1xuXHRcdFx0YWxsUmVxdWVzdHMucHVzaChyZXF1ZXN0KTtcblx0XHRcdHJldHVybiByZXF1ZXN0O1xuXHRcdH07XG5cdFx0Y29uc3Qgbm90aWZ5ID0gKGtpbmQ6ICdsaXZlJyB8ICdkaXNjb25uZWN0ZWQnIHwgJ2Nvbm5lY3RlZCBwYWlyaW5nJyB8ICdjb25uZWN0aW5nIHBhaXJpbmcnKSA9PiB7XG5cdFx0XHRwYWlyaW5nUGVuZGluZyA9IGtpbmQgPT09ICdjb25uZWN0ZWQgcGFpcmluZycgfHwga2luZCA9PT0gJ2Nvbm5lY3RpbmcgcGFpcmluZyc7XG5cdFx0XHRwaGFzZSA9IGtpbmQgPT09ICdkaXNjb25uZWN0ZWQnID8geyBraW5kOiAnZGlzY29ubmVjdGVkJyB9XG5cdFx0XHRcdDoga2luZCA9PT0gJ2Nvbm5lY3RpbmcgcGFpcmluZycgPyB7IGtpbmQ6ICdjb25uZWN0aW5nJywgcmVhc29uOiAnaW5pdGlhbCcgfVxuXHRcdFx0XHRcdDogeyBraW5kOiAnY29ubmVjdGVkJywgcGF0aDogJ2xvb3BiYWNrJyB9O1xuXHRcdFx0Y29ubmVjdGlvbkVtaXR0ZXIuZmlyZShjb25uZWN0aW9uLmdldENvbm5lY3Rpb25TbmFwc2hvdCgpKTtcblx0XHR9O1xuXHRcdGNvbnN0IGNhdGFsb2c6IENhdGFsb2cgPSB7IHNlc3Npb25zOiBbeyBzZXNzaW9uSWQ6ICdsZWFzZS1zMScsIHRpdGxlOiAnTGVhc2UgczEnIH0sIHsgc2Vzc2lvbklkOiAnbGVhc2UtczInLCB0aXRsZTogJ0xlYXNlIHMyJyB9XSB9O1xuXHRcdGNvbnN0IGluaXRpYWwgPSBkZWZlckNhdGFsb2coKTtcblx0XHRub3RpZnkoJ2xpdmUnKTtcblx0XHRhd2FpdCBib3VuZGVkKGluaXRpYWwuc3RhcnRlZC5wLCAnaW5pdGlhbCByZWFsIGNhdGFsb2cgbXVzdCBzdGFydCcpO1xuXHRcdGF3YWl0IGluaXRpYWwucmVzdWx0LmNvbXBsZXRlKGNhdGFsb2cpO1xuXHRcdGF3YWl0IGJvdW5kZWQocm9zdGVyU2VydmljZS53aGVuRW5naW5lQ2F0YWxvZ1JlZnJlc2hDb21wbGV0ZSgpLCAnaW5pdGlhbCByZWFsIGNhdGFsb2cgbXVzdCBmaW5pc2gnKTtcblx0XHRhc3NlcnQuc3RyaWN0RXF1YWwoZ2V0Q29udmVyc2F0aW9uU2Vzc2lvblJlYWRpbmVzcyhyb3N0ZXJTZXJ2aWNlKSwgJ3JlYWR5Jyk7XG5cdFx0YmVmb3JlUGFuZT8uKHJvc3RlclNlcnZpY2UpO1xuXHRcdGNvbnN0IGhhcm5lc3MgPSBhd2FpdCBjcmVhdGVSZXZlYWxIYXJuZXNzV2l0aFJvc3Rlcihyb3N0ZXJTZXJ2aWNlLCBjb25uZWN0aW9uLCB0cnVlKTtcblx0XHRjb25zdCBwYW5lID0gYXdhaXQgd2FpdEZvckVuZ2luZVBhbmUocGFydEZvcihoYXJuZXNzLnBhcnRzLCBoYXJuZXNzLnByaW1hcnlJZCksIGhhcm5lc3Mub3BlbkVycm9ycyk7XG5cdFx0Y29uc3QgbGVucyA9IHBhbmUuYWN0aXZlQ29udmVyc2F0aW9uTGVucztcblx0XHRhc3NlcnQub2sobGVucyk7XG5cdFx0YXNzZXJ0Lm9rKGxlbnMuc2Vzc2lvblZpZXdMZWFzZSwgJ2luaXRpYWwgcmVhbCB2aXNpYmxlIG93bmVyIG11c3QgaGF2ZSBhIGxlYXNlJyk7XG5cdFx0aWYgKGxlbnMuc2Vzc2lvblZpZXdMZWFzZS5zbmFwc2hvdC5zZXNzaW9uSWQgIT09IGhhcm5lc3MucHJpbWFyeUlkKSB7XG5cdFx0XHRjb25zdCBiYXNlbGluZSA9IEV2ZW50LnRvUHJvbWlzZShsZW5zLnNlc3Npb25WaWV3TGVhc2Uub25EaWRBcHBseUZyYW1lKTtcblx0XHRcdHRyeSB7XG5cdFx0XHRcdGF3YWl0IGJvdW5kZWQoYmFzZWxpbmUsICdpbml0aWFsIGhvc3QgYmFzZWxpbmUgbXVzdCByZWFjaCB0aGUgUGFuZSBsZWFzZScpO1xuXHRcdFx0fSBmaW5hbGx5IHtcblx0XHRcdFx0YmFzZWxpbmUuY2FuY2VsKCk7XG5cdFx0XHR9XG5cdFx0fVxuXHRcdGFzc2VydC5zdHJpY3RFcXVhbChsZW5zLnNlc3Npb25WaWV3TGVhc2Uuc25hcHNob3Quc2Vzc2lvbklkLCBoYXJuZXNzLnByaW1hcnlJZCk7XG5cdFx0cmV0dXJuIHsgLi4uaGFybmVzcywgcGFuZSwgbGVucywgY29ubmVjdGlvbiwgc2Vzc2lvblZpZXcsIGRlZmVyQ2F0YWxvZywgbm90aWZ5LCBjYXRhbG9nIH07XG5cdH1cblxuXHR0eXBlIEVuZ2luZVJldmVhbEhhcm5lc3MgPSBBd2FpdGVkPFJldHVyblR5cGU8dHlwZW9mIGNyZWF0ZUVuZ2luZVJldmVhbEhhcm5lc3M+PjtcblxuXHRmdW5jdGlvbiBhc3NlcnRWaXNpYmxlTWlzc2luZyhoYXJuZXNzOiBFbmdpbmVSZXZlYWxIYXJuZXNzLCBwYW5lID0gaGFybmVzcy5wYW5lLCBrZXkgPSBoYXJuZXNzLnByaW1hcnlJZCk6IENvbnZlcnNhdGlvbkxlbnMge1xuXHRcdGNvbnN0IGxlbnMgPSBwYW5lLmFjdGl2ZUNvbnZlcnNhdGlvbkxlbnM7XG5cdFx0YXNzZXJ0Lm9rKGxlbnMpO1xuXHRcdGFzc2VydC5zdHJpY3RFcXVhbChsZW5zLmJvdW5kU2Vzc2lvbklkLCBrZXkpO1xuXHRcdGFzc2VydC5zdHJpY3RFcXVhbChsZW5zLmlzRGlzcG9zZWQsIGZhbHNlKTtcblx0XHRhc3NlcnQuc3RyaWN0RXF1YWwoaGFybmVzcy5zZXNzaW9uV2luZG93U2VydmljZS5pc1Nlc3Npb25XaW5kb3dWaXNpYmxlKGtleSksIHRydWUpO1xuXHRcdGFzc2VydC5zdHJpY3RFcXVhbChsZW5zLnNlc3Npb25WaWV3QmluZGluZ1N1c3BlbmRlZCwgZmFsc2UpO1xuXHRcdGFzc2VydC5zdHJpY3RFcXVhbChsZW5zLnNlc3Npb25WaWV3TGVhc2UsIHVuZGVmaW5lZCwgJ3JlYWwgY29ubmVjdGlvbi9CaW5kaW5nIG11c3QgbmF0dXJhbGx5IHJlbW92ZSB0aGUgZW1wdHkgb3duZXIgbGVhc2UnKTtcblx0XHRyZXR1cm4gbGVucztcblx0fVxuXG5cdGFzeW5jIGZ1bmN0aW9uIHN0YXJ0RW1wdHlDYXRhbG9nUmVmcmVzaChoYXJuZXNzOiBFbmdpbmVSZXZlYWxIYXJuZXNzLCByZWNvbm5lY3QgPSBmYWxzZSkge1xuXHRcdGNvbnN0IHJlcXVlc3QgPSBoYXJuZXNzLmRlZmVyQ2F0YWxvZygpO1xuXHRcdGlmIChyZWNvbm5lY3QpIHtcblx0XHRcdGhhcm5lc3Mubm90aWZ5KCdkaXNjb25uZWN0ZWQnKTtcblx0XHR9XG5cdFx0aGFybmVzcy5ub3RpZnkoJ2xpdmUnKTtcblx0XHRhd2FpdCBib3VuZGVkKHJlcXVlc3Quc3RhcnRlZC5wLCAncmVhbCByZXBsYWNlbWVudCBsaXN0U2Vzc2lvbnMgbXVzdCBzdGFydCcpO1xuXHRcdGFzc2VydC5zdHJpY3RFcXVhbChnZXRDb252ZXJzYXRpb25TZXNzaW9uUmVhZGluZXNzKGhhcm5lc3Mucm9zdGVyU2VydmljZSksICdsb2FkaW5nJyk7XG5cdFx0YXNzZXJ0LnN0cmljdEVxdWFsKGhhcm5lc3MucGFuZS5hY3RpdmVDb252ZXJzYXRpb25MZW5zLCBoYXJuZXNzLmxlbnMpO1xuXHRcdGFzc2VydFZpc2libGVNaXNzaW5nKGhhcm5lc3MpO1xuXHRcdHJldHVybiByZXF1ZXN0O1xuXHR9XG5cblx0YXN5bmMgZnVuY3Rpb24gY29tcGxldGVDYXRhbG9nKGhhcm5lc3M6IEVuZ2luZVJldmVhbEhhcm5lc3MsIHJlcXVlc3Q6IFJldHVyblR5cGU8RW5naW5lUmV2ZWFsSGFybmVzc1snZGVmZXJDYXRhbG9nJ10+KTogUHJvbWlzZTx2b2lkPiB7XG5cdFx0YXdhaXQgcmVxdWVzdC5yZXN1bHQuY29tcGxldGUoaGFybmVzcy5jYXRhbG9nKTtcblx0XHRhd2FpdCBib3VuZGVkKGhhcm5lc3Mucm9zdGVyU2VydmljZS53aGVuRW5naW5lQ2F0YWxvZ1JlZnJlc2hDb21wbGV0ZSgpLCAncmVhbCBjYXRhbG9nIG11c3Qgc2V0dGxlJyk7XG5cdFx0YXNzZXJ0LnN0cmljdEVxdWFsKGdldENvbnZlcnNhdGlvblNlc3Npb25SZWFkaW5lc3MoaGFybmVzcy5yb3N0ZXJTZXJ2aWNlKSwgJ3JlYWR5Jyk7XG5cdH1cblxuXHRmdW5jdGlvbiBvYnNlcnZlUGFuZUJpbmRzKGxlbnM6IENvbnZlcnNhdGlvbkxlbnMpOiAoKSA9PiBudW1iZXIge1xuXHRcdGxldCBjYWxscyA9IDA7XG5cdFx0Y29uc3Qgb3JpZ2luYWwgPSBsZW5zLmJpbmRTZXNzaW9uVmlldztcblx0XHRsZW5zLmJpbmRTZXNzaW9uVmlldyA9IHNlc3Npb25JZCA9PiB7XG5cdFx0XHRjYWxscysrO1xuXHRcdFx0b3JpZ2luYWwuY2FsbChsZW5zLCBzZXNzaW9uSWQpO1xuXHRcdH07XG5cdFx0c3RvcmUuYWRkKHRvRGlzcG9zYWJsZSgoKSA9PiB7IGxlbnMuYmluZFNlc3Npb25WaWV3ID0gb3JpZ2luYWw7IH0pKTtcblx0XHRyZXR1cm4gKCkgPT4gY2FsbHM7XG5cdH1cblxuXHRhc3luYyBmdW5jdGlvbiBhc3NlcnRFbmdpbmVGcmFtZVBhaW50cyhoYXJuZXNzOiBFbmdpbmVSZXZlYWxIYXJuZXNzLCBwYW5lOiBDb252ZXJzYXRpb25FZGl0b3JQYW5lLCBzZXNzaW9uSWQ6IHN0cmluZywgdGV4dDogc3RyaW5nKTogUHJvbWlzZTx2b2lkPiB7XG5cdFx0Y29uc3QgbGVucyA9IHBhbmUuYWN0aXZlQ29udmVyc2F0aW9uTGVucztcblx0XHRhc3NlcnQub2sobGVucyk7XG5cdFx0Y29uc3QgbGVhc2UgPSBsZW5zLnNlc3Npb25WaWV3TGVhc2U7XG5cdFx0YXNzZXJ0Lm9rKGxlYXNlLCAndGhpcyBhY3R1YWwgUGFuZSBtdXN0IG93biB0aGUgcmVjb3ZlcmVkIGxlYXNlJyk7XG5cdFx0YXNzZXJ0LnN0cmljdEVxdWFsKGxlYXNlLnNlc3Npb25JZCwgc2Vzc2lvbklkKTtcblx0XHRpZiAoIWhhcm5lc3Muc2Vzc2lvblZpZXcuaGFzU2Vzc2lvbkxpc3RlbmVyKHNlc3Npb25JZCkpIHtcblx0XHRcdGNvbnN0IGxpc3RlbmluZyA9IEV2ZW50LnRvUHJvbWlzZShFdmVudC5maWx0ZXIoaGFybmVzcy5zZXNzaW9uVmlldy5vbkRpZExpc3RlbiwgKCkgPT4gaGFybmVzcy5zZXNzaW9uVmlldy5oYXNTZXNzaW9uTGlzdGVuZXIoc2Vzc2lvbklkKSkpO1xuXHRcdFx0dHJ5IHtcblx0XHRcdFx0YXdhaXQgYm91bmRlZChsaXN0ZW5pbmcsICdhY3R1YWwgaG9zdCBsZWFzZSBhY3F1aXJlIGFuZCBmcmFtZSBsaXN0ZW5lciBtdXN0IGNvbXBsZXRlJyk7XG5cdFx0XHR9IGZpbmFsbHkge1xuXHRcdFx0XHRsaXN0ZW5pbmcuY2FuY2VsKCk7XG5cdFx0XHR9XG5cdFx0fVxuXHRcdGNvbnN0IGNvbHVtbiA9IHBhbmUuZ2V0UmVhZGluZ0NvbHVtbigpO1xuXHRcdGFzc2VydC5vayhjb2x1bW4pO1xuXHRcdGNvbnN0IHBhaW50ZWQgPSBuZXcgRGVmZXJyZWRQcm9taXNlPHZvaWQ+KCk7XG5cdFx0Y29uc3QgY2hlY2sgPSAoKSA9PiB7XG5cdFx0XHRjb25zdCBib2R5ID0gY29sdW1uLnF1ZXJ5U2VsZWN0b3IoYC5jb252ZXJzYXRpb24tbGVucy10dXJuW2RhdGEtdHVybi1pZD1cIiR7c2Vzc2lvbklkfS1ib2R5XCJdIC5jb252ZXJzYXRpb24tbGVucy10dXJuLWJvZHlgKTtcblx0XHRcdGNvbnN0IHBlbmRpbmcgPSBjb2x1bW4ucXVlcnlTZWxlY3RvcihgLmNvbnZlcnNhdGlvbi1sZW5zLWNvbmZpcm1hdGlvbi1zZWF0W2RhdGEtdHVybi1pZD1cIiR7c2Vzc2lvbklkfS1wZXJtaXNzaW9uXCJdYCk7XG5cdFx0XHRpZiAoYm9keT8udGV4dENvbnRlbnQgPT09IHRleHQgJiYgcGVuZGluZz8udGV4dENvbnRlbnQ/LmluY2x1ZGVzKGBQZXJtaXNzaW9uIGZvciAke3Nlc3Npb25JZH1gKSkge1xuXHRcdFx0XHR2b2lkIHBhaW50ZWQuY29tcGxldGUoKTtcblx0XHRcdH1cblx0XHR9O1xuXHRcdGNvbnN0IG9ic2VydmVyID0gbmV3IE11dGF0aW9uT2JzZXJ2ZXIoY2hlY2spO1xuXHRcdG9ic2VydmVyLm9ic2VydmUoY29sdW1uLCB7IGNoaWxkTGlzdDogdHJ1ZSwgY2hhcmFjdGVyRGF0YTogdHJ1ZSwgc3VidHJlZTogdHJ1ZSB9KTtcblx0XHRjb25zdCBhZG1pdHRlZCA9IEV2ZW50LnRvUHJvbWlzZShsZWFzZS5vbkRpZEFwcGx5RnJhbWUpO1xuXHRcdHRyeSB7XG5cdFx0XHRoYXJuZXNzLnNlc3Npb25WaWV3LmVtaXRTZXNzaW9uKHNlc3Npb25JZCwgdGV4dCk7XG5cdFx0XHRhd2FpdCBib3VuZGVkKGFkbWl0dGVkLCAnZnJhbWUgbXVzdCBiZSBhZG1pdHRlZCBieSB0aGUgYWN0dWFsIFBhbmUgbGVhc2UnKTtcblx0XHRcdHBhbmUubGF5b3V0KHsgd2lkdGg6IDgwMCwgaGVpZ2h0OiA2MDAgfSk7XG5cdFx0XHRjaGVjaygpO1xuXHRcdFx0YXdhaXQgYm91bmRlZChwYWludGVkLnAsICdhY3R1YWwgUGFuZSB0dXJuIGFuZCBwZW5kaW5nIHNlYXQgbXVzdCBwYWludCB0aHJvdWdoIFRpbWVsaW5lSG9zdCcpO1xuXHRcdFx0YXNzZXJ0LnN0cmljdEVxdWFsKGxlbnMuc2Vzc2lvblZpZXdMZWFzZSwgbGVhc2UpO1xuXHRcdFx0YXNzZXJ0LnN0cmljdEVxdWFsKGxlYXNlLnNuYXBzaG90LnRpbWVsaW5lLmxlbmd0aCwgMik7XG5cdFx0XHRhc3NlcnQuc3RyaWN0RXF1YWwobGVhc2Uuc25hcHNob3QucGVuZGluZ0FjdGlvbnMubGVuZ3RoLCAxKTtcblx0XHR9IGZpbmFsbHkge1xuXHRcdFx0b2JzZXJ2ZXIuZGlzY29ubmVjdCgpO1xuXHRcdFx0YWRtaXR0ZWQuY2FuY2VsKCk7XG5cdFx0fVxuXHR9XG5cblx0YXN5bmMgZnVuY3Rpb24gd2FpdEZvclNlc3Npb25QYW5lKFxuXHRcdGhhcm5lc3M6IEF3YWl0ZWQ8UmV0dXJuVHlwZTx0eXBlb2YgY3JlYXRlUmV2ZWFsSGFybmVzcz4+LFxuXHRcdHNlc3Npb25LZXk6IHN0cmluZyxcblx0KTogUHJvbWlzZTxDb252ZXJzYXRpb25FZGl0b3JQYW5lPiB7XG5cdFx0cmV0dXJuIHdhaXRGb3JQYW5lKHBhcnRGb3IoaGFybmVzcy5wYXJ0cywgc2Vzc2lvbktleSksIGhhcm5lc3Mub3BlbkVycm9ycywgaGFybmVzcy5wYXJ0cyk7XG5cdH1cblxuXHRzdWl0ZSgndmlzaWJsZSBlbmdpbmUgbGVhc2UgcmVjb3ZlcnknLCAoKSA9PiB7XG5cdFx0dGVzdCgnTDEgc2FtZSB2aXNpYmxlIGVtcHR5IG93bmVyIHJlY292ZXJzIGl0cyBvd24gbGVhc2UgYWZ0ZXIgc2FtZS1zZXNzaW9uIGNhdGFsb2cgcmVhZHkgd2l0aG91dCByZXZlYWwnLCBhc3luYyAoKSA9PiB7XG5cdFx0XHRjb25zdCBoYXJuZXNzID0gYXdhaXQgY3JlYXRlRW5naW5lUmV2ZWFsSGFybmVzcygpO1xuXHRcdFx0Y29uc3QgeyBwYW5lLCBsZW5zLCBwcmltYXJ5SWQsIHJvc3RlclNlcnZpY2UgfSA9IGhhcm5lc3M7XG5cdFx0XHRjb25zdCBpbnB1dCA9IHBhbmUuaW5wdXQ7XG5cdFx0XHRhc3NlcnQub2soaW5wdXQpO1xuXHRcdFx0YXNzZXJ0LnN0cmljdEVxdWFsKGxlbnMubGFzdEF0dGFjaGVkRW50cmllcy5sZW5ndGgsIDApO1xuXHRcdFx0YXNzZXJ0LnN0cmljdEVxdWFsKGxlbnMuc2Vzc2lvblZpZXdMZWFzZT8uc25hcHNob3QudGltZWxpbmUubGVuZ3RoLCAwKTtcblx0XHRcdGNvbnN0IHBlbmRpbmcgPSBhd2FpdCBzdGFydEVtcHR5Q2F0YWxvZ1JlZnJlc2goaGFybmVzcywgdHJ1ZSk7XG5cdFx0XHRhc3NlcnQuc3RyaWN0RXF1YWwocGFuZS5pbnB1dCwgaW5wdXQpO1xuXHRcdFx0bGV0IGFjdGl2ZUNoYW5nZXMgPSAwO1xuXHRcdFx0Y29uc3QgYWN0aXZlTGlzdGVuZXIgPSBzdG9yZS5hZGQocm9zdGVyU2VydmljZS5vbkRpZENoYW5nZUFjdGl2ZVNlc3Npb24oKCkgPT4geyBhY3RpdmVDaGFuZ2VzKys7IH0pKTtcblx0XHRcdGF3YWl0IGNvbXBsZXRlQ2F0YWxvZyhoYXJuZXNzLCBwZW5kaW5nKTtcblx0XHRcdGFzc2VydC5zdHJpY3RFcXVhbChyb3N0ZXJTZXJ2aWNlLmdldEFjdGl2ZVNlc3Npb25JZCgpLCBwcmltYXJ5SWQpO1xuXHRcdFx0YXNzZXJ0LnN0cmljdEVxdWFsKGFjdGl2ZUNoYW5nZXMsIDAsICdzYW1lLXNlc3Npb24gcmVjb3ZlcnkgbXVzdCBub3QgcmVseSBvbiBhbiBhY3RpdmUtaWQgZXZlbnQnKTtcblx0XHRcdGFzc2VydC5zdHJpY3RFcXVhbChwYW5lLmlucHV0LCBpbnB1dCk7XG5cdFx0XHRhc3NlcnQuc3RyaWN0RXF1YWwocGFuZS5hY3RpdmVDb252ZXJzYXRpb25MZW5zLCBsZW5zKTtcblx0XHRcdGFzc2VydC5zdHJpY3RFcXVhbChsZW5zLmJvdW5kU2Vzc2lvbklkLCBwcmltYXJ5SWQpO1xuXHRcdFx0YXNzZXJ0LnN0cmljdEVxdWFsKGxlbnMuaXNEaXNwb3NlZCwgZmFsc2UpO1xuXHRcdFx0YXNzZXJ0LnN0cmljdEVxdWFsKGlzQ29udmVyc2F0aW9uRW5naW5lTGl2ZShoYXJuZXNzLmNvbm5lY3Rpb24uZ2V0Q29ubmVjdGlvblBoYXNlKCksIGhhcm5lc3MuY29ubmVjdGlvbi5nZXRDb25uZWN0aW9uU25hcHNob3QoKS5wYWlyaW5nUGVuZGluZyksIHRydWUpO1xuXHRcdFx0YXNzZXJ0LnN0cmljdEVxdWFsKGlzQ29udmVyc2F0aW9uUGFpcmluZ0hvbGQoaGFybmVzcy5jb25uZWN0aW9uKSwgZmFsc2UpO1xuXHRcdFx0YXNzZXJ0Lm9rKGxlbnMuc2Vzc2lvblZpZXdMZWFzZSwgJ2NhdGFsb2cgcmVhZHkgbXVzdCByZXN0b3JlIHRoaXMgdmlzaWJsZSBQYW5lIGxlYXNlIHdpdGhvdXQgaGlkZS9yZXZlYWwnKTtcblx0XHRcdGFzc2VydC5zdHJpY3RFcXVhbChsZW5zLnNlc3Npb25WaWV3TGVhc2Uuc2Vzc2lvbklkLCBwcmltYXJ5SWQpO1xuXHRcdFx0YWN0aXZlTGlzdGVuZXIuZGlzcG9zZSgpO1xuXHRcdFx0YXdhaXQgYXNzZXJ0RW5naW5lRnJhbWVQYWludHMoaGFybmVzcywgcGFuZSwgcHJpbWFyeUlkLCAnTDEgcmVjb3ZlcmVkIFBhbmUgYm9keScpO1xuXHRcdH0pO1xuXG5cdFx0dGVzdCgnTDIgY29udGludW91c2x5IGxpdmUgbm9uZW1wdHkgb3duZXIga2VlcHMgbGVhc2Ugc25hcHNob3QgZW50cmllcyBhbmQgdGV4dCB0aHJvdWdoIGNhdGFsb2cgcGVuZGluZyBmYWlsdXJlIGFuZCByZWFkeScsIGFzeW5jICgpID0+IHtcblx0XHRcdGNvbnN0IGhhcm5lc3MgPSBhd2FpdCBjcmVhdGVFbmdpbmVSZXZlYWxIYXJuZXNzKCk7XG5cdFx0XHRhd2FpdCBhc3NlcnRFbmdpbmVGcmFtZVBhaW50cyhoYXJuZXNzLCBoYXJuZXNzLnBhbmUsIGhhcm5lc3MucHJpbWFyeUlkLCAnTDIga2VlcCB0aGlzIGJvZHknKTtcblx0XHRcdGNvbnN0IGxlYXNlID0gaGFybmVzcy5sZW5zLnNlc3Npb25WaWV3TGVhc2U7XG5cdFx0XHRhc3NlcnQub2sobGVhc2UpO1xuXHRcdFx0Y29uc3Qgc25hcHNob3QgPSBsZWFzZS5zbmFwc2hvdDtcblx0XHRcdGNvbnN0IGVudHJpZXMgPSBoYXJuZXNzLmxlbnMubGFzdEF0dGFjaGVkRW50cmllcztcblx0XHRcdGNvbnN0IGlucHV0ID0gaGFybmVzcy5wYW5lLmlucHV0O1xuXHRcdFx0Y29uc3QgYXNzZXJ0S2VwdCA9ICgpID0+IHtcblx0XHRcdFx0YXNzZXJ0LnN0cmljdEVxdWFsKGhhcm5lc3MucGFuZS5pbnB1dCwgaW5wdXQpO1xuXHRcdFx0XHRhc3NlcnQuc3RyaWN0RXF1YWwoaGFybmVzcy5wYW5lLmFjdGl2ZUNvbnZlcnNhdGlvbkxlbnMsIGhhcm5lc3MubGVucyk7XG5cdFx0XHRcdGFzc2VydC5zdHJpY3RFcXVhbChoYXJuZXNzLmNvbm5lY3Rpb24uZ2V0Q29ubmVjdGlvblNuYXBzaG90KCkuZW5naW5lSWRlbnRpdHlJZCwgJ3JldmVhbC1lbmdpbmUnKTtcblx0XHRcdFx0YXNzZXJ0LnN0cmljdEVxdWFsKGlzQ29udmVyc2F0aW9uRW5naW5lTGl2ZShoYXJuZXNzLmNvbm5lY3Rpb24uZ2V0Q29ubmVjdGlvblBoYXNlKCksIGhhcm5lc3MuY29ubmVjdGlvbi5nZXRDb25uZWN0aW9uU25hcHNob3QoKS5wYWlyaW5nUGVuZGluZyksIHRydWUpO1xuXHRcdFx0XHRhc3NlcnQuc3RyaWN0RXF1YWwoaXNDb252ZXJzYXRpb25QYWlyaW5nSG9sZChoYXJuZXNzLmNvbm5lY3Rpb24pLCBmYWxzZSk7XG5cdFx0XHRcdGFzc2VydC5zdHJpY3RFcXVhbChoYXJuZXNzLnJvc3RlclNlcnZpY2UuZ2V0QWN0aXZlU2Vzc2lvbklkKCksIGhhcm5lc3MucHJpbWFyeUlkKTtcblx0XHRcdFx0YXNzZXJ0LnN0cmljdEVxdWFsKGhhcm5lc3MubGVucy5ib3VuZFNlc3Npb25JZCwgaGFybmVzcy5wcmltYXJ5SWQpO1xuXHRcdFx0XHRhc3NlcnQuc3RyaWN0RXF1YWwoaGFybmVzcy5sZW5zLnNlc3Npb25WaWV3TGVhc2UsIGxlYXNlKTtcblx0XHRcdFx0YXNzZXJ0LnN0cmljdEVxdWFsKGxlYXNlLnNuYXBzaG90LCBzbmFwc2hvdCk7XG5cdFx0XHRcdGFzc2VydC5zdHJpY3RFcXVhbChoYXJuZXNzLmxlbnMubGFzdEF0dGFjaGVkRW50cmllcywgZW50cmllcyk7XG5cdFx0XHRcdGFzc2VydC5zdHJpY3RFcXVhbChoYXJuZXNzLnBhbmUuZ2V0UmVhZGluZ0NvbHVtbigpPy5xdWVyeVNlbGVjdG9yKGAuY29udmVyc2F0aW9uLWxlbnMtdHVybltkYXRhLXR1cm4taWQ9XCIke2hhcm5lc3MucHJpbWFyeUlkfS1ib2R5XCJdIC5jb252ZXJzYXRpb24tbGVucy10dXJuLWJvZHlgKT8udGV4dENvbnRlbnQsICdMMiBrZWVwIHRoaXMgYm9keScpO1xuXHRcdFx0fTtcblx0XHRcdGNvbnN0IGZhaWxlZCA9IGhhcm5lc3MuZGVmZXJDYXRhbG9nKCk7XG5cdFx0XHRoYXJuZXNzLm5vdGlmeSgnbGl2ZScpO1xuXHRcdFx0YXdhaXQgYm91bmRlZChmYWlsZWQuc3RhcnRlZC5wLCAnc2FtZS1saXZlIGNhdGFsb2cgcmVmcmVzaCBtdXN0IHN0YXJ0Jyk7XG5cdFx0XHRhc3NlcnQuc3RyaWN0RXF1YWwoZ2V0Q29udmVyc2F0aW9uU2Vzc2lvblJlYWRpbmVzcyhoYXJuZXNzLnJvc3RlclNlcnZpY2UpLCAnbG9hZGluZycpO1xuXHRcdFx0YXNzZXJ0S2VwdCgpO1xuXHRcdFx0YXdhaXQgZmFpbGVkLnJlc3VsdC5lcnJvcihuZXcgRXJyb3IoJ2NhdGFsb2cgdW5hdmFpbGFibGUnKSk7XG5cdFx0XHRhd2FpdCBib3VuZGVkKGhhcm5lc3Mucm9zdGVyU2VydmljZS53aGVuRW5naW5lQ2F0YWxvZ1JlZnJlc2hDb21wbGV0ZSgpLCAnZmFpbGVkIHJlYWwgbGlzdCBtdXN0IHNldHRsZScpO1xuXHRcdFx0YXNzZXJ0LnN0cmljdEVxdWFsKGdldENvbnZlcnNhdGlvblNlc3Npb25SZWFkaW5lc3MoaGFybmVzcy5yb3N0ZXJTZXJ2aWNlKSwgJ3VuYXZhaWxhYmxlJyk7XG5cdFx0XHRhc3NlcnRLZXB0KCk7XG5cdFx0XHRjb25zdCByZWNvdmVyZWQgPSBoYXJuZXNzLmRlZmVyQ2F0YWxvZygpO1xuXHRcdFx0aGFybmVzcy5ub3RpZnkoJ2xpdmUnKTtcblx0XHRcdGF3YWl0IGJvdW5kZWQocmVjb3ZlcmVkLnN0YXJ0ZWQucCwgJ3NhbWUtbGl2ZSByZWNvdmVyeSBsaXN0IG11c3Qgc3RhcnQnKTtcblx0XHRcdGFzc2VydEtlcHQoKTtcblx0XHRcdGF3YWl0IGNvbXBsZXRlQ2F0YWxvZyhoYXJuZXNzLCByZWNvdmVyZWQpO1xuXHRcdFx0YXNzZXJ0S2VwdCgpO1xuXHRcdH0pO1xuXG5cdFx0dGVzdCgnTDMgbG9hZGluZyBhbmQgcmVhbCBsaXN0IHJlamVjdGlvbiBsZWF2ZSBhIHZpc2libGUgZW1wdHkgb3duZXIgbWlzc2luZyB1bnRpbCBzdWNjZXNzZnVsIHJlYWR5JywgYXN5bmMgKCkgPT4ge1xuXHRcdFx0Y29uc3QgaGFybmVzcyA9IGF3YWl0IGNyZWF0ZUVuZ2luZVJldmVhbEhhcm5lc3MoKTtcblx0XHRcdGNvbnN0IGZhaWxlZCA9IGF3YWl0IHN0YXJ0RW1wdHlDYXRhbG9nUmVmcmVzaChoYXJuZXNzKTtcblx0XHRcdGNvbnN0IGJpbmRzID0gb2JzZXJ2ZVBhbmVCaW5kcyhoYXJuZXNzLmxlbnMpO1xuXHRcdFx0YXNzZXJ0VmlzaWJsZU1pc3NpbmcoaGFybmVzcyk7XG5cdFx0XHRhd2FpdCBmYWlsZWQucmVzdWx0LmVycm9yKG5ldyBFcnJvcignbGlzdFNlc3Npb25zIHJlamVjdGVkJykpO1xuXHRcdFx0YXdhaXQgYm91bmRlZChoYXJuZXNzLnJvc3RlclNlcnZpY2Uud2hlbkVuZ2luZUNhdGFsb2dSZWZyZXNoQ29tcGxldGUoKSwgJ3JlYWwgcmVqZWN0ZWQgbGlzdCBtdXN0IHNldHRsZScpO1xuXHRcdFx0YXNzZXJ0LnN0cmljdEVxdWFsKGdldENvbnZlcnNhdGlvblNlc3Npb25SZWFkaW5lc3MoaGFybmVzcy5yb3N0ZXJTZXJ2aWNlKSwgJ3VuYXZhaWxhYmxlJyk7XG5cdFx0XHRhc3NlcnRWaXNpYmxlTWlzc2luZyhoYXJuZXNzKTtcblx0XHRcdGFzc2VydC5zdHJpY3RFcXVhbChiaW5kcygpLCAwKTtcblx0XHRcdGNvbnN0IHJlY292ZXJ5ID0gYXdhaXQgc3RhcnRFbXB0eUNhdGFsb2dSZWZyZXNoKGhhcm5lc3MpO1xuXHRcdFx0Y29uc3QgYmVmb3JlUmVhZHkgPSBiaW5kcygpO1xuXHRcdFx0YXdhaXQgY29tcGxldGVDYXRhbG9nKGhhcm5lc3MsIHJlY292ZXJ5KTtcblx0XHRcdGFzc2VydC5zdHJpY3RFcXVhbChiaW5kcygpIC0gYmVmb3JlUmVhZHksIDEsICd0aGUgc2Vzc2lvbi1yZWFkeSBsaXN0ZW5lciBtdXN0IGNhbGwgdGhlIHJlYWwgUGFuZSBiaW5kIG9uY2UnKTtcblx0XHRcdGF3YWl0IGFzc2VydEVuZ2luZUZyYW1lUGFpbnRzKGhhcm5lc3MsIGhhcm5lc3MucGFuZSwgaGFybmVzcy5wcmltYXJ5SWQsICdMMyBjYXRhbG9nIHJlY292ZXJ5Jyk7XG5cdFx0fSk7XG5cblx0XHRmb3IgKGNvbnN0IHN0YXRlIG9mIFsnZGlzY29ubmVjdGVkJywgJ2Nvbm5lY3RlZCBwYWlyaW5nJywgJ2Nvbm5lY3RpbmcgcGFpcmluZyddIGFzIGNvbnN0KSB7XG5cdFx0XHR0ZXN0KGBMMyAke3N0YXRlfSBRdWV1ZVJlYWRlciBzZXNzaW9uIHdpbmRvdyBrZWVwcyBhIG5hdHVyYWxseSBtaXNzaW5nIHZpc2libGUgb3duZXIgdW5ib3VuZGAsIGFzeW5jICgpID0+IHtcblx0XHRcdFx0bGV0IGhhcm5lc3M6IEVuZ2luZVJldmVhbEhhcm5lc3MgfCB1bmRlZmluZWQ7XG5cdFx0XHRcdGxldCBhcm1lZCA9IGZhbHNlO1xuXHRcdFx0XHRsZXQgYmluZHM6ICgoKSA9PiBudW1iZXIpIHwgdW5kZWZpbmVkO1xuXHRcdFx0XHRjb25zdCBvcmRlcjogc3RyaW5nW10gPSBbXTtcblx0XHRcdFx0Y29uc3QgY2FwdHVyZSA9IChwb3NpdGlvbjogJ2JlZm9yZScgfCAnYWZ0ZXInKSA9PiB7XG5cdFx0XHRcdFx0YXNzZXJ0Lm9rKGhhcm5lc3MpO1xuXHRcdFx0XHRcdGFzc2VydC5vayhiaW5kcyk7XG5cdFx0XHRcdFx0Y29uc3QgbGVucyA9IGhhcm5lc3MucGFuZS5hY3RpdmVDb252ZXJzYXRpb25MZW5zO1xuXHRcdFx0XHRcdGFzc2VydC5vayhsZW5zKTtcblx0XHRcdFx0XHRyZXR1cm4ge1xuXHRcdFx0XHRcdFx0cG9zaXRpb24sIHBhbmU6IGhhcm5lc3MucGFuZSwgaW5wdXQ6IGhhcm5lc3MucGFuZS5pbnB1dCwgbGVucyxcblx0XHRcdFx0XHRcdGJvdW5kOiBsZW5zLmJvdW5kU2Vzc2lvbklkLCB2aXNpYmxlOiBoYXJuZXNzLnNlc3Npb25XaW5kb3dTZXJ2aWNlLmlzU2Vzc2lvbldpbmRvd1Zpc2libGUoaGFybmVzcy5wcmltYXJ5SWQpLFxuXHRcdFx0XHRcdFx0c3VzcGVuZGVkOiBsZW5zLnNlc3Npb25WaWV3QmluZGluZ1N1c3BlbmRlZCwgZGlzcG9zZWQ6IGxlbnMuaXNEaXNwb3NlZCwgbGVhc2U6IGxlbnMuc2Vzc2lvblZpZXdMZWFzZSxcblx0XHRcdFx0XHRcdHBoYXNlOiBoYXJuZXNzLmNvbm5lY3Rpb24uZ2V0Q29ubmVjdGlvblBoYXNlKCkua2luZCwgcGFpcmluZzogaGFybmVzcy5jb25uZWN0aW9uLmdldENvbm5lY3Rpb25TbmFwc2hvdCgpLnBhaXJpbmdQZW5kaW5nLFxuXHRcdFx0XHRcdFx0Y29ubmVjdGVkOiBoYXJuZXNzLnJvc3RlclNlcnZpY2UuaXNFbmdpbmVDb25uZWN0ZWQoKSwgcmVhZGluZXNzOiBnZXRDb252ZXJzYXRpb25TZXNzaW9uUmVhZGluZXNzKGhhcm5lc3Mucm9zdGVyU2VydmljZSksXG5cdFx0XHRcdFx0XHRxdWV1ZTogaGFybmVzcy5yb3N0ZXJTZXJ2aWNlLmdldE1lc3NhZ2VRdWV1ZVN0YXRlKGhhcm5lc3MucHJpbWFyeUlkKS5yZWFkU3RhdGUsIGJpbmRDYWxsczogYmluZHMoKSxcblx0XHRcdFx0XHR9O1xuXHRcdFx0XHR9O1xuXHRcdFx0XHRjb25zdCBzYW1wbGVzOiBSZXR1cm5UeXBlPHR5cGVvZiBjYXB0dXJlPltdID0gW107XG5cdFx0XHRcdGhhcm5lc3MgPSBhd2FpdCBjcmVhdGVFbmdpbmVSZXZlYWxIYXJuZXNzKHJvc3RlciA9PiB7XG5cdFx0XHRcdFx0c3RvcmUuYWRkKHJvc3Rlci5vbkRpZENoYW5nZVNlc3Npb24oaWQgPT4ge1xuXHRcdFx0XHRcdFx0aWYgKGFybWVkICYmIGlkID09PSAnbGVhc2UtczEnICYmIHNhbXBsZXMubGVuZ3RoID09PSAwICYmIHJvc3Rlci5nZXRNZXNzYWdlUXVldWVTdGF0ZShpZCkucmVhZFN0YXRlID09PSAnc3RhbGUnKSB7XG5cdFx0XHRcdFx0XHRcdG9yZGVyLnB1c2goJ3Nlc3Npb24gYmVmb3JlJyk7XG5cdFx0XHRcdFx0XHRcdHNhbXBsZXMucHVzaChjYXB0dXJlKCdiZWZvcmUnKSk7XG5cdFx0XHRcdFx0XHR9XG5cdFx0XHRcdFx0fSkpO1xuXHRcdFx0XHR9KTtcblx0XHRcdFx0Y29uc3QgY3VycmVudCA9IGhhcm5lc3M7XG5cdFx0XHRcdGJpbmRzID0gb2JzZXJ2ZVBhbmVCaW5kcyhjdXJyZW50LmxlbnMpO1xuXHRcdFx0XHRzdG9yZS5hZGQoY3VycmVudC5yb3N0ZXJTZXJ2aWNlLm9uRGlkQ2hhbmdlU2Vzc2lvbihpZCA9PiB7XG5cdFx0XHRcdFx0aWYgKGFybWVkICYmIGlkID09PSBjdXJyZW50LnByaW1hcnlJZCAmJiBzYW1wbGVzLmxlbmd0aCA9PT0gMSkge1xuXHRcdFx0XHRcdFx0b3JkZXIucHVzaCgnc2Vzc2lvbiBhZnRlcicpO1xuXHRcdFx0XHRcdFx0c2FtcGxlcy5wdXNoKGNhcHR1cmUoJ2FmdGVyJykpO1xuXHRcdFx0XHRcdH1cblx0XHRcdFx0fSkpO1xuXHRcdFx0XHRjb25zdCBwZW5kaW5nID0gYXdhaXQgc3RhcnRFbXB0eUNhdGFsb2dSZWZyZXNoKGN1cnJlbnQpO1xuXHRcdFx0XHRhc3NlcnQuc3RyaWN0RXF1YWwoY3VycmVudC5yb3N0ZXJTZXJ2aWNlLmdldE1lc3NhZ2VRdWV1ZVN0YXRlKGN1cnJlbnQucHJpbWFyeUlkKS5yZWFkU3RhdGUsICd1bnN1cHBvcnRlZCcpO1xuXHRcdFx0XHRjb25zdCBiZWZvcmVDYWxscyA9IGJpbmRzKCk7XG5cdFx0XHRcdGNvbnN0IGlucHV0ID0gY3VycmVudC5wYW5lLmlucHV0O1xuXHRcdFx0XHRhcm1lZCA9IHRydWU7XG5cdFx0XHRcdG9yZGVyLnB1c2goJ1VBIHN0YXJ0Jyk7XG5cdFx0XHRcdGN1cnJlbnQubm90aWZ5KHN0YXRlKTtcblx0XHRcdFx0b3JkZXIucHVzaCgnVUEgcmV0dXJuJyk7XG5cdFx0XHRcdGFybWVkID0gZmFsc2U7XG5cdFx0XHRcdGFzc2VydC5kZWVwU3RyaWN0RXF1YWwob3JkZXIsIFsnVUEgc3RhcnQnLCAnc2Vzc2lvbiBiZWZvcmUnLCAnc2Vzc2lvbiBhZnRlcicsICdVQSByZXR1cm4nXSwgJ1F1ZXVlUmVhZGVyIG11c3QgZXhwb3NlIHRoZSBhY3R1YWwgaW5kZXBlbmRlbnQgY2FsbGJhY2sgd2luZG93Jyk7XG5cdFx0XHRcdGFzc2VydC5zdHJpY3RFcXVhbChzYW1wbGVzLmxlbmd0aCwgMik7XG5cdFx0XHRcdGZvciAoY29uc3Qgc2FtcGxlIG9mIHNhbXBsZXMpIHtcblx0XHRcdFx0XHRhc3NlcnQuc3RyaWN0RXF1YWwoc2FtcGxlLnBhbmUsIGN1cnJlbnQucGFuZSk7XG5cdFx0XHRcdFx0YXNzZXJ0LnN0cmljdEVxdWFsKHNhbXBsZS5pbnB1dCwgaW5wdXQpO1xuXHRcdFx0XHRcdGFzc2VydC5zdHJpY3RFcXVhbChzYW1wbGUubGVucywgY3VycmVudC5sZW5zKTtcblx0XHRcdFx0XHRhc3NlcnQuc3RyaWN0RXF1YWwoc2FtcGxlLmJvdW5kLCBjdXJyZW50LnByaW1hcnlJZCk7XG5cdFx0XHRcdFx0YXNzZXJ0LnN0cmljdEVxdWFsKHNhbXBsZS52aXNpYmxlLCB0cnVlKTtcblx0XHRcdFx0XHRhc3NlcnQuc3RyaWN0RXF1YWwoc2FtcGxlLnN1c3BlbmRlZCwgZmFsc2UpO1xuXHRcdFx0XHRcdGFzc2VydC5zdHJpY3RFcXVhbChzYW1wbGUuZGlzcG9zZWQsIGZhbHNlKTtcblx0XHRcdFx0XHRhc3NlcnQuc3RyaWN0RXF1YWwoc2FtcGxlLmxlYXNlLCB1bmRlZmluZWQpO1xuXHRcdFx0XHRcdGFzc2VydC5zdHJpY3RFcXVhbChzYW1wbGUucGhhc2UsIHN0YXRlID09PSAnZGlzY29ubmVjdGVkJyA/ICdkaXNjb25uZWN0ZWQnIDogc3RhdGUgPT09ICdjb25uZWN0aW5nIHBhaXJpbmcnID8gJ2Nvbm5lY3RpbmcnIDogJ2Nvbm5lY3RlZCcpO1xuXHRcdFx0XHRcdGFzc2VydC5zdHJpY3RFcXVhbChzYW1wbGUucGFpcmluZywgc3RhdGUgIT09ICdkaXNjb25uZWN0ZWQnKTtcblx0XHRcdFx0XHRhc3NlcnQuc3RyaWN0RXF1YWwoc2FtcGxlLmNvbm5lY3RlZCwgZmFsc2UpO1xuXHRcdFx0XHRcdGFzc2VydC5zdHJpY3RFcXVhbChzYW1wbGUucmVhZGluZXNzLCAncmVhZHknKTtcblx0XHRcdFx0XHRhc3NlcnQuc3RyaWN0RXF1YWwoc2FtcGxlLnF1ZXVlLCAnc3RhbGUnKTtcblx0XHRcdFx0XHRhc3NlcnQuc3RyaWN0RXF1YWwoc2FtcGxlLmJpbmRDYWxscywgYmVmb3JlQ2FsbHMsICduZXcgcmVjb25jaWxlIG11c3Qgbm90IGJpbmQgd2l0aGluIHRoZSBub24tbGl2ZSBjYWxsYmFjayB3aW5kb3cnKTtcblx0XHRcdFx0fVxuXHRcdFx0XHQvLyBMYXRlciBleGlzdGluZyBjb25uZWN0aW9uIGNhbGxiYWNrcyBtYXkgbGVnaXRpbWF0ZWx5IGJpbmQgYSBjYWNoZTsgZHJhaW4gdGhhdCBzY29wZSBzZXBhcmF0ZWx5LlxuXHRcdFx0XHRhd2FpdCBwZW5kaW5nLnJlc3VsdC5jb21wbGV0ZShjdXJyZW50LmNhdGFsb2cpO1xuXHRcdFx0XHRhd2FpdCBib3VuZGVkKGN1cnJlbnQucm9zdGVyU2VydmljZS53aGVuRW5naW5lQ2F0YWxvZ1JlZnJlc2hDb21wbGV0ZSgpLCAnc3RhbGUgcGVuZGluZyBjYXRhbG9nIG11c3QgZHJhaW4nKTtcblx0XHRcdFx0Y29uc3QgcmVjb3ZlcnkgPSBhd2FpdCBzdGFydEVtcHR5Q2F0YWxvZ1JlZnJlc2goY3VycmVudCk7XG5cdFx0XHRcdGF3YWl0IGNvbXBsZXRlQ2F0YWxvZyhjdXJyZW50LCByZWNvdmVyeSk7XG5cdFx0XHRcdGF3YWl0IGFzc2VydEVuZ2luZUZyYW1lUGFpbnRzKGN1cnJlbnQsIGN1cnJlbnQucGFuZSwgY3VycmVudC5wcmltYXJ5SWQsIGBMMyAke3N0YXRlfSByZXN0b3JlZGApO1xuXHRcdFx0fSk7XG5cdFx0fVxuXG5cdFx0dGVzdCgnTDQgaGlkZGVuIHN1c3BlbmRlZCBvd25lciBzdGF5cyB1bmJvdW5kIHRocm91Z2ggZmFpbGVkIGFuZCByZWFkeSBjYXRhbG9ncyB1bnRpbCBwdWJsaWMgcmVzdG9yZScsIGFzeW5jICgpID0+IHtcblx0XHRcdGNvbnN0IGhhcm5lc3MgPSBhd2FpdCBjcmVhdGVFbmdpbmVSZXZlYWxIYXJuZXNzKCk7XG5cdFx0XHRhd2FpdCBoYXJuZXNzLnNlc3Npb25XaW5kb3dTZXJ2aWNlLm9wZW5TZXNzaW9uQmVzaWRlKCdsZWFzZS1zMicpO1xuXHRcdFx0Y29uc3QgcGFuZSA9IGF3YWl0IHdhaXRGb3JFbmdpbmVQYW5lKHBhcnRGb3IoaGFybmVzcy5wYXJ0cywgJ2xlYXNlLXMyJykpO1xuXHRcdFx0dHJhY2tFZGl0b3JzKGhhcm5lc3MucGFydHMpO1xuXHRcdFx0Y29uc3QgbGVucyA9IHBhbmUuYWN0aXZlQ29udmVyc2F0aW9uTGVucztcblx0XHRcdGFzc2VydC5vayhsZW5zPy5zZXNzaW9uVmlld0xlYXNlKTtcblx0XHRcdGhhcm5lc3Muc2Vzc2lvbldpbmRvd1NlcnZpY2UuaGlkZVNlc3Npb25XaW5kb3coJ2xlYXNlLXMyJyk7XG5cdFx0XHRhc3NlcnQuc3RyaWN0RXF1YWwobGVucy5zZXNzaW9uVmlld0JpbmRpbmdTdXNwZW5kZWQsIHRydWUpO1xuXHRcdFx0YXNzZXJ0LnN0cmljdEVxdWFsKGxlbnMuc2Vzc2lvblZpZXdMZWFzZSwgdW5kZWZpbmVkKTtcblx0XHRcdGNvbnN0IGJpbmRzID0gb2JzZXJ2ZVBhbmVCaW5kcyhsZW5zKTtcblx0XHRcdGNvbnN0IGZhaWxlZCA9IGhhcm5lc3MuZGVmZXJDYXRhbG9nKCk7XG5cdFx0XHRoYXJuZXNzLm5vdGlmeSgnbGl2ZScpO1xuXHRcdFx0YXdhaXQgYm91bmRlZChmYWlsZWQuc3RhcnRlZC5wLCAnaGlkZGVuIGNvbnRyb2wgcmVhbCBsaXN0IG11c3Qgc3RhcnQnKTtcblx0XHRcdGF3YWl0IGZhaWxlZC5yZXN1bHQuZXJyb3IobmV3IEVycm9yKCdoaWRkZW4gY2F0YWxvZyBmYWlsdXJlJykpO1xuXHRcdFx0YXdhaXQgYm91bmRlZChoYXJuZXNzLnJvc3RlclNlcnZpY2Uud2hlbkVuZ2luZUNhdGFsb2dSZWZyZXNoQ29tcGxldGUoKSwgJ2hpZGRlbiBmYWlsdXJlIG11c3Qgc2V0dGxlJyk7XG5cdFx0XHRhc3NlcnQuc3RyaWN0RXF1YWwobGVucy5zZXNzaW9uVmlld0xlYXNlLCB1bmRlZmluZWQpO1xuXHRcdFx0YXNzZXJ0LnN0cmljdEVxdWFsKGJpbmRzKCksIDApO1xuXHRcdFx0Y29uc3QgcmVhZHkgPSBoYXJuZXNzLmRlZmVyQ2F0YWxvZygpO1xuXHRcdFx0aGFybmVzcy5ub3RpZnkoJ2xpdmUnKTtcblx0XHRcdGF3YWl0IGJvdW5kZWQocmVhZHkuc3RhcnRlZC5wLCAnaGlkZGVuIHJlY292ZXJ5IGxpc3QgbXVzdCBzdGFydCcpO1xuXHRcdFx0YXdhaXQgY29tcGxldGVDYXRhbG9nKGhhcm5lc3MsIHJlYWR5KTtcblx0XHRcdGFzc2VydC5zdHJpY3RFcXVhbChoYXJuZXNzLnNlc3Npb25XaW5kb3dTZXJ2aWNlLmlzU2Vzc2lvbldpbmRvd1Zpc2libGUoJ2xlYXNlLXMyJyksIGZhbHNlKTtcblx0XHRcdGFzc2VydC5zdHJpY3RFcXVhbChsZW5zLnNlc3Npb25WaWV3QmluZGluZ1N1c3BlbmRlZCwgdHJ1ZSk7XG5cdFx0XHRhc3NlcnQuc3RyaWN0RXF1YWwobGVucy5zZXNzaW9uVmlld0xlYXNlLCB1bmRlZmluZWQpO1xuXHRcdFx0YXNzZXJ0LnN0cmljdEVxdWFsKGJpbmRzKCksIDApO1xuXHRcdFx0aGFybmVzcy5zZXNzaW9uV2luZG93U2VydmljZS5yZXN0b3JlU2Vzc2lvbldpbmRvdygnbGVhc2UtczInKTtcblx0XHRcdGFzc2VydC5zdHJpY3RFcXVhbChsZW5zLnNlc3Npb25WaWV3QmluZGluZ1N1c3BlbmRlZCwgZmFsc2UpO1xuXHRcdFx0Y29uc3QgcmVzdG9yZWRMZW5zID0gcGFuZS5hY3RpdmVDb252ZXJzYXRpb25MZW5zO1xuXHRcdFx0YXNzZXJ0Lm9rKHJlc3RvcmVkTGVucyk7XG5cdFx0XHRhc3NlcnQuc3RyaWN0RXF1YWwocmVzdG9yZWRMZW5zLCBsZW5zKTtcblx0XHRcdGFzc2VydC5zdHJpY3RFcXVhbChyZXN0b3JlZExlbnMuc2Vzc2lvblZpZXdMZWFzZT8uc2Vzc2lvbklkLCAnbGVhc2UtczInKTtcblx0XHRcdGF3YWl0IGFzc2VydEVuZ2luZUZyYW1lUGFpbnRzKGhhcm5lc3MsIHBhbmUsICdsZWFzZS1zMicsICdMNCBwdWJsaWMgcmVzdG9yZScpO1xuXHRcdFx0Y29uc3QgcmV0aXJlZExlYXNlID0gcmVzdG9yZWRMZW5zLnNlc3Npb25WaWV3TGVhc2U7XG5cdFx0XHRhc3NlcnQub2socmV0aXJlZExlYXNlKTtcblx0XHRcdGNvbnN0IHJldGFpbmVkT2JzZXJ2ZXIgPSBzdG9yZS5hZGQoaGFybmVzcy5yb3N0ZXJTZXJ2aWNlLmFjcXVpcmVTZXNzaW9uVmlldygnbGVhc2UtczInKSk7XG5cdFx0XHRhc3NlcnQubm90U3RyaWN0RXF1YWwocmV0YWluZWRPYnNlcnZlciwgcmV0aXJlZExlYXNlKTtcblx0XHRcdGNvbnN0IGhvc3RMZWFzZSA9IGhhcm5lc3Muc2Vzc2lvblZpZXcuYWNxdWlyZWQuZmluZChsZWFzZSA9PiBsZWFzZS5zZXNzaW9uSWQgPT09ICdsZWFzZS1zMicgJiYgIWhhcm5lc3Muc2Vzc2lvblZpZXcucmVsZWFzZWQuaGFzKGxlYXNlLmxlYXNlSWQpKTtcblx0XHRcdGFzc2VydC5vayhob3N0TGVhc2UsICd0aGUgcmVzdG9yZWQgUGFuZSBhbmQgb2JzZXJ2ZXIgbXVzdCBzaGFyZSBhbiBhY3F1aXJlZCBzMiBob3N0IGxlYXNlJyk7XG5cdFx0XHRsZXQgcmV0aXJlZEZyYW1lcyA9IDA7XG5cdFx0XHRzdG9yZS5hZGQocmV0aXJlZExlYXNlLm9uRGlkQXBwbHlGcmFtZSgoKSA9PiB7IHJldGlyZWRGcmFtZXMrKzsgfSkpO1xuXHRcdFx0Y29uc3QgcmVtb3ZlZCA9IGhhcm5lc3MuZGVmZXJDYXRhbG9nKCk7XG5cdFx0XHRoYXJuZXNzLm5vdGlmeSgnbGl2ZScpO1xuXHRcdFx0YXdhaXQgYm91bmRlZChyZW1vdmVkLnN0YXJ0ZWQucCwgJ3B1YmxpYyByZW1vdmFsIGNhdGFsb2cgbXVzdCBzdGFydCcpO1xuXHRcdFx0Y29uc3Qgc3Vydml2aW5nQ2F0YWxvZyA9IHsgc2Vzc2lvbnM6IGhhcm5lc3MuY2F0YWxvZy5zZXNzaW9ucy5maWx0ZXIoc2Vzc2lvbiA9PiBzZXNzaW9uLnNlc3Npb25JZCAhPT0gJ2xlYXNlLXMyJykgfTtcblx0XHRcdGF3YWl0IHJlbW92ZWQucmVzdWx0LmNvbXBsZXRlKHN1cnZpdmluZ0NhdGFsb2cpO1xuXHRcdFx0YXdhaXQgYm91bmRlZChoYXJuZXNzLnJvc3RlclNlcnZpY2Uud2hlbkVuZ2luZUNhdGFsb2dSZWZyZXNoQ29tcGxldGUoKSwgJ3B1YmxpYyBwcnVuZSBtdXN0IHNldHRsZScpO1xuXHRcdFx0YXNzZXJ0LnN0cmljdEVxdWFsKGhhcm5lc3Muc2Vzc2lvbldpbmRvd1NlcnZpY2UuZ2V0TGVhZlNsb3RzKCdsZWFzZS1zMicpLCB1bmRlZmluZWQpO1xuXHRcdFx0YXNzZXJ0LnN0cmljdEVxdWFsKGhhcm5lc3Muc2Vzc2lvbldpbmRvd1NlcnZpY2UuaXNTZXNzaW9uV2luZG93SGlkZGVuKCdsZWFzZS1zMicpLCBmYWxzZSk7XG5cdFx0XHRhc3NlcnQuc3RyaWN0RXF1YWwoaGFybmVzcy5zZXNzaW9uV2luZG93U2VydmljZS5pc1Nlc3Npb25XaW5kb3dWaXNpYmxlKCdsZWFzZS1zMicpLCBmYWxzZSk7XG5cdFx0XHRhc3NlcnQuc3RyaWN0RXF1YWwobGVucy5pc0Rpc3Bvc2VkLCB0cnVlKTtcblx0XHRcdGNvbnN0IHJldGlyZWRTbmFwc2hvdCA9IHJldGlyZWRMZWFzZS5zbmFwc2hvdDtcblx0XHRcdGNvbnN0IGZyYW1lc0FmdGVyUmVtb3ZhbCA9IHJldGlyZWRGcmFtZXM7XG5cdFx0XHRjb25zdCBvYnNlcnZlZCA9IEV2ZW50LnRvUHJvbWlzZShyZXRhaW5lZE9ic2VydmVyLm9uRGlkQXBwbHlGcmFtZSk7XG5cdFx0XHR0cnkge1xuXHRcdFx0XHRoYXJuZXNzLnNlc3Npb25WaWV3LmVtaXRTZXNzaW9uKCdsZWFzZS1zMicsICdMNCByZXRhaW5lZCBvYnNlcnZlciBvbmx5Jyk7XG5cdFx0XHRcdGF3YWl0IGJvdW5kZWQob2JzZXJ2ZWQsICd0aGUgbGl2ZSByZXRhaW5lZCBvYnNlcnZlciBtdXN0IGFkbWl0IHRoZSBwb3N0LXBydW5lIGhvc3QgZnJhbWUnKTtcblx0XHRcdFx0YXNzZXJ0Lm5vdFN0cmljdEVxdWFsKHJldGFpbmVkT2JzZXJ2ZXIuc25hcHNob3QsIHJldGlyZWRTbmFwc2hvdCk7XG5cdFx0XHRcdGFzc2VydC5zdHJpY3RFcXVhbChyZXRpcmVkTGVhc2Uuc25hcHNob3QsIHJldGlyZWRTbmFwc2hvdCwgJ3RoZSBkaXNwb3NlZCBQYW5lIGxlYXNlIG11c3Qgbm8gbG9uZ2VyIHJlY2VpdmUgc2hhcmVkIGhvc3Qgc25hcHNob3RzJyk7XG5cdFx0XHRcdGFzc2VydC5zdHJpY3RFcXVhbChyZXRpcmVkRnJhbWVzLCBmcmFtZXNBZnRlclJlbW92YWwpO1xuXHRcdFx0fSBmaW5hbGx5IHtcblx0XHRcdFx0b2JzZXJ2ZWQuY2FuY2VsKCk7XG5cdFx0XHRcdHJldGFpbmVkT2JzZXJ2ZXIuZGlzcG9zZSgpO1xuXHRcdFx0fVxuXHRcdFx0YXNzZXJ0LnN0cmljdEVxdWFsKGhhcm5lc3Muc2Vzc2lvblZpZXcucmVsZWFzZWQuaGFzKGhvc3RMZWFzZS5sZWFzZUlkKSwgdHJ1ZSwgJ3RoZSByZXRpcmVkIFBhbmUgYW5kIHJvc3RlciBtdXN0IHJlbGVhc2UgdGhlaXIgb3duZXJzaGlwIGJlZm9yZSB0aGUgZmluYWwgb2JzZXJ2ZXIgcmVsZWFzZXMgdGhlIGhvc3QnKTtcblx0XHRcdGNvbnN0IGFmdGVyUmVtb3ZhbCA9IGJpbmRzKCk7XG5cdFx0XHRjb25zdCBsYXRlID0gaGFybmVzcy5kZWZlckNhdGFsb2coKTtcblx0XHRcdGhhcm5lc3Mubm90aWZ5KCdsaXZlJyk7XG5cdFx0XHRhd2FpdCBib3VuZGVkKGxhdGUuc3RhcnRlZC5wLCAncG9zdC1yZW1vdmFsIGNhdGFsb2cgbXVzdCBzdGFydCcpO1xuXHRcdFx0YXdhaXQgbGF0ZS5yZXN1bHQuY29tcGxldGUoc3Vydml2aW5nQ2F0YWxvZyk7XG5cdFx0XHRhd2FpdCBib3VuZGVkKGhhcm5lc3Mucm9zdGVyU2VydmljZS53aGVuRW5naW5lQ2F0YWxvZ1JlZnJlc2hDb21wbGV0ZSgpLCAncG9zdC1yZW1vdmFsIGNhdGFsb2cgbXVzdCBzZXR0bGUnKTtcblx0XHRcdGFzc2VydC5zdHJpY3RFcXVhbChiaW5kcygpLCBhZnRlclJlbW92YWwsICdsYXRlciByZWFkeSBub3RpY2VzIGNhbm5vdCByZXZpdmUgdGhlIHJlbW92ZWQgbm9uLWhpZGRlbiBsZWFmJyk7XG5cdFx0XHRhc3NlcnQuc3RyaWN0RXF1YWwocmV0aXJlZExlYXNlLnNuYXBzaG90LCByZXRpcmVkU25hcHNob3QpO1xuXHRcdFx0YXNzZXJ0LnN0cmljdEVxdWFsKHJldGlyZWRGcmFtZXMsIGZyYW1lc0FmdGVyUmVtb3ZhbCk7XG5cdFx0XHRhc3NlcnQuc3RyaWN0RXF1YWwoaGFybmVzcy5zZXNzaW9uVmlldy5yZWxlYXNlZC5oYXMoaG9zdExlYXNlLmxlYXNlSWQpLCB0cnVlKTtcblx0XHRcdGF3YWl0IGFzc2VydEVuZ2luZUZyYW1lUGFpbnRzKGhhcm5lc3MsIGhhcm5lc3MucGFuZSwgaGFybmVzcy5wcmltYXJ5SWQsICdMNCBzdXJ2aXZpbmcgb3duZXInKTtcblx0XHR9KTtcblxuXHRcdHRlc3QoJ0w0IGFuIHVubW91bnRlZCBub24taGlkZGVuIGJvdW5kIGtleSBjYW5ub3QgcmVjb25jaWxlIGJlZm9yZSBpdHMgcHVibGljIGxlYWYgZXhpc3RzJywgYXN5bmMgKCkgPT4ge1xuXHRcdFx0Y29uc3QgaGFybmVzcyA9IGF3YWl0IGNyZWF0ZUVuZ2luZVJldmVhbEhhcm5lc3MoKTtcblx0XHRcdGNvbnN0IHBlbmRpbmcgPSBhd2FpdCBzdGFydEVtcHR5Q2F0YWxvZ1JlZnJlc2goaGFybmVzcyk7XG5cdFx0XHRjb25zdCBpbnB1dCA9IHN0b3JlLmFkZChuZXcgQ29udmVyc2F0aW9uQ2hhdElucHV0KGdldENvbnZlcnNhdGlvbkNoYXRSZXNvdXJjZSgnbGVhc2UtczInLCAndW5tb3VudGVkJykpKTtcblx0XHRcdGNvbnN0IHBhcnQgPSBwYXJ0Rm9yKGhhcm5lc3MucGFydHMsIGhhcm5lc3MucHJpbWFyeUlkKTtcblx0XHRcdGF3YWl0IGhhcm5lc3MuZWRpdG9yU2VydmljZS5vcGVuRWRpdG9yKGlucHV0LCB1bmRlZmluZWQsIHBhcnQuYWN0aXZlR3JvdXApO1xuXHRcdFx0Y29uc3QgcGFuZSA9IHBhcnQuYWN0aXZlR3JvdXAuYWN0aXZlRWRpdG9yUGFuZTtcblx0XHRcdGFzc2VydC5vayhwYW5lIGluc3RhbmNlb2YgQ29udmVyc2F0aW9uRWRpdG9yUGFuZSk7XG5cdFx0XHRjb25zdCBsZW5zID0gcGFuZS5hY3RpdmVDb252ZXJzYXRpb25MZW5zO1xuXHRcdFx0YXNzZXJ0Lm9rKGxlbnMpO1xuXHRcdFx0YXNzZXJ0LnN0cmljdEVxdWFsKHBhbmUuaW5wdXQsIGlucHV0KTtcblx0XHRcdGFzc2VydC5zdHJpY3RFcXVhbChsZW5zLmJvdW5kU2Vzc2lvbklkLCAnbGVhc2UtczInKTtcblx0XHRcdGFzc2VydC5zdHJpY3RFcXVhbChsZW5zLnNlc3Npb25WaWV3TGVhc2UsIHVuZGVmaW5lZCk7XG5cdFx0XHRhc3NlcnQuc3RyaWN0RXF1YWwobGVucy5zZXNzaW9uVmlld0JpbmRpbmdTdXNwZW5kZWQsIGZhbHNlKTtcblx0XHRcdGFzc2VydC5zdHJpY3RFcXVhbChoYXJuZXNzLnNlc3Npb25XaW5kb3dTZXJ2aWNlLmlzU2Vzc2lvbldpbmRvd0hpZGRlbignbGVhc2UtczInKSwgZmFsc2UpO1xuXHRcdFx0YXNzZXJ0LnN0cmljdEVxdWFsKGhhcm5lc3Muc2Vzc2lvbldpbmRvd1NlcnZpY2UuaXNTZXNzaW9uV2luZG93VmlzaWJsZSgnbGVhc2UtczInKSwgZmFsc2UpO1xuXHRcdFx0Y29uc3QgYmluZHMgPSBvYnNlcnZlUGFuZUJpbmRzKGxlbnMpO1xuXHRcdFx0YXdhaXQgY29tcGxldGVDYXRhbG9nKGhhcm5lc3MsIHBlbmRpbmcpO1xuXHRcdFx0YXNzZXJ0LnN0cmljdEVxdWFsKGxlbnMuc2Vzc2lvblZpZXdMZWFzZSwgdW5kZWZpbmVkKTtcblx0XHRcdGFzc2VydC5zdHJpY3RFcXVhbChiaW5kcygpLCAwLCAnbm90LWhpZGRlbiBpcyBub3QgZXZpZGVuY2Ugb2YgYSB2aXNpYmxlIGxlYWYnKTtcblx0XHRcdGF3YWl0IGhhcm5lc3Muc2Vzc2lvbldpbmRvd1NlcnZpY2Uub3BlblNlc3Npb25CZXNpZGUoJ2xlYXNlLXMyJyk7XG5cdFx0XHRjb25zdCBtb3VudGVkID0gYXdhaXQgd2FpdEZvckVuZ2luZVBhbmUocGFydEZvcihoYXJuZXNzLnBhcnRzLCAnbGVhc2UtczInKSk7XG5cdFx0XHR0cmFja0VkaXRvcnMoaGFybmVzcy5wYXJ0cyk7XG5cdFx0XHRhd2FpdCBhc3NlcnRFbmdpbmVGcmFtZVBhaW50cyhoYXJuZXNzLCBtb3VudGVkLCAnbGVhc2UtczInLCAnTDQgbW91bnRlZCBzdWNjZXNzb3InKTtcblx0XHR9KTtcblxuXHRcdGZvciAoY29uc3QgYWN0aW9uIG9mIFsnY2xlYXJJbnB1dCcsICdkaXNwb3NlJywgJ3N3aXRjaCBpbnB1dCddIGFzIGNvbnN0KSB7XG5cdFx0XHR0ZXN0KGBMNSAke2FjdGlvbn0gZHVyaW5nIHJlYWwgY2F0YWxvZyBwZW5kaW5nIGNhbm5vdCByZXZpdmUgdGhlIGNhcHR1cmVkIG93bmVyYCwgYXN5bmMgKCkgPT4ge1xuXHRcdFx0XHRjb25zdCBoYXJuZXNzID0gYXdhaXQgY3JlYXRlRW5naW5lUmV2ZWFsSGFybmVzcygpO1xuXHRcdFx0XHRjb25zdCBwZW5kaW5nID0gYXdhaXQgc3RhcnRFbXB0eUNhdGFsb2dSZWZyZXNoKGhhcm5lc3MpO1xuXHRcdFx0XHRjb25zdCBvbGRJbnB1dCA9IGhhcm5lc3MucGFuZS5pbnB1dDtcblx0XHRcdFx0Y29uc3Qgb2xkTGVucyA9IGhhcm5lc3MubGVucztcblx0XHRcdFx0Y29uc3Qgb2xkQmluZHMgPSBvYnNlcnZlUGFuZUJpbmRzKG9sZExlbnMpO1xuXHRcdFx0XHRpZiAoYWN0aW9uID09PSAnY2xlYXJJbnB1dCcpIHtcblx0XHRcdFx0XHRoYXJuZXNzLnBhbmUuY2xlYXJJbnB1dCgpO1xuXHRcdFx0XHR9IGVsc2UgaWYgKGFjdGlvbiA9PT0gJ2Rpc3Bvc2UnKSB7XG5cdFx0XHRcdFx0aGFybmVzcy5wYW5lLmRpc3Bvc2UoKTtcblx0XHRcdFx0fSBlbHNlIHtcblx0XHRcdFx0XHRjb25zdCBpbnB1dCA9IHN0b3JlLmFkZChuZXcgQ29udmVyc2F0aW9uQ2hhdElucHV0KGdldENvbnZlcnNhdGlvbkNoYXRSZXNvdXJjZShoYXJuZXNzLnByaW1hcnlJZCwgJ3N1Y2Nlc3NvcicpKSk7XG5cdFx0XHRcdFx0YXdhaXQgaGFybmVzcy5lZGl0b3JTZXJ2aWNlLm9wZW5FZGl0b3IoaW5wdXQsIHVuZGVmaW5lZCwgcGFydEZvcihoYXJuZXNzLnBhcnRzLCBoYXJuZXNzLnByaW1hcnlJZCkuYWN0aXZlR3JvdXApO1xuXHRcdFx0XHRcdGFzc2VydC5zdHJpY3RFcXVhbChoYXJuZXNzLnBhbmUuaW5wdXQsIGlucHV0KTtcblx0XHRcdFx0XHRhc3NlcnQubm90U3RyaWN0RXF1YWwoaGFybmVzcy5wYW5lLmlucHV0LCBvbGRJbnB1dCk7XG5cdFx0XHRcdH1cblx0XHRcdFx0Y29uc3QgYmVmb3JlUmVhZHkgPSBvbGRCaW5kcygpO1xuXHRcdFx0XHRhd2FpdCBjb21wbGV0ZUNhdGFsb2coaGFybmVzcywgcGVuZGluZyk7XG5cdFx0XHRcdGlmIChhY3Rpb24gPT09ICdzd2l0Y2ggaW5wdXQnKSB7XG5cdFx0XHRcdFx0YXNzZXJ0LnN0cmljdEVxdWFsKGhhcm5lc3MucGFuZS5hY3RpdmVDb252ZXJzYXRpb25MZW5zPy5ib3VuZFNlc3Npb25JZCwgaGFybmVzcy5wcmltYXJ5SWQpO1xuXHRcdFx0XHRcdGFzc2VydC5zdHJpY3RFcXVhbChvbGRCaW5kcygpIC0gYmVmb3JlUmVhZHksIDEsICdvbmx5IHRoZSBjdXJyZW50IGlucHV0IGxpc3RlbmVyIG1heSByZWNvbmNpbGUnKTtcblx0XHRcdFx0XHRhc3NlcnQuc3RyaWN0RXF1YWwoaGFybmVzcy5wYW5lLmFjdGl2ZUNvbnZlcnNhdGlvbkxlbnM/LnNlc3Npb25WaWV3TGVhc2U/LnNlc3Npb25JZCwgaGFybmVzcy5wcmltYXJ5SWQpO1xuXHRcdFx0XHR9IGVsc2Uge1xuXHRcdFx0XHRcdGFzc2VydC5zdHJpY3RFcXVhbChoYXJuZXNzLnBhbmUuYWN0aXZlQ29udmVyc2F0aW9uTGVucywgdW5kZWZpbmVkKTtcblx0XHRcdFx0XHRhc3NlcnQuc3RyaWN0RXF1YWwob2xkTGVucy5pc0Rpc3Bvc2VkLCB0cnVlKTtcblx0XHRcdFx0XHRhc3NlcnQuc3RyaWN0RXF1YWwob2xkQmluZHMoKSwgYmVmb3JlUmVhZHksICdsYXRlIGNhdGFsb2cvc2Vzc2lvbiBub3RpY2VzIGNhbm5vdCBiaW5kIHRoZSByZXRpcmVkIG93bmVyJyk7XG5cdFx0XHRcdH1cblx0XHRcdH0pO1xuXHRcdH1cblxuXHRcdHRlc3QoJ0w2IHJlcGVhdGVkIHJlYWwgc2Vzc2lvbiBub3RpY2VzIGtlZXAgdGhlIHJlY292ZXJlZCBsZWFzZSBhbmQgY29udGludWUgZGVsaXZlcmluZyBmcmFtZXMnLCBhc3luYyAoKSA9PiB7XG5cdFx0XHRjb25zdCBoYXJuZXNzID0gYXdhaXQgY3JlYXRlRW5naW5lUmV2ZWFsSGFybmVzcygpO1xuXHRcdFx0Y29uc3QgcGVuZGluZyA9IGF3YWl0IHN0YXJ0RW1wdHlDYXRhbG9nUmVmcmVzaChoYXJuZXNzKTtcblx0XHRcdGF3YWl0IGNvbXBsZXRlQ2F0YWxvZyhoYXJuZXNzLCBwZW5kaW5nKTtcblx0XHRcdGF3YWl0IGFzc2VydEVuZ2luZUZyYW1lUGFpbnRzKGhhcm5lc3MsIGhhcm5lc3MucGFuZSwgaGFybmVzcy5wcmltYXJ5SWQsICdMNiBmaXJzdCBmcmFtZScpO1xuXHRcdFx0Y29uc3QgbGVhc2UgPSBoYXJuZXNzLmxlbnMuc2Vzc2lvblZpZXdMZWFzZTtcblx0XHRcdGFzc2VydC5vayhsZWFzZSk7XG5cdFx0XHRjb25zdCBjb3VudCA9IGhhcm5lc3Muc2Vzc2lvblZpZXcuYWNxdWlyZWQubGVuZ3RoO1xuXHRcdFx0Zm9yIChsZXQgaSA9IDA7IGkgPCAyOyBpKyspIHtcblx0XHRcdFx0Y29uc3QgcmVmcmVzaCA9IGhhcm5lc3MuZGVmZXJDYXRhbG9nKCk7XG5cdFx0XHRcdGhhcm5lc3Mubm90aWZ5KCdsaXZlJyk7XG5cdFx0XHRcdGF3YWl0IGJvdW5kZWQocmVmcmVzaC5zdGFydGVkLnAsICdkdXBsaWNhdGUgcmVhbCByZWZyZXNoIG11c3Qgc3RhcnQnKTtcblx0XHRcdFx0YXdhaXQgY29tcGxldGVDYXRhbG9nKGhhcm5lc3MsIHJlZnJlc2gpO1xuXHRcdFx0XHRhc3NlcnQuc3RyaWN0RXF1YWwoaGFybmVzcy5sZW5zLnNlc3Npb25WaWV3TGVhc2UsIGxlYXNlKTtcblx0XHRcdFx0YXNzZXJ0LnN0cmljdEVxdWFsKGhhcm5lc3Muc2Vzc2lvblZpZXcuYWNxdWlyZWQubGVuZ3RoLCBjb3VudCwgJ29ic2VydmF0aW9uIG93bmVycyBtdXN0IG5vdCBpbXBseSBhIG5ldyBwaHlzaWNhbCBhY3F1aXNpdGlvbicpO1xuXHRcdFx0fVxuXHRcdFx0YXdhaXQgYXNzZXJ0RW5naW5lRnJhbWVQYWludHMoaGFybmVzcywgaGFybmVzcy5wYW5lLCBoYXJuZXNzLnByaW1hcnlJZCwgJ0w2IGxhdGVyIGZyYW1lJyk7XG5cdFx0XHRhc3NlcnQuc3RyaWN0RXF1YWwoaGFybmVzcy5sZW5zLnNlc3Npb25WaWV3TGVhc2UsIGxlYXNlKTtcblx0XHR9KTtcblxuXHRcdHRlc3QoJ0w3IHR3byBwaW5uZWQgdmlzaWJsZSBvd25lcnMgcmVjb3ZlciB0aGVpciBvd24gYm91bmRzIGZyb20gb25lIGFjdGl2ZS1zZXNzaW9uIGNhdGFsb2cgbm90aWNlJywgYXN5bmMgKCkgPT4ge1xuXHRcdFx0Y29uc3QgaGFybmVzcyA9IGF3YWl0IGNyZWF0ZUVuZ2luZVJldmVhbEhhcm5lc3MoKTtcblx0XHRcdGF3YWl0IGhhcm5lc3Muc2Vzc2lvbldpbmRvd1NlcnZpY2Uub3BlblNlc3Npb25CZXNpZGUoJ2xlYXNlLXMyJyk7XG5cdFx0XHRjb25zdCBzZWNvbmQgPSBhd2FpdCB3YWl0Rm9yRW5naW5lUGFuZShwYXJ0Rm9yKGhhcm5lc3MucGFydHMsICdsZWFzZS1zMicpKTtcblx0XHRcdHRyYWNrRWRpdG9ycyhoYXJuZXNzLnBhcnRzKTtcblx0XHRcdGNvbnN0IGxlbnMyID0gc2Vjb25kLmFjdGl2ZUNvbnZlcnNhdGlvbkxlbnM7XG5cdFx0XHRhc3NlcnQub2sobGVuczI/LnNlc3Npb25WaWV3TGVhc2UpO1xuXHRcdFx0YXdhaXQgaGFybmVzcy5zZXNzaW9uV2luZG93U2VydmljZS5yZXZlYWxTZXNzaW9uV2luZG93KGhhcm5lc3MucHJpbWFyeUlkKTtcblx0XHRcdGFzc2VydC5zdHJpY3RFcXVhbChoYXJuZXNzLnNlc3Npb25XaW5kb3dTZXJ2aWNlLmlzU2Vzc2lvbldpbmRvd1Zpc2libGUoaGFybmVzcy5wcmltYXJ5SWQpLCB0cnVlKTtcblx0XHRcdGFzc2VydC5zdHJpY3RFcXVhbChoYXJuZXNzLnNlc3Npb25XaW5kb3dTZXJ2aWNlLmlzU2Vzc2lvbldpbmRvd1Zpc2libGUoJ2xlYXNlLXMyJyksIHRydWUpO1xuXHRcdFx0Y29uc3QgcGVuZGluZyA9IGF3YWl0IHN0YXJ0RW1wdHlDYXRhbG9nUmVmcmVzaChoYXJuZXNzKTtcblx0XHRcdGFzc2VydFZpc2libGVNaXNzaW5nKGhhcm5lc3MsIHNlY29uZCwgJ2xlYXNlLXMyJyk7XG5cdFx0XHRjb25zdCBhY3RpdmUgPSBoYXJuZXNzLnJvc3RlclNlcnZpY2UuZ2V0QWN0aXZlU2Vzc2lvbklkKCk7XG5cdFx0XHRjb25zdCBub3RpZmllZDogc3RyaW5nW10gPSBbXTtcblx0XHRcdHN0b3JlLmFkZChoYXJuZXNzLnJvc3RlclNlcnZpY2Uub25EaWRDaGFuZ2VTZXNzaW9uKGlkID0+IHsgbm90aWZpZWQucHVzaChpZCk7IH0pKTtcblx0XHRcdGF3YWl0IGNvbXBsZXRlQ2F0YWxvZyhoYXJuZXNzLCBwZW5kaW5nKTtcblx0XHRcdGFzc2VydC5vayhub3RpZmllZC5pbmNsdWRlcyhhY3RpdmUpKTtcblx0XHRcdGFzc2VydC5vayghbm90aWZpZWQuaW5jbHVkZXMoJ2xlYXNlLXMyJyksICd0aGUgaW5hY3RpdmUgcGlubmVkIGxlYWYgY2Fubm90IHJlbHkgb24gaXRzIG93biBldmVudCBpZCcpO1xuXHRcdFx0YXNzZXJ0LnN0cmljdEVxdWFsKGhhcm5lc3MucGFuZS5hY3RpdmVDb252ZXJzYXRpb25MZW5zLCBoYXJuZXNzLmxlbnMpO1xuXHRcdFx0YXNzZXJ0LnN0cmljdEVxdWFsKHNlY29uZC5hY3RpdmVDb252ZXJzYXRpb25MZW5zLCBsZW5zMik7XG5cdFx0XHRhc3NlcnQuc3RyaWN0RXF1YWwoaGFybmVzcy5sZW5zLnNlc3Npb25WaWV3TGVhc2U/LnNlc3Npb25JZCwgaGFybmVzcy5wcmltYXJ5SWQpO1xuXHRcdFx0YXNzZXJ0LnN0cmljdEVxdWFsKGxlbnMyLnNlc3Npb25WaWV3TGVhc2U/LnNlc3Npb25JZCwgJ2xlYXNlLXMyJyk7XG5cdFx0XHRhc3NlcnQubm90U3RyaWN0RXF1YWwoaGFybmVzcy5sZW5zLnNlc3Npb25WaWV3TGVhc2UsIGxlbnMyLnNlc3Npb25WaWV3TGVhc2UpO1xuXHRcdFx0YXdhaXQgYXNzZXJ0RW5naW5lRnJhbWVQYWludHMoaGFybmVzcywgaGFybmVzcy5wYW5lLCBoYXJuZXNzLnByaW1hcnlJZCwgJ0w3IGZpcnN0IGxlYWYgb25seScpO1xuXHRcdFx0YXdhaXQgYXNzZXJ0RW5naW5lRnJhbWVQYWludHMoaGFybmVzcywgc2Vjb25kLCAnbGVhc2UtczInLCAnTDcgc2Vjb25kIGxlYWYgb25seScpO1xuXHRcdFx0YXNzZXJ0Lm9rKCFoYXJuZXNzLnBhbmUuZ2V0UmVhZGluZ0NvbHVtbigpPy50ZXh0Q29udGVudD8uaW5jbHVkZXMoJ0w3IHNlY29uZCBsZWFmIG9ubHknKSk7XG5cdFx0XHRhc3NlcnQub2soIXNlY29uZC5nZXRSZWFkaW5nQ29sdW1uKCk/LnRleHRDb250ZW50Py5pbmNsdWRlcygnTDcgZmlyc3QgbGVhZiBvbmx5JykpO1xuXHRcdH0pO1xuXHR9KTtcblxuXHR0ZXN0KCc4IHNpbmdsZS1sZWFmIHJldmVhbCBBXHUyMTkyQlx1MjE5MkEga2VlcHMgb25lIHZpc2libGUgcHJpbWFyeSB3aXRob3V0IGhpZGUgYnV0dG9uJywgYXN5bmMgKCkgPT4ge1xuXHRcdGNvbnN0IGhhcm5lc3MgPSBhd2FpdCBjcmVhdGVSZXZlYWxIYXJuZXNzKCk7XG5cdFx0Y29uc3QgeyBwYXJ0cywgc2Vzc2lvbldpbmRvd1NlcnZpY2UsIHJvc3RlclNlcnZpY2UsIHByaW1hcnlJZCB9ID0gaGFybmVzcztcblx0XHRjb25zdCBiID0gcm9zdGVyU2VydmljZS5zZWVkU2Vzc2lvblF1aWV0bHkoKTtcblxuXHRcdGF3YWl0IHNlc3Npb25XaW5kb3dTZXJ2aWNlLnJldmVhbFNlc3Npb25XaW5kb3coYik7XG5cdFx0Y29uc3QgcGFydEIgPSBwYXJ0Rm9yKHBhcnRzLCBiKTtcblx0XHRhd2FpdCB3YWl0Rm9yU2Vzc2lvblBhbmUoaGFybmVzcywgYik7XG5cdFx0YXNzZXJ0LmRlZXBTdHJpY3RFcXVhbCh2aXNpYmxlTGVhZktleXMoc2Vzc2lvbldpbmRvd1NlcnZpY2UpLCBbYl0pO1xuXHRcdGFzc2VydC5zdHJpY3RFcXVhbChzZXNzaW9uV2luZG93U2VydmljZS5nZXRQcmltYXJ5U2Vzc2lvbktleSgpLCBiKTtcblx0XHRhc3NlcnQuc3RyaWN0RXF1YWwocGFydEIuc2Vzc2lvbktleSwgYik7XG5cdFx0YXNzZXJ0LnN0cmljdEVxdWFsKHBhcnRzLmdldEFjdGl2ZUNvbnZlcnNhdGlvbkVkaXRvclBhcnQoKT8uc2Vzc2lvbktleSwgYik7XG5cdFx0YXNzZXJ0Lm9rKHNlc3Npb25XaW5kb3dTZXJ2aWNlLmlzU2Vzc2lvbldpbmRvd0hpZGRlbihwcmltYXJ5SWQpKTtcblx0XHRhc3NlcnQuc3RyaWN0RXF1YWwocGFydEZvcihwYXJ0cywgcHJpbWFyeUlkKS5zZXNzaW9uS2V5LCBwcmltYXJ5SWQpO1xuXHRcdGFzc2VydC5zdHJpY3RFcXVhbChoaWRlQnV0dG9uKHNlc3Npb25XaW5kb3dTZXJ2aWNlLCBiKT8uaGlkZGVuLCB0cnVlKTtcblxuXHRcdGF3YWl0IHNlc3Npb25XaW5kb3dTZXJ2aWNlLnJldmVhbFNlc3Npb25XaW5kb3cocHJpbWFyeUlkKTtcblx0XHRhd2FpdCB3YWl0Rm9yU2Vzc2lvblBhbmUoaGFybmVzcywgcHJpbWFyeUlkKTtcblx0XHRhc3NlcnQuZGVlcFN0cmljdEVxdWFsKHZpc2libGVMZWFmS2V5cyhzZXNzaW9uV2luZG93U2VydmljZSksIFtwcmltYXJ5SWRdKTtcblx0XHRhc3NlcnQuc3RyaWN0RXF1YWwoc2Vzc2lvbldpbmRvd1NlcnZpY2UuZ2V0UHJpbWFyeVNlc3Npb25LZXkoKSwgcHJpbWFyeUlkKTtcblx0XHRhc3NlcnQuc3RyaWN0RXF1YWwoaGlkZUJ1dHRvbihzZXNzaW9uV2luZG93U2VydmljZSwgcHJpbWFyeUlkKT8uaGlkZGVuLCB0cnVlKTtcblx0fSk7XG5cblx0dGVzdCgnaGlkZSBmb2N1c2VkIHNlY29uZGFyeSBsZWFmIG1vdmVzIGZvY3VzIHRvIHByaW1hcnknLCBhc3luYyAoKSA9PiB7XG5cdFx0Y29uc3QgaGFybmVzcyA9IGNyZWF0ZUxpZ2h0d2VpZ2h0V2luZG93SGFybmVzcygpO1xuXHRcdGF3YWl0IHRpbWVvdXQoMCk7XG5cdFx0Y29uc3QgcHJpbWFyeUlkID0gaGFybmVzcy5yb3N0ZXJTZXJ2aWNlLmdldEFjdGl2ZVNlc3Npb25JZCgpO1xuXHRcdGF3YWl0IGhhcm5lc3Muc2Vzc2lvbldpbmRvd1NlcnZpY2UuZW5zdXJlUHJpbWFyeVdpbmRvdyhwcmltYXJ5SWQpO1xuXHRcdGNvbnN0IHNlY29uZGFyeUlkID0gaGFybmVzcy5yb3N0ZXJTZXJ2aWNlLnNlZWRTZXNzaW9uUXVpZXRseSgpO1xuXHRcdGF3YWl0IGhhcm5lc3Muc2Vzc2lvbldpbmRvd1NlcnZpY2Uub3BlblNlc3Npb25CZXNpZGUoc2Vjb25kYXJ5SWQpO1xuXHRcdGF3YWl0IGhhcm5lc3Muc2Vzc2lvbldpbmRvd1NlcnZpY2UucmV2ZWFsU2Vzc2lvbldpbmRvdyhzZWNvbmRhcnlJZCk7XG5cdFx0YXNzZXJ0LnN0cmljdEVxdWFsKGhhcm5lc3Muc2Vzc2lvbldpbmRvd1NlcnZpY2UuZ2V0Rm9jdXNlZExlYWZTZXNzaW9uS2V5KCksIHNlY29uZGFyeUlkKTtcblxuXHRcdGhhcm5lc3Muc2Vzc2lvbldpbmRvd1NlcnZpY2UuaGlkZVNlc3Npb25XaW5kb3coc2Vjb25kYXJ5SWQpO1xuXG5cdFx0YXNzZXJ0LnN0cmljdEVxdWFsKGhhcm5lc3Muc2Vzc2lvbldpbmRvd1NlcnZpY2UuaXNTZXNzaW9uV2luZG93SGlkZGVuKHNlY29uZGFyeUlkKSwgdHJ1ZSk7XG5cdFx0YXNzZXJ0LnN0cmljdEVxdWFsKGhhcm5lc3Muc2Vzc2lvbldpbmRvd1NlcnZpY2UuZ2V0Rm9jdXNlZExlYWZTZXNzaW9uS2V5KCksIHByaW1hcnlJZCk7XG5cdFx0Y29uc3QgcHJpbWFyeUxlYWYgPSBoYXJuZXNzLnNlc3Npb25XaW5kb3dTZXJ2aWNlLmdldExlYWZTbG90cyhwcmltYXJ5SWQpITtcblx0XHRjb25zdCBhY3RpdmUgPSBnZXRBY3RpdmVFbGVtZW50KCk7XG5cdFx0YXNzZXJ0Lm9rKFxuXHRcdFx0cHJpbWFyeUxlYWYuY29udGFpbmVyID09PSBhY3RpdmUgfHwgcHJpbWFyeUxlYWYuY29udGFpbmVyLmNvbnRhaW5zKGFjdGl2ZSksXG5cdFx0XHQnZm9jdXMgbXVzdCBsZWF2ZSB0aGUgaGlkZGVuIGxlYWYgYW5kIGxhbmQgb24gdGhlIHZpc2libGUgcHJpbWFyeScsXG5cdFx0KTtcblx0fSk7XG5cblx0dGVzdCgnOCB0d28gdmlzaWJsZSBsZWF2ZXM6IHJldmVhbCBhbHJlYWR5LXZpc2libGUgbGVhZiBmb2N1c2VzIGl0JywgYXN5bmMgKCkgPT4ge1xuXHRcdGNvbnN0IGhhcm5lc3MgPSBhd2FpdCBjcmVhdGVSZXZlYWxIYXJuZXNzKCk7XG5cdFx0Y29uc3QgeyBwYXJ0cywgc2Vzc2lvbldpbmRvd1NlcnZpY2UsIHJvc3RlclNlcnZpY2UsIHByaW1hcnlJZCwgY29udmVyc2F0aW9uUGFydCB9ID0gaGFybmVzcztcblx0XHRjb25zdCBiID0gcm9zdGVyU2VydmljZS5zZWVkU2Vzc2lvblF1aWV0bHkoKTtcblx0XHRhd2FpdCBzZXNzaW9uV2luZG93U2VydmljZS5vcGVuU2Vzc2lvbkJlc2lkZShiKTtcblx0XHRhd2FpdCB3YWl0Rm9yU2Vzc2lvblBhbmUoaGFybmVzcywgYik7XG5cdFx0YXNzZXJ0LnN0cmljdEVxdWFsKHNlc3Npb25XaW5kb3dTZXJ2aWNlLmdldFZpc2libGVXaW5kb3dDb3VudCgpLCAyKTtcblxuXHRcdGF3YWl0IHNlc3Npb25XaW5kb3dTZXJ2aWNlLnJldmVhbFNlc3Npb25XaW5kb3coYik7XG5cdFx0YXNzZXJ0LnN0cmljdEVxdWFsKHNlc3Npb25XaW5kb3dTZXJ2aWNlLmdldFZpc2libGVXaW5kb3dDb3VudCgpLCAyKTtcblx0XHRhc3NlcnQuc3RyaWN0RXF1YWwoc2Vzc2lvbldpbmRvd1NlcnZpY2UuZ2V0Rm9jdXNlZExlYWZTZXNzaW9uS2V5KCksIGIpO1xuXHRcdGFzc2VydC5zdHJpY3RFcXVhbChyb3N0ZXJTZXJ2aWNlLmdldEFjdGl2ZVNlc3Npb25JZCgpLCBiKTtcblx0XHRhc3NlcnQuc3RyaWN0RXF1YWwocGFydHMuZ2V0QWN0aXZlQ29udmVyc2F0aW9uRWRpdG9yUGFydCgpPy5zZXNzaW9uS2V5LCBiKTtcblx0XHRjb25zdCBsZWFmQiA9IHNlc3Npb25XaW5kb3dTZXJ2aWNlLmdldExlYWZTbG90cyhiKTtcblx0XHRhc3NlcnQub2sobGVhZkIpO1xuXHRcdGNvbnN0IGFjdGl2ZSA9IGdldEFjdGl2ZUVsZW1lbnQoKTtcblx0XHRhc3NlcnQub2soXG5cdFx0XHRsZWFmQi5jb250YWluZXIgPT09IGFjdGl2ZSB8fCBsZWFmQi5jb250YWluZXIuY29udGFpbnMoYWN0aXZlKSxcblx0XHRcdCdmb2N1cyBtdXN0IHN0YXkgaW4gdGhlIHJldmVhbGVkIGxlYWYsIG5vdCBzbmFwIGJhY2sgdG8gcHJpbWFyeScsXG5cdFx0KTtcblx0XHRjb25zdCBjaHJvbWUgPSBjb3VudExlYWZDaHJvbWUoc2Vzc2lvbldpbmRvd1NlcnZpY2UsIGNvbnZlcnNhdGlvblBhcnQpO1xuXHRcdGFzc2VydC5zdHJpY3RFcXVhbChjaHJvbWUuYmFycywgMik7XG5cdFx0YXNzZXJ0LnN0cmljdEVxdWFsKHBhcnRGb3IocGFydHMsIHByaW1hcnlJZCkuc2Vzc2lvbktleSwgcHJpbWFyeUlkKTtcblx0XHRhc3NlcnQuc3RyaWN0RXF1YWwocGFydEZvcihwYXJ0cywgYikuc2Vzc2lvbktleSwgYik7XG5cdH0pO1xuXG5cdHRlc3QoJ2NhbmNlbGxlZCBhbHJlYWR5LXZpc2libGUgcmV2ZWFsIGRvZXMgbm90IHN3aXRjaCB0aGUgYWN0aXZlIHNlc3Npb24gYmFjaycsIGFzeW5jICgpID0+IHtcblx0XHRjb25zdCBoYXJuZXNzID0gYXdhaXQgY3JlYXRlUmV2ZWFsSGFybmVzcygpO1xuXHRcdGNvbnN0IHsgcGFydHMsIHNlc3Npb25XaW5kb3dTZXJ2aWNlLCByb3N0ZXJTZXJ2aWNlLCBwcmltYXJ5SWQgfSA9IGhhcm5lc3M7XG5cdFx0Y29uc3QgYiA9IHJvc3RlclNlcnZpY2Uuc2VlZFNlc3Npb25RdWlldGx5KCk7XG5cdFx0YXdhaXQgc2Vzc2lvbldpbmRvd1NlcnZpY2Uub3BlblNlc3Npb25CZXNpZGUoYik7XG5cdFx0Y29uc3QgcGFuZUEgPSBhd2FpdCB3YWl0Rm9yU2Vzc2lvblBhbmUoaGFybmVzcywgcHJpbWFyeUlkKTtcblx0XHRjb25zdCBwYW5lQiA9IGF3YWl0IHdhaXRGb3JTZXNzaW9uUGFuZShoYXJuZXNzLCBiKTtcblx0XHRhc3NlcnQub2socGFuZUEubGVhZlNlc3Npb25CYXJIb3N0KTtcblx0XHRhc3NlcnQub2socGFuZUIubGVhZlNlc3Npb25CYXJIb3N0KTtcblx0XHRhc3NlcnQuc3RyaWN0RXF1YWwoc2Vzc2lvbldpbmRvd1NlcnZpY2UuZ2V0VmlzaWJsZVdpbmRvd0NvdW50KCksIDIpO1xuXG5cdFx0bGV0IHJlbGVhc2VBID0gKCkgPT4geyB9O1xuXHRcdGNvbnN0IGdhdGUgPSBuZXcgUHJvbWlzZTx2b2lkPihyZXNvbHZlID0+IHsgcmVsZWFzZUEgPSByZXNvbHZlOyB9KTtcblx0XHQocGFydEZvcihwYXJ0cywgcHJpbWFyeUlkKSBhcyB7IHdoZW5SZWFkeTogUHJvbWlzZTx2b2lkPiB9KS53aGVuUmVhZHkgPSBnYXRlO1xuXG5cdFx0Y29uc3Qgc3dpdGNoZWQ6IHN0cmluZ1tdID0gW107XG5cdFx0Y29uc3Qgb3JpZ2luYWxTd2l0Y2ggPSByb3N0ZXJTZXJ2aWNlLnN3aXRjaFNlc3Npb24uYmluZChyb3N0ZXJTZXJ2aWNlKTtcblx0XHRyb3N0ZXJTZXJ2aWNlLnN3aXRjaFNlc3Npb24gPSAoc2Vzc2lvbklkOiBzdHJpbmcpID0+IHtcblx0XHRcdHN3aXRjaGVkLnB1c2goc2Vzc2lvbklkKTtcblx0XHRcdG9yaWdpbmFsU3dpdGNoKHNlc3Npb25JZCk7XG5cdFx0fTtcblxuXHRcdGNvbnN0IGZpcnN0ID0gcGFuZUEubGVhZlNlc3Npb25CYXJIb3N0LnN3aXRjaExlYWZTZXNzaW9uKHByaW1hcnlJZCk7XG5cdFx0dHJ5IHtcblx0XHRcdGF3YWl0IHRpbWVvdXQoMCk7XG5cdFx0XHRhd2FpdCBwYW5lQi5sZWFmU2Vzc2lvbkJhckhvc3Quc3dpdGNoTGVhZlNlc3Npb24oYik7XG5cdFx0XHRhc3NlcnQuc3RyaWN0RXF1YWwoc2Vzc2lvbldpbmRvd1NlcnZpY2UuZ2V0Rm9jdXNlZExlYWZTZXNzaW9uS2V5KCksIGIpO1xuXHRcdFx0YXNzZXJ0LnN0cmljdEVxdWFsKHJvc3RlclNlcnZpY2UuZ2V0QWN0aXZlU2Vzc2lvbklkKCksIGIpO1xuXHRcdFx0c3dpdGNoZWQubGVuZ3RoID0gMDtcblx0XHRcdHJlbGVhc2VBKCk7XG5cdFx0XHRhd2FpdCBmaXJzdDtcblx0XHRcdGFzc2VydC5kZWVwU3RyaWN0RXF1YWwoc3dpdGNoZWQsIFtdKTtcblx0XHRcdGFzc2VydC5zdHJpY3RFcXVhbChzZXNzaW9uV2luZG93U2VydmljZS5nZXRGb2N1c2VkTGVhZlNlc3Npb25LZXkoKSwgYik7XG5cdFx0XHRhc3NlcnQuc3RyaWN0RXF1YWwocm9zdGVyU2VydmljZS5nZXRBY3RpdmVTZXNzaW9uSWQoKSwgYik7XG5cdFx0fSBmaW5hbGx5IHtcblx0XHRcdHJlbGVhc2VBKCk7XG5cdFx0fVxuXHR9KTtcblxuXHR0ZXN0KCdoaWRlIGR1cmluZyBwYW5lLWxlc3MgcmV2ZWFsIHdhaXQgZG9lcyBub3Qgc3RlYWwgZm9jdXMgb3IgdGhlIGFjdGl2ZSBzZXNzaW9uJywgYXN5bmMgZnVuY3Rpb24gKCkge1xuXHRcdHRoaXMudGltZW91dCgxNV8wMDApO1xuXHRcdGNvbnN0IGhhcm5lc3MgPSBjcmVhdGVMaWdodHdlaWdodFdpbmRvd0hhcm5lc3MoKTtcblx0XHRhd2FpdCB0aW1lb3V0KDApO1xuXHRcdGNvbnN0IHsgc2Vzc2lvbldpbmRvd1NlcnZpY2UsIHJvc3RlclNlcnZpY2UsIGNvbnZlcnNhdGlvblBhcnRzIH0gPSBoYXJuZXNzO1xuXHRcdGNvbnN0IHByaW1hcnlJZCA9IHJvc3RlclNlcnZpY2UuZ2V0QWN0aXZlU2Vzc2lvbklkKCk7XG5cdFx0YXdhaXQgc2Vzc2lvbldpbmRvd1NlcnZpY2UuZW5zdXJlUHJpbWFyeVdpbmRvdyhwcmltYXJ5SWQpO1xuXHRcdGNvbnN0IHNlY29uZGFyeUlkID0gcm9zdGVyU2VydmljZS5zZWVkU2Vzc2lvblF1aWV0bHkoKTtcblx0XHRhd2FpdCBzZXNzaW9uV2luZG93U2VydmljZS5vcGVuU2Vzc2lvbkJlc2lkZShzZWNvbmRhcnlJZCk7XG5cdFx0YXNzZXJ0LnN0cmljdEVxdWFsKHNlc3Npb25XaW5kb3dTZXJ2aWNlLmlzU2Vzc2lvbldpbmRvd1Zpc2libGUocHJpbWFyeUlkKSwgdHJ1ZSk7XG5cdFx0YXNzZXJ0LnN0cmljdEVxdWFsKHNlc3Npb25XaW5kb3dTZXJ2aWNlLmlzU2Vzc2lvbldpbmRvd1Zpc2libGUoc2Vjb25kYXJ5SWQpLCB0cnVlKTtcblx0XHRhc3NlcnQuc3RyaWN0RXF1YWwoc2Vzc2lvbldpbmRvd1NlcnZpY2UuZ2V0VmlzaWJsZVdpbmRvd0NvdW50KCksIDIpO1xuXG5cdFx0Y29uc3Qgc2Vjb25kYXJ5UGFydCA9IGNvbnZlcnNhdGlvblBhcnRzLmZpbmQocGFydCA9PiBwYXJ0LnNlc3Npb25LZXkgPT09IHNlY29uZGFyeUlkKTtcblx0XHRhc3NlcnQub2soc2Vjb25kYXJ5UGFydCk7XG5cdFx0Y29uc3QgZ3JvdXAgPSBzZWNvbmRhcnlQYXJ0LmFjdGl2ZUdyb3VwIGFzIHsgYWN0aXZlRWRpdG9yUGFuZT86IHsgZ2V0SWQoKTogc3RyaW5nIH07IG9uRGlkQWN0aXZlRWRpdG9yQ2hhbmdlPzogRXZlbnQ8dW5rbm93bj4gfTtcblx0XHRncm91cC5hY3RpdmVFZGl0b3JQYW5lID0gdW5kZWZpbmVkO1xuXHRcdGdyb3VwLm9uRGlkQWN0aXZlRWRpdG9yQ2hhbmdlID0gRXZlbnQuTm9uZTtcblxuXHRcdGF3YWl0IHNlc3Npb25XaW5kb3dTZXJ2aWNlLnJldmVhbFNlc3Npb25XaW5kb3cocHJpbWFyeUlkKTtcblx0XHRhc3NlcnQuc3RyaWN0RXF1YWwoc2Vzc2lvbldpbmRvd1NlcnZpY2UuZ2V0Rm9jdXNlZExlYWZTZXNzaW9uS2V5KCksIHByaW1hcnlJZCk7XG5cdFx0YXNzZXJ0LnN0cmljdEVxdWFsKHJvc3RlclNlcnZpY2UuZ2V0QWN0aXZlU2Vzc2lvbklkKCksIHByaW1hcnlJZCk7XG5cdFx0Y29uc3QgcHJpbWFyeUxlYWYgPSBzZXNzaW9uV2luZG93U2VydmljZS5nZXRMZWFmU2xvdHMocHJpbWFyeUlkKSE7XG5cdFx0Y29uc3QgYWN0aXZlQmVmb3JlID0gZ2V0QWN0aXZlRWxlbWVudCgpO1xuXHRcdGFzc2VydC5vayhcblx0XHRcdHByaW1hcnlMZWFmLmNvbnRhaW5lciA9PT0gYWN0aXZlQmVmb3JlIHx8IHByaW1hcnlMZWFmLmNvbnRhaW5lci5jb250YWlucyhhY3RpdmVCZWZvcmUpLFxuXHRcdFx0J3ByaW1hcnkgbXVzdCBvd24gZm9jdXMgYmVmb3JlIHRoZSBzdGFsbGVkIHJldmVhbCcsXG5cdFx0KTtcblxuXHRcdGNvbnN0IHN3aXRjaGVkOiBzdHJpbmdbXSA9IFtdO1xuXHRcdGNvbnN0IG9yaWdpbmFsU3dpdGNoID0gcm9zdGVyU2VydmljZS5zd2l0Y2hTZXNzaW9uLmJpbmQocm9zdGVyU2VydmljZSk7XG5cdFx0cm9zdGVyU2VydmljZS5zd2l0Y2hTZXNzaW9uID0gKHNlc3Npb25JZDogc3RyaW5nKSA9PiB7XG5cdFx0XHRzd2l0Y2hlZC5wdXNoKHNlc3Npb25JZCk7XG5cdFx0XHRvcmlnaW5hbFN3aXRjaChzZXNzaW9uSWQpO1xuXHRcdH07XG5cblx0XHRsZXQgc2V0dGxlZCA9IGZhbHNlO1xuXHRcdGNvbnN0IHJldmVhbCA9IHNlc3Npb25XaW5kb3dTZXJ2aWNlLnJldmVhbFNlc3Npb25XaW5kb3coc2Vjb25kYXJ5SWQpLmZpbmFsbHkoKCkgPT4geyBzZXR0bGVkID0gdHJ1ZTsgfSk7XG5cdFx0YXdhaXQgdGltZW91dCgwKTtcblx0XHRhc3NlcnQuc3RyaWN0RXF1YWwoc2V0dGxlZCwgZmFsc2UsICdyZXZlYWwgbXVzdCBzdGlsbCBiZSB3YWl0aW5nIGZvciBhbiBlZGl0b3IgcGFuZScpO1xuXHRcdGFzc2VydC5zdHJpY3RFcXVhbChzZXNzaW9uV2luZG93U2VydmljZS5pc1Nlc3Npb25XaW5kb3dWaXNpYmxlKHNlY29uZGFyeUlkKSwgdHJ1ZSk7XG5cblx0XHRzZXNzaW9uV2luZG93U2VydmljZS5oaWRlU2Vzc2lvbldpbmRvdyhzZWNvbmRhcnlJZCk7XG5cdFx0YXNzZXJ0LnN0cmljdEVxdWFsKHNlc3Npb25XaW5kb3dTZXJ2aWNlLmlzU2Vzc2lvbldpbmRvd0hpZGRlbihzZWNvbmRhcnlJZCksIHRydWUpO1xuXHRcdGFzc2VydC5zdHJpY3RFcXVhbChzZXNzaW9uV2luZG93U2VydmljZS5nZXRGb2N1c2VkTGVhZlNlc3Npb25LZXkoKSwgcHJpbWFyeUlkKTtcblx0XHRhc3NlcnQuc3RyaWN0RXF1YWwocm9zdGVyU2VydmljZS5nZXRBY3RpdmVTZXNzaW9uSWQoKSwgcHJpbWFyeUlkKTtcblx0XHRjb25zdCBhY3RpdmVEdXJpbmcgPSBnZXRBY3RpdmVFbGVtZW50KCk7XG5cdFx0YXNzZXJ0Lm9rKFxuXHRcdFx0cHJpbWFyeUxlYWYuY29udGFpbmVyID09PSBhY3RpdmVEdXJpbmcgfHwgcHJpbWFyeUxlYWYuY29udGFpbmVyLmNvbnRhaW5zKGFjdGl2ZUR1cmluZyksXG5cdFx0XHQnZm9jdXMgbXVzdCBzdGF5IG9uIHRoZSBwcmltYXJ5IHdoaWxlIHRoZSBoaWRkZW4gbGVhZiBpcyBzdGlsbCB3YWl0aW5nJyxcblx0XHQpO1xuXG5cdFx0YXdhaXQgcmV2ZWFsO1xuXHRcdGFzc2VydC5zdHJpY3RFcXVhbChzZXR0bGVkLCB0cnVlKTtcblx0XHRhc3NlcnQuc3RyaWN0RXF1YWwoc2Vzc2lvbldpbmRvd1NlcnZpY2UuaXNTZXNzaW9uV2luZG93SGlkZGVuKHNlY29uZGFyeUlkKSwgdHJ1ZSk7XG5cdFx0YXNzZXJ0LnN0cmljdEVxdWFsKHNlc3Npb25XaW5kb3dTZXJ2aWNlLmdldEZvY3VzZWRMZWFmU2Vzc2lvbktleSgpLCBwcmltYXJ5SWQpO1xuXHRcdGFzc2VydC5zdHJpY3RFcXVhbChyb3N0ZXJTZXJ2aWNlLmdldEFjdGl2ZVNlc3Npb25JZCgpLCBwcmltYXJ5SWQpO1xuXHRcdGNvbnN0IGFjdGl2ZUFmdGVyID0gZ2V0QWN0aXZlRWxlbWVudCgpO1xuXHRcdGFzc2VydC5vayhcblx0XHRcdHByaW1hcnlMZWFmLmNvbnRhaW5lciA9PT0gYWN0aXZlQWZ0ZXIgfHwgcHJpbWFyeUxlYWYuY29udGFpbmVyLmNvbnRhaW5zKGFjdGl2ZUFmdGVyKSxcblx0XHRcdCdmb2N1cyBtdXN0IHN0YXkgb24gdGhlIHByaW1hcnkgYWZ0ZXIgdGhlIHBhbmUgd2FpdCBlbmRzJyxcblx0XHQpO1xuXHRcdGFzc2VydC5kZWVwU3RyaWN0RXF1YWwoc3dpdGNoZWQsIFtdKTtcblx0fSk7XG5cblx0dGVzdCgnMTAgU2VsZWN0Qm94IHBhdGggb24gcmVhbCBwYW5lIGNoYW5nZXMgdGhlIGxlYWYgKFBSRC0wMDIgIzEpJywgYXN5bmMgKCkgPT4ge1xuXHRcdGNvbnN0IGhhcm5lc3MgPSBhd2FpdCBjcmVhdGVSZXZlYWxIYXJuZXNzKCk7XG5cdFx0Y29uc3QgeyBwYXJ0cywgc2Vzc2lvbldpbmRvd1NlcnZpY2UsIHJvc3RlclNlcnZpY2UsIHByaW1hcnlJZCB9ID0gaGFybmVzcztcblx0XHRjb25zdCBiID0gcm9zdGVyU2VydmljZS5zZWVkU2Vzc2lvblF1aWV0bHkoKTtcblx0XHRjb25zdCBwYW5lID0gYXdhaXQgd2FpdEZvclNlc3Npb25QYW5lKGhhcm5lc3MsIHByaW1hcnlJZCk7XG5cdFx0YXNzZXJ0Lm9rKHBhbmUubGVhZlNlc3Npb25CYXJIb3N0KTtcblx0XHRhd2FpdCBwYW5lLmxlYWZTZXNzaW9uQmFySG9zdCEuc3dpdGNoTGVhZlNlc3Npb24oYik7XG5cdFx0YXdhaXQgd2FpdEZvclNlc3Npb25QYW5lKGhhcm5lc3MsIGIpO1xuXHRcdGFzc2VydC5zdHJpY3RFcXVhbChzZXNzaW9uV2luZG93U2VydmljZS5nZXRQcmltYXJ5U2Vzc2lvbktleSgpLCBiKTtcblx0XHRhc3NlcnQuc3RyaWN0RXF1YWwoc2Vzc2lvbldpbmRvd1NlcnZpY2UuZ2V0VmlzaWJsZVdpbmRvd0NvdW50KCksIDEpO1xuXHRcdGFzc2VydC5vayhwYXJ0Rm9yKHBhcnRzLCBiKS5hY3RpdmVHcm91cC5hY3RpdmVFZGl0b3IpO1xuXHR9KTtcblxuXHR0ZXN0KCcxMCB0d28gdmlzaWJsZSBsZWF2ZXM6IFNlbGVjdEJveCBvbiBvbmUgbGVhZiByZXBsYWNlcyB0aGF0IGxlYWYgd2l0aCBhIHRoaXJkIHNlc3Npb24nLCBhc3luYyAoKSA9PiB7XG5cdFx0Y29uc3QgaGFybmVzcyA9IGF3YWl0IGNyZWF0ZVJldmVhbEhhcm5lc3MoKTtcblx0XHRjb25zdCB7IHBhcnRzLCBzZXNzaW9uV2luZG93U2VydmljZSwgcm9zdGVyU2VydmljZSwgcHJpbWFyeUlkIH0gPSBoYXJuZXNzO1xuXHRcdGNvbnN0IGIgPSByb3N0ZXJTZXJ2aWNlLnNlZWRTZXNzaW9uUXVpZXRseSgpO1xuXHRcdGNvbnN0IGMgPSByb3N0ZXJTZXJ2aWNlLnNlZWRTZXNzaW9uUXVpZXRseSgpO1xuXHRcdGF3YWl0IHNlc3Npb25XaW5kb3dTZXJ2aWNlLm9wZW5TZXNzaW9uQmVzaWRlKGIpO1xuXHRcdGNvbnN0IHBhbmVCID0gYXdhaXQgd2FpdEZvclNlc3Npb25QYW5lKGhhcm5lc3MsIGIpO1xuXHRcdGFzc2VydC5vayhwYW5lQi5sZWFmU2Vzc2lvbkJhckhvc3QpO1xuXHRcdGF3YWl0IHBhbmVCLmxlYWZTZXNzaW9uQmFySG9zdCEuc3dpdGNoTGVhZlNlc3Npb24oYyk7XG5cdFx0YXdhaXQgd2FpdEZvclNlc3Npb25QYW5lKGhhcm5lc3MsIGMpO1xuXHRcdGNvbnN0IHZpc2libGUgPSB2aXNpYmxlTGVhZktleXMoc2Vzc2lvbldpbmRvd1NlcnZpY2UpO1xuXHRcdGFzc2VydC5zdHJpY3RFcXVhbCh2aXNpYmxlLmxlbmd0aCwgMik7XG5cdFx0YXNzZXJ0Lm9rKHZpc2libGUuaW5jbHVkZXMocHJpbWFyeUlkKSwgJ3RoZSBvdGhlciBsZWFmIG11c3Qgc3RheScpO1xuXHRcdGFzc2VydC5vayh2aXNpYmxlLmluY2x1ZGVzKGMpLCAndGhlIG9wZXJhdGVkIGxlYWYgbXVzdCBiZWNvbWUgdGhlIHRoaXJkIHNlc3Npb24nKTtcblx0XHRhc3NlcnQub2soIXZpc2libGUuaW5jbHVkZXMoYiksICd0aGUgb3BlcmF0ZWQgbGVhZiBtdXN0IG5vdCByZW1haW4nKTtcblx0XHRhc3NlcnQuc3RyaWN0RXF1YWwocGFydEZvcihwYXJ0cywgcHJpbWFyeUlkKS5zZXNzaW9uS2V5LCBwcmltYXJ5SWQpO1xuXHRcdGFzc2VydC5zdHJpY3RFcXVhbChwYXJ0Rm9yKHBhcnRzLCBjKS5zZXNzaW9uS2V5LCBjKTtcblx0XHRhc3NlcnQuc3RyaWN0RXF1YWwoc2Vzc2lvbldpbmRvd1NlcnZpY2UuaXNTZXNzaW9uV2luZG93SGlkZGVuKGIpLCB0cnVlKTtcblx0fSk7XG5cblx0dGVzdCgnZG9lcyBub3QgbGVhayB1bmhhbmRsZWQgcmVqZWN0aW9uIHdoZW4gc3dpdGNoVG9TZXNzaW9uIHN3aXRjaExlYWZTZXNzaW9uIHJlamVjdHMgYW5kIG9uVW5leHBlY3RlZEVycm9yIHdhcm4tdGhlbi1yZXRocm93cycsIGFzeW5jICgpID0+IHtcblx0XHRjb25zdCBoYXJuZXNzID0gYXdhaXQgY3JlYXRlUmV2ZWFsSGFybmVzcygpO1xuXHRcdGNvbnN0IHBhbmUgPSBhd2FpdCB3YWl0Rm9yU2Vzc2lvblBhbmUoaGFybmVzcywgaGFybmVzcy5wcmltYXJ5SWQpO1xuXHRcdGFzc2VydC5vayhwYW5lLmxlYWZTZXNzaW9uQmFySG9zdCk7XG5cdFx0Y29uc3QgcGFpbnRCb29tID0gbmV3IEVycm9yKCdzd2l0Y2ggYm9vbScpO1xuXHRcdHBhbmUubGVhZlNlc3Npb25CYXJIb3N0LnN3aXRjaExlYWZTZXNzaW9uID0gYXN5bmMgKCkgPT4ge1xuXHRcdFx0dGhyb3cgcGFpbnRCb29tO1xuXHRcdH07XG5cdFx0YXdhaXQgYXNzZXJ0V2FyblRoZW5SZXRocm93RG9lc05vdExlYWsocGFpbnRCb29tLCAoKSA9PiB7XG5cdFx0XHRwYW5lLmxlYWZTZXNzaW9uQmFySG9zdCEuc3dpdGNoVG9TZXNzaW9uKCdvdGhlci1zZXNzaW9uJyk7XG5cdFx0fSk7XG5cdH0pO1xuXG5cdHRlc3QoJ2RvZXMgbm90IGxlYWsgdW5oYW5kbGVkIHJlamVjdGlvbiB3aGVuIFNlbGVjdEJveCBoZWxwZXIgc3dpdGNoVG9TZXNzaW9uIHN3aXRjaExlYWZTZXNzaW9uIHJlamVjdHMgYW5kIG9uVW5leHBlY3RlZEVycm9yIHdhcm4tdGhlbi1yZXRocm93cycsIGFzeW5jICgpID0+IHtcblx0XHRjb25zdCBoYXJuZXNzID0gYXdhaXQgY3JlYXRlUmV2ZWFsSGFybmVzcygpO1xuXHRcdGNvbnN0IHBhbmUgPSBhd2FpdCB3YWl0Rm9yU2Vzc2lvblBhbmUoaGFybmVzcywgaGFybmVzcy5wcmltYXJ5SWQpO1xuXHRcdGFzc2VydC5vayhwYW5lLmxlYWZTZXNzaW9uQmFySG9zdCk7XG5cdFx0Y29uc3QgcGFpbnRCb29tID0gbmV3IEVycm9yKCdzd2l0Y2ggYm9vbScpO1xuXHRcdHBhbmUubGVhZlNlc3Npb25CYXJIb3N0LnN3aXRjaExlYWZTZXNzaW9uID0gYXN5bmMgKCkgPT4ge1xuXHRcdFx0dGhyb3cgcGFpbnRCb29tO1xuXHRcdH07XG5cdFx0YXdhaXQgYXNzZXJ0V2FyblRoZW5SZXRocm93RG9lc05vdExlYWsocGFpbnRCb29tLCAoKSA9PiB7XG5cdFx0XHRzd2l0Y2hUb1Nlc3Npb25IZWxwZXIocGFuZS5sZWFmU2Vzc2lvbkJhckhvc3QhLCAnb3RoZXItc2Vzc2lvbicpO1xuXHRcdH0pO1xuXHR9KTtcblxuXHR0ZXN0KCdTZWxlY3RCb3ggaGVscGVyIHN3aXRjaFRvU2Vzc2lvbiBmaXJlLWFuZC1mb3JnZXQgdm9pZHMgZG91YmxlLWNhdGNoIG9uVW5leHBlY3RlZEVycm9yJywgYXN5bmMgKCkgPT4ge1xuXHRcdGNvbnN0IHNvdXJjZSA9IGF3YWl0IF9fcmVhZEZpbGVJblRlc3RzKGAke3Byb2Nlc3MuY3dkKCl9L3NyYy92cy93b3JrYmVuY2gvY29udHJpYi9jb252ZXJzYXRpb24vYnJvd3Nlci9jb252ZXJzYXRpb25MZW5zU2Vzc2lvbkJhci50c2ApO1xuXHRcdGNvbnN0IGRvdWJsZUNhdGNoID0gJy5jYXRjaChvblVuZXhwZWN0ZWRFcnJvcikuY2F0Y2gob25VbmV4cGVjdGVkRXJyb3IpJztcblx0XHRhc3NlcnQub2soc291cmNlLmluY2x1ZGVzKGB2b2lkIGhvc3Quc3dpdGNoTGVhZlNlc3Npb24oc2Vzc2lvbklkKSR7ZG91YmxlQ2F0Y2h9YCkpO1xuXHRcdGFzc2VydC5vayghc291cmNlLmluY2x1ZGVzKCd2b2lkIGhvc3Quc3dpdGNoTGVhZlNlc3Npb24oc2Vzc2lvbklkKTsnKSk7XG5cdH0pO1xuXG5cdHRlc3QoJzEwIE5ldyBTZXNzaW9uIGluIHN0dWIgcGF0aCBiZWNvbWVzIHRoZSBvbmx5IHZpc2libGUgbGVhZicsIGFzeW5jICgpID0+IHtcblx0XHRjb25zdCBoYXJuZXNzID0gYXdhaXQgY3JlYXRlUmV2ZWFsSGFybmVzcygpO1xuXHRcdGNvbnN0IHsgc2Vzc2lvbldpbmRvd1NlcnZpY2UsIHJvc3RlclNlcnZpY2UsIHByaW1hcnlJZCB9ID0gaGFybmVzcztcblx0XHRjb25zdCBwYW5lID0gYXdhaXQgd2FpdEZvclNlc3Npb25QYW5lKGhhcm5lc3MsIHByaW1hcnlJZCk7XG5cdFx0YXNzZXJ0Lm9rKHBhbmUubGVhZlNlc3Npb25CYXJIb3N0KTtcblx0XHRwYW5lLmxlYWZTZXNzaW9uQmFySG9zdCEuY3JlYXRlTmV3U2Vzc2lvbigpO1xuXHRcdGNvbnN0IGRlYWRsaW5lID0gRGF0ZS5ub3coKSArIDMwMDA7XG5cdFx0bGV0IG5ld0lkID0gcm9zdGVyU2VydmljZS5nZXRBY3RpdmVTZXNzaW9uSWQoKTtcblx0XHR3aGlsZSAobmV3SWQgPT09IHByaW1hcnlJZCAmJiBEYXRlLm5vdygpIDwgZGVhZGxpbmUpIHtcblx0XHRcdGF3YWl0IHRpbWVvdXQoMjApO1xuXHRcdFx0bmV3SWQgPSByb3N0ZXJTZXJ2aWNlLmdldEFjdGl2ZVNlc3Npb25JZCgpO1xuXHRcdH1cblx0XHRhc3NlcnQubm90U3RyaWN0RXF1YWwobmV3SWQsIHByaW1hcnlJZCk7XG5cdFx0YXdhaXQgd2FpdEZvclNlc3Npb25QYW5lKGhhcm5lc3MsIG5ld0lkKTtcblx0XHRhc3NlcnQuc3RyaWN0RXF1YWwoc2Vzc2lvbldpbmRvd1NlcnZpY2UuZ2V0VmlzaWJsZVdpbmRvd0NvdW50KCksIDEpO1xuXHRcdGFzc2VydC5zdHJpY3RFcXVhbChzZXNzaW9uV2luZG93U2VydmljZS5nZXRQcmltYXJ5U2Vzc2lvbktleSgpLCBuZXdJZCk7XG5cdFx0YXNzZXJ0LnN0cmljdEVxdWFsKGhpZGVCdXR0b24oc2Vzc2lvbldpbmRvd1NlcnZpY2UsIG5ld0lkKT8uaGlkZGVuLCB0cnVlKTtcblx0XHRhc3NlcnQuc3RyaWN0RXF1YWwoc2Vzc2lvbldpbmRvd1NlcnZpY2UuaXNTZXNzaW9uV2luZG93SGlkZGVuKHByaW1hcnlJZCksIHRydWUpO1xuXHR9KTtcblxuXHR0ZXN0KCcxMyBlYWNoIHZpc2libGUgbGVhZiBoYXMgZXhhY3RseSBvbmUgU2Vzc2lvbkJhciBhbmQgd2luZG93LW5hdjsgUGFydCBzbG90IGhhcyBub25lJywgYXN5bmMgKCkgPT4ge1xuXHRcdGNvbnN0IGhhcm5lc3MgPSBhd2FpdCBjcmVhdGVSZXZlYWxIYXJuZXNzKCk7XG5cdFx0Y29uc3QgeyBzZXNzaW9uV2luZG93U2VydmljZSwgcm9zdGVyU2VydmljZSwgY29udmVyc2F0aW9uUGFydCwgcHJpbWFyeUlkIH0gPSBoYXJuZXNzO1xuXHRcdGNvbnN0IGIgPSByb3N0ZXJTZXJ2aWNlLnNlZWRTZXNzaW9uUXVpZXRseSgpO1xuXHRcdGNvbnN0IGMgPSByb3N0ZXJTZXJ2aWNlLnNlZWRTZXNzaW9uUXVpZXRseSgpO1xuXG5cdFx0YXdhaXQgc2Vzc2lvbldpbmRvd1NlcnZpY2UucmV2ZWFsU2Vzc2lvbldpbmRvdyhiKTtcblx0XHRhd2FpdCB3YWl0Rm9yU2Vzc2lvblBhbmUoaGFybmVzcywgYik7XG5cdFx0YXdhaXQgc2Vzc2lvbldpbmRvd1NlcnZpY2UucmV2ZWFsU2Vzc2lvbldpbmRvdyhjKTtcblx0XHRhd2FpdCB3YWl0Rm9yU2Vzc2lvblBhbmUoaGFybmVzcywgYyk7XG5cdFx0YXdhaXQgc2Vzc2lvbldpbmRvd1NlcnZpY2UucmV2ZWFsU2Vzc2lvbldpbmRvdyhwcmltYXJ5SWQpO1xuXHRcdGF3YWl0IHdhaXRGb3JTZXNzaW9uUGFuZShoYXJuZXNzLCBwcmltYXJ5SWQpO1xuXHRcdGxldCBjaHJvbWUgPSBjb3VudExlYWZDaHJvbWUoc2Vzc2lvbldpbmRvd1NlcnZpY2UsIGNvbnZlcnNhdGlvblBhcnQpO1xuXHRcdGFzc2VydC5zdHJpY3RFcXVhbChzZXNzaW9uV2luZG93U2VydmljZS5nZXRWaXNpYmxlV2luZG93Q291bnQoKSwgMSk7XG5cdFx0YXNzZXJ0LnN0cmljdEVxdWFsKGNocm9tZS5iYXJzLCAxKTtcblx0XHRhc3NlcnQuc3RyaWN0RXF1YWwoY2hyb21lLm5hdnMsIDEpO1xuXHRcdGFzc2VydC5zdHJpY3RFcXVhbChjaHJvbWUucGFydFNsb3RCYXJzLCAwKTtcblxuXHRcdGF3YWl0IHNlc3Npb25XaW5kb3dTZXJ2aWNlLm9wZW5TZXNzaW9uQmVzaWRlKGIpO1xuXHRcdGF3YWl0IHdhaXRGb3JTZXNzaW9uUGFuZShoYXJuZXNzLCBiKTtcblx0XHRjaHJvbWUgPSBjb3VudExlYWZDaHJvbWUoc2Vzc2lvbldpbmRvd1NlcnZpY2UsIGNvbnZlcnNhdGlvblBhcnQpO1xuXHRcdGFzc2VydC5zdHJpY3RFcXVhbChzZXNzaW9uV2luZG93U2VydmljZS5nZXRWaXNpYmxlV2luZG93Q291bnQoKSwgMik7XG5cdFx0YXNzZXJ0LnN0cmljdEVxdWFsKGNocm9tZS5iYXJzLCAyKTtcblx0XHRhc3NlcnQuc3RyaWN0RXF1YWwoY2hyb21lLm5hdnMsIDIpO1xuXHRcdGFzc2VydC5zdHJpY3RFcXVhbChjaHJvbWUucGFydFNsb3RCYXJzLCAwKTtcblx0fSk7XG5cblx0dGVzdCgnMTNiIGxlYWYgU2Vzc2lvbkJhciBhbmQgY29udGFpbmVyIHJlY2VpdmUgaXMtbmFycm93IHdoZW4gcGFuZSB3aWR0aCBpcyB1bmRlciA0NTBweCcsIGFzeW5jICgpID0+IHtcblx0XHRjb25zdCBoYXJuZXNzID0gYXdhaXQgY3JlYXRlUmV2ZWFsSGFybmVzcygpO1xuXHRcdGNvbnN0IHsgc2Vzc2lvbldpbmRvd1NlcnZpY2UsIHByaW1hcnlJZCB9ID0gaGFybmVzcztcblx0XHRjb25zdCBwYW5lID0gYXdhaXQgd2FpdEZvclNlc3Npb25QYW5lKGhhcm5lc3MsIHByaW1hcnlJZCk7XG5cdFx0Y29uc3QgbGVhZiA9IHNlc3Npb25XaW5kb3dTZXJ2aWNlLmdldExlYWZTbG90cyhwcmltYXJ5SWQpITtcblxuXHRcdHBhbmUubGF5b3V0KG5ldyBEaW1lbnNpb24oNTAwLCA2MDApKTtcblx0XHRhc3NlcnQub2sobGVhZi5zZXNzaW9uQmFyLmNsYXNzTGlzdC5jb250YWlucygnaXMtbWVkaXVtJykpO1xuXHRcdGFzc2VydC5vayghbGVhZi5zZXNzaW9uQmFyLmNsYXNzTGlzdC5jb250YWlucygnaXMtbmFycm93JykpO1xuXG5cdFx0cGFuZS5sYXlvdXQobmV3IERpbWVuc2lvbig0MDAsIDYwMCkpO1xuXHRcdGFzc2VydC5vayhsZWFmLnNlc3Npb25CYXIuY2xhc3NMaXN0LmNvbnRhaW5zKCdpcy1uYXJyb3cnKSk7XG5cdFx0YXNzZXJ0Lm9rKGxlYWYuY29udGFpbmVyLmNsYXNzTGlzdC5jb250YWlucygnaXMtbmFycm93JykpO1xuXHRcdGFzc2VydC5vayghbGVhZi5zZXNzaW9uQmFyLmNsYXNzTGlzdC5jb250YWlucygnaXMtY29tcGFjdCcpKTtcblxuXHRcdHBhbmUubGF5b3V0KG5ldyBEaW1lbnNpb24oMjUwLCA2MDApKTtcblx0XHRhc3NlcnQub2sobGVhZi5zZXNzaW9uQmFyLmNsYXNzTGlzdC5jb250YWlucygnaXMtbmFycm93JykpO1xuXHRcdGFzc2VydC5vayhsZWFmLnNlc3Npb25CYXIuY2xhc3NMaXN0LmNvbnRhaW5zKCdpcy1jb21wYWN0JykpO1xuXG5cdFx0cGFuZS5sYXlvdXQobmV3IERpbWVuc2lvbig5NTAsIDYwMCkpO1xuXHRcdGFzc2VydC5vayghbGVhZi5zZXNzaW9uQmFyLmNsYXNzTGlzdC5jb250YWlucygnaXMtbmFycm93JykpO1xuXHRcdGFzc2VydC5vayghbGVhZi5jb250YWluZXIuY2xhc3NMaXN0LmNvbnRhaW5zKCdpcy1uYXJyb3cnKSk7XG5cdFx0YXNzZXJ0Lm9rKCFsZWFmLnNlc3Npb25CYXIuY2xhc3NMaXN0LmNvbnRhaW5zKCdpcy1jb21wYWN0JykpO1xuXHR9KTtcblxuXHR0ZXN0KCcxNCByZXZlYWwgbW91bnRzIG92ZXJsYXkgc28gb3BlblN1YkFnZW50IGRvZXMgbm90IHRocm93JywgYXN5bmMgKCkgPT4ge1xuXHRcdGNvbnN0IGhhcm5lc3MgPSBhd2FpdCBjcmVhdGVSZXZlYWxIYXJuZXNzKCk7XG5cdFx0Y29uc3QgeyBzZXNzaW9uV2luZG93U2VydmljZSwgc2Vzc2lvbkNoYXRTZXJ2aWNlLCByb3N0ZXJTZXJ2aWNlIH0gPSBoYXJuZXNzO1xuXHRcdGNvbnN0IGIgPSByb3N0ZXJTZXJ2aWNlLnNlZWRTZXNzaW9uUXVpZXRseSgpO1xuXHRcdGF3YWl0IHNlc3Npb25XaW5kb3dTZXJ2aWNlLnJldmVhbFNlc3Npb25XaW5kb3coYik7XG5cdFx0YXdhaXQgd2FpdEZvclNlc3Npb25QYW5lKGhhcm5lc3MsIGIpO1xuXHRcdGF3YWl0IHNlc3Npb25DaGF0U2VydmljZS5vcGVuU3ViQWdlbnQoYiwgJ3Rvb2wtZnJvbS1yZXZlYWwnLCAnUmV2ZWFsIHRvb2wnKTtcblx0XHRhc3NlcnQuc3RyaWN0RXF1YWwoc2Vzc2lvbkNoYXRTZXJ2aWNlLmlzU3ViQWdlbnREaWFsb2dPcGVuKGIpLCB0cnVlKTtcblx0fSk7XG5cblx0dGVzdCgnMTUgbGF0ZXN0LXdpbnMgcmV2ZWFsIGVuZHMgb24gQjsgYmluZC1mYWlsZWQgc2VudGluZWwgZG9lcyBub3QgY3JlYXRlIGEgbGVhZicsIGFzeW5jICgpID0+IHtcblx0XHRjb25zdCB7IHNlc3Npb25XaW5kb3dTZXJ2aWNlLCByb3N0ZXJTZXJ2aWNlLCBwcmltYXJ5SWQgfSA9IGF3YWl0IGNyZWF0ZVJldmVhbEhhcm5lc3MoKTtcblx0XHRjb25zdCBhID0gcm9zdGVyU2VydmljZS5zZWVkU2Vzc2lvblF1aWV0bHkoKTtcblx0XHRjb25zdCBiID0gcm9zdGVyU2VydmljZS5zZWVkU2Vzc2lvblF1aWV0bHkoKTtcblx0XHRjb25zdCBmaXJzdCA9IHNlc3Npb25XaW5kb3dTZXJ2aWNlLnJldmVhbFNlc3Npb25XaW5kb3coYSk7XG5cdFx0Y29uc3Qgc2Vjb25kID0gc2Vzc2lvbldpbmRvd1NlcnZpY2UucmV2ZWFsU2Vzc2lvbldpbmRvdyhiKTtcblx0XHRhd2FpdCBQcm9taXNlLmFsbChbZmlyc3QsIHNlY29uZF0pO1xuXHRcdGFzc2VydC5kZWVwU3RyaWN0RXF1YWwodmlzaWJsZUxlYWZLZXlzKHNlc3Npb25XaW5kb3dTZXJ2aWNlKSwgW2JdKTtcblx0XHRhc3NlcnQuc3RyaWN0RXF1YWwoc2Vzc2lvbldpbmRvd1NlcnZpY2UuZ2V0UHJpbWFyeVNlc3Npb25LZXkoKSwgYik7XG5cblx0XHRjb25zdCBrZXlzQmVmb3JlID0gWy4uLnNlc3Npb25XaW5kb3dTZXJ2aWNlLmdldEFsbExlYWZTZXNzaW9uS2V5cygpXTtcblx0XHRyb3N0ZXJTZXJ2aWNlLmZpcmVBY3RpdmVTZXNzaW9uKEVOR0lORV9CSU5EX0ZBSUxFRF9TRVNTSU9OX0lEKTtcblx0XHRhd2FpdCB0aW1lb3V0KDIwKTtcblx0XHRhc3NlcnQuZGVlcFN0cmljdEVxdWFsKFsuLi5zZXNzaW9uV2luZG93U2VydmljZS5nZXRBbGxMZWFmU2Vzc2lvbktleXMoKV0sIGtleXNCZWZvcmUpO1xuXHRcdGFzc2VydC5zdHJpY3RFcXVhbChzZXNzaW9uV2luZG93U2VydmljZS5nZXRMZWFmU2xvdHMoRU5HSU5FX0JJTkRfRkFJTEVEX1NFU1NJT05fSUQpLCB1bmRlZmluZWQpO1xuXHRcdGFzc2VydC5vayhzZXNzaW9uV2luZG93U2VydmljZS5nZXRMZWFmU2xvdHMocHJpbWFyeUlkKSB8fCBzZXNzaW9uV2luZG93U2VydmljZS5nZXRMZWFmU2xvdHMoYikpO1xuXHR9KTtcblxuXHR0ZXN0KCdvbkRpZERlbGV0ZVNlc3Npb24gZGlzcG9zZXMgdmlzaWJsZSBsZWFmIHdoZW4gYmluZC1mYWlsZWQgc2tpcHMgcmV2ZWFsJywgYXN5bmMgKCkgPT4ge1xuXHRcdGNvbnN0IGhhcm5lc3MgPSBjcmVhdGVMaWdodHdlaWdodFdpbmRvd0hhcm5lc3MoKTtcblx0XHRhd2FpdCB0aW1lb3V0KDApO1xuXHRcdGNvbnN0IHNlc3Npb25JZCA9IGhhcm5lc3Mucm9zdGVyU2VydmljZS5nZXRBY3RpdmVTZXNzaW9uSWQoKTtcblx0XHRhd2FpdCBoYXJuZXNzLnNlc3Npb25XaW5kb3dTZXJ2aWNlLmVuc3VyZVByaW1hcnlXaW5kb3coc2Vzc2lvbklkKTtcblx0XHRhc3NlcnQuZGVlcFN0cmljdEVxdWFsKHZpc2libGVMZWFmS2V5cyhoYXJuZXNzLnNlc3Npb25XaW5kb3dTZXJ2aWNlKSwgW3Nlc3Npb25JZF0pO1xuXHRcdGFzc2VydC5vayhoYXJuZXNzLmNvbnZlcnNhdGlvblBhcnRzLnNvbWUocGFydCA9PiBwYXJ0LnNlc3Npb25LZXkgPT09IHNlc3Npb25JZCkpO1xuXG5cdFx0aGFybmVzcy5yb3N0ZXJTZXJ2aWNlLmZpcmVBY3RpdmVTZXNzaW9uKEVOR0lORV9CSU5EX0ZBSUxFRF9TRVNTSU9OX0lEKTtcblx0XHRoYXJuZXNzLnJvc3RlclNlcnZpY2UuZmlyZURlbGV0ZWRTZXNzaW9uKHNlc3Npb25JZCk7XG5cblx0XHRhc3NlcnQuZGVlcFN0cmljdEVxdWFsKHZpc2libGVMZWFmS2V5cyhoYXJuZXNzLnNlc3Npb25XaW5kb3dTZXJ2aWNlKSwgW10pO1xuXHRcdGFzc2VydC5zdHJpY3RFcXVhbChoYXJuZXNzLnNlc3Npb25XaW5kb3dTZXJ2aWNlLmdldFByaW1hcnlTZXNzaW9uS2V5KCksIHVuZGVmaW5lZCk7XG5cdFx0YXNzZXJ0Lm9rKCFoYXJuZXNzLnNlc3Npb25XaW5kb3dTZXJ2aWNlLmdldEFsbExlYWZTZXNzaW9uS2V5cygpLmluY2x1ZGVzKHNlc3Npb25JZCkpO1xuXHRcdGFzc2VydC5vayghaGFybmVzcy5jb252ZXJzYXRpb25QYXJ0cy5zb21lKHBhcnQgPT4gcGFydC5zZXNzaW9uS2V5ID09PSBzZXNzaW9uSWQpKTtcblx0fSk7XG5cblx0dGVzdCgnb25EaWREZWxldGVTZXNzaW9uIGRpc3Bvc2VzIGEgaGlkZGVuIGxlYWYgYW5kIGl0cyBlZGl0b3IgcGFydCcsIGFzeW5jICgpID0+IHtcblx0XHRjb25zdCBoYXJuZXNzID0gYXdhaXQgY3JlYXRlUmV2ZWFsSGFybmVzcygpO1xuXHRcdGNvbnN0IHsgcGFydHMsIHNlc3Npb25XaW5kb3dTZXJ2aWNlLCByb3N0ZXJTZXJ2aWNlLCBwcmltYXJ5SWQgfSA9IGhhcm5lc3M7XG5cdFx0Y29uc3Qgc2Vjb25kYXJ5SWQgPSByb3N0ZXJTZXJ2aWNlLnNlZWRTZXNzaW9uUXVpZXRseSgpO1xuXHRcdGF3YWl0IHNlc3Npb25XaW5kb3dTZXJ2aWNlLm9wZW5TZXNzaW9uQmVzaWRlKHNlY29uZGFyeUlkKTtcblx0XHRhd2FpdCB3YWl0Rm9yU2Vzc2lvblBhbmUoaGFybmVzcywgc2Vjb25kYXJ5SWQpO1xuXG5cdFx0YXNzZXJ0LnN0cmljdEVxdWFsKHNlc3Npb25XaW5kb3dTZXJ2aWNlLmlzU2Vzc2lvbldpbmRvd0hpZGRlbihwcmltYXJ5SWQpLCB0cnVlKTtcblx0XHRhc3NlcnQub2soc2Vzc2lvbldpbmRvd1NlcnZpY2UuZ2V0TGVhZlNsb3RzKHByaW1hcnlJZCkpO1xuXHRcdGFzc2VydC5vayhwYXJ0cy5jb252ZXJzYXRpb25QYXJ0cy5zb21lKHBhcnQgPT4gcGFydC5zZXNzaW9uS2V5ID09PSBwcmltYXJ5SWQpKTtcblxuXHRcdHJvc3RlclNlcnZpY2UuZmlyZURlbGV0ZWRTZXNzaW9uKHByaW1hcnlJZCk7XG5cblx0XHRhc3NlcnQuc3RyaWN0RXF1YWwoc2Vzc2lvbldpbmRvd1NlcnZpY2UuZ2V0TGVhZlNsb3RzKHByaW1hcnlJZCksIHVuZGVmaW5lZCk7XG5cdFx0YXNzZXJ0Lm9rKCFwYXJ0cy5jb252ZXJzYXRpb25QYXJ0cy5zb21lKHBhcnQgPT4gcGFydC5zZXNzaW9uS2V5ID09PSBwcmltYXJ5SWQpKTtcblx0XHRhc3NlcnQuZGVlcFN0cmljdEVxdWFsKHZpc2libGVMZWFmS2V5cyhzZXNzaW9uV2luZG93U2VydmljZSksIFtzZWNvbmRhcnlJZF0pO1xuXHR9KTtcblxuXHR0ZXN0KCcxNSBzdHViLXNlZWQgdW50aXRsZWQgb25EaWRDaGFuZ2VBY3RpdmVTZXNzaW9uIHN0aWxsIHJldmVhbHMnLCBhc3luYyAoKSA9PiB7XG5cdFx0Y29uc3QgaGFybmVzcyA9IGF3YWl0IGNyZWF0ZVJldmVhbEhhcm5lc3MoKTtcblx0XHRjb25zdCB7IHNlc3Npb25XaW5kb3dTZXJ2aWNlLCByb3N0ZXJTZXJ2aWNlIH0gPSBoYXJuZXNzO1xuXHRcdGFzc2VydC5vayhpc0VuZ2luZVJvc3RlclBsYWNlaG9sZGVyU2Vzc2lvbklkKCd1bnRpdGxlZCcpKTtcblx0XHRhc3NlcnQub2socm9zdGVyU2VydmljZS5nZXRTZXNzaW9ucygpLnNvbWUoc2Vzc2lvbiA9PiBzZXNzaW9uLmlkID09PSAndW50aXRsZWQnKSk7XG5cdFx0Y29uc3QgYiA9IHJvc3RlclNlcnZpY2Uuc2VlZFNlc3Npb25RdWlldGx5KCk7XG5cdFx0YXdhaXQgc2Vzc2lvbldpbmRvd1NlcnZpY2UucmV2ZWFsU2Vzc2lvbldpbmRvdyhiKTtcblx0XHRhd2FpdCB3YWl0Rm9yU2Vzc2lvblBhbmUoaGFybmVzcywgYik7XG5cdFx0YXNzZXJ0LnN0cmljdEVxdWFsKHNlc3Npb25XaW5kb3dTZXJ2aWNlLmlzU2Vzc2lvbldpbmRvd0hpZGRlbigndW50aXRsZWQnKSwgdHJ1ZSk7XG5cblx0XHRyb3N0ZXJTZXJ2aWNlLmZpcmVBY3RpdmVTZXNzaW9uKCd1bnRpdGxlZCcpO1xuXHRcdGF3YWl0IHdhaXRGb3JTZXNzaW9uUGFuZShoYXJuZXNzLCAndW50aXRsZWQnKTtcblx0XHRhc3NlcnQuc3RyaWN0RXF1YWwoc2Vzc2lvbldpbmRvd1NlcnZpY2UuaXNTZXNzaW9uV2luZG93VmlzaWJsZSgndW50aXRsZWQnKSwgdHJ1ZSk7XG5cdFx0YXNzZXJ0LmRlZXBTdHJpY3RFcXVhbCh2aXNpYmxlTGVhZktleXMoc2Vzc2lvbldpbmRvd1NlcnZpY2UpLCBbJ3VudGl0bGVkJ10pO1xuXHRcdGFzc2VydC5zdHJpY3RFcXVhbChzZXNzaW9uV2luZG93U2VydmljZS5nZXRQcmltYXJ5U2Vzc2lvbktleSgpLCAndW50aXRsZWQnKTtcblx0fSk7XG5cblx0dGVzdCgnMTUgcmV2ZWFsIGNyZWF0ZSBmYWlsdXJlIHJvbGxzIGJhY2sgcGFydCArIGxlYWYgYW5kIHJlYnVpbGRzIHRoZSBzYW1lIGtleScsIGFzeW5jICgpID0+IHtcblx0XHRjb25zdCByb3N0ZXJTZXJ2aWNlID0gc3RvcmUuYWRkKG5ldyBRdWlldFJvc3RlclNlcnZpY2UoKSk7XG5cdFx0Y29uc3QgZ3JpZEhvc3QgPSBkb2N1bWVudC5jcmVhdGVFbGVtZW50KCdkaXYnKTtcblx0XHRkb2N1bWVudC5ib2R5LmFwcGVuZENoaWxkKGdyaWRIb3N0KTtcblx0XHRzdG9yZS5hZGQoeyBkaXNwb3NlOiAoKSA9PiBncmlkSG9zdC5yZW1vdmUoKSB9KTtcblxuXHRcdGNvbnN0IGNvbnZlcnNhdGlvblBhcnRzOiBJQ29udmVyc2F0aW9uRWRpdG9yUGFydFtdID0gW107XG5cdFx0bGV0IHRocm93T25DcmVhdGUgPSBmYWxzZTtcblx0XHRjb25zdCBlZGl0b3JHcm91cHNTZXJ2aWNlID0ge1xuXHRcdFx0Y3JlYXRlQ29udmVyc2F0aW9uRWRpdG9yUGFydDogKF9wYXJlbnQ6IHVua25vd24sIHNlc3Npb25LZXk6IHN0cmluZykgPT4ge1xuXHRcdFx0XHRpZiAodGhyb3dPbkNyZWF0ZSkge1xuXHRcdFx0XHRcdHRocm93IG5ldyBFcnJvcigncmV2ZWFsIGJvb20nKTtcblx0XHRcdFx0fVxuXHRcdFx0XHRjb25zdCBwYXJ0ID0geyBzZXNzaW9uS2V5LCB3aGVuUmVhZHk6IFByb21pc2UucmVzb2x2ZSgpLCBhY3RpdmVHcm91cDogeyBmb2N1czogKCkgPT4geyB9LCBhY3RpdmVFZGl0b3JQYW5lOiB7IGdldElkOiAoKSA9PiBDb252ZXJzYXRpb25FZGl0b3JQYW5lSWQgfSB9IH0gYXMgdW5rbm93biBhcyBJQ29udmVyc2F0aW9uRWRpdG9yUGFydDtcblx0XHRcdFx0Y29udmVyc2F0aW9uUGFydHMucHVzaChwYXJ0KTtcblx0XHRcdFx0cmV0dXJuIHBhcnQ7XG5cdFx0XHR9LFxuXHRcdFx0ZGlzcG9zZUNvbnZlcnNhdGlvbkVkaXRvclBhcnQ6IChzZXNzaW9uS2V5OiBzdHJpbmcpID0+IHtcblx0XHRcdFx0Y29uc3QgaW5kZXggPSBjb252ZXJzYXRpb25QYXJ0cy5maW5kSW5kZXgocGFydCA9PiBwYXJ0LnNlc3Npb25LZXkgPT09IHNlc3Npb25LZXkpO1xuXHRcdFx0XHRpZiAoaW5kZXggPj0gMCkge1xuXHRcdFx0XHRcdGNvbnZlcnNhdGlvblBhcnRzLnNwbGljZShpbmRleCwgMSk7XG5cdFx0XHRcdH1cblx0XHRcdH0sXG5cdFx0XHRzZXRGb2N1c2VkQ29udmVyc2F0aW9uTGVhZjogKCkgPT4geyB9LFxuXHRcdFx0Z2V0Rm9jdXNlZENvbnZlcnNhdGlvbkxlYWY6ICgpID0+IHVuZGVmaW5lZCxcblx0XHRcdGdldCBjb252ZXJzYXRpb25QYXJ0cygpIHtcblx0XHRcdFx0cmV0dXJuIGNvbnZlcnNhdGlvblBhcnRzO1xuXHRcdFx0fSxcblx0XHR9IGFzIHVua25vd24gYXMgSUVkaXRvckdyb3Vwc1NlcnZpY2U7XG5cblx0XHRjb25zdCBlcnJvcnM6IHN0cmluZ1tdID0gW107XG5cdFx0Y29uc3Qgc2Vzc2lvbldpbmRvd1NlcnZpY2UgPSBzdG9yZS5hZGQobmV3IENvbnZlcnNhdGlvblNlc3Npb25XaW5kb3dTZXJ2aWNlKFxuXHRcdFx0e1xuXHRcdFx0XHRvbkRpZENyZWF0ZVNsb3RzOiBFdmVudC5Ob25lLFxuXHRcdFx0XHRvbkRpZEZvY3VzOiBFdmVudC5Ob25lLFxuXHRcdFx0XHRnZXRTbG90czogKCkgPT4gKHsgc2Vzc2lvbkJhcjogZG9jdW1lbnQuY3JlYXRlRWxlbWVudCgnZGl2JyksIHNlc3Npb25XaW5kb3dHcmlkOiBncmlkSG9zdCwgZWRpdG9yUGFydEhvc3Q6IHVuZGVmaW5lZCB9KSxcblx0XHRcdFx0c2V0Rm9jdXNlZExlYWZDb250YWluZXI6ICgpID0+IHsgfSxcblx0XHRcdFx0Zm9jdXM6ICgpID0+IHsgfSxcblx0XHRcdH0gYXMgdW5rbm93biBhcyBJQ29udmVyc2F0aW9uUGFydFNlcnZpY2UsXG5cdFx0XHRlZGl0b3JHcm91cHNTZXJ2aWNlLFxuXHRcdFx0cm9zdGVyU2VydmljZSxcblx0XHRcdG5ldyBOdWxsTG9nU2VydmljZSgpLFxuXHRcdFx0e1xuXHRcdFx0XHRlcnJvcjogKG1lc3NhZ2U6IHN0cmluZyB8IEVycm9yKSA9PiB7XG5cdFx0XHRcdFx0ZXJyb3JzLnB1c2godHlwZW9mIG1lc3NhZ2UgPT09ICdzdHJpbmcnID8gbWVzc2FnZSA6IGdldEVycm9yTWVzc2FnZShtZXNzYWdlKSk7XG5cdFx0XHRcdH0sXG5cdFx0XHR9IGFzIElOb3RpZmljYXRpb25TZXJ2aWNlLFxuXHRcdCkpO1xuXG5cdFx0YXdhaXQgdGltZW91dCgwKTtcblx0XHRjb25zdCBwcmltYXJ5SWQgPSByb3N0ZXJTZXJ2aWNlLmdldEFjdGl2ZVNlc3Npb25JZCgpO1xuXHRcdGF3YWl0IHNlc3Npb25XaW5kb3dTZXJ2aWNlLmVuc3VyZVByaW1hcnlXaW5kb3cocHJpbWFyeUlkKTtcblx0XHRjb25zdCB0YXJnZXQgPSByb3N0ZXJTZXJ2aWNlLnNlZWRTZXNzaW9uUXVpZXRseSgpO1xuXHRcdHRocm93T25DcmVhdGUgPSB0cnVlO1xuXHRcdGF3YWl0IHNlc3Npb25XaW5kb3dTZXJ2aWNlLnJldmVhbFNlc3Npb25XaW5kb3codGFyZ2V0KTtcblxuXHRcdGFzc2VydC5vayhlcnJvcnMuc29tZShlcnJvciA9PiBlcnJvci5pbmNsdWRlcygncmV2ZWFsIGJvb20nKSkpO1xuXHRcdGFzc2VydC5zdHJpY3RFcXVhbChzZXNzaW9uV2luZG93U2VydmljZS5nZXRQcmltYXJ5U2Vzc2lvbktleSgpLCBwcmltYXJ5SWQpO1xuXHRcdGFzc2VydC5zdHJpY3RFcXVhbChzZXNzaW9uV2luZG93U2VydmljZS5nZXRMZWFmU2xvdHModGFyZ2V0KSwgdW5kZWZpbmVkKTtcblx0XHRhc3NlcnQub2soIXNlc3Npb25XaW5kb3dTZXJ2aWNlLmdldEFsbExlYWZTZXNzaW9uS2V5cygpLmluY2x1ZGVzKHRhcmdldCkpO1xuXHRcdGFzc2VydC5vayghY29udmVyc2F0aW9uUGFydHMuc29tZShwYXJ0ID0+IHBhcnQuc2Vzc2lvbktleSA9PT0gdGFyZ2V0KSk7XG5cblx0XHR0aHJvd09uQ3JlYXRlID0gZmFsc2U7XG5cdFx0YXdhaXQgc2Vzc2lvbldpbmRvd1NlcnZpY2UucmV2ZWFsU2Vzc2lvbldpbmRvdyh0YXJnZXQpO1xuXHRcdGFzc2VydC5vayhzZXNzaW9uV2luZG93U2VydmljZS5nZXRMZWFmU2xvdHModGFyZ2V0KSk7XG5cdFx0YXNzZXJ0Lm9rKGNvbnZlcnNhdGlvblBhcnRzLnNvbWUocGFydCA9PiBwYXJ0LnNlc3Npb25LZXkgPT09IHRhcmdldCkpO1xuXHRcdGFzc2VydC5vayhzZXNzaW9uV2luZG93U2VydmljZS5nZXRMZWFmU2xvdHModGFyZ2V0KT8uY29udGFpbmVyLmlzQ29ubmVjdGVkKTtcblx0fSk7XG5cblx0YXN5bmMgZnVuY3Rpb24gb3BlblR3b0xpZ2h0d2VpZ2h0TGVhdmVzKCkge1xuXHRcdGNvbnN0IGVycm9yczogc3RyaW5nW10gPSBbXTtcblx0XHRjb25zdCBoYXJuZXNzID0gY3JlYXRlTGlnaHR3ZWlnaHRXaW5kb3dIYXJuZXNzKCk7XG5cdFx0aGFybmVzcy5zZXROb3RpZnlFcnJvcihtZXNzYWdlID0+IHtcblx0XHRcdGVycm9ycy5wdXNoKHR5cGVvZiBtZXNzYWdlID09PSAnc3RyaW5nJyA/IG1lc3NhZ2UgOiBnZXRFcnJvck1lc3NhZ2UobWVzc2FnZSkpO1xuXHRcdH0pO1xuXHRcdGF3YWl0IHRpbWVvdXQoMCk7XG5cdFx0Y29uc3QgcHJpbWFyeUlkID0gaGFybmVzcy5yb3N0ZXJTZXJ2aWNlLmdldEFjdGl2ZVNlc3Npb25JZCgpO1xuXHRcdGF3YWl0IGhhcm5lc3Muc2Vzc2lvbldpbmRvd1NlcnZpY2UuZW5zdXJlUHJpbWFyeVdpbmRvdyhwcmltYXJ5SWQpO1xuXHRcdGNvbnN0IHNlY29uZGFyeUlkID0gaGFybmVzcy5yb3N0ZXJTZXJ2aWNlLnNlZWRTZXNzaW9uUXVpZXRseSgpO1xuXHRcdGF3YWl0IGhhcm5lc3Muc2Vzc2lvbldpbmRvd1NlcnZpY2Uub3BlblNlc3Npb25CZXNpZGUoc2Vjb25kYXJ5SWQpO1xuXHRcdGFzc2VydC5zdHJpY3RFcXVhbChoYXJuZXNzLnNlc3Npb25XaW5kb3dTZXJ2aWNlLmdldFZpc2libGVXaW5kb3dDb3VudCgpLCAyKTtcblx0XHRhc3NlcnQuc3RyaWN0RXF1YWwoaGFybmVzcy5zZXNzaW9uV2luZG93U2VydmljZS5pc1Nlc3Npb25XaW5kb3dWaXNpYmxlKHByaW1hcnlJZCksIHRydWUpO1xuXHRcdGFzc2VydC5zdHJpY3RFcXVhbChoYXJuZXNzLnNlc3Npb25XaW5kb3dTZXJ2aWNlLmlzU2Vzc2lvbldpbmRvd1Zpc2libGUoc2Vjb25kYXJ5SWQpLCB0cnVlKTtcblx0XHRjb25zdCBpbmNvbWluZ0lkID0gaGFybmVzcy5yb3N0ZXJTZXJ2aWNlLnNlZWRTZXNzaW9uUXVpZXRseSgpO1xuXHRcdHJldHVybiB7IGhhcm5lc3MsIGVycm9ycywgcHJpbWFyeUlkLCBzZWNvbmRhcnlJZCwgaW5jb21pbmdJZCB9O1xuXHR9XG5cblx0dGVzdCgnc2Vjb25kYXJ5IHJlcGxhY2UgY3JlYXRlIGZhaWx1cmUgcmVzdG9yZXMgdGhlIG91dGdvaW5nIGxlYWYgYW5kIG5vdGlmaWVzJywgYXN5bmMgKCkgPT4ge1xuXHRcdGNvbnN0IHsgaGFybmVzcywgZXJyb3JzLCBwcmltYXJ5SWQsIHNlY29uZGFyeUlkLCBpbmNvbWluZ0lkIH0gPSBhd2FpdCBvcGVuVHdvTGlnaHR3ZWlnaHRMZWF2ZXMoKTtcblx0XHRjb25zdCB7IHNlc3Npb25XaW5kb3dTZXJ2aWNlLCBjb252ZXJzYXRpb25QYXJ0cyB9ID0gaGFybmVzcztcblx0XHRoYXJuZXNzLnNldFRocm93T25DcmVhdGUodHJ1ZSk7XG5cdFx0YXdhaXQgc2Vzc2lvbldpbmRvd1NlcnZpY2UucmV2ZWFsU2Vzc2lvbldpbmRvdyhpbmNvbWluZ0lkLCB7IHJlcGxhY2U6IHNlY29uZGFyeUlkIH0pO1xuXG5cdFx0YXNzZXJ0LnN0cmljdEVxdWFsKHNlc3Npb25XaW5kb3dTZXJ2aWNlLmlzU2Vzc2lvbldpbmRvd1Zpc2libGUoc2Vjb25kYXJ5SWQpLCB0cnVlKTtcblx0XHRhc3NlcnQuc3RyaWN0RXF1YWwoc2Vzc2lvbldpbmRvd1NlcnZpY2UuaXNTZXNzaW9uV2luZG93VmlzaWJsZShwcmltYXJ5SWQpLCB0cnVlKTtcblx0XHRhc3NlcnQuc3RyaWN0RXF1YWwoc2Vzc2lvbldpbmRvd1NlcnZpY2UuZ2V0VmlzaWJsZVdpbmRvd0NvdW50KCksIDIpO1xuXHRcdGFzc2VydC5zdHJpY3RFcXVhbChzZXNzaW9uV2luZG93U2VydmljZS5nZXRMZWFmU2xvdHMoaW5jb21pbmdJZCksIHVuZGVmaW5lZCk7XG5cdFx0YXNzZXJ0Lm9rKCFzZXNzaW9uV2luZG93U2VydmljZS5nZXRBbGxMZWFmU2Vzc2lvbktleXMoKS5pbmNsdWRlcyhpbmNvbWluZ0lkKSk7XG5cdFx0YXNzZXJ0Lm9rKCFjb252ZXJzYXRpb25QYXJ0cy5zb21lKHBhcnQgPT4gcGFydC5zZXNzaW9uS2V5ID09PSBpbmNvbWluZ0lkKSk7XG5cdFx0YXNzZXJ0Lm9rKGVycm9ycy5zb21lKGVycm9yID0+IGVycm9yLmluY2x1ZGVzKCdyZXZlYWwgYm9vbScpKSk7XG5cdH0pO1xuXG5cdHRlc3QoJ3NlY29uZGFyeSByZXBsYWNlIHdoZW5SZWFkeSBmYWlsdXJlIHJlc3RvcmVzIHRoZSBvdXRnb2luZyBsZWFmIGFuZCBub3RpZmllcycsIGFzeW5jICgpID0+IHtcblx0XHRjb25zdCB7IGhhcm5lc3MsIGVycm9ycywgcHJpbWFyeUlkLCBzZWNvbmRhcnlJZCwgaW5jb21pbmdJZCB9ID0gYXdhaXQgb3BlblR3b0xpZ2h0d2VpZ2h0TGVhdmVzKCk7XG5cdFx0Y29uc3QgeyBzZXNzaW9uV2luZG93U2VydmljZSwgY29udmVyc2F0aW9uUGFydHMgfSA9IGhhcm5lc3M7XG5cdFx0aGFybmVzcy5zZXRSZWplY3RXaGVuUmVhZHkodHJ1ZSk7XG5cdFx0YXdhaXQgc2Vzc2lvbldpbmRvd1NlcnZpY2UucmV2ZWFsU2Vzc2lvbldpbmRvdyhpbmNvbWluZ0lkLCB7IHJlcGxhY2U6IHNlY29uZGFyeUlkIH0pO1xuXG5cdFx0YXNzZXJ0LnN0cmljdEVxdWFsKHNlc3Npb25XaW5kb3dTZXJ2aWNlLmlzU2Vzc2lvbldpbmRvd1Zpc2libGUoc2Vjb25kYXJ5SWQpLCB0cnVlKTtcblx0XHRhc3NlcnQuc3RyaWN0RXF1YWwoc2Vzc2lvbldpbmRvd1NlcnZpY2UuaXNTZXNzaW9uV2luZG93VmlzaWJsZShwcmltYXJ5SWQpLCB0cnVlKTtcblx0XHRhc3NlcnQuc3RyaWN0RXF1YWwoc2Vzc2lvbldpbmRvd1NlcnZpY2UuZ2V0VmlzaWJsZVdpbmRvd0NvdW50KCksIDIpO1xuXHRcdGFzc2VydC5zdHJpY3RFcXVhbChzZXNzaW9uV2luZG93U2VydmljZS5nZXRMZWFmU2xvdHMoaW5jb21pbmdJZCksIHVuZGVmaW5lZCk7XG5cdFx0YXNzZXJ0Lm9rKCFzZXNzaW9uV2luZG93U2VydmljZS5nZXRBbGxMZWFmU2Vzc2lvbktleXMoKS5pbmNsdWRlcyhpbmNvbWluZ0lkKSk7XG5cdFx0YXNzZXJ0Lm9rKCFjb252ZXJzYXRpb25QYXJ0cy5zb21lKHBhcnQgPT4gcGFydC5zZXNzaW9uS2V5ID09PSBpbmNvbWluZ0lkKSk7XG5cdFx0YXNzZXJ0Lm9rKGVycm9ycy5zb21lKGVycm9yID0+IGVycm9yLmluY2x1ZGVzKCd3aGVuUmVhZHkgYm9vbScpKSk7XG5cdH0pO1xuXG5cdHRlc3QoJ3ByaW1hcnkgcmVwbGFjZSBjcmVhdGUgZmFpbHVyZSBkb2VzIG5vdCBoaWRlIHRoZSBvbGQgcHJpbWFyeScsIGFzeW5jICgpID0+IHtcblx0XHRjb25zdCB7IGhhcm5lc3MsIGVycm9ycywgcHJpbWFyeUlkLCBzZWNvbmRhcnlJZCwgaW5jb21pbmdJZCB9ID0gYXdhaXQgb3BlblR3b0xpZ2h0d2VpZ2h0TGVhdmVzKCk7XG5cdFx0Y29uc3QgeyBzZXNzaW9uV2luZG93U2VydmljZSB9ID0gaGFybmVzcztcblx0XHRoYXJuZXNzLnNldFRocm93T25DcmVhdGUodHJ1ZSk7XG5cdFx0YXdhaXQgc2Vzc2lvbldpbmRvd1NlcnZpY2UucmV2ZWFsU2Vzc2lvbldpbmRvdyhpbmNvbWluZ0lkLCB7IHJlcGxhY2U6IHByaW1hcnlJZCB9KTtcblxuXHRcdGFzc2VydC5zdHJpY3RFcXVhbChzZXNzaW9uV2luZG93U2VydmljZS5pc1Nlc3Npb25XaW5kb3dWaXNpYmxlKHByaW1hcnlJZCksIHRydWUpO1xuXHRcdGFzc2VydC5zdHJpY3RFcXVhbChzZXNzaW9uV2luZG93U2VydmljZS5pc1Nlc3Npb25XaW5kb3dIaWRkZW4ocHJpbWFyeUlkKSwgZmFsc2UpO1xuXHRcdGFzc2VydC5zdHJpY3RFcXVhbChzZXNzaW9uV2luZG93U2VydmljZS5pc1Nlc3Npb25XaW5kb3dWaXNpYmxlKHNlY29uZGFyeUlkKSwgdHJ1ZSk7XG5cdFx0YXNzZXJ0LnN0cmljdEVxdWFsKHNlc3Npb25XaW5kb3dTZXJ2aWNlLmdldFByaW1hcnlTZXNzaW9uS2V5KCksIHByaW1hcnlJZCk7XG5cdFx0YXNzZXJ0LnN0cmljdEVxdWFsKHNlc3Npb25XaW5kb3dTZXJ2aWNlLmdldFZpc2libGVXaW5kb3dDb3VudCgpLCAyKTtcblx0XHRhc3NlcnQuc3RyaWN0RXF1YWwoc2Vzc2lvbldpbmRvd1NlcnZpY2UuZ2V0TGVhZlNsb3RzKGluY29taW5nSWQpLCB1bmRlZmluZWQpO1xuXHRcdGFzc2VydC5vayghc2Vzc2lvbldpbmRvd1NlcnZpY2UuZ2V0QWxsTGVhZlNlc3Npb25LZXlzKCkuaW5jbHVkZXMoaW5jb21pbmdJZCkpO1xuXHRcdGFzc2VydC5vayhlcnJvcnMuc29tZShlcnJvciA9PiBlcnJvci5pbmNsdWRlcygncmV2ZWFsIGJvb20nKSkpO1xuXHR9KTtcblxuXHR0ZXN0KCcxNyBoaWRpbmcgYSBsZWFmIHJlbGVhc2VzIGl0cyBsZW5zIGxlYXNlIGFuZCByZXN0b3JlIHJlYWNxdWlyZXMgaXQnLCBhc3luYyAoKSA9PiB7XG5cdFx0Y29uc3QgaGFybmVzcyA9IGF3YWl0IGNyZWF0ZVJldmVhbEhhcm5lc3MoKTtcblx0XHRjb25zdCB7IHBhcnRzLCBzZXNzaW9uV2luZG93U2VydmljZSwgcm9zdGVyU2VydmljZSwgcHJpbWFyeUlkLCBzZXNzaW9uQ2hhdFNlcnZpY2UgfSA9IGhhcm5lc3M7XG5cdFx0YXdhaXQgc2Vzc2lvbkNoYXRTZXJ2aWNlLm9wZW5FeHRlbnNpb25UYWIocHJpbWFyeUlkLCAnZm9yay1sZWFzZScsIHsgdGl0bGU6ICdGb3JrIGxlYXNlJyB9KTtcblx0XHRjb25zdCBwYW5lQSA9IGF3YWl0IHdhaXRGb3JTZXNzaW9uUGFuZShoYXJuZXNzLCBwcmltYXJ5SWQpO1xuXHRcdGNvbnN0IHBhcnRBID0gcGFydEZvcihwYXJ0cywgcHJpbWFyeUlkKTtcblx0XHRjb25zdCB0YWJDb3VudCA9IHBhcnRBLmFjdGl2ZUdyb3VwLmNvdW50O1xuXHRcdGFzc2VydC5vayh0YWJDb3VudCA+PSAyKTtcblx0XHRhc3NlcnQub2socGFuZUEuYWN0aXZlQ29udmVyc2F0aW9uTGVucyk7XG5cblx0XHRjb25zdCBiID0gcm9zdGVyU2VydmljZS5zZWVkU2Vzc2lvblF1aWV0bHkoKTtcblx0XHRhd2FpdCBzZXNzaW9uV2luZG93U2VydmljZS5yZXZlYWxTZXNzaW9uV2luZG93KGIpO1xuXHRcdGF3YWl0IHdhaXRGb3JTZXNzaW9uUGFuZShoYXJuZXNzLCBiKTtcblx0XHRhc3NlcnQuc3RyaWN0RXF1YWwoc2Vzc2lvbldpbmRvd1NlcnZpY2UuaXNTZXNzaW9uV2luZG93SGlkZGVuKHByaW1hcnlJZCksIHRydWUpO1xuXHRcdGFzc2VydC5zdHJpY3RFcXVhbChwYXJ0QS5hY3RpdmVHcm91cC5jb3VudCwgdGFiQ291bnQpO1xuXHRcdGNvbnN0IGhpZGRlbkxlbnNlcyA9IGF3YWl0IGNvbGxlY3RMZWFmQ29udmVyc2F0aW9uTGVuc2VzKHBhcnRBKTtcblx0XHRhc3NlcnQuc3RyaWN0RXF1YWwoaGlkZGVuTGVuc2VzLmxlbmd0aCwgdGFiQ291bnQpO1xuXHRcdGZvciAoY29uc3QgbGVucyBvZiBoaWRkZW5MZW5zZXMpIHtcblx0XHRcdGFzc2VydC5zdHJpY3RFcXVhbChsZW5zLnNlc3Npb25WaWV3TGVhc2UsIHVuZGVmaW5lZCk7XG5cdFx0fVxuXHRcdGFzc2VydC5zdHJpY3RFcXVhbChwYXJ0QS5zZXNzaW9uS2V5LCBwcmltYXJ5SWQpO1xuXHRcdGNvbnN0IGhpZGRlbkxlYWYgPSBzZXNzaW9uV2luZG93U2VydmljZS5nZXRMZWFmU2xvdHMocHJpbWFyeUlkKT8uY29udGFpbmVyO1xuXHRcdGFzc2VydC5vayhoaWRkZW5MZWFmPy5jbGFzc0xpc3QuY29udGFpbnMoY29udmVyc2F0aW9uU2Vzc2lvbkxlYWZIaWRkZW5DbGFzcykpO1xuXHRcdGNvbnN0IHN0YWxlQmFubmVyID0gaGlkZGVuTGVhZj8ucXVlcnlTZWxlY3RvcignLmNvbnZlcnNhdGlvbi1sZW5zLXN0YWxlLXNuYXBzaG90JykgYXMgSFRNTEVsZW1lbnQgfCBudWxsO1xuXHRcdGFzc2VydC5vayghc3RhbGVCYW5uZXIgfHwgc3RhbGVCYW5uZXIuaGlkZGVuIHx8ICFzdGFsZUJhbm5lci50ZXh0Q29udGVudCk7XG5cblx0XHRhd2FpdCBzZXNzaW9uV2luZG93U2VydmljZS5yZXZlYWxTZXNzaW9uV2luZG93KHByaW1hcnlJZCk7XG5cdFx0Y29uc3QgcGFuZUEyID0gYXdhaXQgd2FpdEZvclNlc3Npb25QYW5lKGhhcm5lc3MsIHByaW1hcnlJZCk7XG5cdFx0Y29uc3QgcmVzdG9yZWRMZW5zZXMgPSBhd2FpdCBjb2xsZWN0TGVhZkNvbnZlcnNhdGlvbkxlbnNlcyhwYXJ0Rm9yKHBhcnRzLCBwcmltYXJ5SWQpKTtcblx0XHRhc3NlcnQuc3RyaWN0RXF1YWwocmVzdG9yZWRMZW5zZXMubGVuZ3RoLCB0YWJDb3VudCk7XG5cdFx0Zm9yIChjb25zdCBsZW5zIG9mIHJlc3RvcmVkTGVuc2VzKSB7XG5cdFx0XHRhc3NlcnQub2sobGVucy5zZXNzaW9uVmlld0xlYXNlLCAncmVzdG9yZSBtdXN0IHJlYWNxdWlyZSBzZXNzaW9uVmlld0xlYXNlIG9uIGV2ZXJ5IGxlYWYgbGVucycpO1xuXHRcdH1cblx0XHRhc3NlcnQub2socGFuZUEyLmFjdGl2ZUNvbnZlcnNhdGlvbkxlbnM/LnNlc3Npb25WaWV3TGVhc2UsICdyZXN0b3JlIG11c3QgcmVhY3F1aXJlIHNlc3Npb25WaWV3TGVhc2UnKTtcblx0fSk7XG5cblx0dGVzdCgnZG9lcyBub3QgbGVhayB1bmhhbmRsZWQgcmVqZWN0aW9uIHdoZW4gb25EaWRDaGFuZ2VBY3RpdmVTZXNzaW9uIHJldmVhbCBjYXRjaC1wYXRoIG5vdGljZSB0aHJvd3MgYW5kIG9uVW5leHBlY3RlZEVycm9yIHdhcm4tdGhlbi1yZXRocm93cycsIGFzeW5jICgpID0+IHtcblx0XHQvLyByZXZlYWxTZXNzaW9uV2luZG93IGFscmVhZHkgY2F0Y2hlcyBjcmVhdGUgdGhyb3c7IGEgbG9uZSBpbm5lciByZWplY3QgZG9lcyBub3QgbGVhay5cblx0XHQvLyBUaGUgdm9pZCBvbkRpZENoYW5nZUFjdGl2ZVNlc3Npb24gY2FsbCBzaXRlIHN0aWxsIG5lZWRzIGAuY2F0Y2hgIHdoZW4gdGhlIGNhdGNoLXBhdGggbm90aWNlIHRocm93cy5cblx0XHQvLyBBIGxvbmUgYC5jYXRjaChvblVuZXhwZWN0ZWRFcnJvcilgIHN0aWxsIGxlYWtzIHdoZW4gdGhlIGhhbmRsZXIgd2Fybi10aGVuLXJldGhyb3dzLlxuXHRcdGNvbnN0IHBhaW50Qm9vbSA9IG5ldyBFcnJvcigncGFpbnQgYm9vbScpO1xuXHRcdGNvbnN0IGhhcm5lc3MgPSBjcmVhdGVMaWdodHdlaWdodFdpbmRvd0hhcm5lc3MoKTtcblx0XHRhd2FpdCB0aW1lb3V0KDApO1xuXHRcdGNvbnN0IHByaW1hcnlJZCA9IGhhcm5lc3Mucm9zdGVyU2VydmljZS5nZXRBY3RpdmVTZXNzaW9uSWQoKTtcblx0XHRhd2FpdCBoYXJuZXNzLnNlc3Npb25XaW5kb3dTZXJ2aWNlLmVuc3VyZVByaW1hcnlXaW5kb3cocHJpbWFyeUlkKTtcblx0XHRjb25zdCB0YXJnZXQgPSBoYXJuZXNzLnJvc3RlclNlcnZpY2Uuc2VlZFNlc3Npb25RdWlldGx5KCk7XG5cdFx0aGFybmVzcy5zZXRUaHJvd09uQ3JlYXRlKHRydWUpO1xuXHRcdGF3YWl0IGFzc2VydFdhcm5UaGVuUmV0aHJvd0RvZXNOb3RMZWFrKHBhaW50Qm9vbSwgKCkgPT4ge1xuXHRcdFx0aGFybmVzcy5zZXROb3RpZnlFcnJvcigoKSA9PiB7XG5cdFx0XHRcdHRocm93IHBhaW50Qm9vbTtcblx0XHRcdH0pO1xuXHRcdFx0aGFybmVzcy5yb3N0ZXJTZXJ2aWNlLmZpcmVBY3RpdmVTZXNzaW9uKHRhcmdldCk7XG5cdFx0fSk7XG5cdH0pO1xuXG5cdHRlc3QoJ2RvZXMgbm90IGxlYWsgdW5oYW5kbGVkIHJlamVjdGlvbiB3aGVuIGF0dGFjaEdyaWQgcGVuZGluZyByZXZlYWwgY2F0Y2gtcGF0aCBub3RpY2UgdGhyb3dzIGFuZCBvblVuZXhwZWN0ZWRFcnJvciB3YXJuLXRoZW4tcmV0aHJvd3MnLCBhc3luYyAoKSA9PiB7XG5cdFx0Ly8gcmV2ZWFsU2Vzc2lvbldpbmRvdyBhbHJlYWR5IGNhdGNoZXMgY3JlYXRlIHRocm93OyBhIGxvbmUgaW5uZXIgcmVqZWN0IGRvZXMgbm90IGxlYWsuXG5cdFx0Ly8gVGhlIHZvaWQgYXR0YWNoR3JpZCBwZW5kaW5nIGNhbGwgc2l0ZSBzdGlsbCBuZWVkcyBgLmNhdGNoYCB3aGVuIHRoZSBjYXRjaC1wYXRoIG5vdGljZSB0aHJvd3MuXG5cdFx0Ly8gQSBsb25lIGAuY2F0Y2gob25VbmV4cGVjdGVkRXJyb3IpYCBzdGlsbCBsZWFrcyB3aGVuIHRoZSBoYW5kbGVyIHdhcm4tdGhlbi1yZXRocm93cy5cblx0XHRjb25zdCBwYWludEJvb20gPSBuZXcgRXJyb3IoJ3BhaW50IGJvb20nKTtcblx0XHRjb25zdCBoYXJuZXNzID0gY3JlYXRlTGlnaHR3ZWlnaHRXaW5kb3dIYXJuZXNzKHsgZGVsYXlTbG90czogdHJ1ZSB9KTtcblx0XHRjb25zdCB0YXJnZXQgPSBoYXJuZXNzLnJvc3RlclNlcnZpY2Uuc2VlZFNlc3Npb25RdWlldGx5KCk7XG5cdFx0aGFybmVzcy5zZXRUaHJvd09uQ3JlYXRlKHRydWUpO1xuXHRcdGF3YWl0IGFzc2VydFdhcm5UaGVuUmV0aHJvd0RvZXNOb3RMZWFrKHBhaW50Qm9vbSwgKCkgPT4ge1xuXHRcdFx0aGFybmVzcy5zZXROb3RpZnlFcnJvcigoKSA9PiB7XG5cdFx0XHRcdHRocm93IHBhaW50Qm9vbTtcblx0XHRcdH0pO1xuXHRcdFx0dm9pZCBoYXJuZXNzLnNlc3Npb25XaW5kb3dTZXJ2aWNlLnJldmVhbFNlc3Npb25XaW5kb3codGFyZ2V0LCB7IHJlcGxhY2U6IGhhcm5lc3Mucm9zdGVyU2VydmljZS5nZXRBY3RpdmVTZXNzaW9uSWQoKSB9KTtcblx0XHRcdGhhcm5lc3MuYXR0YWNoU2xvdHMoKTtcblx0XHR9KTtcblx0fSk7XG5cblx0dGVzdCgnc2Vzc2lvbiB3aW5kb3cgZmlyZS1hbmQtZm9yZ2V0IHZvaWRzIGRvdWJsZS1jYXRjaCBvblVuZXhwZWN0ZWRFcnJvcicsIGFzeW5jICgpID0+IHtcblx0XHRjb25zdCBzb3VyY2UgPSBhd2FpdCBfX3JlYWRGaWxlSW5UZXN0cyhgJHtwcm9jZXNzLmN3ZCgpfS9zcmMvdnMvd29ya2JlbmNoL2NvbnRyaWIvY29udmVyc2F0aW9uL2Jyb3dzZXIvY29udmVyc2F0aW9uU2Vzc2lvbldpbmRvd1NlcnZpY2UudHNgKTtcblx0XHRjb25zdCBkb3VibGVDYXRjaCA9ICcuY2F0Y2gob25VbmV4cGVjdGVkRXJyb3IpLmNhdGNoKG9uVW5leHBlY3RlZEVycm9yKSc7XG5cdFx0YXNzZXJ0Lm9rKHNvdXJjZS5pbmNsdWRlcyhgdm9pZCB0aGlzLnJldmVhbFNlc3Npb25XaW5kb3coc2Vzc2lvbktleSkke2RvdWJsZUNhdGNofWApKTtcblx0XHRhc3NlcnQub2soc291cmNlLmluY2x1ZGVzKGB2b2lkIHRoaXMucmV2ZWFsU2Vzc2lvbldpbmRvdyhwZW5kaW5nLnNlc3Npb25LZXksIHBlbmRpbmcub3B0aW9ucykke2RvdWJsZUNhdGNofWApKTtcblx0XHRhc3NlcnQub2soc291cmNlLmluY2x1ZGVzKGB2b2lkIHRoaXMuZW5zdXJlUHJpbWFyeVdpbmRvdyh0aGlzLnJvc3RlclNlcnZpY2UuZ2V0QWN0aXZlU2Vzc2lvbklkKCkpJHtkb3VibGVDYXRjaH1gKSk7XG5cdFx0YXNzZXJ0Lm9rKCFzb3VyY2UuaW5jbHVkZXMoJ3ZvaWQgdGhpcy5yZXZlYWxTZXNzaW9uV2luZG93KHNlc3Npb25LZXkpOycpKTtcblx0XHRhc3NlcnQub2soIXNvdXJjZS5pbmNsdWRlcygndm9pZCB0aGlzLnJldmVhbFNlc3Npb25XaW5kb3cocGVuZGluZy5zZXNzaW9uS2V5LCBwZW5kaW5nLm9wdGlvbnMpOycpKTtcblx0XHRhc3NlcnQub2soIXNvdXJjZS5pbmNsdWRlcygndm9pZCB0aGlzLmVuc3VyZVByaW1hcnlXaW5kb3codGhpcy5yb3N0ZXJTZXJ2aWNlLmdldEFjdGl2ZVNlc3Npb25JZCgpKTsnKSk7XG5cdH0pO1xufSk7XG4iXSwKICAibWFwcGluZ3MiOiAiQUFLQSxPQUFPLFlBQVk7QUFDbkIsU0FBUyxXQUFXLHdCQUF3QjtBQUM1QyxTQUFTLGtCQUFrQjtBQUMzQixTQUFTLGlCQUFpQixhQUFhLGVBQWU7QUFDdEQsU0FBUyxjQUFjLGlCQUFpQixpQ0FBaUM7QUFDekUsU0FBUyxTQUFTLGFBQWE7QUFDL0IsU0FBUyxZQUE2QixvQkFBb0I7QUFDMUQsU0FBUywrQ0FBK0M7QUFDeEQsU0FBUyxzQkFBc0I7QUFDL0IsU0FBUyxhQUFhLHNCQUFzQjtBQUU1QyxTQUFTLGdDQUFnQztBQUN6QyxTQUFTLGdCQUFnQjtBQUN6QixTQUFTLGtCQUFrQixnQ0FBOEQ7QUFDekYsU0FBa0MsNEJBQTRCO0FBQzlELFNBQVMscUJBQXFCO0FBQzlCLFNBQVMsc0JBQXNCO0FBQy9CLFNBQVMsd0JBQWdEO0FBQ3pELFNBQVMsbUJBQW1CLG9CQUFvQixxQkFBcUIscUNBQXFDO0FBQzFHLFNBQVMsNkJBQTZCO0FBQ3RDLE9BQU87QUFDUCxTQUFTLDhCQUE4QjtBQUN2QyxTQUFTLDJDQUEyQztBQUNwRCxTQUFTLDBDQUEwQztBQUNuRCxTQUFTLCtCQUErQixzQ0FBc0M7QUFDOUUsU0FBUyxnQ0FBZ0MsdUNBQXVDO0FBQ2hGLFNBQVMsbUJBQW1CLDZCQUE2QjtBQUN6RCxTQUFTLGtDQUFrQyx5Q0FBeUM7QUFDcEYsU0FBUyx5QkFBeUIsa0NBQWtDO0FBQ3BFLFNBQVMsZ0NBQWdDLGtDQUFrQztBQUMzRSxTQUFTLDBDQUEwQztBQUNuRCxTQUFTLHFDQUFxQztBQUM5QyxTQUFTLGlDQUFpQywrQkFBK0IsMENBQTBDO0FBQ25ILFNBQVMsdUNBQXVDO0FBQ2hELFNBQVMsMEJBQTBCLGlDQUFpQztBQUNwRSxTQUFTLDJCQUEyQjtBQUVwQyxTQUFTLDBCQUEwQiwwQ0FBMEM7QUFDN0UsU0FBUyx1Q0FBdUM7QUFDaEQsU0FBUyxnQ0FBZ0M7QUFJekMsU0FBUyx1QkFBdUIsbUNBQW1DO0FBQ25FLFNBQVMsNENBQTRDO0FBQ3JELFNBQVMsNENBQTRDO0FBQ3JELFNBQVMsb0RBQW9EO0FBQzdELFNBQVMsd0JBQXdCO0FBQ2pDLFNBQVMsbUJBQW1CO0FBSTVCLE1BQU0sMkJBQTJCLHdCQUF3QjtBQUFBLEVBQ3hELHFCQUE2QjtBQUM1QixVQUFNLFdBQVcsS0FBSyxNQUFNLG1CQUFtQjtBQUMvQyxVQUFNLFlBQVksS0FBSyxNQUFNLGNBQWM7QUFDM0MsU0FBSyxNQUFNLGNBQWMsUUFBUTtBQUNqQyxTQUFLLG9CQUFvQixLQUFLLFNBQVM7QUFDdkMsV0FBTztBQUFBLEVBQ1I7QUFBQSxFQUVBLGtCQUFrQixXQUF5QjtBQUMxQyxTQUFLLDBCQUEwQixLQUFLLFNBQVM7QUFBQSxFQUM5QztBQUFBLEVBRUEsbUJBQW1CLFdBQXlCO0FBQzNDLFNBQUssb0JBQW9CLEtBQUssU0FBUztBQUFBLEVBQ3hDO0FBQ0Q7QUFHQSxNQUFNLGdDQUFnQyxXQUFnRDtBQUFBLEVBQXRGO0FBQUE7QUFFQyxTQUFTLFdBQXFELENBQUM7QUFDL0QsU0FBUyxXQUFXLG9CQUFJLElBQVk7QUFDcEMsU0FBaUIsV0FBVyxvQkFBSSxJQUEwRDtBQUMxRixTQUFpQixXQUFXLG9CQUFJLElBQW9CO0FBQ3BELFNBQWlCLFlBQVksb0JBQUksSUFBWTtBQUM3QyxTQUFpQixZQUFZLEtBQUssVUFBVSxJQUFJLFFBQWdCLENBQUM7QUFDakUsU0FBUyxjQUFjLEtBQUssVUFBVTtBQUFBO0FBQUEsRUFFdEMsdUJBQXVCLFNBQTZEO0FBQ25GLFFBQUksVUFBVSxLQUFLLFNBQVMsSUFBSSxPQUFPO0FBQ3ZDLFFBQUksQ0FBQyxTQUFTO0FBQ2IsZ0JBQVUsS0FBSyxVQUFVLElBQUksUUFBNkM7QUFBQSxRQUN6RSx1QkFBdUIsTUFBTSxlQUFlLE1BQU07QUFDakQsZUFBSyxVQUFVLE9BQU87QUFDdEIsZUFBSyxVQUFVLElBQUksT0FBTztBQUMxQixlQUFLLFVBQVUsS0FBSyxPQUFPO0FBQUEsUUFDNUIsQ0FBQztBQUFBLE1BQ0YsQ0FBQyxDQUFDO0FBQ0YsV0FBSyxTQUFTLElBQUksU0FBUyxPQUFPO0FBQUEsSUFDbkM7QUFDQSxXQUFPLFFBQVE7QUFBQSxFQUNoQjtBQUFBLEVBRUEsTUFBTSxhQUFhLFdBQW9DO0FBQ3RELFVBQU0sVUFBVSxVQUFVLFNBQVMsSUFBSSxLQUFLLFNBQVMsU0FBUyxDQUFDO0FBQy9ELFNBQUssU0FBUyxLQUFLLEVBQUUsU0FBUyxVQUFVLENBQUM7QUFDekMsV0FBTztBQUFBLEVBQ1I7QUFBQSxFQUNBLE1BQU0sdUJBQXVCLFdBQW9DO0FBQUUsV0FBTztBQUFBLEVBQVc7QUFBQSxFQUNyRixNQUFNLGFBQWEsU0FBZ0M7QUFBRSxTQUFLLFNBQVMsSUFBSSxPQUFPO0FBQUEsRUFBRztBQUFBLEVBQ2pGLE1BQU0sT0FBdUI7QUFBRSxVQUFNLElBQUksTUFBTSwrQkFBK0I7QUFBQSxFQUFHO0FBQUEsRUFDakYsTUFBTSxnQkFBK0I7QUFBQSxFQUFFO0FBQUEsRUFDdkMsTUFBTSxjQUE2QjtBQUFBLEVBQUU7QUFBQSxFQUNyQyxNQUFNLGdCQUFnQjtBQUFFLFdBQU8sRUFBRSxJQUFJLE9BQWdCLFFBQVEsY0FBdUI7QUFBQSxFQUFHO0FBQUEsRUFFdkYsbUJBQW1CLFdBQTRCO0FBQzlDLFdBQU8sS0FBSyxTQUFTLEtBQUssV0FBUyxNQUFNLGNBQWMsYUFBYSxLQUFLLFVBQVUsSUFBSSxNQUFNLE9BQU8sS0FBSyxDQUFDLEtBQUssU0FBUyxJQUFJLE1BQU0sT0FBTyxDQUFDO0FBQUEsRUFDM0k7QUFBQSxFQUVBLFlBQVksV0FBbUIsTUFBb0I7QUFDbEQsZUFBVyxTQUFTLEtBQUssVUFBVTtBQUNsQyxVQUFJLE1BQU0sY0FBYyxXQUFXO0FBQ2xDLGFBQUssVUFBVSxNQUFNLFNBQVMsSUFBSTtBQUFBLE1BQ25DO0FBQUEsSUFDRDtBQUFBLEVBQ0Q7QUFBQSxFQUVRLFVBQVUsU0FBaUIsTUFBcUI7QUFDdkQsVUFBTSxRQUFRLEtBQUssU0FBUyxLQUFLLGVBQWEsVUFBVSxZQUFZLE9BQU87QUFDM0UsUUFBSSxDQUFDLFNBQVMsS0FBSyxTQUFTLElBQUksT0FBTyxHQUFHO0FBQ3pDO0FBQUEsSUFDRDtBQUNBLFVBQU0sYUFBYSxvQkFBb0IsTUFBTSxXQUFXLFNBQVMsU0FBWSxDQUFDLElBQUk7QUFBQSxNQUNqRixFQUFFLElBQUksR0FBRyxNQUFNLFNBQVMsU0FBUyxNQUFNLFFBQVEsS0FBSztBQUFBLE1BQ3BELEVBQUUsSUFBSSxHQUFHLE1BQU0sU0FBUyxlQUFlLE1BQU0sZ0JBQWdCLE1BQU0sa0JBQWtCLE1BQU0sU0FBUyxJQUFJLFFBQVEsVUFBVTtBQUFBLElBQzNILENBQUM7QUFDRCxVQUFNLFdBQVcsS0FBSyxTQUFTLElBQUksT0FBTyxLQUFLLEtBQUs7QUFDcEQsU0FBSyxTQUFTLElBQUksU0FBUyxPQUFPO0FBQ2xDLFNBQUssU0FBUyxJQUFJLE9BQU8sR0FBRyxLQUFLO0FBQUEsTUFDaEM7QUFBQSxNQUFTLFdBQVcsTUFBTTtBQUFBLE1BQVcsU0FBUyxFQUFFLE1BQU0sV0FBVztBQUFBLE1BQ2pFLE9BQU87QUFBQSxRQUNOLE9BQU8sRUFBRSxTQUFpQyxZQUFZLEdBQUcsU0FBUyxTQUFTLFNBQVMsTUFBTSxFQUFFLE1BQU0sWUFBWSxVQUFVLEVBQUUsR0FBRyxXQUFXLFVBQVUsTUFBTSxFQUFFLE1BQU0sT0FBTyxFQUFFLEVBQUUsRUFBRTtBQUFBLFFBQzdLLGFBQWEsQ0FBQyxHQUFHLFdBQVcsV0FBVyxFQUFFLElBQUksQ0FBQyxDQUFDLFFBQVEsV0FBVyxPQUFPLEVBQUUsSUFBSSxxQkFBcUIsUUFBUSxZQUFZLEVBQUU7QUFBQSxNQUMzSDtBQUFBLElBQ0QsQ0FBQztBQUFBLEVBQ0Y7QUFDRDtBQUVBLE1BQU0sNERBQTRELE1BQU07QUFFdkUsUUFBTSxpQkFBaUI7QUFDdkIsUUFBTSx1QkFBdUI7QUFFN0IsK0NBQTZDO0FBRTdDLFFBQU0sUUFBUSx3Q0FBd0M7QUFDdEQsUUFBTSxjQUFjO0FBRXBCLFdBQVMsWUFBWTtBQUNwQixVQUFNLElBQUksUUFBYyxhQUFXLFdBQVcsc0JBQXNCLE1BQU0sV0FBVyxzQkFBc0IsTUFBTSxRQUFRLENBQUMsQ0FBQyxDQUFDO0FBQUEsRUFDN0gsQ0FBQztBQUVELFFBQU0sV0FBWTtBQUNqQixTQUFLLFFBQVEsR0FBTTtBQUNuQixVQUFNLElBQUksbUJBQW1CLGdCQUFnQixDQUFDLElBQUksZUFBZSxtQkFBbUIsR0FBRyxJQUFJLGVBQWUscUJBQXFCLENBQUMsR0FBRyxvQkFBb0IsQ0FBQztBQUFBLEVBQ3pKLENBQUM7QUFFRCxXQUFTLFlBQVksT0FBNEQ7QUFDaEYsZUFBVyxRQUFRLE1BQU0sbUJBQW1CO0FBQzNDLFdBQUssT0FBTyxLQUFLLEtBQUssR0FBRyxDQUFDO0FBQUEsSUFDM0I7QUFBQSxFQUNEO0FBRUEsV0FBUyxhQUFhLE9BQTREO0FBQ2pGLGVBQVcsUUFBUSxNQUFNLG1CQUFtQjtBQUMzQyxpQkFBVyxVQUFVLEtBQUssWUFBWSxTQUFTO0FBQzlDLGNBQU0sSUFBSSxNQUFNO0FBQUEsTUFDakI7QUFBQSxJQUNEO0FBQUEsRUFDRDtBQUVBLGlCQUFlLFlBQVksTUFBK0IsYUFBd0IsQ0FBQyxHQUFHLE9BQXdGO0FBQzdLLFVBQU0sS0FBSztBQUNYLFVBQU0sV0FBVyxLQUFLLElBQUksSUFBSTtBQUM5QixXQUFPLEtBQUssSUFBSSxJQUFJLFVBQVU7QUFDN0IsWUFBTSxPQUFPLEtBQUssWUFBWTtBQUM5QixVQUFJLGdCQUFnQix3QkFBd0I7QUFDM0MsWUFBSSxPQUFPO0FBQ1YsdUJBQWEsS0FBSztBQUFBLFFBQ25CO0FBQ0EsZUFBTztBQUFBLE1BQ1I7QUFDQSxZQUFNLFFBQVEsRUFBRTtBQUFBLElBQ2pCO0FBQ0EsVUFBTSxTQUFTLFdBQVcsSUFBSSxXQUFTLGlCQUFpQixRQUFRLE1BQU0sU0FBUyxNQUFNLFVBQVUsT0FBTyxLQUFLLENBQUMsRUFBRSxLQUFLLElBQUk7QUFDdkgsVUFBTSxJQUFJLE1BQU0sd0NBQXdDLEtBQUssVUFBVSxTQUFTLEtBQUssWUFBWSxrQkFBa0IsTUFBTSxDQUFDLEdBQUcsU0FBUztBQUFBLEVBQUssTUFBTSxLQUFLLEVBQUUsRUFBRTtBQUFBLEVBQzNKO0FBRUEsV0FBUyxRQUFRLE9BQXNELFlBQTZDO0FBQ25ILFVBQU0sT0FBTyxNQUFNLGtCQUFrQixLQUFLLGVBQWEsVUFBVSxlQUFlLFVBQVU7QUFDMUYsV0FBTyxHQUFHLE1BQU0sZ0JBQWdCLFVBQVUsRUFBRTtBQUM1QyxXQUFPO0FBQUEsRUFDUjtBQUVBLFdBQVMsZ0JBQWdCLGVBQTJEO0FBQ25GLFdBQU8sQ0FBQyxHQUFHLGNBQWMsc0JBQXNCLENBQUM7QUFBQSxFQUNqRDtBQUVBLFdBQVMsV0FBVyxlQUFpRCxZQUE4QztBQUNsSCxXQUFPLGNBQWMsYUFBYSxVQUFVLEdBQUcsV0FBVyxjQUFjLGlDQUFpQztBQUFBLEVBQzFHO0FBRUEsaUJBQWUsaUNBQWlDLFdBQWtCLEtBQWdEO0FBRWpILFVBQU0sa0JBQTZCLENBQUM7QUFDcEMsVUFBTSxzQkFBaUMsQ0FBQztBQUN4QyxVQUFNLHVCQUF1QixDQUFDLFdBQW9CLG9CQUFvQixLQUFLLE1BQU07QUFDakYsWUFBUSxHQUFHLHNCQUFzQixvQkFBb0I7QUFDckQsVUFBTSx1QkFBdUIsYUFBYSwwQkFBMEI7QUFDcEUsOEJBQTBCLFdBQVM7QUFDbEMsc0JBQWdCLEtBQUssS0FBSztBQUMxQixVQUFJLGdCQUFnQixXQUFXLEdBQUc7QUFDakMsY0FBTTtBQUFBLE1BQ1A7QUFBQSxJQUNELENBQUM7QUFDRCxRQUFJO0FBQ0gsWUFBTSxJQUFJO0FBQ1YsWUFBTSxRQUFRLENBQUM7QUFDZixhQUFPLGdCQUFnQixFQUFFLHFCQUFxQixnQkFBZ0IsR0FBRztBQUFBLFFBQ2hFLHFCQUFxQixDQUFDO0FBQUEsUUFDdEIsaUJBQWlCLENBQUMsV0FBVyxTQUFTO0FBQUEsTUFDdkMsQ0FBQztBQUFBLElBQ0YsVUFBRTtBQUNELGdDQUEwQixvQkFBb0I7QUFDOUMsY0FBUSxJQUFJLHNCQUFzQixvQkFBb0I7QUFBQSxJQUN2RDtBQUFBLEVBQ0Q7QUFFQSxXQUFTLCtCQUErQixTQUFvQztBQUMzRSxVQUFNLGdCQUFnQixNQUFNLElBQUksSUFBSSxtQkFBbUIsQ0FBQztBQUN4RCxVQUFNLFdBQVcsU0FBUyxjQUFjLEtBQUs7QUFDN0MsYUFBUyxLQUFLLFlBQVksUUFBUTtBQUNsQyxVQUFNLElBQUksRUFBRSxTQUFTLE1BQU0sU0FBUyxPQUFPLEVBQUUsQ0FBQztBQUU5QyxVQUFNLG1CQUFtQixJQUFJLFFBQXNDO0FBQ25FLFVBQU0sSUFBSSxnQkFBZ0I7QUFFMUIsUUFBSSxnQkFBZ0I7QUFDcEIsUUFBSSxrQkFBa0I7QUFDdEIsVUFBTSxvQkFBK0MsQ0FBQztBQUN0RCxVQUFNLHNCQUFzQjtBQUFBLE1BQzNCLDhCQUE4QixDQUFDLFNBQWtCLGVBQXVCO0FBQ3ZFLFlBQUksZUFBZTtBQUNsQixnQkFBTSxJQUFJLE1BQU0sYUFBYTtBQUFBLFFBQzlCO0FBQ0EsWUFBSSxZQUEyQixRQUFRLFFBQVE7QUFDL0MsWUFBSSxpQkFBaUI7QUFDcEIsZ0JBQU0sV0FBVyxRQUFRLE9BQU8sSUFBSSxNQUFNLGdCQUFnQixDQUFDO0FBRTNELGVBQUssU0FBUyxNQUFNLE1BQU07QUFBQSxVQUFFLENBQUM7QUFDN0Isc0JBQVk7QUFBQSxRQUNiO0FBQ0EsY0FBTSxPQUFPLEVBQUUsWUFBWSxXQUFXLGFBQWEsRUFBRSxPQUFPLE1BQU07QUFBQSxRQUFFLEdBQUcsa0JBQWtCLEVBQUUsT0FBTyxNQUFNLHlCQUF5QixFQUFFLEVBQUU7QUFDckksMEJBQWtCLEtBQUssSUFBSTtBQUMzQixlQUFPO0FBQUEsTUFDUjtBQUFBLE1BQ0EsK0JBQStCLENBQUMsZUFBdUI7QUFDdEQsY0FBTSxRQUFRLGtCQUFrQixVQUFVLFVBQVEsS0FBSyxlQUFlLFVBQVU7QUFDaEYsWUFBSSxTQUFTLEdBQUc7QUFDZiw0QkFBa0IsT0FBTyxPQUFPLENBQUM7QUFBQSxRQUNsQztBQUFBLE1BQ0Q7QUFBQSxNQUNBLDRCQUE0QixNQUFNO0FBQUEsTUFBRTtBQUFBLE1BQ3BDLDRCQUE0QixNQUFNO0FBQUEsTUFDbEMsSUFBSSxvQkFBb0I7QUFDdkIsZUFBTztBQUFBLE1BQ1I7QUFBQSxJQUNEO0FBRUEsUUFBSTtBQUNKLFVBQU0sdUJBQXVCLE1BQU0sSUFBSSxJQUFJO0FBQUEsTUFDMUM7QUFBQSxRQUNDLGtCQUFrQixpQkFBaUI7QUFBQSxRQUNuQyxZQUFZLE1BQU07QUFBQSxRQUNsQixVQUFVLE1BQU0sU0FBUyxhQUN0QixTQUNBLEVBQUUsWUFBWSxTQUFTLGNBQWMsS0FBSyxHQUFHLG1CQUFtQixVQUFVLGdCQUFnQixPQUFVO0FBQUEsUUFDdkcseUJBQXlCLE1BQU07QUFBQSxRQUFFO0FBQUEsUUFDakMsT0FBTyxNQUFNO0FBQUEsUUFBRTtBQUFBLE1BQ2hCO0FBQUEsTUFDQTtBQUFBLE1BQ0E7QUFBQSxNQUNBLElBQUksZUFBZTtBQUFBLE1BQ25CO0FBQUEsUUFDQyxPQUFPLENBQUMsWUFBNEI7QUFDbkMsMEJBQWdCLE9BQU87QUFBQSxRQUN4QjtBQUFBLE1BQ0Q7QUFBQSxJQUNELENBQUM7QUFFRCxXQUFPO0FBQUEsTUFDTjtBQUFBLE1BQ0E7QUFBQSxNQUNBO0FBQUEsTUFDQSxpQkFBaUIsT0FBZ0I7QUFDaEMsd0JBQWdCO0FBQUEsTUFDakI7QUFBQSxNQUNBLG1CQUFtQixPQUFnQjtBQUNsQywwQkFBa0I7QUFBQSxNQUNuQjtBQUFBLE1BQ0EsZUFBZSxTQUE0QztBQUMxRCx3QkFBZ0I7QUFBQSxNQUNqQjtBQUFBLE1BQ0EsY0FBYztBQUNiLHlCQUFpQixLQUFLO0FBQUEsVUFDckIsWUFBWSxTQUFTLGNBQWMsS0FBSztBQUFBLFVBQ3hDLG1CQUFtQjtBQUFBLFVBQ25CLGdCQUFnQjtBQUFBLFFBQ2pCLENBQUM7QUFBQSxNQUNGO0FBQUEsSUFDRDtBQUFBLEVBQ0Q7QUFFQSxpQkFBZSw4QkFBOEIsTUFBNEQ7QUFDeEcsVUFBTSxRQUFRLEtBQUs7QUFDbkIsVUFBTSxTQUE2QixDQUFDO0FBQ3BDLGVBQVcsVUFBVSxNQUFNLFNBQVM7QUFDbkMsWUFBTSxNQUFNLFdBQVcsTUFBTTtBQUM3QixZQUFNLE9BQU8sTUFBTTtBQUNuQixhQUFPLEdBQUcsZ0JBQWdCLHdCQUF3QixzQ0FBc0MsT0FBTyxRQUFRLEVBQUU7QUFDekcsWUFBTSxPQUFPLEtBQUs7QUFDbEIsYUFBTyxHQUFHLE1BQU0seURBQXlELE9BQU8sUUFBUSxHQUFHO0FBQzNGLGFBQU8sS0FBSyxJQUFJO0FBQUEsSUFDakI7QUFDQSxXQUFPO0FBQUEsRUFDUjtBQUVBLFdBQVMsZ0JBQWdCLGVBQWlELGtCQUEwRjtBQUNuSyxRQUFJLE9BQU87QUFDWCxRQUFJLE9BQU87QUFDWCxlQUFXLE9BQU8sY0FBYyxzQkFBc0IsR0FBRztBQUN4RCxZQUFNLE9BQU8sY0FBYyxhQUFhLEdBQUc7QUFDM0MsYUFBTyxHQUFHLElBQUk7QUFDZCxjQUFRLEtBQUssVUFBVSxpQkFBaUIsZ0NBQWdDLEVBQUU7QUFDMUUsY0FBUSxLQUFLLFVBQVUsaUJBQWlCLDBCQUEwQixFQUFFO0FBQUEsSUFDckU7QUFDQSxVQUFNLGVBQWUsaUJBQWlCLFNBQVMsR0FBRyxXQUFXLGlCQUFpQixnQ0FBZ0MsRUFBRSxVQUFVO0FBQzFILFdBQU8sRUFBRSxNQUFNLE1BQU0sYUFBYTtBQUFBLEVBQ25DO0FBRUEsV0FBUyx3QkFBd0Isc0JBQThFO0FBQzlHLHlCQUFxQixLQUFLLDRCQUE0QixNQUFNLElBQUksSUFBSSwrQkFBK0IsQ0FBQyxDQUFDO0FBQ3JHLHlCQUFxQixLQUFLLG9DQUFvQztBQUFBLE1BQzdELGVBQWU7QUFBQSxNQUNmLGNBQWMsT0FBTyxFQUFFLFNBQVMsTUFBTTtBQUFBLE1BQUUsRUFBRTtBQUFBLE1BQzFDLFlBQVksTUFBTTtBQUFBLE1BQUU7QUFBQSxNQUNwQiwwQkFBMEIsTUFBTTtBQUFBLE1BQ2hDLHFCQUFxQixNQUFNO0FBQUEsTUFBRTtBQUFBLE1BQzdCLGtDQUFrQyxNQUFNO0FBQUEsTUFBRTtBQUFBLElBQzNDLENBQUM7QUFDRCx5QkFBcUIsS0FBSywrQkFBK0I7QUFBQSxNQUN4RCxlQUFlO0FBQUEsTUFDZixhQUFhLE1BQU07QUFBQSxNQUNuQix3QkFBd0IsTUFBTSxDQUFDO0FBQUEsSUFDaEMsQ0FBQztBQUNELHlCQUFxQixLQUFLLGtCQUFrQjtBQUFBLE1BQzNDLGVBQWU7QUFBQSxNQUNmLFFBQVEsWUFBWTtBQUFBLE1BQUU7QUFBQSxJQUN2QixDQUFnQztBQUNoQyx5QkFBcUIsS0FBSyxhQUFhO0FBQUEsTUFDdEMsZUFBZTtBQUFBLE1BQ2YsSUFBSSxlQUFlO0FBQUUsZUFBTyxDQUFDO0FBQUEsTUFBRztBQUFBLE1BQ2hDLElBQUksa0JBQWtCO0FBQUUsZUFBTztBQUFBLE1BQUc7QUFBQSxNQUNsQyxvQkFBb0IsTUFBTTtBQUFBLE1BQzFCLHVCQUF1QixNQUFNO0FBQUEsTUFDN0IscUJBQXFCLE1BQU07QUFBRSxjQUFNLElBQUksTUFBTSxpQkFBaUI7QUFBQSxNQUFHO0FBQUEsTUFDakUsZUFBZSxNQUFNO0FBQUEsSUFDdEIsQ0FBMkI7QUFBQSxFQUM1QjtBQUVBLGlCQUFlLHNCQUFzQjtBQUNwQyxXQUFPLDhCQUE4QixNQUFNLElBQUksSUFBSSxtQkFBbUIsQ0FBQyxHQUFHLHFDQUFxQyxDQUFDO0FBQUEsRUFDakg7QUFFQSxpQkFBZSw4QkFBaUUsZUFBa0IsWUFBc0MsU0FBUyxPQUFPO0FBQ3ZKLFVBQU0sYUFBd0IsQ0FBQztBQUMvQixVQUFNLHVCQUF1Qiw4QkFBOEI7QUFBQSxNQUMxRCxzQkFBc0IsTUFBTSxJQUFJLHlCQUF5QjtBQUFBLFFBQ3hELFdBQVcsRUFBRSxRQUFRLEVBQUUsZUFBZSxNQUFNLEVBQUU7QUFBQSxRQUM5QyxDQUFDLCtCQUErQixHQUFHO0FBQUEsTUFDcEMsQ0FBQztBQUFBLElBQ0YsR0FBRyxLQUFLO0FBQ1IseUJBQXFCLEtBQUssYUFBYTtBQUFBLE1BQ3RDLE9BQU8sQ0FBQyxVQUFtQjtBQUFFLG1CQUFXLEtBQUssS0FBSztBQUFBLE1BQUc7QUFBQSxNQUNyRCxNQUFNLE1BQU07QUFBQSxNQUFFO0FBQUEsTUFDZCxNQUFNLE1BQU07QUFBQSxNQUFFO0FBQUEsTUFDZCxPQUFPLE1BQU07QUFBQSxNQUFFO0FBQUEsTUFDZixPQUFPLE1BQU07QUFBQSxNQUFFO0FBQUEsTUFDZixPQUFPLE1BQU07QUFBQSxNQUFFO0FBQUEsTUFDZixVQUFVLE1BQU07QUFBQSxNQUNoQixVQUFVLE1BQU07QUFBQSxNQUFFO0FBQUEsTUFDbEIscUJBQXFCLE1BQU07QUFBQSxJQUM1QixDQUEyQjtBQUMzQix5QkFBcUIsS0FBSyw0QkFBNEIsYUFBYTtBQUNuRSx5QkFBcUIsS0FBSywwQkFBMEIsVUFBVTtBQUM5RCw0QkFBd0Isb0JBQW9CO0FBQzVDLHlDQUFxQyxvQkFBb0I7QUFDekQseUJBQXFCLGVBQWUsY0FBWSxTQUFTLEdBQTJCLGlCQUFpQixhQUFhLEVBQUUsTUFBTSxRQUFRLENBQUM7QUFFbkksVUFBTSxRQUFRLE1BQU0sa0JBQWtCLHNCQUFzQixXQUFXO0FBQ3ZFLFVBQU0sSUFBSSxLQUFLO0FBQ2YseUJBQXFCLEtBQUssc0JBQXNCLEtBQUs7QUFDckQsVUFBTSxnQkFBZ0IsWUFBWSxJQUFJLHFCQUFxQixlQUFlLGVBQWUsTUFBUyxDQUFDO0FBQ25HLHlCQUFxQixLQUFLLGdCQUFnQixhQUFhO0FBRXZELFVBQU0sbUJBQW1CLE1BQU0sSUFBSSxxQkFBcUIsZUFBZSxnQkFBZ0IsQ0FBQztBQUN4RixVQUFNLFNBQVMsU0FBUyxjQUFjLEtBQUs7QUFDM0MsYUFBUyxLQUFLLFlBQVksTUFBTTtBQUNoQyxVQUFNLElBQUksRUFBRSxTQUFTLE1BQU0sT0FBTyxPQUFPLEVBQUUsQ0FBQztBQUM1QyxxQkFBaUIsT0FBTyxNQUFNO0FBQzlCLHlCQUFxQixLQUFLLDBCQUEwQixnQkFBZ0I7QUFFcEUsVUFBTSxxQkFBcUIsWUFBWSxJQUFJLHFCQUFxQixlQUFlLDhCQUE4QixDQUFDO0FBQzlHLHlCQUFxQixLQUFLLGlDQUFpQyxrQkFBa0I7QUFDN0UsVUFBTSx1QkFBdUIsWUFBWSxJQUFJLHFCQUFxQixlQUFlLGdDQUFnQyxDQUFDO0FBQ2xILHlCQUFxQixLQUFLLG1DQUFtQyxvQkFBb0I7QUFDakYsVUFBTSxvQkFBb0IsWUFBWSxJQUFJLHFCQUFxQixlQUFlLDZCQUE2QixDQUFDO0FBQzVHLHlCQUFxQixLQUFLLGdDQUFnQyxpQkFBaUI7QUFFM0UsVUFBTSxJQUFJLHFCQUFxQixlQUFlLG1DQUFtQyxDQUFDO0FBQ2xGLFVBQU0sSUFBSSxxQkFBcUIsZUFBZSxrQ0FBa0MsQ0FBQztBQUVqRixVQUFNLFlBQVksY0FBYyxtQkFBbUI7QUFDbkQsVUFBTSxxQkFBcUIsb0JBQW9CLFNBQVM7QUFDeEQsVUFBTSxjQUFjLFFBQVEsT0FBTyxTQUFTO0FBQzVDLFFBQUksUUFBUTtBQUNYLFlBQU0sa0JBQWtCLGFBQWEsVUFBVTtBQUFBLElBQ2hELE9BQU87QUFDTixZQUFNLFlBQVksYUFBYSxZQUFZLEtBQUs7QUFBQSxJQUNqRDtBQUNBLGdCQUFZLEtBQUs7QUFDakIsaUJBQWEsS0FBSztBQUVsQixXQUFPLEVBQUUsc0JBQXNCLGVBQWUsT0FBTyxrQkFBa0IsZUFBZSxzQkFBc0Isb0JBQW9CLFdBQVcsV0FBVztBQUFBLEVBQ3ZKO0FBRUEsaUJBQWUsUUFBVyxTQUFxQixTQUE2QjtBQUMzRSxVQUFNLFNBQVMsTUFBTSxZQUFZLFFBQVEsS0FBSyxZQUFVLEVBQUUsTUFBTSxFQUFFLEdBQUcsR0FBSTtBQUN6RSxXQUFPLEdBQUcsUUFBUSxPQUFPO0FBQ3pCLFdBQU8sT0FBTztBQUFBLEVBQ2Y7QUFFQSxpQkFBZSxrQkFBa0IsTUFBK0IsYUFBaUMsQ0FBQyxHQUFvQztBQUNySSxRQUFJO0FBQ0gsWUFBTSxRQUFRLEtBQUssV0FBVyxvQ0FBb0M7QUFDbEUsVUFBSSxFQUFFLEtBQUssWUFBWSw0QkFBNEIseUJBQXlCO0FBQzNFLGNBQU0sUUFBUSxNQUFNLFVBQVUsTUFBTTtBQUFBLFVBQU8sS0FBSyxZQUFZO0FBQUEsVUFDM0QsTUFBTSxLQUFLLFlBQVksNEJBQTRCO0FBQUEsUUFBc0IsQ0FBQztBQUMzRSxZQUFJO0FBQ0gsZ0JBQU0sUUFBUSxPQUFPLDhDQUE4QztBQUFBLFFBQ3BFLFVBQUU7QUFDRCxnQkFBTSxPQUFPO0FBQUEsUUFDZDtBQUFBLE1BQ0Q7QUFDQSxZQUFNLE9BQU8sS0FBSyxZQUFZO0FBQzlCLGFBQU8sR0FBRyxnQkFBZ0Isc0JBQXNCO0FBQ2hELGFBQU87QUFBQSxJQUNSLFNBQVMsT0FBTztBQUNmLFVBQUk7QUFDSCxZQUFJLGlCQUFpQixPQUFPO0FBQzNCLGdCQUFNLGdCQUFnQixNQUFNO0FBQzVCLGdCQUFNLFFBQVEsS0FBSztBQUNuQixnQkFBTSxlQUFlLE1BQU07QUFDM0IsZ0JBQU0sYUFBYSxNQUFNO0FBQ3pCLGdCQUFNLGNBQWMsS0FBSyxVQUFVO0FBQUEsWUFDbEMsTUFBTSxFQUFFLFVBQVUsS0FBSyxVQUFVLFlBQVksS0FBSyxXQUFXO0FBQUEsWUFDN0QsU0FBUyxNQUFNO0FBQUEsWUFDZixzQkFBc0IsY0FBYyxVQUFVLFNBQVMsS0FBSztBQUFBLFlBQzVELGNBQWMsWUFBWSxNQUFNLEtBQUs7QUFBQSxZQUNyQyxvQ0FBb0Msc0JBQXNCO0FBQUEsWUFDMUQsWUFBWSxXQUFXLElBQUksZUFBYSxxQkFBcUIsUUFDMUQsRUFBRSxNQUFNLFVBQVUsTUFBTSxTQUFTLFVBQVUsU0FBUyxPQUFPLFVBQVUsU0FBUyxLQUFLLElBQ25GLEVBQUUsTUFBTSxPQUFPLFdBQVcsU0FBUyxPQUFPLFNBQVMsR0FBRyxPQUFPLEtBQUssQ0FBQztBQUFBLFVBQ3ZFLEdBQUcsTUFBTSxDQUFDO0FBQ1YsaUJBQU8sZUFBZSxPQUFPLFNBQVM7QUFBQSxZQUNyQyxPQUFPLEdBQUcsaUJBQWlCLEdBQUcsTUFBTSxJQUFJLEtBQUssTUFBTSxPQUFPLEVBQUU7QUFBQSxpQ0FBb0MsV0FBVztBQUFBLFVBQzVHLENBQUM7QUFBQSxRQUNGO0FBQUEsTUFDRCxRQUFRO0FBQUEsTUFFUjtBQUNBLFlBQU07QUFBQSxJQUNQO0FBQUEsRUFDRDtBQUVBLGlCQUFlLDBCQUEwQixZQUFnRTtBQUV4RyxVQUFNLFdBQW1GLENBQUM7QUFDMUYsVUFBTSxjQUErQixDQUFDO0FBQ3RDLFFBQUksUUFBeUIsRUFBRSxNQUFNLGVBQWU7QUFDcEQsUUFBSSxpQkFBaUI7QUFDckIsVUFBTSxvQkFBb0IsTUFBTSxJQUFJLElBQUksUUFBdUUsQ0FBQztBQUNoSCxVQUFNLE9BQU8scUNBQXFDO0FBQ2xELFVBQU0sYUFBYSxxQ0FBcUM7QUFBQSxNQUN2RCxtQkFBbUIsTUFBTSx5QkFBeUIsT0FBTyxjQUFjO0FBQUEsTUFDdkUsb0JBQW9CLE1BQU07QUFBQSxNQUMxQixtQkFBbUIsTUFBTTtBQUFBLE1BQ3pCLHVCQUF1QixPQUFPLEVBQUUsR0FBRyxLQUFLLHNCQUFzQixHQUFHLFdBQVcsTUFBTSxjQUFjLE1BQU0sU0FBUyxnQkFBZ0IsZ0JBQWdCLGtCQUFrQixpQkFBaUIsUUFBUSxFQUFFO0FBQUEsTUFDNUwsdUJBQXVCLGtCQUFrQjtBQUFBLE1BQ3pDLGNBQWMsTUFBTTtBQUNuQixjQUFNLFVBQVUsU0FBUyxNQUFNO0FBQy9CLGVBQU8sR0FBRyxTQUFTLDJEQUEyRDtBQUM5RSxhQUFLLFFBQVEsUUFBUSxTQUFTO0FBQzlCLGVBQU8sUUFBUSxPQUFPO0FBQUEsTUFDdkI7QUFBQSxJQUNELENBQUM7QUFDRCxVQUFNLGNBQWMsTUFBTSxJQUFJLElBQUksd0JBQXdCLENBQUM7QUFDM0QsVUFBTSxnQkFBZ0IsTUFBTSxJQUFJLElBQUksZ0NBQWdDLFlBQVksYUFBYSxFQUFFLGVBQWUsUUFBVyxpQkFBaUIsTUFBTSxLQUFLLENBQUMsQ0FBQztBQUV2SixVQUFNLElBQUksYUFBYSxNQUFNO0FBQzVCLGlCQUFXLFdBQVcsYUFBYTtBQUNsQyxZQUFJLENBQUMsUUFBUSxPQUFPLFdBQVc7QUFDOUIsZUFBSyxRQUFRLE9BQU8sU0FBUyxFQUFFLFVBQVUsQ0FBQyxFQUFFLENBQUM7QUFBQSxRQUM5QztBQUFBLE1BQ0Q7QUFBQSxJQUNELENBQUMsQ0FBQztBQUNGLFVBQU0sZUFBZSxNQUFNO0FBQzFCLFlBQU0sVUFBVSxFQUFFLFNBQVMsSUFBSSxnQkFBc0IsR0FBRyxRQUFRLElBQUksZ0JBQXlCLEVBQUU7QUFDL0YsZUFBUyxLQUFLLE9BQU87QUFDckIsa0JBQVksS0FBSyxPQUFPO0FBQ3hCLGFBQU87QUFBQSxJQUNSO0FBQ0EsVUFBTSxTQUFTLENBQUMsU0FBK0U7QUFDOUYsdUJBQWlCLFNBQVMsdUJBQXVCLFNBQVM7QUFDMUQsY0FBUSxTQUFTLGlCQUFpQixFQUFFLE1BQU0sZUFBZSxJQUN0RCxTQUFTLHVCQUF1QixFQUFFLE1BQU0sY0FBYyxRQUFRLFVBQVUsSUFDdkUsRUFBRSxNQUFNLGFBQWEsTUFBTSxXQUFXO0FBQzFDLHdCQUFrQixLQUFLLFdBQVcsc0JBQXNCLENBQUM7QUFBQSxJQUMxRDtBQUNBLFVBQU0sVUFBbUIsRUFBRSxVQUFVLENBQUMsRUFBRSxXQUFXLFlBQVksT0FBTyxXQUFXLEdBQUcsRUFBRSxXQUFXLFlBQVksT0FBTyxXQUFXLENBQUMsRUFBRTtBQUNsSSxVQUFNLFVBQVUsYUFBYTtBQUM3QixXQUFPLE1BQU07QUFDYixVQUFNLFFBQVEsUUFBUSxRQUFRLEdBQUcsaUNBQWlDO0FBQ2xFLFVBQU0sUUFBUSxPQUFPLFNBQVMsT0FBTztBQUNyQyxVQUFNLFFBQVEsY0FBYyxpQ0FBaUMsR0FBRyxrQ0FBa0M7QUFDbEcsV0FBTyxZQUFZLGdDQUFnQyxhQUFhLEdBQUcsT0FBTztBQUMxRSxpQkFBYSxhQUFhO0FBQzFCLFVBQU0sVUFBVSxNQUFNLDhCQUE4QixlQUFlLFlBQVksSUFBSTtBQUNuRixVQUFNLE9BQU8sTUFBTSxrQkFBa0IsUUFBUSxRQUFRLE9BQU8sUUFBUSxTQUFTLEdBQUcsUUFBUSxVQUFVO0FBQ2xHLFVBQU0sT0FBTyxLQUFLO0FBQ2xCLFdBQU8sR0FBRyxJQUFJO0FBQ2QsV0FBTyxHQUFHLEtBQUssa0JBQWtCLDhDQUE4QztBQUMvRSxRQUFJLEtBQUssaUJBQWlCLFNBQVMsY0FBYyxRQUFRLFdBQVc7QUFDbkUsWUFBTSxXQUFXLE1BQU0sVUFBVSxLQUFLLGlCQUFpQixlQUFlO0FBQ3RFLFVBQUk7QUFDSCxjQUFNLFFBQVEsVUFBVSxpREFBaUQ7QUFBQSxNQUMxRSxVQUFFO0FBQ0QsaUJBQVMsT0FBTztBQUFBLE1BQ2pCO0FBQUEsSUFDRDtBQUNBLFdBQU8sWUFBWSxLQUFLLGlCQUFpQixTQUFTLFdBQVcsUUFBUSxTQUFTO0FBQzlFLFdBQU8sRUFBRSxHQUFHLFNBQVMsTUFBTSxNQUFNLFlBQVksYUFBYSxjQUFjLFFBQVEsUUFBUTtBQUFBLEVBQ3pGO0FBSUEsV0FBUyxxQkFBcUIsU0FBOEIsT0FBTyxRQUFRLE1BQU0sTUFBTSxRQUFRLFdBQTZCO0FBQzNILFVBQU0sT0FBTyxLQUFLO0FBQ2xCLFdBQU8sR0FBRyxJQUFJO0FBQ2QsV0FBTyxZQUFZLEtBQUssZ0JBQWdCLEdBQUc7QUFDM0MsV0FBTyxZQUFZLEtBQUssWUFBWSxLQUFLO0FBQ3pDLFdBQU8sWUFBWSxRQUFRLHFCQUFxQix1QkFBdUIsR0FBRyxHQUFHLElBQUk7QUFDakYsV0FBTyxZQUFZLEtBQUssNkJBQTZCLEtBQUs7QUFDMUQsV0FBTyxZQUFZLEtBQUssa0JBQWtCLFFBQVcscUVBQXFFO0FBQzFILFdBQU87QUFBQSxFQUNSO0FBRUEsaUJBQWUseUJBQXlCLFNBQThCLFlBQVksT0FBTztBQUN4RixVQUFNLFVBQVUsUUFBUSxhQUFhO0FBQ3JDLFFBQUksV0FBVztBQUNkLGNBQVEsT0FBTyxjQUFjO0FBQUEsSUFDOUI7QUFDQSxZQUFRLE9BQU8sTUFBTTtBQUNyQixVQUFNLFFBQVEsUUFBUSxRQUFRLEdBQUcsMENBQTBDO0FBQzNFLFdBQU8sWUFBWSxnQ0FBZ0MsUUFBUSxhQUFhLEdBQUcsU0FBUztBQUNwRixXQUFPLFlBQVksUUFBUSxLQUFLLHdCQUF3QixRQUFRLElBQUk7QUFDcEUseUJBQXFCLE9BQU87QUFDNUIsV0FBTztBQUFBLEVBQ1I7QUFFQSxpQkFBZSxnQkFBZ0IsU0FBOEIsU0FBeUU7QUFDckksVUFBTSxRQUFRLE9BQU8sU0FBUyxRQUFRLE9BQU87QUFDN0MsVUFBTSxRQUFRLFFBQVEsY0FBYyxpQ0FBaUMsR0FBRywwQkFBMEI7QUFDbEcsV0FBTyxZQUFZLGdDQUFnQyxRQUFRLGFBQWEsR0FBRyxPQUFPO0FBQUEsRUFDbkY7QUFFQSxXQUFTLGlCQUFpQixNQUFzQztBQUMvRCxRQUFJLFFBQVE7QUFDWixVQUFNLFdBQVcsS0FBSztBQUN0QixTQUFLLGtCQUFrQixlQUFhO0FBQ25DO0FBQ0EsZUFBUyxLQUFLLE1BQU0sU0FBUztBQUFBLElBQzlCO0FBQ0EsVUFBTSxJQUFJLGFBQWEsTUFBTTtBQUFFLFdBQUssa0JBQWtCO0FBQUEsSUFBVSxDQUFDLENBQUM7QUFDbEUsV0FBTyxNQUFNO0FBQUEsRUFDZDtBQUVBLGlCQUFlLHdCQUF3QixTQUE4QixNQUE4QixXQUFtQixNQUE2QjtBQUNsSixVQUFNLE9BQU8sS0FBSztBQUNsQixXQUFPLEdBQUcsSUFBSTtBQUNkLFVBQU0sUUFBUSxLQUFLO0FBQ25CLFdBQU8sR0FBRyxPQUFPLCtDQUErQztBQUNoRSxXQUFPLFlBQVksTUFBTSxXQUFXLFNBQVM7QUFDN0MsUUFBSSxDQUFDLFFBQVEsWUFBWSxtQkFBbUIsU0FBUyxHQUFHO0FBQ3ZELFlBQU0sWUFBWSxNQUFNLFVBQVUsTUFBTSxPQUFPLFFBQVEsWUFBWSxhQUFhLE1BQU0sUUFBUSxZQUFZLG1CQUFtQixTQUFTLENBQUMsQ0FBQztBQUN4SSxVQUFJO0FBQ0gsY0FBTSxRQUFRLFdBQVcsNERBQTREO0FBQUEsTUFDdEYsVUFBRTtBQUNELGtCQUFVLE9BQU87QUFBQSxNQUNsQjtBQUFBLElBQ0Q7QUFDQSxVQUFNLFNBQVMsS0FBSyxpQkFBaUI7QUFDckMsV0FBTyxHQUFHLE1BQU07QUFDaEIsVUFBTSxVQUFVLElBQUksZ0JBQXNCO0FBQzFDLFVBQU0sUUFBUSxNQUFNO0FBQ25CLFlBQU0sT0FBTyxPQUFPLGNBQWMseUNBQXlDLFNBQVMsc0NBQXNDO0FBQzFILFlBQU0sVUFBVSxPQUFPLGNBQWMsc0RBQXNELFNBQVMsZUFBZTtBQUNuSCxVQUFJLE1BQU0sZ0JBQWdCLFFBQVEsU0FBUyxhQUFhLFNBQVMsa0JBQWtCLFNBQVMsRUFBRSxHQUFHO0FBQ2hHLGFBQUssUUFBUSxTQUFTO0FBQUEsTUFDdkI7QUFBQSxJQUNEO0FBQ0EsVUFBTSxXQUFXLElBQUksaUJBQWlCLEtBQUs7QUFDM0MsYUFBUyxRQUFRLFFBQVEsRUFBRSxXQUFXLE1BQU0sZUFBZSxNQUFNLFNBQVMsS0FBSyxDQUFDO0FBQ2hGLFVBQU0sV0FBVyxNQUFNLFVBQVUsTUFBTSxlQUFlO0FBQ3RELFFBQUk7QUFDSCxjQUFRLFlBQVksWUFBWSxXQUFXLElBQUk7QUFDL0MsWUFBTSxRQUFRLFVBQVUsaURBQWlEO0FBQ3pFLFdBQUssT0FBTyxFQUFFLE9BQU8sS0FBSyxRQUFRLElBQUksQ0FBQztBQUN2QyxZQUFNO0FBQ04sWUFBTSxRQUFRLFFBQVEsR0FBRyxtRUFBbUU7QUFDNUYsYUFBTyxZQUFZLEtBQUssa0JBQWtCLEtBQUs7QUFDL0MsYUFBTyxZQUFZLE1BQU0sU0FBUyxTQUFTLFFBQVEsQ0FBQztBQUNwRCxhQUFPLFlBQVksTUFBTSxTQUFTLGVBQWUsUUFBUSxDQUFDO0FBQUEsSUFDM0QsVUFBRTtBQUNELGVBQVMsV0FBVztBQUNwQixlQUFTLE9BQU87QUFBQSxJQUNqQjtBQUFBLEVBQ0Q7QUFFQSxpQkFBZSxtQkFDZCxTQUNBLFlBQ2tDO0FBQ2xDLFdBQU8sWUFBWSxRQUFRLFFBQVEsT0FBTyxVQUFVLEdBQUcsUUFBUSxZQUFZLFFBQVEsS0FBSztBQUFBLEVBQ3pGO0FBRUEsUUFBTSxpQ0FBaUMsTUFBTTtBQUM1QyxTQUFLLHNHQUFzRyxZQUFZO0FBQ3RILFlBQU0sVUFBVSxNQUFNLDBCQUEwQjtBQUNoRCxZQUFNLEVBQUUsTUFBTSxNQUFNLFdBQVcsY0FBYyxJQUFJO0FBQ2pELFlBQU0sUUFBUSxLQUFLO0FBQ25CLGFBQU8sR0FBRyxLQUFLO0FBQ2YsYUFBTyxZQUFZLEtBQUssb0JBQW9CLFFBQVEsQ0FBQztBQUNyRCxhQUFPLFlBQVksS0FBSyxrQkFBa0IsU0FBUyxTQUFTLFFBQVEsQ0FBQztBQUNyRSxZQUFNLFVBQVUsTUFBTSx5QkFBeUIsU0FBUyxJQUFJO0FBQzVELGFBQU8sWUFBWSxLQUFLLE9BQU8sS0FBSztBQUNwQyxVQUFJLGdCQUFnQjtBQUNwQixZQUFNLGlCQUFpQixNQUFNLElBQUksY0FBYyx5QkFBeUIsTUFBTTtBQUFFO0FBQUEsTUFBaUIsQ0FBQyxDQUFDO0FBQ25HLFlBQU0sZ0JBQWdCLFNBQVMsT0FBTztBQUN0QyxhQUFPLFlBQVksY0FBYyxtQkFBbUIsR0FBRyxTQUFTO0FBQ2hFLGFBQU8sWUFBWSxlQUFlLEdBQUcsMkRBQTJEO0FBQ2hHLGFBQU8sWUFBWSxLQUFLLE9BQU8sS0FBSztBQUNwQyxhQUFPLFlBQVksS0FBSyx3QkFBd0IsSUFBSTtBQUNwRCxhQUFPLFlBQVksS0FBSyxnQkFBZ0IsU0FBUztBQUNqRCxhQUFPLFlBQVksS0FBSyxZQUFZLEtBQUs7QUFDekMsYUFBTyxZQUFZLHlCQUF5QixRQUFRLFdBQVcsbUJBQW1CLEdBQUcsUUFBUSxXQUFXLHNCQUFzQixFQUFFLGNBQWMsR0FBRyxJQUFJO0FBQ3JKLGFBQU8sWUFBWSwwQkFBMEIsUUFBUSxVQUFVLEdBQUcsS0FBSztBQUN2RSxhQUFPLEdBQUcsS0FBSyxrQkFBa0Isd0VBQXdFO0FBQ3pHLGFBQU8sWUFBWSxLQUFLLGlCQUFpQixXQUFXLFNBQVM7QUFDN0QscUJBQWUsUUFBUTtBQUN2QixZQUFNLHdCQUF3QixTQUFTLE1BQU0sV0FBVyx3QkFBd0I7QUFBQSxJQUNqRixDQUFDO0FBRUQsU0FBSyx1SEFBdUgsWUFBWTtBQUN2SSxZQUFNLFVBQVUsTUFBTSwwQkFBMEI7QUFDaEQsWUFBTSx3QkFBd0IsU0FBUyxRQUFRLE1BQU0sUUFBUSxXQUFXLG1CQUFtQjtBQUMzRixZQUFNLFFBQVEsUUFBUSxLQUFLO0FBQzNCLGFBQU8sR0FBRyxLQUFLO0FBQ2YsWUFBTSxXQUFXLE1BQU07QUFDdkIsWUFBTSxVQUFVLFFBQVEsS0FBSztBQUM3QixZQUFNLFFBQVEsUUFBUSxLQUFLO0FBQzNCLFlBQU0sYUFBYSxNQUFNO0FBQ3hCLGVBQU8sWUFBWSxRQUFRLEtBQUssT0FBTyxLQUFLO0FBQzVDLGVBQU8sWUFBWSxRQUFRLEtBQUssd0JBQXdCLFFBQVEsSUFBSTtBQUNwRSxlQUFPLFlBQVksUUFBUSxXQUFXLHNCQUFzQixFQUFFLGtCQUFrQixlQUFlO0FBQy9GLGVBQU8sWUFBWSx5QkFBeUIsUUFBUSxXQUFXLG1CQUFtQixHQUFHLFFBQVEsV0FBVyxzQkFBc0IsRUFBRSxjQUFjLEdBQUcsSUFBSTtBQUNySixlQUFPLFlBQVksMEJBQTBCLFFBQVEsVUFBVSxHQUFHLEtBQUs7QUFDdkUsZUFBTyxZQUFZLFFBQVEsY0FBYyxtQkFBbUIsR0FBRyxRQUFRLFNBQVM7QUFDaEYsZUFBTyxZQUFZLFFBQVEsS0FBSyxnQkFBZ0IsUUFBUSxTQUFTO0FBQ2pFLGVBQU8sWUFBWSxRQUFRLEtBQUssa0JBQWtCLEtBQUs7QUFDdkQsZUFBTyxZQUFZLE1BQU0sVUFBVSxRQUFRO0FBQzNDLGVBQU8sWUFBWSxRQUFRLEtBQUsscUJBQXFCLE9BQU87QUFDNUQsZUFBTyxZQUFZLFFBQVEsS0FBSyxpQkFBaUIsR0FBRyxjQUFjLHlDQUF5QyxRQUFRLFNBQVMsc0NBQXNDLEdBQUcsYUFBYSxtQkFBbUI7QUFBQSxNQUN0TTtBQUNBLFlBQU0sU0FBUyxRQUFRLGFBQWE7QUFDcEMsY0FBUSxPQUFPLE1BQU07QUFDckIsWUFBTSxRQUFRLE9BQU8sUUFBUSxHQUFHLHNDQUFzQztBQUN0RSxhQUFPLFlBQVksZ0NBQWdDLFFBQVEsYUFBYSxHQUFHLFNBQVM7QUFDcEYsaUJBQVc7QUFDWCxZQUFNLE9BQU8sT0FBTyxNQUFNLElBQUksTUFBTSxxQkFBcUIsQ0FBQztBQUMxRCxZQUFNLFFBQVEsUUFBUSxjQUFjLGlDQUFpQyxHQUFHLDhCQUE4QjtBQUN0RyxhQUFPLFlBQVksZ0NBQWdDLFFBQVEsYUFBYSxHQUFHLGFBQWE7QUFDeEYsaUJBQVc7QUFDWCxZQUFNLFlBQVksUUFBUSxhQUFhO0FBQ3ZDLGNBQVEsT0FBTyxNQUFNO0FBQ3JCLFlBQU0sUUFBUSxVQUFVLFFBQVEsR0FBRyxvQ0FBb0M7QUFDdkUsaUJBQVc7QUFDWCxZQUFNLGdCQUFnQixTQUFTLFNBQVM7QUFDeEMsaUJBQVc7QUFBQSxJQUNaLENBQUM7QUFFRCxTQUFLLGlHQUFpRyxZQUFZO0FBQ2pILFlBQU0sVUFBVSxNQUFNLDBCQUEwQjtBQUNoRCxZQUFNLFNBQVMsTUFBTSx5QkFBeUIsT0FBTztBQUNyRCxZQUFNLFFBQVEsaUJBQWlCLFFBQVEsSUFBSTtBQUMzQywyQkFBcUIsT0FBTztBQUM1QixZQUFNLE9BQU8sT0FBTyxNQUFNLElBQUksTUFBTSx1QkFBdUIsQ0FBQztBQUM1RCxZQUFNLFFBQVEsUUFBUSxjQUFjLGlDQUFpQyxHQUFHLGdDQUFnQztBQUN4RyxhQUFPLFlBQVksZ0NBQWdDLFFBQVEsYUFBYSxHQUFHLGFBQWE7QUFDeEYsMkJBQXFCLE9BQU87QUFDNUIsYUFBTyxZQUFZLE1BQU0sR0FBRyxDQUFDO0FBQzdCLFlBQU0sV0FBVyxNQUFNLHlCQUF5QixPQUFPO0FBQ3ZELFlBQU0sY0FBYyxNQUFNO0FBQzFCLFlBQU0sZ0JBQWdCLFNBQVMsUUFBUTtBQUN2QyxhQUFPLFlBQVksTUFBTSxJQUFJLGFBQWEsR0FBRyw4REFBOEQ7QUFDM0csWUFBTSx3QkFBd0IsU0FBUyxRQUFRLE1BQU0sUUFBUSxXQUFXLHFCQUFxQjtBQUFBLElBQzlGLENBQUM7QUFFRCxlQUFXLFNBQVMsQ0FBQyxnQkFBZ0IscUJBQXFCLG9CQUFvQixHQUFZO0FBQ3pGLFdBQUssTUFBTSxLQUFLLCtFQUErRSxZQUFZO0FBQzFHLFlBQUk7QUFDSixZQUFJLFFBQVE7QUFDWixZQUFJO0FBQ0osY0FBTSxRQUFrQixDQUFDO0FBQ3pCLGNBQU0sVUFBVSxDQUFDLGFBQWlDO0FBQ2pELGlCQUFPLEdBQUcsT0FBTztBQUNqQixpQkFBTyxHQUFHLEtBQUs7QUFDZixnQkFBTSxPQUFPLFFBQVEsS0FBSztBQUMxQixpQkFBTyxHQUFHLElBQUk7QUFDZCxpQkFBTztBQUFBLFlBQ047QUFBQSxZQUFVLE1BQU0sUUFBUTtBQUFBLFlBQU0sT0FBTyxRQUFRLEtBQUs7QUFBQSxZQUFPO0FBQUEsWUFDekQsT0FBTyxLQUFLO0FBQUEsWUFBZ0IsU0FBUyxRQUFRLHFCQUFxQix1QkFBdUIsUUFBUSxTQUFTO0FBQUEsWUFDMUcsV0FBVyxLQUFLO0FBQUEsWUFBNkIsVUFBVSxLQUFLO0FBQUEsWUFBWSxPQUFPLEtBQUs7QUFBQSxZQUNwRixPQUFPLFFBQVEsV0FBVyxtQkFBbUIsRUFBRTtBQUFBLFlBQU0sU0FBUyxRQUFRLFdBQVcsc0JBQXNCLEVBQUU7QUFBQSxZQUN6RyxXQUFXLFFBQVEsY0FBYyxrQkFBa0I7QUFBQSxZQUFHLFdBQVcsZ0NBQWdDLFFBQVEsYUFBYTtBQUFBLFlBQ3RILE9BQU8sUUFBUSxjQUFjLHFCQUFxQixRQUFRLFNBQVMsRUFBRTtBQUFBLFlBQVcsV0FBVyxNQUFNO0FBQUEsVUFDbEc7QUFBQSxRQUNEO0FBQ0EsY0FBTSxVQUF3QyxDQUFDO0FBQy9DLGtCQUFVLE1BQU0sMEJBQTBCLFlBQVU7QUFDbkQsZ0JBQU0sSUFBSSxPQUFPLG1CQUFtQixRQUFNO0FBQ3pDLGdCQUFJLFNBQVMsT0FBTyxjQUFjLFFBQVEsV0FBVyxLQUFLLE9BQU8scUJBQXFCLEVBQUUsRUFBRSxjQUFjLFNBQVM7QUFDaEgsb0JBQU0sS0FBSyxnQkFBZ0I7QUFDM0Isc0JBQVEsS0FBSyxRQUFRLFFBQVEsQ0FBQztBQUFBLFlBQy9CO0FBQUEsVUFDRCxDQUFDLENBQUM7QUFBQSxRQUNILENBQUM7QUFDRCxjQUFNLFVBQVU7QUFDaEIsZ0JBQVEsaUJBQWlCLFFBQVEsSUFBSTtBQUNyQyxjQUFNLElBQUksUUFBUSxjQUFjLG1CQUFtQixRQUFNO0FBQ3hELGNBQUksU0FBUyxPQUFPLFFBQVEsYUFBYSxRQUFRLFdBQVcsR0FBRztBQUM5RCxrQkFBTSxLQUFLLGVBQWU7QUFDMUIsb0JBQVEsS0FBSyxRQUFRLE9BQU8sQ0FBQztBQUFBLFVBQzlCO0FBQUEsUUFDRCxDQUFDLENBQUM7QUFDRixjQUFNLFVBQVUsTUFBTSx5QkFBeUIsT0FBTztBQUN0RCxlQUFPLFlBQVksUUFBUSxjQUFjLHFCQUFxQixRQUFRLFNBQVMsRUFBRSxXQUFXLGFBQWE7QUFDekcsY0FBTSxjQUFjLE1BQU07QUFDMUIsY0FBTSxRQUFRLFFBQVEsS0FBSztBQUMzQixnQkFBUTtBQUNSLGNBQU0sS0FBSyxVQUFVO0FBQ3JCLGdCQUFRLE9BQU8sS0FBSztBQUNwQixjQUFNLEtBQUssV0FBVztBQUN0QixnQkFBUTtBQUNSLGVBQU8sZ0JBQWdCLE9BQU8sQ0FBQyxZQUFZLGtCQUFrQixpQkFBaUIsV0FBVyxHQUFHLGdFQUFnRTtBQUM1SixlQUFPLFlBQVksUUFBUSxRQUFRLENBQUM7QUFDcEMsbUJBQVcsVUFBVSxTQUFTO0FBQzdCLGlCQUFPLFlBQVksT0FBTyxNQUFNLFFBQVEsSUFBSTtBQUM1QyxpQkFBTyxZQUFZLE9BQU8sT0FBTyxLQUFLO0FBQ3RDLGlCQUFPLFlBQVksT0FBTyxNQUFNLFFBQVEsSUFBSTtBQUM1QyxpQkFBTyxZQUFZLE9BQU8sT0FBTyxRQUFRLFNBQVM7QUFDbEQsaUJBQU8sWUFBWSxPQUFPLFNBQVMsSUFBSTtBQUN2QyxpQkFBTyxZQUFZLE9BQU8sV0FBVyxLQUFLO0FBQzFDLGlCQUFPLFlBQVksT0FBTyxVQUFVLEtBQUs7QUFDekMsaUJBQU8sWUFBWSxPQUFPLE9BQU8sTUFBUztBQUMxQyxpQkFBTyxZQUFZLE9BQU8sT0FBTyxVQUFVLGlCQUFpQixpQkFBaUIsVUFBVSx1QkFBdUIsZUFBZSxXQUFXO0FBQ3hJLGlCQUFPLFlBQVksT0FBTyxTQUFTLFVBQVUsY0FBYztBQUMzRCxpQkFBTyxZQUFZLE9BQU8sV0FBVyxLQUFLO0FBQzFDLGlCQUFPLFlBQVksT0FBTyxXQUFXLE9BQU87QUFDNUMsaUJBQU8sWUFBWSxPQUFPLE9BQU8sT0FBTztBQUN4QyxpQkFBTyxZQUFZLE9BQU8sV0FBVyxhQUFhLGlFQUFpRTtBQUFBLFFBQ3BIO0FBRUEsY0FBTSxRQUFRLE9BQU8sU0FBUyxRQUFRLE9BQU87QUFDN0MsY0FBTSxRQUFRLFFBQVEsY0FBYyxpQ0FBaUMsR0FBRyxrQ0FBa0M7QUFDMUcsY0FBTSxXQUFXLE1BQU0seUJBQXlCLE9BQU87QUFDdkQsY0FBTSxnQkFBZ0IsU0FBUyxRQUFRO0FBQ3ZDLGNBQU0sd0JBQXdCLFNBQVMsUUFBUSxNQUFNLFFBQVEsV0FBVyxNQUFNLEtBQUssV0FBVztBQUFBLE1BQy9GLENBQUM7QUFBQSxJQUNGO0FBRUEsU0FBSyxrR0FBa0csWUFBWTtBQUNsSCxZQUFNLFVBQVUsTUFBTSwwQkFBMEI7QUFDaEQsWUFBTSxRQUFRLHFCQUFxQixrQkFBa0IsVUFBVTtBQUMvRCxZQUFNLE9BQU8sTUFBTSxrQkFBa0IsUUFBUSxRQUFRLE9BQU8sVUFBVSxDQUFDO0FBQ3ZFLG1CQUFhLFFBQVEsS0FBSztBQUMxQixZQUFNLE9BQU8sS0FBSztBQUNsQixhQUFPLEdBQUcsTUFBTSxnQkFBZ0I7QUFDaEMsY0FBUSxxQkFBcUIsa0JBQWtCLFVBQVU7QUFDekQsYUFBTyxZQUFZLEtBQUssNkJBQTZCLElBQUk7QUFDekQsYUFBTyxZQUFZLEtBQUssa0JBQWtCLE1BQVM7QUFDbkQsWUFBTSxRQUFRLGlCQUFpQixJQUFJO0FBQ25DLFlBQU0sU0FBUyxRQUFRLGFBQWE7QUFDcEMsY0FBUSxPQUFPLE1BQU07QUFDckIsWUFBTSxRQUFRLE9BQU8sUUFBUSxHQUFHLHFDQUFxQztBQUNyRSxZQUFNLE9BQU8sT0FBTyxNQUFNLElBQUksTUFBTSx3QkFBd0IsQ0FBQztBQUM3RCxZQUFNLFFBQVEsUUFBUSxjQUFjLGlDQUFpQyxHQUFHLDRCQUE0QjtBQUNwRyxhQUFPLFlBQVksS0FBSyxrQkFBa0IsTUFBUztBQUNuRCxhQUFPLFlBQVksTUFBTSxHQUFHLENBQUM7QUFDN0IsWUFBTSxRQUFRLFFBQVEsYUFBYTtBQUNuQyxjQUFRLE9BQU8sTUFBTTtBQUNyQixZQUFNLFFBQVEsTUFBTSxRQUFRLEdBQUcsaUNBQWlDO0FBQ2hFLFlBQU0sZ0JBQWdCLFNBQVMsS0FBSztBQUNwQyxhQUFPLFlBQVksUUFBUSxxQkFBcUIsdUJBQXVCLFVBQVUsR0FBRyxLQUFLO0FBQ3pGLGFBQU8sWUFBWSxLQUFLLDZCQUE2QixJQUFJO0FBQ3pELGFBQU8sWUFBWSxLQUFLLGtCQUFrQixNQUFTO0FBQ25ELGFBQU8sWUFBWSxNQUFNLEdBQUcsQ0FBQztBQUM3QixjQUFRLHFCQUFxQixxQkFBcUIsVUFBVTtBQUM1RCxhQUFPLFlBQVksS0FBSyw2QkFBNkIsS0FBSztBQUMxRCxZQUFNLGVBQWUsS0FBSztBQUMxQixhQUFPLEdBQUcsWUFBWTtBQUN0QixhQUFPLFlBQVksY0FBYyxJQUFJO0FBQ3JDLGFBQU8sWUFBWSxhQUFhLGtCQUFrQixXQUFXLFVBQVU7QUFDdkUsWUFBTSx3QkFBd0IsU0FBUyxNQUFNLFlBQVksbUJBQW1CO0FBQzVFLFlBQU0sZUFBZSxhQUFhO0FBQ2xDLGFBQU8sR0FBRyxZQUFZO0FBQ3RCLFlBQU0sbUJBQW1CLE1BQU0sSUFBSSxRQUFRLGNBQWMsbUJBQW1CLFVBQVUsQ0FBQztBQUN2RixhQUFPLGVBQWUsa0JBQWtCLFlBQVk7QUFDcEQsWUFBTSxZQUFZLFFBQVEsWUFBWSxTQUFTLEtBQUssV0FBUyxNQUFNLGNBQWMsY0FBYyxDQUFDLFFBQVEsWUFBWSxTQUFTLElBQUksTUFBTSxPQUFPLENBQUM7QUFDL0ksYUFBTyxHQUFHLFdBQVcscUVBQXFFO0FBQzFGLFVBQUksZ0JBQWdCO0FBQ3BCLFlBQU0sSUFBSSxhQUFhLGdCQUFnQixNQUFNO0FBQUU7QUFBQSxNQUFpQixDQUFDLENBQUM7QUFDbEUsWUFBTSxVQUFVLFFBQVEsYUFBYTtBQUNyQyxjQUFRLE9BQU8sTUFBTTtBQUNyQixZQUFNLFFBQVEsUUFBUSxRQUFRLEdBQUcsbUNBQW1DO0FBQ3BFLFlBQU0sbUJBQW1CLEVBQUUsVUFBVSxRQUFRLFFBQVEsU0FBUyxPQUFPLGFBQVcsUUFBUSxjQUFjLFVBQVUsRUFBRTtBQUNsSCxZQUFNLFFBQVEsT0FBTyxTQUFTLGdCQUFnQjtBQUM5QyxZQUFNLFFBQVEsUUFBUSxjQUFjLGlDQUFpQyxHQUFHLDBCQUEwQjtBQUNsRyxhQUFPLFlBQVksUUFBUSxxQkFBcUIsYUFBYSxVQUFVLEdBQUcsTUFBUztBQUNuRixhQUFPLFlBQVksUUFBUSxxQkFBcUIsc0JBQXNCLFVBQVUsR0FBRyxLQUFLO0FBQ3hGLGFBQU8sWUFBWSxRQUFRLHFCQUFxQix1QkFBdUIsVUFBVSxHQUFHLEtBQUs7QUFDekYsYUFBTyxZQUFZLEtBQUssWUFBWSxJQUFJO0FBQ3hDLFlBQU0sa0JBQWtCLGFBQWE7QUFDckMsWUFBTSxxQkFBcUI7QUFDM0IsWUFBTSxXQUFXLE1BQU0sVUFBVSxpQkFBaUIsZUFBZTtBQUNqRSxVQUFJO0FBQ0gsZ0JBQVEsWUFBWSxZQUFZLFlBQVksMkJBQTJCO0FBQ3ZFLGNBQU0sUUFBUSxVQUFVLGlFQUFpRTtBQUN6RixlQUFPLGVBQWUsaUJBQWlCLFVBQVUsZUFBZTtBQUNoRSxlQUFPLFlBQVksYUFBYSxVQUFVLGlCQUFpQixzRUFBc0U7QUFDakksZUFBTyxZQUFZLGVBQWUsa0JBQWtCO0FBQUEsTUFDckQsVUFBRTtBQUNELGlCQUFTLE9BQU87QUFDaEIseUJBQWlCLFFBQVE7QUFBQSxNQUMxQjtBQUNBLGFBQU8sWUFBWSxRQUFRLFlBQVksU0FBUyxJQUFJLFVBQVUsT0FBTyxHQUFHLE1BQU0sc0dBQXNHO0FBQ3BMLFlBQU0sZUFBZSxNQUFNO0FBQzNCLFlBQU0sT0FBTyxRQUFRLGFBQWE7QUFDbEMsY0FBUSxPQUFPLE1BQU07QUFDckIsWUFBTSxRQUFRLEtBQUssUUFBUSxHQUFHLGlDQUFpQztBQUMvRCxZQUFNLEtBQUssT0FBTyxTQUFTLGdCQUFnQjtBQUMzQyxZQUFNLFFBQVEsUUFBUSxjQUFjLGlDQUFpQyxHQUFHLGtDQUFrQztBQUMxRyxhQUFPLFlBQVksTUFBTSxHQUFHLGNBQWMsK0RBQStEO0FBQ3pHLGFBQU8sWUFBWSxhQUFhLFVBQVUsZUFBZTtBQUN6RCxhQUFPLFlBQVksZUFBZSxrQkFBa0I7QUFDcEQsYUFBTyxZQUFZLFFBQVEsWUFBWSxTQUFTLElBQUksVUFBVSxPQUFPLEdBQUcsSUFBSTtBQUM1RSxZQUFNLHdCQUF3QixTQUFTLFFBQVEsTUFBTSxRQUFRLFdBQVcsb0JBQW9CO0FBQUEsSUFDN0YsQ0FBQztBQUVELFNBQUssdUZBQXVGLFlBQVk7QUFDdkcsWUFBTSxVQUFVLE1BQU0sMEJBQTBCO0FBQ2hELFlBQU0sVUFBVSxNQUFNLHlCQUF5QixPQUFPO0FBQ3RELFlBQU0sUUFBUSxNQUFNLElBQUksSUFBSSxzQkFBc0IsNEJBQTRCLFlBQVksV0FBVyxDQUFDLENBQUM7QUFDdkcsWUFBTSxPQUFPLFFBQVEsUUFBUSxPQUFPLFFBQVEsU0FBUztBQUNyRCxZQUFNLFFBQVEsY0FBYyxXQUFXLE9BQU8sUUFBVyxLQUFLLFdBQVc7QUFDekUsWUFBTSxPQUFPLEtBQUssWUFBWTtBQUM5QixhQUFPLEdBQUcsZ0JBQWdCLHNCQUFzQjtBQUNoRCxZQUFNLE9BQU8sS0FBSztBQUNsQixhQUFPLEdBQUcsSUFBSTtBQUNkLGFBQU8sWUFBWSxLQUFLLE9BQU8sS0FBSztBQUNwQyxhQUFPLFlBQVksS0FBSyxnQkFBZ0IsVUFBVTtBQUNsRCxhQUFPLFlBQVksS0FBSyxrQkFBa0IsTUFBUztBQUNuRCxhQUFPLFlBQVksS0FBSyw2QkFBNkIsS0FBSztBQUMxRCxhQUFPLFlBQVksUUFBUSxxQkFBcUIsc0JBQXNCLFVBQVUsR0FBRyxLQUFLO0FBQ3hGLGFBQU8sWUFBWSxRQUFRLHFCQUFxQix1QkFBdUIsVUFBVSxHQUFHLEtBQUs7QUFDekYsWUFBTSxRQUFRLGlCQUFpQixJQUFJO0FBQ25DLFlBQU0sZ0JBQWdCLFNBQVMsT0FBTztBQUN0QyxhQUFPLFlBQVksS0FBSyxrQkFBa0IsTUFBUztBQUNuRCxhQUFPLFlBQVksTUFBTSxHQUFHLEdBQUcsOENBQThDO0FBQzdFLFlBQU0sUUFBUSxxQkFBcUIsa0JBQWtCLFVBQVU7QUFDL0QsWUFBTSxVQUFVLE1BQU0sa0JBQWtCLFFBQVEsUUFBUSxPQUFPLFVBQVUsQ0FBQztBQUMxRSxtQkFBYSxRQUFRLEtBQUs7QUFDMUIsWUFBTSx3QkFBd0IsU0FBUyxTQUFTLFlBQVksc0JBQXNCO0FBQUEsSUFDbkYsQ0FBQztBQUVELGVBQVcsVUFBVSxDQUFDLGNBQWMsV0FBVyxjQUFjLEdBQVk7QUFDeEUsV0FBSyxNQUFNLE1BQU0saUVBQWlFLFlBQVk7QUFDN0YsY0FBTSxVQUFVLE1BQU0sMEJBQTBCO0FBQ2hELGNBQU0sVUFBVSxNQUFNLHlCQUF5QixPQUFPO0FBQ3RELGNBQU0sV0FBVyxRQUFRLEtBQUs7QUFDOUIsY0FBTSxVQUFVLFFBQVE7QUFDeEIsY0FBTSxXQUFXLGlCQUFpQixPQUFPO0FBQ3pDLFlBQUksV0FBVyxjQUFjO0FBQzVCLGtCQUFRLEtBQUssV0FBVztBQUFBLFFBQ3pCLFdBQVcsV0FBVyxXQUFXO0FBQ2hDLGtCQUFRLEtBQUssUUFBUTtBQUFBLFFBQ3RCLE9BQU87QUFDTixnQkFBTSxRQUFRLE1BQU0sSUFBSSxJQUFJLHNCQUFzQiw0QkFBNEIsUUFBUSxXQUFXLFdBQVcsQ0FBQyxDQUFDO0FBQzlHLGdCQUFNLFFBQVEsY0FBYyxXQUFXLE9BQU8sUUFBVyxRQUFRLFFBQVEsT0FBTyxRQUFRLFNBQVMsRUFBRSxXQUFXO0FBQzlHLGlCQUFPLFlBQVksUUFBUSxLQUFLLE9BQU8sS0FBSztBQUM1QyxpQkFBTyxlQUFlLFFBQVEsS0FBSyxPQUFPLFFBQVE7QUFBQSxRQUNuRDtBQUNBLGNBQU0sY0FBYyxTQUFTO0FBQzdCLGNBQU0sZ0JBQWdCLFNBQVMsT0FBTztBQUN0QyxZQUFJLFdBQVcsZ0JBQWdCO0FBQzlCLGlCQUFPLFlBQVksUUFBUSxLQUFLLHdCQUF3QixnQkFBZ0IsUUFBUSxTQUFTO0FBQ3pGLGlCQUFPLFlBQVksU0FBUyxJQUFJLGFBQWEsR0FBRywrQ0FBK0M7QUFDL0YsaUJBQU8sWUFBWSxRQUFRLEtBQUssd0JBQXdCLGtCQUFrQixXQUFXLFFBQVEsU0FBUztBQUFBLFFBQ3ZHLE9BQU87QUFDTixpQkFBTyxZQUFZLFFBQVEsS0FBSyx3QkFBd0IsTUFBUztBQUNqRSxpQkFBTyxZQUFZLFFBQVEsWUFBWSxJQUFJO0FBQzNDLGlCQUFPLFlBQVksU0FBUyxHQUFHLGFBQWEsNERBQTREO0FBQUEsUUFDekc7QUFBQSxNQUNELENBQUM7QUFBQSxJQUNGO0FBRUEsU0FBSyw0RkFBNEYsWUFBWTtBQUM1RyxZQUFNLFVBQVUsTUFBTSwwQkFBMEI7QUFDaEQsWUFBTSxVQUFVLE1BQU0seUJBQXlCLE9BQU87QUFDdEQsWUFBTSxnQkFBZ0IsU0FBUyxPQUFPO0FBQ3RDLFlBQU0sd0JBQXdCLFNBQVMsUUFBUSxNQUFNLFFBQVEsV0FBVyxnQkFBZ0I7QUFDeEYsWUFBTSxRQUFRLFFBQVEsS0FBSztBQUMzQixhQUFPLEdBQUcsS0FBSztBQUNmLFlBQU0sUUFBUSxRQUFRLFlBQVksU0FBUztBQUMzQyxlQUFTLElBQUksR0FBRyxJQUFJLEdBQUcsS0FBSztBQUMzQixjQUFNLFVBQVUsUUFBUSxhQUFhO0FBQ3JDLGdCQUFRLE9BQU8sTUFBTTtBQUNyQixjQUFNLFFBQVEsUUFBUSxRQUFRLEdBQUcsbUNBQW1DO0FBQ3BFLGNBQU0sZ0JBQWdCLFNBQVMsT0FBTztBQUN0QyxlQUFPLFlBQVksUUFBUSxLQUFLLGtCQUFrQixLQUFLO0FBQ3ZELGVBQU8sWUFBWSxRQUFRLFlBQVksU0FBUyxRQUFRLE9BQU8sOERBQThEO0FBQUEsTUFDOUg7QUFDQSxZQUFNLHdCQUF3QixTQUFTLFFBQVEsTUFBTSxRQUFRLFdBQVcsZ0JBQWdCO0FBQ3hGLGFBQU8sWUFBWSxRQUFRLEtBQUssa0JBQWtCLEtBQUs7QUFBQSxJQUN4RCxDQUFDO0FBRUQsU0FBSyxnR0FBZ0csWUFBWTtBQUNoSCxZQUFNLFVBQVUsTUFBTSwwQkFBMEI7QUFDaEQsWUFBTSxRQUFRLHFCQUFxQixrQkFBa0IsVUFBVTtBQUMvRCxZQUFNLFNBQVMsTUFBTSxrQkFBa0IsUUFBUSxRQUFRLE9BQU8sVUFBVSxDQUFDO0FBQ3pFLG1CQUFhLFFBQVEsS0FBSztBQUMxQixZQUFNLFFBQVEsT0FBTztBQUNyQixhQUFPLEdBQUcsT0FBTyxnQkFBZ0I7QUFDakMsWUFBTSxRQUFRLHFCQUFxQixvQkFBb0IsUUFBUSxTQUFTO0FBQ3hFLGFBQU8sWUFBWSxRQUFRLHFCQUFxQix1QkFBdUIsUUFBUSxTQUFTLEdBQUcsSUFBSTtBQUMvRixhQUFPLFlBQVksUUFBUSxxQkFBcUIsdUJBQXVCLFVBQVUsR0FBRyxJQUFJO0FBQ3hGLFlBQU0sVUFBVSxNQUFNLHlCQUF5QixPQUFPO0FBQ3RELDJCQUFxQixTQUFTLFFBQVEsVUFBVTtBQUNoRCxZQUFNLFNBQVMsUUFBUSxjQUFjLG1CQUFtQjtBQUN4RCxZQUFNLFdBQXFCLENBQUM7QUFDNUIsWUFBTSxJQUFJLFFBQVEsY0FBYyxtQkFBbUIsUUFBTTtBQUFFLGlCQUFTLEtBQUssRUFBRTtBQUFBLE1BQUcsQ0FBQyxDQUFDO0FBQ2hGLFlBQU0sZ0JBQWdCLFNBQVMsT0FBTztBQUN0QyxhQUFPLEdBQUcsU0FBUyxTQUFTLE1BQU0sQ0FBQztBQUNuQyxhQUFPLEdBQUcsQ0FBQyxTQUFTLFNBQVMsVUFBVSxHQUFHLDBEQUEwRDtBQUNwRyxhQUFPLFlBQVksUUFBUSxLQUFLLHdCQUF3QixRQUFRLElBQUk7QUFDcEUsYUFBTyxZQUFZLE9BQU8sd0JBQXdCLEtBQUs7QUFDdkQsYUFBTyxZQUFZLFFBQVEsS0FBSyxrQkFBa0IsV0FBVyxRQUFRLFNBQVM7QUFDOUUsYUFBTyxZQUFZLE1BQU0sa0JBQWtCLFdBQVcsVUFBVTtBQUNoRSxhQUFPLGVBQWUsUUFBUSxLQUFLLGtCQUFrQixNQUFNLGdCQUFnQjtBQUMzRSxZQUFNLHdCQUF3QixTQUFTLFFBQVEsTUFBTSxRQUFRLFdBQVcsb0JBQW9CO0FBQzVGLFlBQU0sd0JBQXdCLFNBQVMsUUFBUSxZQUFZLHFCQUFxQjtBQUNoRixhQUFPLEdBQUcsQ0FBQyxRQUFRLEtBQUssaUJBQWlCLEdBQUcsYUFBYSxTQUFTLHFCQUFxQixDQUFDO0FBQ3hGLGFBQU8sR0FBRyxDQUFDLE9BQU8saUJBQWlCLEdBQUcsYUFBYSxTQUFTLG9CQUFvQixDQUFDO0FBQUEsSUFDbEYsQ0FBQztBQUFBLEVBQ0YsQ0FBQztBQUVELE9BQUssc0ZBQTRFLFlBQVk7QUFDNUYsVUFBTSxVQUFVLE1BQU0sb0JBQW9CO0FBQzFDLFVBQU0sRUFBRSxPQUFPLHNCQUFzQixlQUFlLFVBQVUsSUFBSTtBQUNsRSxVQUFNLElBQUksY0FBYyxtQkFBbUI7QUFFM0MsVUFBTSxxQkFBcUIsb0JBQW9CLENBQUM7QUFDaEQsVUFBTSxRQUFRLFFBQVEsT0FBTyxDQUFDO0FBQzlCLFVBQU0sbUJBQW1CLFNBQVMsQ0FBQztBQUNuQyxXQUFPLGdCQUFnQixnQkFBZ0Isb0JBQW9CLEdBQUcsQ0FBQyxDQUFDLENBQUM7QUFDakUsV0FBTyxZQUFZLHFCQUFxQixxQkFBcUIsR0FBRyxDQUFDO0FBQ2pFLFdBQU8sWUFBWSxNQUFNLFlBQVksQ0FBQztBQUN0QyxXQUFPLFlBQVksTUFBTSxnQ0FBZ0MsR0FBRyxZQUFZLENBQUM7QUFDekUsV0FBTyxHQUFHLHFCQUFxQixzQkFBc0IsU0FBUyxDQUFDO0FBQy9ELFdBQU8sWUFBWSxRQUFRLE9BQU8sU0FBUyxFQUFFLFlBQVksU0FBUztBQUNsRSxXQUFPLFlBQVksV0FBVyxzQkFBc0IsQ0FBQyxHQUFHLFFBQVEsSUFBSTtBQUVwRSxVQUFNLHFCQUFxQixvQkFBb0IsU0FBUztBQUN4RCxVQUFNLG1CQUFtQixTQUFTLFNBQVM7QUFDM0MsV0FBTyxnQkFBZ0IsZ0JBQWdCLG9CQUFvQixHQUFHLENBQUMsU0FBUyxDQUFDO0FBQ3pFLFdBQU8sWUFBWSxxQkFBcUIscUJBQXFCLEdBQUcsU0FBUztBQUN6RSxXQUFPLFlBQVksV0FBVyxzQkFBc0IsU0FBUyxHQUFHLFFBQVEsSUFBSTtBQUFBLEVBQzdFLENBQUM7QUFFRCxPQUFLLHNEQUFzRCxZQUFZO0FBQ3RFLFVBQU0sVUFBVSwrQkFBK0I7QUFDL0MsVUFBTSxRQUFRLENBQUM7QUFDZixVQUFNLFlBQVksUUFBUSxjQUFjLG1CQUFtQjtBQUMzRCxVQUFNLFFBQVEscUJBQXFCLG9CQUFvQixTQUFTO0FBQ2hFLFVBQU0sY0FBYyxRQUFRLGNBQWMsbUJBQW1CO0FBQzdELFVBQU0sUUFBUSxxQkFBcUIsa0JBQWtCLFdBQVc7QUFDaEUsVUFBTSxRQUFRLHFCQUFxQixvQkFBb0IsV0FBVztBQUNsRSxXQUFPLFlBQVksUUFBUSxxQkFBcUIseUJBQXlCLEdBQUcsV0FBVztBQUV2RixZQUFRLHFCQUFxQixrQkFBa0IsV0FBVztBQUUxRCxXQUFPLFlBQVksUUFBUSxxQkFBcUIsc0JBQXNCLFdBQVcsR0FBRyxJQUFJO0FBQ3hGLFdBQU8sWUFBWSxRQUFRLHFCQUFxQix5QkFBeUIsR0FBRyxTQUFTO0FBQ3JGLFVBQU0sY0FBYyxRQUFRLHFCQUFxQixhQUFhLFNBQVM7QUFDdkUsVUFBTSxTQUFTLGlCQUFpQjtBQUNoQyxXQUFPO0FBQUEsTUFDTixZQUFZLGNBQWMsVUFBVSxZQUFZLFVBQVUsU0FBUyxNQUFNO0FBQUEsTUFDekU7QUFBQSxJQUNEO0FBQUEsRUFDRCxDQUFDO0FBRUQsT0FBSyxnRUFBZ0UsWUFBWTtBQUNoRixVQUFNLFVBQVUsTUFBTSxvQkFBb0I7QUFDMUMsVUFBTSxFQUFFLE9BQU8sc0JBQXNCLGVBQWUsV0FBVyxpQkFBaUIsSUFBSTtBQUNwRixVQUFNLElBQUksY0FBYyxtQkFBbUI7QUFDM0MsVUFBTSxxQkFBcUIsa0JBQWtCLENBQUM7QUFDOUMsVUFBTSxtQkFBbUIsU0FBUyxDQUFDO0FBQ25DLFdBQU8sWUFBWSxxQkFBcUIsc0JBQXNCLEdBQUcsQ0FBQztBQUVsRSxVQUFNLHFCQUFxQixvQkFBb0IsQ0FBQztBQUNoRCxXQUFPLFlBQVkscUJBQXFCLHNCQUFzQixHQUFHLENBQUM7QUFDbEUsV0FBTyxZQUFZLHFCQUFxQix5QkFBeUIsR0FBRyxDQUFDO0FBQ3JFLFdBQU8sWUFBWSxjQUFjLG1CQUFtQixHQUFHLENBQUM7QUFDeEQsV0FBTyxZQUFZLE1BQU0sZ0NBQWdDLEdBQUcsWUFBWSxDQUFDO0FBQ3pFLFVBQU0sUUFBUSxxQkFBcUIsYUFBYSxDQUFDO0FBQ2pELFdBQU8sR0FBRyxLQUFLO0FBQ2YsVUFBTSxTQUFTLGlCQUFpQjtBQUNoQyxXQUFPO0FBQUEsTUFDTixNQUFNLGNBQWMsVUFBVSxNQUFNLFVBQVUsU0FBUyxNQUFNO0FBQUEsTUFDN0Q7QUFBQSxJQUNEO0FBQ0EsVUFBTSxTQUFTLGdCQUFnQixzQkFBc0IsZ0JBQWdCO0FBQ3JFLFdBQU8sWUFBWSxPQUFPLE1BQU0sQ0FBQztBQUNqQyxXQUFPLFlBQVksUUFBUSxPQUFPLFNBQVMsRUFBRSxZQUFZLFNBQVM7QUFDbEUsV0FBTyxZQUFZLFFBQVEsT0FBTyxDQUFDLEVBQUUsWUFBWSxDQUFDO0FBQUEsRUFDbkQsQ0FBQztBQUVELE9BQUssNEVBQTRFLFlBQVk7QUFDNUYsVUFBTSxVQUFVLE1BQU0sb0JBQW9CO0FBQzFDLFVBQU0sRUFBRSxPQUFPLHNCQUFzQixlQUFlLFVBQVUsSUFBSTtBQUNsRSxVQUFNLElBQUksY0FBYyxtQkFBbUI7QUFDM0MsVUFBTSxxQkFBcUIsa0JBQWtCLENBQUM7QUFDOUMsVUFBTSxRQUFRLE1BQU0sbUJBQW1CLFNBQVMsU0FBUztBQUN6RCxVQUFNLFFBQVEsTUFBTSxtQkFBbUIsU0FBUyxDQUFDO0FBQ2pELFdBQU8sR0FBRyxNQUFNLGtCQUFrQjtBQUNsQyxXQUFPLEdBQUcsTUFBTSxrQkFBa0I7QUFDbEMsV0FBTyxZQUFZLHFCQUFxQixzQkFBc0IsR0FBRyxDQUFDO0FBRWxFLFFBQUksV0FBVyxNQUFNO0FBQUEsSUFBRTtBQUN2QixVQUFNLE9BQU8sSUFBSSxRQUFjLGFBQVc7QUFBRSxpQkFBVztBQUFBLElBQVMsQ0FBQztBQUNqRSxJQUFDLFFBQVEsT0FBTyxTQUFTLEVBQW1DLFlBQVk7QUFFeEUsVUFBTSxXQUFxQixDQUFDO0FBQzVCLFVBQU0saUJBQWlCLGNBQWMsY0FBYyxLQUFLLGFBQWE7QUFDckUsa0JBQWMsZ0JBQWdCLENBQUMsY0FBc0I7QUFDcEQsZUFBUyxLQUFLLFNBQVM7QUFDdkIscUJBQWUsU0FBUztBQUFBLElBQ3pCO0FBRUEsVUFBTSxRQUFRLE1BQU0sbUJBQW1CLGtCQUFrQixTQUFTO0FBQ2xFLFFBQUk7QUFDSCxZQUFNLFFBQVEsQ0FBQztBQUNmLFlBQU0sTUFBTSxtQkFBbUIsa0JBQWtCLENBQUM7QUFDbEQsYUFBTyxZQUFZLHFCQUFxQix5QkFBeUIsR0FBRyxDQUFDO0FBQ3JFLGFBQU8sWUFBWSxjQUFjLG1CQUFtQixHQUFHLENBQUM7QUFDeEQsZUFBUyxTQUFTO0FBQ2xCLGVBQVM7QUFDVCxZQUFNO0FBQ04sYUFBTyxnQkFBZ0IsVUFBVSxDQUFDLENBQUM7QUFDbkMsYUFBTyxZQUFZLHFCQUFxQix5QkFBeUIsR0FBRyxDQUFDO0FBQ3JFLGFBQU8sWUFBWSxjQUFjLG1CQUFtQixHQUFHLENBQUM7QUFBQSxJQUN6RCxVQUFFO0FBQ0QsZUFBUztBQUFBLElBQ1Y7QUFBQSxFQUNELENBQUM7QUFFRCxPQUFLLGdGQUFnRixpQkFBa0I7QUFDdEcsU0FBSyxRQUFRLElBQU07QUFDbkIsVUFBTSxVQUFVLCtCQUErQjtBQUMvQyxVQUFNLFFBQVEsQ0FBQztBQUNmLFVBQU0sRUFBRSxzQkFBc0IsZUFBZSxrQkFBa0IsSUFBSTtBQUNuRSxVQUFNLFlBQVksY0FBYyxtQkFBbUI7QUFDbkQsVUFBTSxxQkFBcUIsb0JBQW9CLFNBQVM7QUFDeEQsVUFBTSxjQUFjLGNBQWMsbUJBQW1CO0FBQ3JELFVBQU0scUJBQXFCLGtCQUFrQixXQUFXO0FBQ3hELFdBQU8sWUFBWSxxQkFBcUIsdUJBQXVCLFNBQVMsR0FBRyxJQUFJO0FBQy9FLFdBQU8sWUFBWSxxQkFBcUIsdUJBQXVCLFdBQVcsR0FBRyxJQUFJO0FBQ2pGLFdBQU8sWUFBWSxxQkFBcUIsc0JBQXNCLEdBQUcsQ0FBQztBQUVsRSxVQUFNLGdCQUFnQixrQkFBa0IsS0FBSyxVQUFRLEtBQUssZUFBZSxXQUFXO0FBQ3BGLFdBQU8sR0FBRyxhQUFhO0FBQ3ZCLFVBQU0sUUFBUSxjQUFjO0FBQzVCLFVBQU0sbUJBQW1CO0FBQ3pCLFVBQU0sMEJBQTBCLE1BQU07QUFFdEMsVUFBTSxxQkFBcUIsb0JBQW9CLFNBQVM7QUFDeEQsV0FBTyxZQUFZLHFCQUFxQix5QkFBeUIsR0FBRyxTQUFTO0FBQzdFLFdBQU8sWUFBWSxjQUFjLG1CQUFtQixHQUFHLFNBQVM7QUFDaEUsVUFBTSxjQUFjLHFCQUFxQixhQUFhLFNBQVM7QUFDL0QsVUFBTSxlQUFlLGlCQUFpQjtBQUN0QyxXQUFPO0FBQUEsTUFDTixZQUFZLGNBQWMsZ0JBQWdCLFlBQVksVUFBVSxTQUFTLFlBQVk7QUFBQSxNQUNyRjtBQUFBLElBQ0Q7QUFFQSxVQUFNLFdBQXFCLENBQUM7QUFDNUIsVUFBTSxpQkFBaUIsY0FBYyxjQUFjLEtBQUssYUFBYTtBQUNyRSxrQkFBYyxnQkFBZ0IsQ0FBQyxjQUFzQjtBQUNwRCxlQUFTLEtBQUssU0FBUztBQUN2QixxQkFBZSxTQUFTO0FBQUEsSUFDekI7QUFFQSxRQUFJLFVBQVU7QUFDZCxVQUFNLFNBQVMscUJBQXFCLG9CQUFvQixXQUFXLEVBQUUsUUFBUSxNQUFNO0FBQUUsZ0JBQVU7QUFBQSxJQUFNLENBQUM7QUFDdEcsVUFBTSxRQUFRLENBQUM7QUFDZixXQUFPLFlBQVksU0FBUyxPQUFPLGlEQUFpRDtBQUNwRixXQUFPLFlBQVkscUJBQXFCLHVCQUF1QixXQUFXLEdBQUcsSUFBSTtBQUVqRix5QkFBcUIsa0JBQWtCLFdBQVc7QUFDbEQsV0FBTyxZQUFZLHFCQUFxQixzQkFBc0IsV0FBVyxHQUFHLElBQUk7QUFDaEYsV0FBTyxZQUFZLHFCQUFxQix5QkFBeUIsR0FBRyxTQUFTO0FBQzdFLFdBQU8sWUFBWSxjQUFjLG1CQUFtQixHQUFHLFNBQVM7QUFDaEUsVUFBTSxlQUFlLGlCQUFpQjtBQUN0QyxXQUFPO0FBQUEsTUFDTixZQUFZLGNBQWMsZ0JBQWdCLFlBQVksVUFBVSxTQUFTLFlBQVk7QUFBQSxNQUNyRjtBQUFBLElBQ0Q7QUFFQSxVQUFNO0FBQ04sV0FBTyxZQUFZLFNBQVMsSUFBSTtBQUNoQyxXQUFPLFlBQVkscUJBQXFCLHNCQUFzQixXQUFXLEdBQUcsSUFBSTtBQUNoRixXQUFPLFlBQVkscUJBQXFCLHlCQUF5QixHQUFHLFNBQVM7QUFDN0UsV0FBTyxZQUFZLGNBQWMsbUJBQW1CLEdBQUcsU0FBUztBQUNoRSxVQUFNLGNBQWMsaUJBQWlCO0FBQ3JDLFdBQU87QUFBQSxNQUNOLFlBQVksY0FBYyxlQUFlLFlBQVksVUFBVSxTQUFTLFdBQVc7QUFBQSxNQUNuRjtBQUFBLElBQ0Q7QUFDQSxXQUFPLGdCQUFnQixVQUFVLENBQUMsQ0FBQztBQUFBLEVBQ3BDLENBQUM7QUFFRCxPQUFLLGdFQUFnRSxZQUFZO0FBQ2hGLFVBQU0sVUFBVSxNQUFNLG9CQUFvQjtBQUMxQyxVQUFNLEVBQUUsT0FBTyxzQkFBc0IsZUFBZSxVQUFVLElBQUk7QUFDbEUsVUFBTSxJQUFJLGNBQWMsbUJBQW1CO0FBQzNDLFVBQU0sT0FBTyxNQUFNLG1CQUFtQixTQUFTLFNBQVM7QUFDeEQsV0FBTyxHQUFHLEtBQUssa0JBQWtCO0FBQ2pDLFVBQU0sS0FBSyxtQkFBb0Isa0JBQWtCLENBQUM7QUFDbEQsVUFBTSxtQkFBbUIsU0FBUyxDQUFDO0FBQ25DLFdBQU8sWUFBWSxxQkFBcUIscUJBQXFCLEdBQUcsQ0FBQztBQUNqRSxXQUFPLFlBQVkscUJBQXFCLHNCQUFzQixHQUFHLENBQUM7QUFDbEUsV0FBTyxHQUFHLFFBQVEsT0FBTyxDQUFDLEVBQUUsWUFBWSxZQUFZO0FBQUEsRUFDckQsQ0FBQztBQUVELE9BQUssd0ZBQXdGLFlBQVk7QUFDeEcsVUFBTSxVQUFVLE1BQU0sb0JBQW9CO0FBQzFDLFVBQU0sRUFBRSxPQUFPLHNCQUFzQixlQUFlLFVBQVUsSUFBSTtBQUNsRSxVQUFNLElBQUksY0FBYyxtQkFBbUI7QUFDM0MsVUFBTSxJQUFJLGNBQWMsbUJBQW1CO0FBQzNDLFVBQU0scUJBQXFCLGtCQUFrQixDQUFDO0FBQzlDLFVBQU0sUUFBUSxNQUFNLG1CQUFtQixTQUFTLENBQUM7QUFDakQsV0FBTyxHQUFHLE1BQU0sa0JBQWtCO0FBQ2xDLFVBQU0sTUFBTSxtQkFBb0Isa0JBQWtCLENBQUM7QUFDbkQsVUFBTSxtQkFBbUIsU0FBUyxDQUFDO0FBQ25DLFVBQU0sVUFBVSxnQkFBZ0Isb0JBQW9CO0FBQ3BELFdBQU8sWUFBWSxRQUFRLFFBQVEsQ0FBQztBQUNwQyxXQUFPLEdBQUcsUUFBUSxTQUFTLFNBQVMsR0FBRywwQkFBMEI7QUFDakUsV0FBTyxHQUFHLFFBQVEsU0FBUyxDQUFDLEdBQUcsaURBQWlEO0FBQ2hGLFdBQU8sR0FBRyxDQUFDLFFBQVEsU0FBUyxDQUFDLEdBQUcsbUNBQW1DO0FBQ25FLFdBQU8sWUFBWSxRQUFRLE9BQU8sU0FBUyxFQUFFLFlBQVksU0FBUztBQUNsRSxXQUFPLFlBQVksUUFBUSxPQUFPLENBQUMsRUFBRSxZQUFZLENBQUM7QUFDbEQsV0FBTyxZQUFZLHFCQUFxQixzQkFBc0IsQ0FBQyxHQUFHLElBQUk7QUFBQSxFQUN2RSxDQUFDO0FBRUQsT0FBSyw2SEFBNkgsWUFBWTtBQUM3SSxVQUFNLFVBQVUsTUFBTSxvQkFBb0I7QUFDMUMsVUFBTSxPQUFPLE1BQU0sbUJBQW1CLFNBQVMsUUFBUSxTQUFTO0FBQ2hFLFdBQU8sR0FBRyxLQUFLLGtCQUFrQjtBQUNqQyxVQUFNLFlBQVksSUFBSSxNQUFNLGFBQWE7QUFDekMsU0FBSyxtQkFBbUIsb0JBQW9CLFlBQVk7QUFDdkQsWUFBTTtBQUFBLElBQ1A7QUFDQSxVQUFNLGlDQUFpQyxXQUFXLE1BQU07QUFDdkQsV0FBSyxtQkFBb0IsZ0JBQWdCLGVBQWU7QUFBQSxJQUN6RCxDQUFDO0FBQUEsRUFDRixDQUFDO0FBRUQsT0FBSyw4SUFBOEksWUFBWTtBQUM5SixVQUFNLFVBQVUsTUFBTSxvQkFBb0I7QUFDMUMsVUFBTSxPQUFPLE1BQU0sbUJBQW1CLFNBQVMsUUFBUSxTQUFTO0FBQ2hFLFdBQU8sR0FBRyxLQUFLLGtCQUFrQjtBQUNqQyxVQUFNLFlBQVksSUFBSSxNQUFNLGFBQWE7QUFDekMsU0FBSyxtQkFBbUIsb0JBQW9CLFlBQVk7QUFDdkQsWUFBTTtBQUFBLElBQ1A7QUFDQSxVQUFNLGlDQUFpQyxXQUFXLE1BQU07QUFDdkQsNEJBQXNCLEtBQUssb0JBQXFCLGVBQWU7QUFBQSxJQUNoRSxDQUFDO0FBQUEsRUFDRixDQUFDO0FBRUQsT0FBSyx5RkFBeUYsWUFBWTtBQUN6RyxVQUFNLFNBQVMsTUFBTSxrQkFBa0IsR0FBRyxRQUFRLElBQUksQ0FBQyw4RUFBOEU7QUFDckksVUFBTSxjQUFjO0FBQ3BCLFdBQU8sR0FBRyxPQUFPLFNBQVMseUNBQXlDLFdBQVcsRUFBRSxDQUFDO0FBQ2pGLFdBQU8sR0FBRyxDQUFDLE9BQU8sU0FBUyx5Q0FBeUMsQ0FBQztBQUFBLEVBQ3RFLENBQUM7QUFFRCxPQUFLLDZEQUE2RCxZQUFZO0FBQzdFLFVBQU0sVUFBVSxNQUFNLG9CQUFvQjtBQUMxQyxVQUFNLEVBQUUsc0JBQXNCLGVBQWUsVUFBVSxJQUFJO0FBQzNELFVBQU0sT0FBTyxNQUFNLG1CQUFtQixTQUFTLFNBQVM7QUFDeEQsV0FBTyxHQUFHLEtBQUssa0JBQWtCO0FBQ2pDLFNBQUssbUJBQW9CLGlCQUFpQjtBQUMxQyxVQUFNLFdBQVcsS0FBSyxJQUFJLElBQUk7QUFDOUIsUUFBSSxRQUFRLGNBQWMsbUJBQW1CO0FBQzdDLFdBQU8sVUFBVSxhQUFhLEtBQUssSUFBSSxJQUFJLFVBQVU7QUFDcEQsWUFBTSxRQUFRLEVBQUU7QUFDaEIsY0FBUSxjQUFjLG1CQUFtQjtBQUFBLElBQzFDO0FBQ0EsV0FBTyxlQUFlLE9BQU8sU0FBUztBQUN0QyxVQUFNLG1CQUFtQixTQUFTLEtBQUs7QUFDdkMsV0FBTyxZQUFZLHFCQUFxQixzQkFBc0IsR0FBRyxDQUFDO0FBQ2xFLFdBQU8sWUFBWSxxQkFBcUIscUJBQXFCLEdBQUcsS0FBSztBQUNyRSxXQUFPLFlBQVksV0FBVyxzQkFBc0IsS0FBSyxHQUFHLFFBQVEsSUFBSTtBQUN4RSxXQUFPLFlBQVkscUJBQXFCLHNCQUFzQixTQUFTLEdBQUcsSUFBSTtBQUFBLEVBQy9FLENBQUM7QUFFRCxPQUFLLHNGQUFzRixZQUFZO0FBQ3RHLFVBQU0sVUFBVSxNQUFNLG9CQUFvQjtBQUMxQyxVQUFNLEVBQUUsc0JBQXNCLGVBQWUsa0JBQWtCLFVBQVUsSUFBSTtBQUM3RSxVQUFNLElBQUksY0FBYyxtQkFBbUI7QUFDM0MsVUFBTSxJQUFJLGNBQWMsbUJBQW1CO0FBRTNDLFVBQU0scUJBQXFCLG9CQUFvQixDQUFDO0FBQ2hELFVBQU0sbUJBQW1CLFNBQVMsQ0FBQztBQUNuQyxVQUFNLHFCQUFxQixvQkFBb0IsQ0FBQztBQUNoRCxVQUFNLG1CQUFtQixTQUFTLENBQUM7QUFDbkMsVUFBTSxxQkFBcUIsb0JBQW9CLFNBQVM7QUFDeEQsVUFBTSxtQkFBbUIsU0FBUyxTQUFTO0FBQzNDLFFBQUksU0FBUyxnQkFBZ0Isc0JBQXNCLGdCQUFnQjtBQUNuRSxXQUFPLFlBQVkscUJBQXFCLHNCQUFzQixHQUFHLENBQUM7QUFDbEUsV0FBTyxZQUFZLE9BQU8sTUFBTSxDQUFDO0FBQ2pDLFdBQU8sWUFBWSxPQUFPLE1BQU0sQ0FBQztBQUNqQyxXQUFPLFlBQVksT0FBTyxjQUFjLENBQUM7QUFFekMsVUFBTSxxQkFBcUIsa0JBQWtCLENBQUM7QUFDOUMsVUFBTSxtQkFBbUIsU0FBUyxDQUFDO0FBQ25DLGFBQVMsZ0JBQWdCLHNCQUFzQixnQkFBZ0I7QUFDL0QsV0FBTyxZQUFZLHFCQUFxQixzQkFBc0IsR0FBRyxDQUFDO0FBQ2xFLFdBQU8sWUFBWSxPQUFPLE1BQU0sQ0FBQztBQUNqQyxXQUFPLFlBQVksT0FBTyxNQUFNLENBQUM7QUFDakMsV0FBTyxZQUFZLE9BQU8sY0FBYyxDQUFDO0FBQUEsRUFDMUMsQ0FBQztBQUVELE9BQUssc0ZBQXNGLFlBQVk7QUFDdEcsVUFBTSxVQUFVLE1BQU0sb0JBQW9CO0FBQzFDLFVBQU0sRUFBRSxzQkFBc0IsVUFBVSxJQUFJO0FBQzVDLFVBQU0sT0FBTyxNQUFNLG1CQUFtQixTQUFTLFNBQVM7QUFDeEQsVUFBTSxPQUFPLHFCQUFxQixhQUFhLFNBQVM7QUFFeEQsU0FBSyxPQUFPLElBQUksVUFBVSxLQUFLLEdBQUcsQ0FBQztBQUNuQyxXQUFPLEdBQUcsS0FBSyxXQUFXLFVBQVUsU0FBUyxXQUFXLENBQUM7QUFDekQsV0FBTyxHQUFHLENBQUMsS0FBSyxXQUFXLFVBQVUsU0FBUyxXQUFXLENBQUM7QUFFMUQsU0FBSyxPQUFPLElBQUksVUFBVSxLQUFLLEdBQUcsQ0FBQztBQUNuQyxXQUFPLEdBQUcsS0FBSyxXQUFXLFVBQVUsU0FBUyxXQUFXLENBQUM7QUFDekQsV0FBTyxHQUFHLEtBQUssVUFBVSxVQUFVLFNBQVMsV0FBVyxDQUFDO0FBQ3hELFdBQU8sR0FBRyxDQUFDLEtBQUssV0FBVyxVQUFVLFNBQVMsWUFBWSxDQUFDO0FBRTNELFNBQUssT0FBTyxJQUFJLFVBQVUsS0FBSyxHQUFHLENBQUM7QUFDbkMsV0FBTyxHQUFHLEtBQUssV0FBVyxVQUFVLFNBQVMsV0FBVyxDQUFDO0FBQ3pELFdBQU8sR0FBRyxLQUFLLFdBQVcsVUFBVSxTQUFTLFlBQVksQ0FBQztBQUUxRCxTQUFLLE9BQU8sSUFBSSxVQUFVLEtBQUssR0FBRyxDQUFDO0FBQ25DLFdBQU8sR0FBRyxDQUFDLEtBQUssV0FBVyxVQUFVLFNBQVMsV0FBVyxDQUFDO0FBQzFELFdBQU8sR0FBRyxDQUFDLEtBQUssVUFBVSxVQUFVLFNBQVMsV0FBVyxDQUFDO0FBQ3pELFdBQU8sR0FBRyxDQUFDLEtBQUssV0FBVyxVQUFVLFNBQVMsWUFBWSxDQUFDO0FBQUEsRUFDNUQsQ0FBQztBQUVELE9BQUssMkRBQTJELFlBQVk7QUFDM0UsVUFBTSxVQUFVLE1BQU0sb0JBQW9CO0FBQzFDLFVBQU0sRUFBRSxzQkFBc0Isb0JBQW9CLGNBQWMsSUFBSTtBQUNwRSxVQUFNLElBQUksY0FBYyxtQkFBbUI7QUFDM0MsVUFBTSxxQkFBcUIsb0JBQW9CLENBQUM7QUFDaEQsVUFBTSxtQkFBbUIsU0FBUyxDQUFDO0FBQ25DLFVBQU0sbUJBQW1CLGFBQWEsR0FBRyxvQkFBb0IsYUFBYTtBQUMxRSxXQUFPLFlBQVksbUJBQW1CLHFCQUFxQixDQUFDLEdBQUcsSUFBSTtBQUFBLEVBQ3BFLENBQUM7QUFFRCxPQUFLLGdGQUFnRixZQUFZO0FBQ2hHLFVBQU0sRUFBRSxzQkFBc0IsZUFBZSxVQUFVLElBQUksTUFBTSxvQkFBb0I7QUFDckYsVUFBTSxJQUFJLGNBQWMsbUJBQW1CO0FBQzNDLFVBQU0sSUFBSSxjQUFjLG1CQUFtQjtBQUMzQyxVQUFNLFFBQVEscUJBQXFCLG9CQUFvQixDQUFDO0FBQ3hELFVBQU0sU0FBUyxxQkFBcUIsb0JBQW9CLENBQUM7QUFDekQsVUFBTSxRQUFRLElBQUksQ0FBQyxPQUFPLE1BQU0sQ0FBQztBQUNqQyxXQUFPLGdCQUFnQixnQkFBZ0Isb0JBQW9CLEdBQUcsQ0FBQyxDQUFDLENBQUM7QUFDakUsV0FBTyxZQUFZLHFCQUFxQixxQkFBcUIsR0FBRyxDQUFDO0FBRWpFLFVBQU0sYUFBYSxDQUFDLEdBQUcscUJBQXFCLHNCQUFzQixDQUFDO0FBQ25FLGtCQUFjLGtCQUFrQiw2QkFBNkI7QUFDN0QsVUFBTSxRQUFRLEVBQUU7QUFDaEIsV0FBTyxnQkFBZ0IsQ0FBQyxHQUFHLHFCQUFxQixzQkFBc0IsQ0FBQyxHQUFHLFVBQVU7QUFDcEYsV0FBTyxZQUFZLHFCQUFxQixhQUFhLDZCQUE2QixHQUFHLE1BQVM7QUFDOUYsV0FBTyxHQUFHLHFCQUFxQixhQUFhLFNBQVMsS0FBSyxxQkFBcUIsYUFBYSxDQUFDLENBQUM7QUFBQSxFQUMvRixDQUFDO0FBRUQsT0FBSywwRUFBMEUsWUFBWTtBQUMxRixVQUFNLFVBQVUsK0JBQStCO0FBQy9DLFVBQU0sUUFBUSxDQUFDO0FBQ2YsVUFBTSxZQUFZLFFBQVEsY0FBYyxtQkFBbUI7QUFDM0QsVUFBTSxRQUFRLHFCQUFxQixvQkFBb0IsU0FBUztBQUNoRSxXQUFPLGdCQUFnQixnQkFBZ0IsUUFBUSxvQkFBb0IsR0FBRyxDQUFDLFNBQVMsQ0FBQztBQUNqRixXQUFPLEdBQUcsUUFBUSxrQkFBa0IsS0FBSyxVQUFRLEtBQUssZUFBZSxTQUFTLENBQUM7QUFFL0UsWUFBUSxjQUFjLGtCQUFrQiw2QkFBNkI7QUFDckUsWUFBUSxjQUFjLG1CQUFtQixTQUFTO0FBRWxELFdBQU8sZ0JBQWdCLGdCQUFnQixRQUFRLG9CQUFvQixHQUFHLENBQUMsQ0FBQztBQUN4RSxXQUFPLFlBQVksUUFBUSxxQkFBcUIscUJBQXFCLEdBQUcsTUFBUztBQUNqRixXQUFPLEdBQUcsQ0FBQyxRQUFRLHFCQUFxQixzQkFBc0IsRUFBRSxTQUFTLFNBQVMsQ0FBQztBQUNuRixXQUFPLEdBQUcsQ0FBQyxRQUFRLGtCQUFrQixLQUFLLFVBQVEsS0FBSyxlQUFlLFNBQVMsQ0FBQztBQUFBLEVBQ2pGLENBQUM7QUFFRCxPQUFLLGlFQUFpRSxZQUFZO0FBQ2pGLFVBQU0sVUFBVSxNQUFNLG9CQUFvQjtBQUMxQyxVQUFNLEVBQUUsT0FBTyxzQkFBc0IsZUFBZSxVQUFVLElBQUk7QUFDbEUsVUFBTSxjQUFjLGNBQWMsbUJBQW1CO0FBQ3JELFVBQU0scUJBQXFCLGtCQUFrQixXQUFXO0FBQ3hELFVBQU0sbUJBQW1CLFNBQVMsV0FBVztBQUU3QyxXQUFPLFlBQVkscUJBQXFCLHNCQUFzQixTQUFTLEdBQUcsSUFBSTtBQUM5RSxXQUFPLEdBQUcscUJBQXFCLGFBQWEsU0FBUyxDQUFDO0FBQ3RELFdBQU8sR0FBRyxNQUFNLGtCQUFrQixLQUFLLFVBQVEsS0FBSyxlQUFlLFNBQVMsQ0FBQztBQUU3RSxrQkFBYyxtQkFBbUIsU0FBUztBQUUxQyxXQUFPLFlBQVkscUJBQXFCLGFBQWEsU0FBUyxHQUFHLE1BQVM7QUFDMUUsV0FBTyxHQUFHLENBQUMsTUFBTSxrQkFBa0IsS0FBSyxVQUFRLEtBQUssZUFBZSxTQUFTLENBQUM7QUFDOUUsV0FBTyxnQkFBZ0IsZ0JBQWdCLG9CQUFvQixHQUFHLENBQUMsV0FBVyxDQUFDO0FBQUEsRUFDNUUsQ0FBQztBQUVELE9BQUssZ0VBQWdFLFlBQVk7QUFDaEYsVUFBTSxVQUFVLE1BQU0sb0JBQW9CO0FBQzFDLFVBQU0sRUFBRSxzQkFBc0IsY0FBYyxJQUFJO0FBQ2hELFdBQU8sR0FBRyxtQ0FBbUMsVUFBVSxDQUFDO0FBQ3hELFdBQU8sR0FBRyxjQUFjLFlBQVksRUFBRSxLQUFLLGFBQVcsUUFBUSxPQUFPLFVBQVUsQ0FBQztBQUNoRixVQUFNLElBQUksY0FBYyxtQkFBbUI7QUFDM0MsVUFBTSxxQkFBcUIsb0JBQW9CLENBQUM7QUFDaEQsVUFBTSxtQkFBbUIsU0FBUyxDQUFDO0FBQ25DLFdBQU8sWUFBWSxxQkFBcUIsc0JBQXNCLFVBQVUsR0FBRyxJQUFJO0FBRS9FLGtCQUFjLGtCQUFrQixVQUFVO0FBQzFDLFVBQU0sbUJBQW1CLFNBQVMsVUFBVTtBQUM1QyxXQUFPLFlBQVkscUJBQXFCLHVCQUF1QixVQUFVLEdBQUcsSUFBSTtBQUNoRixXQUFPLGdCQUFnQixnQkFBZ0Isb0JBQW9CLEdBQUcsQ0FBQyxVQUFVLENBQUM7QUFDMUUsV0FBTyxZQUFZLHFCQUFxQixxQkFBcUIsR0FBRyxVQUFVO0FBQUEsRUFDM0UsQ0FBQztBQUVELE9BQUssNkVBQTZFLFlBQVk7QUFDN0YsVUFBTSxnQkFBZ0IsTUFBTSxJQUFJLElBQUksbUJBQW1CLENBQUM7QUFDeEQsVUFBTSxXQUFXLFNBQVMsY0FBYyxLQUFLO0FBQzdDLGFBQVMsS0FBSyxZQUFZLFFBQVE7QUFDbEMsVUFBTSxJQUFJLEVBQUUsU0FBUyxNQUFNLFNBQVMsT0FBTyxFQUFFLENBQUM7QUFFOUMsVUFBTSxvQkFBK0MsQ0FBQztBQUN0RCxRQUFJLGdCQUFnQjtBQUNwQixVQUFNLHNCQUFzQjtBQUFBLE1BQzNCLDhCQUE4QixDQUFDLFNBQWtCLGVBQXVCO0FBQ3ZFLFlBQUksZUFBZTtBQUNsQixnQkFBTSxJQUFJLE1BQU0sYUFBYTtBQUFBLFFBQzlCO0FBQ0EsY0FBTSxPQUFPLEVBQUUsWUFBWSxXQUFXLFFBQVEsUUFBUSxHQUFHLGFBQWEsRUFBRSxPQUFPLE1BQU07QUFBQSxRQUFFLEdBQUcsa0JBQWtCLEVBQUUsT0FBTyxNQUFNLHlCQUF5QixFQUFFLEVBQUU7QUFDeEosMEJBQWtCLEtBQUssSUFBSTtBQUMzQixlQUFPO0FBQUEsTUFDUjtBQUFBLE1BQ0EsK0JBQStCLENBQUMsZUFBdUI7QUFDdEQsY0FBTSxRQUFRLGtCQUFrQixVQUFVLFVBQVEsS0FBSyxlQUFlLFVBQVU7QUFDaEYsWUFBSSxTQUFTLEdBQUc7QUFDZiw0QkFBa0IsT0FBTyxPQUFPLENBQUM7QUFBQSxRQUNsQztBQUFBLE1BQ0Q7QUFBQSxNQUNBLDRCQUE0QixNQUFNO0FBQUEsTUFBRTtBQUFBLE1BQ3BDLDRCQUE0QixNQUFNO0FBQUEsTUFDbEMsSUFBSSxvQkFBb0I7QUFDdkIsZUFBTztBQUFBLE1BQ1I7QUFBQSxJQUNEO0FBRUEsVUFBTSxTQUFtQixDQUFDO0FBQzFCLFVBQU0sdUJBQXVCLE1BQU0sSUFBSSxJQUFJO0FBQUEsTUFDMUM7QUFBQSxRQUNDLGtCQUFrQixNQUFNO0FBQUEsUUFDeEIsWUFBWSxNQUFNO0FBQUEsUUFDbEIsVUFBVSxPQUFPLEVBQUUsWUFBWSxTQUFTLGNBQWMsS0FBSyxHQUFHLG1CQUFtQixVQUFVLGdCQUFnQixPQUFVO0FBQUEsUUFDckgseUJBQXlCLE1BQU07QUFBQSxRQUFFO0FBQUEsUUFDakMsT0FBTyxNQUFNO0FBQUEsUUFBRTtBQUFBLE1BQ2hCO0FBQUEsTUFDQTtBQUFBLE1BQ0E7QUFBQSxNQUNBLElBQUksZUFBZTtBQUFBLE1BQ25CO0FBQUEsUUFDQyxPQUFPLENBQUMsWUFBNEI7QUFDbkMsaUJBQU8sS0FBSyxPQUFPLFlBQVksV0FBVyxVQUFVLGdCQUFnQixPQUFPLENBQUM7QUFBQSxRQUM3RTtBQUFBLE1BQ0Q7QUFBQSxJQUNELENBQUM7QUFFRCxVQUFNLFFBQVEsQ0FBQztBQUNmLFVBQU0sWUFBWSxjQUFjLG1CQUFtQjtBQUNuRCxVQUFNLHFCQUFxQixvQkFBb0IsU0FBUztBQUN4RCxVQUFNLFNBQVMsY0FBYyxtQkFBbUI7QUFDaEQsb0JBQWdCO0FBQ2hCLFVBQU0scUJBQXFCLG9CQUFvQixNQUFNO0FBRXJELFdBQU8sR0FBRyxPQUFPLEtBQUssV0FBUyxNQUFNLFNBQVMsYUFBYSxDQUFDLENBQUM7QUFDN0QsV0FBTyxZQUFZLHFCQUFxQixxQkFBcUIsR0FBRyxTQUFTO0FBQ3pFLFdBQU8sWUFBWSxxQkFBcUIsYUFBYSxNQUFNLEdBQUcsTUFBUztBQUN2RSxXQUFPLEdBQUcsQ0FBQyxxQkFBcUIsc0JBQXNCLEVBQUUsU0FBUyxNQUFNLENBQUM7QUFDeEUsV0FBTyxHQUFHLENBQUMsa0JBQWtCLEtBQUssVUFBUSxLQUFLLGVBQWUsTUFBTSxDQUFDO0FBRXJFLG9CQUFnQjtBQUNoQixVQUFNLHFCQUFxQixvQkFBb0IsTUFBTTtBQUNyRCxXQUFPLEdBQUcscUJBQXFCLGFBQWEsTUFBTSxDQUFDO0FBQ25ELFdBQU8sR0FBRyxrQkFBa0IsS0FBSyxVQUFRLEtBQUssZUFBZSxNQUFNLENBQUM7QUFDcEUsV0FBTyxHQUFHLHFCQUFxQixhQUFhLE1BQU0sR0FBRyxVQUFVLFdBQVc7QUFBQSxFQUMzRSxDQUFDO0FBRUQsaUJBQWUsMkJBQTJCO0FBQ3pDLFVBQU0sU0FBbUIsQ0FBQztBQUMxQixVQUFNLFVBQVUsK0JBQStCO0FBQy9DLFlBQVEsZUFBZSxhQUFXO0FBQ2pDLGFBQU8sS0FBSyxPQUFPLFlBQVksV0FBVyxVQUFVLGdCQUFnQixPQUFPLENBQUM7QUFBQSxJQUM3RSxDQUFDO0FBQ0QsVUFBTSxRQUFRLENBQUM7QUFDZixVQUFNLFlBQVksUUFBUSxjQUFjLG1CQUFtQjtBQUMzRCxVQUFNLFFBQVEscUJBQXFCLG9CQUFvQixTQUFTO0FBQ2hFLFVBQU0sY0FBYyxRQUFRLGNBQWMsbUJBQW1CO0FBQzdELFVBQU0sUUFBUSxxQkFBcUIsa0JBQWtCLFdBQVc7QUFDaEUsV0FBTyxZQUFZLFFBQVEscUJBQXFCLHNCQUFzQixHQUFHLENBQUM7QUFDMUUsV0FBTyxZQUFZLFFBQVEscUJBQXFCLHVCQUF1QixTQUFTLEdBQUcsSUFBSTtBQUN2RixXQUFPLFlBQVksUUFBUSxxQkFBcUIsdUJBQXVCLFdBQVcsR0FBRyxJQUFJO0FBQ3pGLFVBQU0sYUFBYSxRQUFRLGNBQWMsbUJBQW1CO0FBQzVELFdBQU8sRUFBRSxTQUFTLFFBQVEsV0FBVyxhQUFhLFdBQVc7QUFBQSxFQUM5RDtBQUVBLE9BQUssNEVBQTRFLFlBQVk7QUFDNUYsVUFBTSxFQUFFLFNBQVMsUUFBUSxXQUFXLGFBQWEsV0FBVyxJQUFJLE1BQU0seUJBQXlCO0FBQy9GLFVBQU0sRUFBRSxzQkFBc0Isa0JBQWtCLElBQUk7QUFDcEQsWUFBUSxpQkFBaUIsSUFBSTtBQUM3QixVQUFNLHFCQUFxQixvQkFBb0IsWUFBWSxFQUFFLFNBQVMsWUFBWSxDQUFDO0FBRW5GLFdBQU8sWUFBWSxxQkFBcUIsdUJBQXVCLFdBQVcsR0FBRyxJQUFJO0FBQ2pGLFdBQU8sWUFBWSxxQkFBcUIsdUJBQXVCLFNBQVMsR0FBRyxJQUFJO0FBQy9FLFdBQU8sWUFBWSxxQkFBcUIsc0JBQXNCLEdBQUcsQ0FBQztBQUNsRSxXQUFPLFlBQVkscUJBQXFCLGFBQWEsVUFBVSxHQUFHLE1BQVM7QUFDM0UsV0FBTyxHQUFHLENBQUMscUJBQXFCLHNCQUFzQixFQUFFLFNBQVMsVUFBVSxDQUFDO0FBQzVFLFdBQU8sR0FBRyxDQUFDLGtCQUFrQixLQUFLLFVBQVEsS0FBSyxlQUFlLFVBQVUsQ0FBQztBQUN6RSxXQUFPLEdBQUcsT0FBTyxLQUFLLFdBQVMsTUFBTSxTQUFTLGFBQWEsQ0FBQyxDQUFDO0FBQUEsRUFDOUQsQ0FBQztBQUVELE9BQUssK0VBQStFLFlBQVk7QUFDL0YsVUFBTSxFQUFFLFNBQVMsUUFBUSxXQUFXLGFBQWEsV0FBVyxJQUFJLE1BQU0seUJBQXlCO0FBQy9GLFVBQU0sRUFBRSxzQkFBc0Isa0JBQWtCLElBQUk7QUFDcEQsWUFBUSxtQkFBbUIsSUFBSTtBQUMvQixVQUFNLHFCQUFxQixvQkFBb0IsWUFBWSxFQUFFLFNBQVMsWUFBWSxDQUFDO0FBRW5GLFdBQU8sWUFBWSxxQkFBcUIsdUJBQXVCLFdBQVcsR0FBRyxJQUFJO0FBQ2pGLFdBQU8sWUFBWSxxQkFBcUIsdUJBQXVCLFNBQVMsR0FBRyxJQUFJO0FBQy9FLFdBQU8sWUFBWSxxQkFBcUIsc0JBQXNCLEdBQUcsQ0FBQztBQUNsRSxXQUFPLFlBQVkscUJBQXFCLGFBQWEsVUFBVSxHQUFHLE1BQVM7QUFDM0UsV0FBTyxHQUFHLENBQUMscUJBQXFCLHNCQUFzQixFQUFFLFNBQVMsVUFBVSxDQUFDO0FBQzVFLFdBQU8sR0FBRyxDQUFDLGtCQUFrQixLQUFLLFVBQVEsS0FBSyxlQUFlLFVBQVUsQ0FBQztBQUN6RSxXQUFPLEdBQUcsT0FBTyxLQUFLLFdBQVMsTUFBTSxTQUFTLGdCQUFnQixDQUFDLENBQUM7QUFBQSxFQUNqRSxDQUFDO0FBRUQsT0FBSyxnRUFBZ0UsWUFBWTtBQUNoRixVQUFNLEVBQUUsU0FBUyxRQUFRLFdBQVcsYUFBYSxXQUFXLElBQUksTUFBTSx5QkFBeUI7QUFDL0YsVUFBTSxFQUFFLHFCQUFxQixJQUFJO0FBQ2pDLFlBQVEsaUJBQWlCLElBQUk7QUFDN0IsVUFBTSxxQkFBcUIsb0JBQW9CLFlBQVksRUFBRSxTQUFTLFVBQVUsQ0FBQztBQUVqRixXQUFPLFlBQVkscUJBQXFCLHVCQUF1QixTQUFTLEdBQUcsSUFBSTtBQUMvRSxXQUFPLFlBQVkscUJBQXFCLHNCQUFzQixTQUFTLEdBQUcsS0FBSztBQUMvRSxXQUFPLFlBQVkscUJBQXFCLHVCQUF1QixXQUFXLEdBQUcsSUFBSTtBQUNqRixXQUFPLFlBQVkscUJBQXFCLHFCQUFxQixHQUFHLFNBQVM7QUFDekUsV0FBTyxZQUFZLHFCQUFxQixzQkFBc0IsR0FBRyxDQUFDO0FBQ2xFLFdBQU8sWUFBWSxxQkFBcUIsYUFBYSxVQUFVLEdBQUcsTUFBUztBQUMzRSxXQUFPLEdBQUcsQ0FBQyxxQkFBcUIsc0JBQXNCLEVBQUUsU0FBUyxVQUFVLENBQUM7QUFDNUUsV0FBTyxHQUFHLE9BQU8sS0FBSyxXQUFTLE1BQU0sU0FBUyxhQUFhLENBQUMsQ0FBQztBQUFBLEVBQzlELENBQUM7QUFFRCxPQUFLLHNFQUFzRSxZQUFZO0FBQ3RGLFVBQU0sVUFBVSxNQUFNLG9CQUFvQjtBQUMxQyxVQUFNLEVBQUUsT0FBTyxzQkFBc0IsZUFBZSxXQUFXLG1CQUFtQixJQUFJO0FBQ3RGLFVBQU0sbUJBQW1CLGlCQUFpQixXQUFXLGNBQWMsRUFBRSxPQUFPLGFBQWEsQ0FBQztBQUMxRixVQUFNLFFBQVEsTUFBTSxtQkFBbUIsU0FBUyxTQUFTO0FBQ3pELFVBQU0sUUFBUSxRQUFRLE9BQU8sU0FBUztBQUN0QyxVQUFNLFdBQVcsTUFBTSxZQUFZO0FBQ25DLFdBQU8sR0FBRyxZQUFZLENBQUM7QUFDdkIsV0FBTyxHQUFHLE1BQU0sc0JBQXNCO0FBRXRDLFVBQU0sSUFBSSxjQUFjLG1CQUFtQjtBQUMzQyxVQUFNLHFCQUFxQixvQkFBb0IsQ0FBQztBQUNoRCxVQUFNLG1CQUFtQixTQUFTLENBQUM7QUFDbkMsV0FBTyxZQUFZLHFCQUFxQixzQkFBc0IsU0FBUyxHQUFHLElBQUk7QUFDOUUsV0FBTyxZQUFZLE1BQU0sWUFBWSxPQUFPLFFBQVE7QUFDcEQsVUFBTSxlQUFlLE1BQU0sOEJBQThCLEtBQUs7QUFDOUQsV0FBTyxZQUFZLGFBQWEsUUFBUSxRQUFRO0FBQ2hELGVBQVcsUUFBUSxjQUFjO0FBQ2hDLGFBQU8sWUFBWSxLQUFLLGtCQUFrQixNQUFTO0FBQUEsSUFDcEQ7QUFDQSxXQUFPLFlBQVksTUFBTSxZQUFZLFNBQVM7QUFDOUMsVUFBTSxhQUFhLHFCQUFxQixhQUFhLFNBQVMsR0FBRztBQUNqRSxXQUFPLEdBQUcsWUFBWSxVQUFVLFNBQVMsa0NBQWtDLENBQUM7QUFDNUUsVUFBTSxjQUFjLFlBQVksY0FBYyxtQ0FBbUM7QUFDakYsV0FBTyxHQUFHLENBQUMsZUFBZSxZQUFZLFVBQVUsQ0FBQyxZQUFZLFdBQVc7QUFFeEUsVUFBTSxxQkFBcUIsb0JBQW9CLFNBQVM7QUFDeEQsVUFBTSxTQUFTLE1BQU0sbUJBQW1CLFNBQVMsU0FBUztBQUMxRCxVQUFNLGlCQUFpQixNQUFNLDhCQUE4QixRQUFRLE9BQU8sU0FBUyxDQUFDO0FBQ3BGLFdBQU8sWUFBWSxlQUFlLFFBQVEsUUFBUTtBQUNsRCxlQUFXLFFBQVEsZ0JBQWdCO0FBQ2xDLGFBQU8sR0FBRyxLQUFLLGtCQUFrQiw0REFBNEQ7QUFBQSxJQUM5RjtBQUNBLFdBQU8sR0FBRyxPQUFPLHdCQUF3QixrQkFBa0IseUNBQXlDO0FBQUEsRUFDckcsQ0FBQztBQUVELE9BQUssNElBQTRJLFlBQVk7QUFJNUosVUFBTSxZQUFZLElBQUksTUFBTSxZQUFZO0FBQ3hDLFVBQU0sVUFBVSwrQkFBK0I7QUFDL0MsVUFBTSxRQUFRLENBQUM7QUFDZixVQUFNLFlBQVksUUFBUSxjQUFjLG1CQUFtQjtBQUMzRCxVQUFNLFFBQVEscUJBQXFCLG9CQUFvQixTQUFTO0FBQ2hFLFVBQU0sU0FBUyxRQUFRLGNBQWMsbUJBQW1CO0FBQ3hELFlBQVEsaUJBQWlCLElBQUk7QUFDN0IsVUFBTSxpQ0FBaUMsV0FBVyxNQUFNO0FBQ3ZELGNBQVEsZUFBZSxNQUFNO0FBQzVCLGNBQU07QUFBQSxNQUNQLENBQUM7QUFDRCxjQUFRLGNBQWMsa0JBQWtCLE1BQU07QUFBQSxJQUMvQyxDQUFDO0FBQUEsRUFDRixDQUFDO0FBRUQsT0FBSyxzSUFBc0ksWUFBWTtBQUl0SixVQUFNLFlBQVksSUFBSSxNQUFNLFlBQVk7QUFDeEMsVUFBTSxVQUFVLCtCQUErQixFQUFFLFlBQVksS0FBSyxDQUFDO0FBQ25FLFVBQU0sU0FBUyxRQUFRLGNBQWMsbUJBQW1CO0FBQ3hELFlBQVEsaUJBQWlCLElBQUk7QUFDN0IsVUFBTSxpQ0FBaUMsV0FBVyxNQUFNO0FBQ3ZELGNBQVEsZUFBZSxNQUFNO0FBQzVCLGNBQU07QUFBQSxNQUNQLENBQUM7QUFDRCxXQUFLLFFBQVEscUJBQXFCLG9CQUFvQixRQUFRLEVBQUUsU0FBUyxRQUFRLGNBQWMsbUJBQW1CLEVBQUUsQ0FBQztBQUNySCxjQUFRLFlBQVk7QUFBQSxJQUNyQixDQUFDO0FBQUEsRUFDRixDQUFDO0FBRUQsT0FBSyx1RUFBdUUsWUFBWTtBQUN2RixVQUFNLFNBQVMsTUFBTSxrQkFBa0IsR0FBRyxRQUFRLElBQUksQ0FBQyxvRkFBb0Y7QUFDM0ksVUFBTSxjQUFjO0FBQ3BCLFdBQU8sR0FBRyxPQUFPLFNBQVMsNENBQTRDLFdBQVcsRUFBRSxDQUFDO0FBQ3BGLFdBQU8sR0FBRyxPQUFPLFNBQVMscUVBQXFFLFdBQVcsRUFBRSxDQUFDO0FBQzdHLFdBQU8sR0FBRyxPQUFPLFNBQVMseUVBQXlFLFdBQVcsRUFBRSxDQUFDO0FBQ2pILFdBQU8sR0FBRyxDQUFDLE9BQU8sU0FBUyw0Q0FBNEMsQ0FBQztBQUN4RSxXQUFPLEdBQUcsQ0FBQyxPQUFPLFNBQVMscUVBQXFFLENBQUM7QUFDakcsV0FBTyxHQUFHLENBQUMsT0FBTyxTQUFTLHlFQUF5RSxDQUFDO0FBQUEsRUFDdEcsQ0FBQztBQUNGLENBQUM7IiwKICAibmFtZXMiOiBbXQp9Cg==
