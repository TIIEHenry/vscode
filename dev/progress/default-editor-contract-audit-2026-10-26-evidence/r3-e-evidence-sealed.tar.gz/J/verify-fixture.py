from pathlib import Path
import runpy,sys
sys.dont_write_bytecode=True
assert len(sys.argv)==1,'Use common/verify-fixtures.py J for the canonical output'
sys.argv=[str(Path(__file__).resolve().parent.parent/'common/verify-fixtures.py'),'J']
runpy.run_path(sys.argv[0],run_name='__main__')
