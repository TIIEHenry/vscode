const fs=require('node:fs'),path=require('node:path');
const{chromium}=require('/home/clarence/Projects/Agents/vscode-WorkTrees/merge/node_modules/playwright-core');
(async()=>{
 const info=JSON.parse(fs.readFileSync(path.join(__dirname,'launch.json')));
 const browser=await chromium.connectOverCDP('http://127.0.0.1:'+info.cdpPort);
 try{
  const page=browser.contexts().flatMap(context=>context.pages()).find(page=>page.url().includes(info.repo+'/out/')&&page.url().includes('/workbench-dev.html'));
  if(!page)throw Error('fresh own default editor absent');
  await page.waitForFunction(()=>!!window.driver);await page.evaluate(()=>window.driver.whenWorkbenchRestored());
  await page.evaluate(async binding=>{
   if(window.__eAfter)throw Error('fresh observer already exists');
   const root=location.href.split('/out/')[0]+'/out/';
   const{CommandsRegistry,ICommandService}=await import(root+'vs/platform/commands/common/commands.js');
   const{IInstantiationService}=await import(root+'vs/platform/instantiation/common/instantiation.js');
   const{IEditorService}=await import(root+'vs/workbench/services/editor/common/editorService.js');
   const{IEditorGroupsService}=await import(root+'vs/workbench/services/editor/common/editorGroupsService.js');
   const{IConversationRosterService}=await import(root+'vs/workbench/contrib/conversation/browser/conversationStubService.js');
   const{IUniverseAgentConnection}=await import(root+'vs/platform/universeAgent/common/universeAgentConnection.js');
   const{IWorkbenchEnvironmentService}=await import(root+'vs/workbench/services/environment/common/environmentService.js');
   const{IConversationSessionWindowService}=await import(root+'vs/workbench/contrib/conversation/browser/conversationSessionWindowService.js');
   const b=window.__eAfter={runId:binding.runId,frozenSourceHead:binding.explicitReadySource,frozenOutputsSha256:binding.frozenOutputsSha256,attempt:2,connectionEvents:[],uiErrors:[],startedAt:Date.now()};
   const registration=CommandsRegistry.registerCommand('eAfter.attempt2.capture',accessor=>{
    Object.assign(b,{inst:accessor.get(IInstantiationService),commands:accessor.get(ICommandService),editors:accessor.get(IEditorService),groups:accessor.get(IEditorGroupsService),roster:accessor.get(IConversationRosterService),connection:accessor.get(IUniverseAgentConnection),environment:accessor.get(IWorkbenchEnvironmentService),windows:accessor.get(IConversationSessionWindowService)});
   });
   try{await window.driver.executeCommand('eAfter.attempt2.capture');}finally{registration.dispose();}
   b.describe=input=>input?{ctor:input.constructor.name,typeId:input.typeId,resource:input.resource?.toString(),name:input.getName?.()}:null;
   b.connectionListener=b.connection.onDidChangeConnection(value=>b.connectionEvents.push({at:Date.now(),snapshot:value}));
   window.addEventListener('error',event=>b.uiErrors.push({at:Date.now(),message:event.message}));
   window.addEventListener('unhandledrejection',event=>b.uiErrors.push({at:Date.now(),message:String(event.reason)}));
   if(b.environment.isSessionsWindow)throw Error('not default editor');
  },info);
  console.log(JSON.stringify({attempt:2,ownedWindow:page.url(),cdpPort:info.cdpPort}));
 }finally{await browser.close();}
})().catch(error=>{console.error(error);process.exitCode=1});
