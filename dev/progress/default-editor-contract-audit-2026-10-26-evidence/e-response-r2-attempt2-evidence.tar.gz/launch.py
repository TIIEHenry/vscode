from pathlib import Path
import json, os, select, subprocess, time
base = Path(__file__).resolve().parent
auth = json.loads((base/'e-attempt2-authorization.json').read_text())
home = Path(auth['engineHome'])
assert home.is_dir() and not home.is_symlink() and home.stat().st_uid == os.getuid() and home.stat().st_mode & 0o077 == 0 and not list(home.iterdir())
assert not (base/'launch.json').exists()
subprocess.run(['rtk','proxy','python3',str(base/'guard.py'),'before-launch'],check=True)
readfd, writefd = os.pipe()
with (base/'xvfb.log').open('w') as log:
    xvfb = subprocess.Popen(['rtk','proxy','Xvfb','-displayfd',str(writefd),'-screen','0','1920x1200x24','-nolisten','tcp'],pass_fds=(writefd,),stdin=subprocess.DEVNULL,stdout=log,stderr=subprocess.STDOUT,start_new_session=True)
os.close(writefd)
stat = Path('/proc',str(xvfb.pid),'stat').read_text().split(') ')[-1].split()
lease = {'attempt':2,'createdBy':'/root/sources_audit','xvfbPid':xvfb.pid,'xvfbStartTimeTicks':stat[19],'startedAt':time.time(),'released':False,'runId':auth['runId'],'sourceHead':auth['sourceHead'],'engineHome':str(home)}
(base/'lease.json').write_text(json.dumps(lease,indent=2)+'\n')
assert select.select([readfd],[],[],8)[0]
display = ':'+os.read(readfd,128).decode().strip();os.close(readfd)
assert display[1:].isdigit()
lease['display']=display
(base/'lease.json').write_text(json.dumps(lease,indent=2)+'\n')
env=os.environ.copy();env.update(DISPLAY=display,CODE_OSS_DEV_AUTHED_SHARED_DATA_DIR=str(base/'empty-shared'),UNIVERSE_AGENT_HOME=str(home),PYTHONDONTWRITEBYTECODE='1');env.pop('ELECTRON_RUN_AS_NODE',None)
launcher=Path('/home/clarence/Projects/Agents/vscode/.agents/skills/launch/scripts/launch.sh')
args=['rtk','proxy','bash',str(launcher),'--repo','/home/clarence/Projects/Agents/vscode-WorkTrees/merge','--source-user-data-dir',str(base/'empty-seed'),'--skip-prelaunch','--disable-workspace-trust','--','--new-window','--enable-smoke-test-driver','--use-mock-keychain','--no-sandbox','--disable-gpu',str(base/'after.code-workspace')]
result=subprocess.run(args,env=env,capture_output=True,text=True,start_new_session=True)
(base/'launcher.log').write_text(result.stdout+'\n'+result.stderr)
assert result.returncode==0,result.stderr
info=json.loads(result.stdout.strip().splitlines()[-1]);assert info['agents'] is False
info.update(attempt=2,createdBy='/root/sources_audit',display=display,xvfbPid=xvfb.pid,engineHome=str(home),runId=auth['runId'],explicitReadySource=auth['sourceHead'],explicitReadySourceTree=auth['sourceTree'],freezeNoticeSha256=auth['jFreezeNoticeSha256'],eFreezeNoticeSha256=auth['freezeNoticeSha256'],frozenOutputsSha256=auth['frozenOutputsSha256'],workspace=str(base/'after.code-workspace'))
(base/'launch.json').write_text(json.dumps(info,indent=2)+'\n')
mainstat=Path('/proc',str(info['pid']),'stat').read_text().split(') ')[-1].split()
lease.update(runDir=info['runDir'],electronPid=info['pid'],electronStartTimeTicks=mainstat[19])
(base/'lease.json').write_text(json.dumps(lease,indent=2)+'\n')
print(json.dumps({key:info[key] for key in ['pid','cdpPort','mainPort','display','xvfbPid','runDir','engineHome']}))
