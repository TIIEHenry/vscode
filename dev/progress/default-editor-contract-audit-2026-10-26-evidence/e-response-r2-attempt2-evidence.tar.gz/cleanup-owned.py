from pathlib import Path
import json, os, signal, time, shutil, hashlib
base=Path(__file__).resolve().parent
launch=json.loads((base/'launch.json').read_text());lease=json.loads((base/'lease.json').read_text());server=json.loads((base/'transport-episode-2/server-started.json').read_text())
def process(pid):
    p=Path('/proc',str(pid))
    try:
        st=(p/'stat').read_text().split(') ')[-1].split()
        return {'pid':pid,'ppid':int(st[1]),'state':st[0],'startTicks':st[19],'cmdline':(p/'cmdline').read_bytes().replace(b'\0',b' ').decode(errors='replace')}
    except FileNotFoundError:return None
roots=[(lease['electronPid'],lease['electronStartTimeTicks']),(lease['xvfbPid'],lease['xvfbStartTimeTicks']),(server['pid'],server['processStartTimeTicks'])]
for pid,ticks in roots:
    row=process(pid);assert row and row['startTicks']==ticks,(pid,row,ticks)
assert launch['runDir'] in process(lease['electronPid'])['cmdline']
assert 'Xvfb' in process(lease['xvfbPid'])['cmdline']
assert str(base/'transport-episode-2/fake-uds-engine.cjs') in process(server['pid'])['cmdline']
socket=Path(server['socket']);assert socket.lstat().st_ino==server['socketInode']
allp=[row for p in Path('/proc').iterdir() if p.name.isdigit() for row in [process(int(p.name))] if row]
owned={pid for pid,_ in roots}
while True:
    additions={r['pid'] for r in allp if r['ppid'] in owned};new=owned|additions
    if new==owned:break
    owned=new
records=[r for r in allp if r['pid'] in owned]
(base/'final-live-owned-processes.json').write_text(json.dumps({'at':time.time(),'roots':roots,'processes':records,'sameMainAndProfileThroughoutTransportLoss':True,'finalRendererState':'final-live-renderer-state.json','finalMainState':'final-live-main-runtime.json','finalPublicConnectionPhase':'closed'},indent=2)+'\n')
logs=base/'profile-logs-attempt2';logs.mkdir()
run=Path(launch['runDir']);assert str(run).startswith('/tmp/code-oss-dev-20261027-') and run.is_dir() and not run.is_symlink()
if (run/'code.log').exists():shutil.copyfile(run/'code.log',logs/'code.before-stop.log')
if (Path(launch['userDataDir'])/'logs').exists():shutil.copytree(Path(launch['userDataDir'])/'logs',logs/'user-data-logs-before-stop')
actions=[]
def stop(row,sig):
    current=process(row['pid'])
    if current and current['state']!='Z':
        assert current['startTicks']==row['startTicks'],'PID reuse; never signal'
        os.kill(row['pid'],sig);actions.append({'pid':row['pid'],'startTicks':row['startTicks'],'signal':signal.Signals(sig).name,'at':time.time()})
lookup={r['pid']:r for r in records}
stop(lookup[server['pid']],signal.SIGTERM);time.sleep(.25)
assert not socket.exists()
stop(lookup[lease['electronPid']],signal.SIGTERM);time.sleep(2)
stop(lookup[lease['xvfbPid']],signal.SIGTERM);time.sleep(.5)
for row in records:
    current=process(row['pid'])
    if current and current['state']!='Z':stop(row,signal.SIGTERM)
time.sleep(.5)
for row in records:
    current=process(row['pid'])
    if current and current['state']!='Z':stop(row,signal.SIGKILL)
time.sleep(.25)
remaining=[process(r['pid']) for r in records if process(r['pid']) and process(r['pid'])['state']!='Z']
assert not remaining,remaining
if (run/'code.log').exists():shutil.copyfile(run/'code.log',logs/'code.after-stop.log')
if (Path(launch['userDataDir'])/'logs').exists():shutil.copytree(Path(launch['userDataDir'])/'logs',logs/'user-data-logs-after-stop')
logFiles=[{'path':str(p.relative_to(logs)),'size':p.stat().st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()} for p in sorted(logs.rglob('*')) if p.is_file()]
home=Path(launch['engineHome']);assert str(home).startswith('/tmp/vscode-e-after-home-') and not home.is_symlink() and home.stat().st_uid==os.getuid()
assert not list(home.iterdir()),'Do not remove unexpected home contents'
shutil.rmtree(run);home.rmdir()
record={'at':time.time(),'createdBy':'/root/sources_audit','roots':roots,'actions':actions,'remainingOwnedLiveProcesses':remaining,'runDirRemoved':not run.exists(),'engineHomeRemoved':not home.exists(),'socketAbsent':not socket.exists(),'profileLogFiles':logFiles,'jArtifactsTouched':False,'fixtureRootsRemoved':False,'sourceOutMutated':False}
(base/'attempt2-cleanup.json').write_text(json.dumps(record,indent=2)+'\n')
lease.update(released=True,releasedAt=time.time(),cleanupEvidence='attempt2-cleanup.json');(base/'lease.json').write_text(json.dumps(lease,indent=2)+'\n')
print(json.dumps({'remainingOwnedLiveProcesses':len(remaining),'runDirRemoved':record['runDirRemoved'],'homeRemoved':record['engineHomeRemoved'],'profileLogFiles':len(logFiles),'actions':actions}),flush=True)
