'use strict';
// Controlled temporary transport only. Actual product services/IPC/host/leases remain real.
const fs=require('node:fs'),path=require('node:path'),crypto=require('node:crypto'),assert=require('node:assert/strict');
const {createRequire}=require('node:module');
const base=__dirname;let root=base;while(!fs.existsSync(path.join(root,'run-config.json'))){const parent=path.dirname(root);if(parent===root)throw Error('new run root absent');root=parent;}
const {loadRuntime}=require(path.join(root,'common/gate.cjs'));
const ctx=loadRuntime('E',{launch:true,fake:true}),{config,contract}=ctx,freeze=ctx.notice,repo=config.runtimeRepo,owner=config.owner;
const route={engineHome:config.engineHomes.E},freezeNoticeSha256=ctx.auth.freezeNoticeSha256,frozenOutputsSha256=ctx.auth.frozenOutputsSha256;
const digest=bytes=>crypto.createHash('sha256').update(bytes).digest('hex');
for(const file of freeze.outputs){assert.equal(digest(fs.readFileSync(path.join(repo,file.path))),file.sha256);assert.equal(digest(fs.readFileSync(path.join(repo,file.sourcePath))),file.sourceSha256);}
const engineHome = route.engineHome;
assert.equal(engineHome, config.engineHomes.E);
const homeStat = fs.lstatSync(engineHome);
assert.ok(homeStat.isDirectory() && !homeStat.isSymbolicLink());
assert.equal(homeStat.uid, process.getuid());
assert.equal(homeStat.mode & 0o077, 0);
const socket = path.join(engineHome, 'server.sock');
assert.ok(!fs.existsSync(socket), 'Never unlink another live or stale socket automatically');
assert.ok(!fs.existsSync(path.join(engineHome, 'server.lock')));
assert.ok(!fs.existsSync(path.join(base, 'server-started.json')), 'Inspect and clean the previous owned run first');
const grpc = createRequire(path.join(repo, 'package.json'))('@grpc/grpc-js');
const sessionId = config.fixtureSession;
const rootAgent = 'root';
const sessionTitle = 'D E controlled transport after';
const callsLog = path.join(base, 'fake-io.jsonl');
const commandsPath = path.join(base, 'fake-control.jsonl');
assert.ok(!fs.existsSync(callsLog), 'Inspect the previous fake I/O transcript before a new run');
assert.ok(!fs.existsSync(commandsPath) || fs.statSync(commandsPath).size === 0, 'Do not replay old fixture control commands');
const log = data => fs.appendFileSync(callsLog, JSON.stringify({ at: Date.now(), fakeIo: true, ...data }) + '\n');
const vint = value => {
  let n = BigInt(value); const out = [];
  assert.ok(n >= 0n);
  do { let b = Number(n & 127n); n >>= 7n; if (n) b |= 128; out.push(b); } while (n);
  return Buffer.from(out);
};
const int = (field, value) => Buffer.concat([vint(field * 8), vint(value)]);
const msg = (field, value) => Buffer.concat([vint(field * 8 + 2), vint(value.length), value]);
const str = (field, value) => msg(field, Buffer.from(value, 'utf8'));
const cat = (...parts) => Buffer.concat(parts.flat());
const parse = bytes => {
  const out = []; let p = 0;
  const read = () => { let n = 0n, shift = 0n; for (;;) { assert.ok(p < bytes.length); const b = bytes[p++]; n |= BigInt(b & 127) << shift; if (!(b & 128)) return n; shift += 7n; assert.ok(shift < 70n); } };
  while (p < bytes.length) {
    const key = Number(read()), field = key >> 3, wire = key & 7;
    if (wire === 0) out.push({ field, wire, value: read().toString() });
    else if (wire === 2) { const size = Number(read()); assert.ok(size <= bytes.length - p); out.push({ field, wire, bytes: bytes.subarray(p, p + size) }); p += size; }
    else throw new Error('Temporary fixture only supports existing varint/length-delimited fields');
  }
  return out;
};
const fieldBytes = (bytes, field) => parse(bytes).findLast(x => x.field === field && x.wire === 2)?.bytes;
const fieldText = (bytes, field) => fieldBytes(bytes, field)?.toString('utf8') ?? '';
const methods = ['SystemService.HealthCheck', 'SessionService.List', 'SessionService.Info', 'SessionService.Resume', 'SessionService.Create', 'SessionService.GetHistory', 'SessionService.SessionEventStream', 'AgentService.Chat', 'AgentService.Tree', 'PermissionService.Respond', 'AgentService.RespondQuestion', 'AgentService.SendClientToolResponse'];
const agent = cat(str(1, rootAgent), str(2, 'D E fixture root'), int(4, 2));
const summary = cat(str(1, sessionId), int(2, 2), str(7, sessionTitle));
const streams = new Set();
const pending = new Map();
const held = new Map();
let commandLinesRead = 0;
const event = (field, body) => cat(str(1, sessionId), msg(field, body));
const questionItem = request => cat(str(1, request.itemId ?? 'choose'), str(2, 'D E retained answers'), str(3, 'Choose a label and preserve custom text'), msg(4, str(2, 'Alpha')), msg(4, str(2, 'Beta')), int(5, 1), int(6, 1));
const pendingBody = request => cat(str(1, request.id), int(2, { permission: 1, question: 2, clientTool: 3 }[request.kind]), str(3, request.toolName ?? 'D_E_fixture_no_execution'), str(4, 'D E controlled ' + request.kind), str(5, rootAgent), request.kind === 'question' ? msg(7, questionItem(request)) : Buffer.alloc(0), request.kind === 'clientTool' ? str(8, '{"fixture":true,"execute":false}') : Buffer.alloc(0));
const overlay = () => event(44, cat(int(1, 1), [...pending.values()].map(p => msg(6, pendingBody(p)))));
const broadcast = bytes => { for (const call of streams) call.write(bytes); log({ type: 'stream-emitted', bytes: bytes.toString('hex'), streams: streams.size }); };
const server = new grpc.Server();
function add(service, method, requestStream, responseStream, handler) {
  const key = service + '_' + method;
  server.addService({ [key]: { path: '/agentservice.' + service + '/' + method, requestStream, responseStream, requestDeserialize: Buffer.from, requestSerialize: Buffer.from, responseDeserialize: Buffer.from, responseSerialize: Buffer.from } }, { [key]: handler });
}
function unary(service, method, handler) {
  add(service, method, false, false, (call, callback) => {
    log({ type: 'unary', service, method, requestHex: call.request.toString('hex') });
    try { handler(call.request, callback); } catch (error) { callback({ code: grpc.status.INTERNAL, details: error.message }); }
  });
}
unary('SystemService', 'HealthCheck', (_, cb) => cb(null, Buffer.alloc(0)));
unary('SystemService', 'Connect', (_, cb) => cb(null, msg(3, cat(methods.map(m => str(1, m))))));
unary('SessionService', 'List', (_, cb) => cb(null, cat(msg(1, summary), int(2, 1))));
unary('SessionService', 'Info', (_, cb) => cb(null, cat(str(1, sessionId), msg(2, agent))));
unary('SessionService', 'Create', (request, cb) => {
  // Only the single advertised catalog fixture is allowed. Never create user sessions.
  const requested = fieldText(request, 4);
  if (requested && requested !== sessionId) return cb({ code: grpc.status.INVALID_ARGUMENT, details: 'Only the D E catalog fixture exists' });
  cb(null, str(1, sessionId));
});
unary('SessionService', 'Resume', (request, cb) => cb(null, fieldText(request, 1) === sessionId ? cat(int(1, 1), msg(3, agent)) : str(2, 'Unknown controlled session')));
unary('SessionService', 'GetHistory', (_, cb) => cb(null, Buffer.alloc(0)));
unary('AgentService', 'Tree', (_, cb) => cb(null, msg(1, agent)));
function response(kind, request, cb) {
  assert.equal(fieldText(request, 1), sessionId);
  const inner = kind === 'permission' ? request : fieldBytes(request, 2);
  assert.ok(inner);
  const id = fieldText(inner, kind === 'permission' ? 2 : 1);
  assert.ok(pending.has(id), 'Response must refer to a real emitted fixture request');
  const token = crypto.randomUUID();
  held.set(token, { kind, id, cb });
  log({ type: 'response-held', token, kind, id, requestHex: request.toString('hex'), answersHex: kind === 'question' ? inner.toString('hex') : undefined, customText: kind === 'question' ? fieldText(inner, 3) : undefined });
}
unary('PermissionService', 'Respond', (request, cb) => response('permission', request, cb));
unary('AgentService', 'RespondQuestion', (request, cb) => response('question', request, cb));
unary('AgentService', 'SendClientToolResponse', (request, cb) => response('clientTool', request, cb));
add('SessionService', 'SessionEventStream', true, true, call => {
  call.once('data', request => {
  assert.equal(fieldText(request, 1), sessionId);
  log({ type: 'session-stream-handshake', requestHex: request.toString('hex') });
  streams.add(call);
  call.on('cancelled', () => streams.delete(call));
  call.on('error', error => { streams.delete(call); log({ type: 'stream-error', message: error.message }); });
  call.write(event(10, cat(int(1, 1), int(2, 0), int(3, 1), int(4, 0))));
  call.write(overlay());
  log({ type: 'real-session-stream-subscribed', sessionId, streams: streams.size });
  });
});
add('AgentService', 'Chat', true, true, call => {
  call.on('data', request => {
    log({ type: 'chat-write', requestHex: request.toString('hex') });
    // This fixture tests unary recovery only, never performs workspace tools/chat.
    call.write(cat(str(1, sessionId), str(2, rootAgent)));
  });
  call.on('error', error => log({ type: 'chat-error', message: error.message }));
  call.on('end', () => call.end());
});
function control(command) {
  if (command.op === 'emit') {
    assert.ok(['permission', 'question', 'clientTool'].includes(command.kind));
    assert.match(command.id, /^D-E-[A-Za-z0-9-]+$/);
    assert.ok(!pending.has(command.id));
    pending.set(command.id, { kind: command.kind, id: command.id, itemId: command.itemId });
    broadcast(overlay());
  } else if (command.op === 'settle') {
    assert.ok(['false', 'reject', 'success'].includes(command.outcome));
    const item = held.get(command.token); assert.ok(item, 'Unknown held unary token');
    held.delete(command.token);
    if (command.outcome === 'reject') item.cb({ code: grpc.status.INVALID_ARGUMENT, details: 'D E controlled rejected unary' });
    else item.cb(null, command.outcome === 'success' ? int(1, 1) : str(2, 'D E controlled ok:false unary'));
    if (command.outcome === 'success') pending.delete(item.id);
    log({ type: 'response-settled', ...command, kind: item.kind, id: item.id });
    // Wait for the real UI's immediate local success cleanup to be observed
    // before an explicit publish command sends the fake authoritative snapshot.
  } else if (command.op === 'publish') broadcast(overlay());
  else throw new Error('Unknown temporary control operation');
}
const timer = setInterval(() => {
  if (!fs.existsSync(commandsPath)) return;
  const content = fs.readFileSync(commandsPath, 'utf8');
  const lines = content.split('\n'); lines.pop(); // Only complete appended lines.
  while (commandLinesRead < lines.length) {
    const line = lines[commandLinesRead++];
    if (!line.trim()) continue;
    try { const command = JSON.parse(line); log({ type: 'control', command }); control(command); }
    catch (error) { log({ type: 'control-error', line, message: error.message }); }
  }
}, 100);
let socketInode;
const startedPath = path.join(base, 'server-started.json');
server.bindAsync('unix:' + socket, grpc.ServerCredentials.createInsecure(), error => {
  if (error) throw error;
  fs.chmodSync(socket, 0o600); socketInode = fs.lstatSync(socket).ino;
  fs.writeFileSync(startedPath, JSON.stringify({ runId: contract.runId, freezeNoticeSha256, frozenOutputsSha256, createdBy: owner, pid: process.pid, socket, socketInode, sessionId, processStartTimeTicks: fs.readFileSync('/proc/self/stat', 'utf8').split(') ').at(-1).split(' ')[19], sourceHead: freeze.sourceHead, transport: 'FAKE UDS unary/stream I/O', startedAt: new Date().toISOString() }, null, 2) + '\n');
  log({ type: 'fake-server-started', pid: process.pid, socket, sourceHead: freeze.sourceHead });
});
function stop(signal) {
  clearInterval(timer);
  server.forceShutdown();
  try { if (fs.lstatSync(socket).ino === socketInode) fs.unlinkSync(socket); } catch (error) { if (error.code !== 'ENOENT') throw error; }
  log({ type: 'fake-server-stopped', signal, pid: process.pid });
  process.exit(0);
}
process.on('SIGINT', () => stop('SIGINT'));
process.on('SIGTERM', () => stop('SIGTERM'));
