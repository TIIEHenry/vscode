from pathlib import Path
import json, subprocess, time
base=Path(__file__).resolve().parent;episode=base/'transport-episode-2';session='D-E-attempt2-controlled-session';a='D-E-A2-transport-old-failure';b='D-E-A2-transport-old-busy';records=[]
def control(value):
    with (episode/'fake-control.jsonl').open('a') as f:f.write(json.dumps(value)+'\n')
    time.sleep(.2)
def held(id):return [v for v in map(json.loads,(episode/'fake-io.jsonl').read_text().splitlines()) if v.get('type')=='response-held' and v.get('id')==id]
def step(n,stage,**action):
    label=f'{n:02}-A2-transport-{stage}';action['label']=label
    r=subprocess.run(['rtk','proxy','node',str(base/'driver.cjs'),json.dumps(action)],capture_output=True,text=True)
    with (base/'driver-stdout.jsonl').open('a') as f:f.write(json.dumps({'action':action,'exit':r.returncode,'stdout':r.stdout,'stderr':r.stderr})+'\n')
    records.append(label)
    if r.returncode:raise RuntimeError(r.stdout+r.stderr)
    value=json.loads((base/'steps'/(label+'.json')).read_text());print(json.dumps({'label':label,'result':value.get('result')}),flush=True);return value
def seats(value,id):return [s for s in value['state']['seats'] if s.get('sessionKey')==session and s.get('turnId')==id]
def sel(id,suffix):return f'[data-session-key="{session}"] [data-turn-id="{id}"] '+suffix
try:
    before=json.loads((base/'transport-before-loss.json').read_text());lost=json.loads((base/'steps/60-A2-transport-loss-observed.json').read_text());reconnected=json.loads((base/'steps/61-A2-transport-restart-before-public-recovery.json').read_text())
    assert not lost['state']['connected'] and lost['state']['connection']['phase']['kind']=='disconnected'
    assert reconnected['state']['connected'] and reconnected['state']['connection']['linkId']!=before['linkId']
    assert all(p['leaseSessionId']==session and p['responseProjection']['scope']['id']!=before['paneScopes'][0]['id'] and not p['snapshot']['pendingActions'] for p in reconnected['state']['actualPaneDiagnostics'])
    control({'op':'emit','kind':'permission','id':a});control({'op':'emit','kind':'clientTool','id':b})
    fresh=step(62,'new-link-same-request-ids-fresh-enabled',type='inspect')
    assert len(seats(fresh,a))==len(seats(fresh,b))==2
    assert all(s['busy']!='true' and "Couldn't send" not in s['text'] and any(c.get('ariaDisabled')=='false' for c in s['controls']) for s in seats(fresh,a)+seats(fresh,b))
    step(63,'new-link-permission-normal-keyboard',type='keyboardClick',selector=sel(a,'[role="button"]'),index=0)
    busy=step(64,'new-link-clientTool-normal-click',type='click',selector=sel(b,'.conversation-process-fold-tool-respond'),index=0)
    assert all(s['busy']=='true' for s in seats(busy,a)+seats(busy,b)) and len(held(a))==len(held(b))==1
    control({'op':'settle','token':held(a)[0]['token'],'outcome':'success'});control({'op':'settle','token':held(b)[0]['token'],'outcome':'success'})
    success=step(65,'new-link-local-success-before-publish',type='inspect')
    assert not seats(success,a) and not seats(success,b)
    assert all(not p['snapshot']['pendingActions'] for p in success['state']['actualPaneDiagnostics'])
    assert success['state']['uiErrors']==[]
    control({'op':'publish'})
    result={'state':'PASS','actualTransportLoss':True,'sameMainAndProfile':True,'oldLinkId':before['linkId'],'newLinkId':reconnected['state']['connection']['linkId'],'oldScope':before['paneScopes'][0],'newScopes':[p['responseProjection']['scope'] for p in reconnected['state']['actualPaneDiagnostics']],'actualPaneAutomaticRecovery':True,'publicRecoveryActions':0,'sameRequestIdsFreshAndSuccessful':True,'staleBusyFailureNotCarriedIntoNewBinding':True,'lossCachePermissionControls':'aria-disabled=false observed at60; not credited as disabled; candidate under architecture review','observerInodeReuseAssertion':'transport-episode-2/observer-inode-reuse-assertion.json','steps':['55-A2-transport-old-permission-pending','56-A2-transport-old-permission-first-held','57-A2-transport-old-permission-failed','58-A2-transport-old-clientTool-pending','59-A2-transport-old-clientTool-held-with-old-permission-failure','60-A2-transport-loss-observed','61-A2-transport-restart-before-public-recovery']+records,'nextNumber':66}
    (base/'transport-restart-result.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result),flush=True)
except Exception as error:
    (base/'transport-new-link-failure.json').write_text(json.dumps({'error':str(error),'steps':records},indent=2)+'\n');raise
