import json, pathlib, subprocess, sys, time
base=pathlib.Path(__file__).resolve().parent
for action in json.load(sys.stdin):
 label=action['label']
 assert not (base/'steps'/(label+'.json')).exists(), 'Never overwrite actual action evidence'
 started=time.time()
 r=subprocess.run(['rtk','proxy','node',str(base/'driver.cjs'),json.dumps(action)],text=True,capture_output=True)
 (base/'steps').mkdir(exist_ok=True)
 (base/'steps'/(label+'.driver.log')).write_text(r.stdout+'\n'+r.stderr)
 with (base/'action-execution.jsonl').open('a') as log:log.write(json.dumps({'action':action,'exitCode':r.returncode,'elapsed':time.time()-started})+'\n')
 if r.returncode:
  print(json.dumps({'FAILED':label,'stderr':r.stderr}),flush=True);raise SystemExit(r.returncode)
 state=json.loads((base/'steps'/(label+'.json')).read_text())['state']
 assert state['connected'] is False and state['connection']['phase']['kind']=='disconnected' and state['connection']['transport']=='idle' and state['connection']['channelAlive'] is False and not state['connectionEvents'], 'Engine isolation failed'
 brief=lambda i:(i.get('modified') or i.get('resource') or i.get('name'))if i else None
 groups=lambda items:[{'id':g['id'],'active':brief(g['active']),'tabs':[brief(i) for i in g['editors']]}for g in items]
 visible=[{'modified':d['modified'],'originalText':d['originalText'],'modifiedText':d['modifiedText'],'readonly':[d['originalReadOnly'],d['modifiedReadOnly']]}for d in state['diffs']if d['visibility']and d['visibility']['width']>0 and d['visibility']['height']>0]
 print(json.dumps({'label':label,'activeSession':state['activeSession'],'main':groups([g for g in state['mainGroups']if g['editors']]),'conversation':[{'session':part['sessionKey'],'groups':groups(part['groups'])}for part in state['conversationParts']],'panel':state['panelRef'],'visibleDiffs':visible,'reviewed':[e['resource']for e in state['changes']['entries']if e['reviewed']],'reviewStatus':state['reviewStatus'],'uiErrors':state['uiErrors']}),flush=True)
