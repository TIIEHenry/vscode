#!/usr/bin/env python3
"""Prepared S2 single-lane driver. Requires final frozen manifest AND new parent lane token."""
import argparse
from datetime import datetime, timezone
from collections import Counter
import fcntl
import hashlib
import json
import os
from pathlib import Path
import re
import signal
import subprocess
import time

parser=argparse.ArgumentParser(description=__doc__)
parser.add_argument('--manifest',type=Path,required=True)
parser.add_argument('--stage',choices=['old','new','quality'],required=True)
parser.add_argument('--lane-token',type=Path,required=True)
parser.add_argument('--old-qualification',type=Path)
args=parser.parse_args()
manifest_path=args.manifest.resolve(); manifest=json.loads(manifest_path.read_text())
token=json.loads(args.lane_token.read_text())
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
assert manifest.get('frozen') is True and manifest.get('candidateOnly') is False
assert manifest.get('runtimeAuthorized') is True and not manifest.get('baselineReferenceOnly')
assert token['manifestSha256']==sha(manifest_path)
assert token['runnerSha256']==sha(__file__)
assert token['authorizedBy']=='/root' and token['externalLaneCoordinated'] is True
assert token['directOfficialElectronApproved'] is True
assert args.stage in token['authorizedStages']
assert datetime.now(timezone.utc)<datetime.fromisoformat(token['expiresUtc'])
assert token['authorizationId']
repo=Path(manifest['repo']).resolve(); scratch=Path(manifest['scratch']).resolve()
assert repo.name in ['C','F'] and str(scratch).startswith('/sdd/tmp/')
here=Path(__file__).resolve().parent
assert sha(here/'s2-transpile.mjs')==manifest['transpileDriverSha256']

OFFICIAL_META = 'Tests are using suiteSetup and setup correctly assertCleanState - check that registries are clean at the start of test running'
assert 'oldGrep' in manifest and manifest['oldGrep'] is None
plan = manifest['testPlan']
assert plan['mode'] == 'complete-files' and plan['expectedPending'] == 0
assert plan['officialMeta'] == [{'fullTitle': OFFICIAL_META, 'expectedCount': 1}]
assert set(manifest['oldTests']) == set(manifest['newTests']) == {row['source'] for row in plan['files']}
assert plan['expectedTotalTests'] == sum(row['expectedBusinessTests'] + len(row['sourceScanFullTitles']) for row in plan['files']) + 1
assert all(isinstance(row['expectedBusinessTests'], int) and row['expectedBusinessTests'] > 0 for row in plan['files'])
scan_titles = {title for row in plan['files'] for title in row['sourceScanFullTitles']}
assert scan_titles == {row['fullTitle'] for row in manifest['sourceReadInputs']}

def git(*a):return subprocess.check_output(['git',*a],cwd=repo)
def check_frozen():
    assert git('rev-parse','HEAD').decode().strip()==manifest['frozenHead']
    assert hashlib.sha256(git('diff','HEAD','--','src')).hexdigest()==manifest['sourceDiffSha256']
    assert not git('ls-files','--others','--exclude-standard','--','src').strip()
    for relative,digest in manifest['sourceSha256'].items():assert sha(repo/relative)==digest,relative
    for entry in manifest['sourceReadInputs']:
        assert entry['role']=='current-live-source-scan-not-raw-baseline-runtime'
        assert entry['excludedFromRawBaselineBusinessEvidence'] is True
        assert entry['actualPath']==str(repo/entry['source'])
        assert entry['sha256']==manifest['sourceSha256'][entry['source']]
        assert sha(entry['actualPath'])==entry['sha256'],entry['actualPath']
    for entry in manifest['controls']:assert sha(entry['path'])==entry['sha256'],entry['path']
    for row in manifest['packages']:
        root=Path(row['root']); metadata=root/'package.json'
        assert metadata.is_file()==row['installed'],row['specifier']
        if row['installed']:
            assert sha(metadata)==row['packageJsonSha256'],str(metadata)
            for entry in row['entryCandidates']:assert sha(entry['path'])==entry['sha256'],entry['path']
    for entry in manifest['electron']['files']:assert sha(entry['path'])==entry['sha256'],entry['path']
    for entry in manifest['executables']:assert sha(entry['path'])==entry['sha256'],entry['path']

def check_out_topology():
    root=repo/'out'
    assert root.resolve()==root and not root.is_symlink()
    count=0
    for path in [root,*root.rglob('*')]:
        stat=path.lstat();assert not path.is_symlink(),str(path)
        if path.is_file():assert stat.st_nlink==1,str(path);count+=1
    return count

check_frozen()
for phase,rows in manifest['phases'].items():
    assert rows,phase
    for entry in rows:
        assert sha(entry['snapshot'])==entry['sha256'],entry['source']
        target=Path(entry['out']);assert target.is_relative_to(repo/'out')
        if phase=='old' and entry['role']=='raw-baseline':
            assert hashlib.sha256(git('show',manifest['baseline']+':'+entry['source'])).hexdigest()==entry['sha256']
        if phase=='old':assert 'universeAgentExpectedOwner' not in entry['source'],'green-only helper leaked into old'
if args.stage=='new':
    assert args.old_qualification,'Parent-reviewed old business red qualification is required.'
    qualification=json.loads(args.old_qualification.read_text())
    assert qualification['acceptedBy']=='/root' and qualification['manifestSha256']==sha(manifest_path)
    assert qualification['businessFailures'] and qualification['fixtureFailures']==0
    assert qualification['loadFailures']==0 and qualification['infrastructureFailures']==0
    assert qualification['sourceScanFailures']==0 and qualification['officialMetaFailures']==0
    old_result_path=scratch/'stage-old'/'old-targets-official-result.json'
    assert qualification['oldOfficialResultSha256']==sha(old_result_path)
    old_contract=json.loads((scratch/'stage-old'/'old-targets-result-contract.json').read_text())
    assert old_contract['valid'] is True
    assert json.loads((scratch/'stage-old'/'completed.json').read_text())['sourceOutStable'] is True
    qualified_titles=[row if isinstance(row,str) else row['fullTitle'] for row in qualification['businessFailures']]
    assert set(qualified_titles).issubset(set(old_contract['eligibleFailureTitles']))
    assert not set(qualified_titles)&(scan_titles|{OFFICIAL_META})

# Fresh process check precedes both nonblocking locks. Never hold a lock while waiting.
ancestors=set();pid=os.getpid()
while pid>1:
    ancestors.add(pid)
    try:pid=int(Path(f'/proc/{pid}/stat').read_text().split()[3])
    except (OSError,ValueError):break
active=[]
for process in Path('/proc').iterdir():
    if not process.name.isdigit() or int(process.name) in ancestors:continue
    try:
        command=(process/'cmdline').read_bytes().replace(b'\0',b' ').decode(errors='replace')
        if re.search(r'(?:/|\s)(?:gulp\.js|tsc(?:\.js)?|tsgo)(?:\s|$)|npm run (?:compile|typecheck|transpile)|test/unit/(?:node|electron)/index\.js|scripts/test\.sh|node[^\n]*transpile[^\n]*\.mjs',command):active.append({'pid':process.name,'command':command[:700]})
    except OSError:pass
assert not active,active
class RunnerInterrupted(BaseException):
    pass

signal_state = {'cleanupDepth': 0, 'received': []}
def on_signal(number, _frame):
    signal_state['received'].append({'number': number, 'utc': datetime.now(timezone.utc).isoformat()})
    if signal_state['cleanupDepth'] == 0:
        raise RunnerInterrupted('Runner received signal ' + str(number))

signal.signal(signal.SIGTERM, on_signal)
signal.signal(signal.SIGINT, on_signal)

def proc_stat(pid):
    text = Path('/proc', str(pid), 'stat').read_text()
    tail = text[text.rfind(')') + 2:].split()
    return {'pid': int(pid), 'state': tail[0], 'pgrp': int(tail[2]),
            'session': int(tail[3]), 'startTicks': int(tail[19])}

def group_snapshot(owner):
    members, foreign, uncertainties = [], [], []
    for proc in Path('/proc').iterdir():
        if not proc.name.isdigit():
            continue
        try:
            row = proc_stat(proc.name)
            if row['pgrp'] != owner['pgid']:
                continue
            row['command'] = (proc / 'cmdline').read_bytes().replace(b'\0', b' ').decode(errors='replace')[:500]
            # start_new_session=True proves this session/group belongs to this child.
            # Refuse to signal an unexpected session or reused leader identity.
            if row['session'] != owner['pgid'] or (owner.get('leaderStartTicks') is not None and
                    (row['startTicks'] < owner['leaderStartTicks'] or
                     row['pid'] == owner['pgid'] and row['startTicks'] != owner['leaderStartTicks'])):
                foreign.append(row)
            else:
                members.append(row)
        except (FileNotFoundError, ProcessLookupError):
            pass
        except OSError as error:
            uncertainties.append({'pid': proc.name, 'error': str(error)})
    return {'members': members, 'foreignMembers': foreign, 'scanUncertainties': uncertainties,
            'quiet': not members and not foreign and not uncertainties}

def cleanup_owned_group(owner):
    """Only our start_new_session group; normal/error/timeout all take this bounded path."""
    signal_state['cleanupDepth'] += 1
    started = time.monotonic()
    actions = []
    child = owner['process']
    try:
        child.poll()  # Reap our own exited leader before checking for remaining children.
        first = group_snapshot(owner)
        current = first
        for sig, grace in [(signal.SIGTERM, 3.0), (signal.SIGKILL, 3.0)]:
            if current['quiet'] or current['foreignMembers']:
                break
            if current['members']:
                assert owner['startedNewSession'] and owner['pgid'] == child.pid
                assert owner['pgid'] > 1 and owner['pgid'] != os.getpgrp()
                try:
                    os.killpg(owner['pgid'], sig)
                    actions.append({'signal': signal.Signals(sig).name, 'sent': True})
                except ProcessLookupError:
                    actions.append({'signal': signal.Signals(sig).name, 'sent': False, 'alreadyGone': True})
                except OSError as error:
                    actions.append({'signal': signal.Signals(sig).name, 'sent': False, 'error': str(error)})
            deadline = time.monotonic() + grace
            while time.monotonic() < deadline:
                child.poll()
                current = group_snapshot(owner)
                if current['quiet'] or current['foreignMembers']:
                    break
                time.sleep(min(0.1, max(0.0, deadline - time.monotonic())))
        child.poll()
        final = group_snapshot(owner)
        return {'pgid': owner['pgid'], 'leaderStartTicks': owner.get('leaderStartTicks'),
                'initial': first, 'signals': actions, 'final': final,
                'quiet': final['quiet'], 'childExitAfterCleanup': child.returncode,
                'seconds': time.monotonic() - started,
                'scope': 'only process group created by this driver child with start_new_session=True'}
    except BaseException as error:
        # Preserve cleanup uncertainty as data; the caller still records original wait outcome.
        return {'pgid':owner['pgid'],'leaderStartTicks':owner.get('leaderStartTicks'),
                'quiet':False,'signals':actions,'seconds':time.monotonic()-started,
                'childExitAfterCleanup':child.returncode,
                'cleanupException':{'type':type(error).__name__,'message':str(error)},
                'scope':'only the process group created by this driver child'}
    finally:
        signal_state['cleanupDepth'] -= 1

locks=[]
owned_groups=[]
stage=None
try:
    for name in ['/tmp/vscode-compile.lock','/tmp/vscode-loop-compile.lock']:
        lock=open(name,'a')
        try:fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
        except BaseException:lock.close();raise
        locks.append(lock)
    assert datetime.now(timezone.utc)<datetime.fromisoformat(token['expiresUtc'])
    capacity={str(p):os.statvfs(p).f_bavail*os.statvfs(p).f_frsize for p in [repo,scratch]}
    assert capacity[str(scratch)]>5*1024**3 and capacity[str(repo)]>512*1024**2,capacity
    stage=scratch/('stage-'+args.stage);stage.mkdir(exist_ok=False)
    for name in ['tmp','xdg-cache','npm-cache','npm-logs','artifacts','crashes','profile']:(stage/name).mkdir()
    env=os.environ.copy()
    for name in ['NODE_COMPILE_CACHE','ELECTRON_RUN_AS_NODE','NPM_CONFIG_CACHE','NPM_CONFIG_LOGS_DIR']:env.pop(name,None)
    env.update(NODE_DISABLE_COMPILE_CACHE='1',VSCODE_SKIP_PRELAUNCH='1',GIT_OPTIONAL_LOCKS='0',
        TMPDIR=str(stage/'tmp'),XDG_CACHE_HOME=str(stage/'xdg-cache'),XDG_CONFIG_HOME=str(stage/'profile'),
        npm_config_cache=str(stage/'npm-cache'),npm_config_logs_dir=str(stage/'npm-logs'),
        BUILD_ARTIFACTSTAGINGDIRECTORY=str(stage/'artifacts'))
    # HOME remains unchanged. Official Electron runner creates its userData under TMPDIR.
    results=[]
    protected_rows=[]
    def write(name,value):
        with (stage/name).open('x') as f:json.dump(value,f,indent=2);f.write('\n')
    write('source-read-inputs.json',{'inputs':manifest['sourceReadInputs'],'runtimeRole':'current source in BOTH full phases, excluded from raw-baseline business evidence'})
    write('lane-preflight.json',{'createdUtc':datetime.now(timezone.utc).isoformat(),'authorizationId':token['authorizationId'],'manifestSha256':sha(manifest_path),'pid':os.getpid(),'activeProcessesBeforeLocks':active,'locksHeld':[{'path':l.name,'inode':os.fstat(l.fileno()).st_ino} for l in locks],'capacity':capacity,'outFilesBefore':check_out_topology(),'privateEnvironment':{k:env[k] for k in ['NODE_DISABLE_COMPILE_CACHE','TMPDIR','XDG_CACHE_HOME','XDG_CONFIG_HOME','npm_config_cache','npm_config_logs_dir','BUILD_ARTIFACTSTAGINGDIRECTORY']},'HOMEUnchanged':env.get('HOME')==os.environ.get('HOME')})

    def identities(phase):
        selected={e['out']:e for e in manifest['phases']['old']}
        if phase=='new':selected.update({e['out']:e for e in manifest['phases']['new']})
        rows=[]
        for target,entry in sorted(selected.items()):
            output=Path(target);stat=output.lstat()
            assert not output.is_symlink() and stat.st_nlink==1
            rows.append({'source':entry['source'],'snapshot':entry['snapshot'],'sourceSha256':entry['sha256'],'role':entry['role'],'out':target,'outSha256':sha(output),'bytes':stat.st_size})
        write(phase+'-source-out-identities.json',rows)
        return rows

    def check_identities(rows):
        for entry in rows:assert sha(entry['out'])==entry['outSha256'],'runtime mutated '+entry['out']

    def emitted_graph_check(phase):
        entries=manifest['phases']['old'] if phase=='old' else manifest['completeNew']
        outputs={e['out'] for e in entries};edges=[];dynamic=[]
        pattern=re.compile(r"(?m)^\s*(?:import|export)\s+(?:[^;]*?\bfrom\s*)?['\"]([^'\"]+)['\"]|\bimport\s*\(\s*['\"]([^'\"]+)['\"]\s*\)")
        for entry in entries:
            path=Path(entry['out'])
            if path.suffix!='.js':continue
            text=path.read_text()
            for m in pattern.finditer(text):
                spec=m[1] or m[2]
                if not spec.startswith('.'):continue
                target=(path.parent/spec.split('?',1)[0]).resolve()
                assert str(target) in outputs,('emitted dependency absent from exact snapshot graph',entry['source'],spec,str(target))
                edges.append({'out':str(path),'specifier':spec,'target':str(target)})
                if phase=='old':assert 'universeAgentExpectedOwner' not in str(target)
            if re.search(r'\bimport\s*\(\s*[^\s\'\"]',text):dynamic.append(str(path))
        write(phase+'-emitted-graph.json',{'edges':edges,'nonliteralDynamicCandidates':dynamic,'exactRelativeEdgesCovered':True,'noNewOwnerRuntimeInOld':phase=='old'})

    def validate_official_result(parsed):
        """Validate selection/infrastructure, never automatically qualify business assertions."""
        issues = []
        files = []
        required = ['stats', 'tests', 'passes', 'pending', 'failures']
        if not isinstance(parsed, dict) or any(key not in parsed for key in required):
            return {'valid': False, 'issues': ['missing required official JSON fields'], 'eligibleFailureTitles': []}
        stats = parsed['stats']
        if not isinstance(stats, dict) or any(not isinstance(parsed[key], list) for key in required[1:]):
            return {'valid': False, 'issues': ['invalid official JSON field shapes'], 'eligibleFailureTitles': []}
        for key in ['tests', 'passes', 'pending', 'failures']:
            if not isinstance(stats.get(key), int):
                return {'valid':False,'issues':['official stats count is not integer: '+key],'eligibleFailureTitles':[]}
            if stats[key] != len(parsed[key]):
                issues.append('stats/array count mismatch: ' + key)
            if any(not isinstance(row,dict) or not isinstance(row.get('fullTitle'),str) for row in parsed[key]):
                return {'valid':False,'issues':['official runnable shape invalid: '+key],'eligibleFailureTitles':[]}
        if stats.get('tests', 0) <= 0:
            issues.append('zero official tests')
        if stats.get('tests') != plan['expectedTotalTests']:
            issues.append('total test count differs from frozen expanded plan')
        if stats.get('pending') != plan['expectedPending'] or parsed['pending']:
            issues.append('pending tests differ from expected zero')
        try:
            tests = Counter(row['fullTitle'] for row in parsed['tests'])
            passes = Counter(row['fullTitle'] for row in parsed['passes'])
            failures = Counter(row['fullTitle'] for row in parsed['failures'])
            pending = Counter(row['fullTitle'] for row in parsed['pending'])
        except (KeyError, TypeError):
            return {'valid': False, 'issues': issues + ['official runnable lacks fullTitle'], 'eligibleFailureTitles': []}
        if tests != passes + failures + pending:
            issues.append('outcomes differ from executed tests; hook/infrastructure failure is not business red')
        for meta in plan['officialMeta']:
            title, count = meta['fullTitle'], meta['expectedCount']
            if tests[title] != count or passes[title] != count or failures[title] or pending[title]:
                issues.append('official meta missing, failed or duplicated: ' + title)
        assigned = Counter({OFFICIAL_META: 1})
        for expected in plan['files']:
            prefixes = expected['suitePrefixes']
            selected = Counter({title: count for title, count in tests.items()
                                if any(title.startswith(prefix + ' ') for prefix in prefixes)})
            scans = Counter({title: selected[title] for title in expected['sourceScanFullTitles']})
            actual_business = sum(selected.values()) - sum(scans.values())
            if actual_business != expected['expectedBusinessTests']:
                issues.append('expanded business count differs: ' + expected['source'])
            for title in expected['sourceScanFullTitles']:
                if tests[title] != 1 or passes[title] != 1 or failures[title] or pending[title]:
                    issues.append('current live-source scan missing/failed/duplicated; excluded from raw-baseline business red: ' + title)
            files.append({'source': expected['source'], 'expectedBusinessTests': expected['expectedBusinessTests'],
                          'actualBusinessTests': actual_business, 'actualSourceScanTests': sum(scans.values()),
                          'sourceScanFullTitles': expected['sourceScanFullTitles']})
            assigned += selected
        if assigned != tests:
            issues.append('executed tests outside or multiply assigned to exact selected file suites')
        eligible = [title for title in failures if title not in scan_titles and title != OFFICIAL_META]
        return {'valid': not issues, 'issues': issues, 'files': files,
                'expectedOfficialMetaCount': 1, 'actualOfficialMetaCount': tests[OFFICIAL_META],
                'actualOfficialMetaPassCount': passes[OFFICIAL_META],
                'expectedTotalTests': plan['expectedTotalTests'], 'actualTotalTests': stats.get('tests'),
                'expectedPending': 0, 'actualPending': stats.get('pending'),
                'eligibleFailureTitles': eligible if not issues else [],
                'excludedSourceScanFullTitles': sorted(scan_titles),
                'qualification': 'eligible titles still require parent review of actual business assertions; no auto-classification'}

    def run(label, command, timeout=240):
        check_frozen(); check_out_topology(); check_identities(protected_rows)
        assert datetime.now(timezone.utc) < datetime.fromisoformat(token['expiresUtc'])
        log = stage / (label + '.log')
        started = time.time()
        original_exit = None
        timed_out = False
        wait_exception = None
        cleanup = None
        owner = None
        signal_count_before = len(signal_state['received'])
        with log.open('x') as stream:
            try:
                child = subprocess.Popen(command, cwd=repo, env=env, stdout=stream, stderr=subprocess.STDOUT,
                                         start_new_session=True)
                owner = {'process': child, 'pgid': child.pid, 'startedNewSession': True,
                         'leaderStartTicks': None, 'label': label}
                owned_groups.append(owner)  # Register immediately, before any later operation may fail.
                owner['leaderStartTicks'] = proc_stat(child.pid)['startTicks']
                print(json.dumps({'stage': label, 'pid': child.pid, 'command': command, 'log': str(log)}), flush=True)
                try:
                    original_exit = child.wait(timeout=timeout)
                except subprocess.TimeoutExpired:
                    timed_out = True
            except BaseException as error:
                wait_exception = error
            finally:
                if owner is not None:
                    try:
                        write(label + '-original-wait-outcome.json',
                              {'originalExitCode':original_exit,'timedOut':timed_out,
                               'executionException':({'type':type(wait_exception).__name__,'message':str(wait_exception)}
                                                     if wait_exception is not None else None)})
                    finally:
                        cleanup = cleanup_owned_group(owner)
                        write(label + '-process-group-cleanup.json', cleanup)
        if wait_exception is None and len(signal_state['received']) != signal_count_before:
            wait_exception = RunnerInterrupted('Signal received during bounded child cleanup')
        effective_exit = -999 if timed_out else original_exit if original_exit is not None else -998
        record = {'stage': label, 'command': command, 'originalExitCode': original_exit,
                  'exitCode': effective_exit, 'timedOut': timed_out,
                  'executionException': ({'type': type(wait_exception).__name__, 'message': str(wait_exception)}
                                         if wait_exception is not None else None),
                  'cleanup': cleanup, 'seconds': time.time() - started,
                  'logSha256': sha(log), 'logBytes': log.stat().st_size}
        raw = log.read_text(errors='replace')
        if label.endswith('-targets'):
            candidates = []
            for marker in re.finditer(r'\{\s*"stats"\s*:', raw):
                try:
                    parsed, length = json.JSONDecoder().raw_decode(raw[marker.start():])
                    if isinstance(parsed, dict) and all(key in parsed for key in ['stats', 'tests', 'passes', 'pending', 'failures']):
                        candidates.append((parsed, raw[marker.start():marker.start() + length]))
                except (ValueError, TypeError):
                    pass
            # Preserve complete reporter JSON BEFORE validating counts, pending, meta or failures.
            for index, (parsed, original_json) in enumerate(candidates, 1):
                suffix = '' if len(candidates) == 1 else '-' + str(index).zfill(2)
                with (stage / (label + '-official-result' + suffix + '.json')).open('x') as stream:
                    stream.write(original_json)
                    stream.write('\n')
            record['officialResultObjectsSaved'] = len(candidates)
            if len(candidates) == 1:
                parsed = candidates[0][0]
                contract = validate_official_result(parsed)
                record['stats'] = parsed['stats']
                record['failureTitles'] = [row.get('fullTitle') if isinstance(row,dict) else '<invalid runnable>' for row in parsed['failures']]
            else:
                contract = {'valid': False, 'issues': ['official JSON absent or ambiguous'], 'eligibleFailureTitles': []}
            if timed_out or wait_exception is not None or cleanup is None or not cleanup['quiet']:
                contract['valid'] = False
                contract['issues'].append('execution/timeout/cleanup failure is not business red')
                contract['eligibleFailureTitles'] = []
            if len(candidates) == 1 and original_exit == 0 and candidates[0][0]['stats'].get('failures'):
                contract['valid'] = False
                contract['issues'].append('zero exit contradicts reported failures')
                contract['eligibleFailureTitles'] = []
            if len(candidates) == 1 and original_exit not in [None, 0] and not candidates[0][0]['stats'].get('failures'):
                contract['valid'] = False
                contract['issues'].append('nonzero exit without official test failures')
                contract['eligibleFailureTitles'] = []
            write(label + '-result-contract.json', contract)
            record['officialResultContract'] = contract
        if label == 'lint' and effective_exit == 0:
            lint = json.loads(raw)
            record['errors'] = sum(row['errorCount'] for row in lint)
            record['warnings'] = sum(row['warningCount'] for row in lint)
        results.append(record)
        write(args.stage + '-driver-results-' + str(len(results)).zfill(2) + '.json', results)
        print(json.dumps(record), flush=True)
        if cleanup is not None and not cleanup['quiet']:
            raise RuntimeError('Owned process group still remains after bounded TERM/KILL; lane NOT returned')
        if wait_exception is not None:
            raise wait_exception
        check_frozen(); check_out_topology(); check_identities(protected_rows)
        if label.endswith('-targets') and not record['officialResultContract']['valid']:
            raise RuntimeError('Official result selection/count/pending/meta/infrastructure contract failed; never business red')
        return effective_exit, record

    node=next(x['path'] for x in manifest['executables'] if x['name']=='node')
    npm=next(x['path'] for x in manifest['executables'] if x['name']=='npm')
    if args.stage in ['old','new']:
        if args.stage=='new':
            prior=json.loads((scratch/'stage-old'/'old-source-out-identities.json').read_text());check_identities(prior)
        code,_=run(args.stage+'-transpile',[node,str(here/'s2-transpile.mjs'),str(manifest_path),args.stage])
        if code:raise SystemExit(code)
        rows=identities(args.stage);protected_rows=rows;emitted_graph_check(args.stage)
        command=[manifest['electron']['entry'],'test/unit/electron/index.js','--no-sandbox','--disable-gpu','--crash-reporter-directory='+str(stage/'crashes')]
        for test in manifest['oldTests' if args.stage=='old' else 'newTests']:command.extend(['--run',test])
        command.extend(['--reporter','json'])
        code,record=run(args.stage+'-targets',command)
        check_identities(rows)
        if args.stage=='new' and code==0:
            assert record['officialResultContract']['valid'] and record['stats']['failures']==0
        write('completed.json',{'stage':args.stage,'exitCode':code,'finishedUtc':datetime.now(timezone.utc).isoformat(),'sourceOutStable':True,'officialResultContractValid':record['officialResultContract']['valid'],'businessQualification':'separate parent review required for old; no auto-classification','CanceledConsumption':'explicit test assertions and local listeners; official cancellation suppression is not proof'})
        raise SystemExit(code)
    assert manifest['lintPaths']
    protected_rows=json.loads((scratch/'stage-new'/'new-source-out-identities.json').read_text())
    check_identities(protected_rows)
    code,_=run('noemit',[npm,'run','typecheck-client','--','--incremental','false'],timeout=420)
    if code:raise SystemExit(code)
    code,_=run('lint',[node,'node_modules/eslint/bin/eslint.js','--no-cache','--format','json',*manifest['lintPaths']])
    raise SystemExit(code)
finally:
    # Recheck/clean only process groups this driver created, even if any stage raised.
    # OS locks are released on exit; laneReturned is a separate, explicit scheduling fact.
    signal_state['cleanupDepth'] += 1
    final_cleanups = []
    try:
        for index, owner in enumerate(owned_groups, 1):
            cleanup = cleanup_owned_group(owner)
            final_cleanups.append({'stage': owner['label'], 'cleanup': cleanup})
            if stage is not None:
                with (stage / ('lane-final-cleanup-' + str(index).zfill(2) + '.json')).open('x') as stream:
                    json.dump(final_cleanups[-1], stream, indent=2)
        lane_returned = all(row['cleanup']['quiet'] for row in final_cleanups)
    except BaseException as error:
        lane_returned = False
        final_cleanups.append({'finalCleanupException': {'type': type(error).__name__, 'message': str(error)}})
    finally:
        for lock in locks:
            fcntl.flock(lock, fcntl.LOCK_UN)
            lock.close()
        signal_state['cleanupDepth'] -= 1
    release = {'finishedUtc': datetime.now(timezone.utc).isoformat(), 'locksReleased': True,
               'laneReturned': lane_returned, 'createdProcessGroups': len(owned_groups),
               'finalCleanups': final_cleanups, 'signalsReceived': signal_state['received'],
               'requiresParentRecovery': not lane_returned}
    if stage is not None:
        with (stage / 'lane-release.json').open('x') as stream:
            json.dump(release, stream, indent=2)
    print(json.dumps(release), flush=True)
    if not lane_returned:
        raise SystemExit('Lane NOT returned: an owned process group or cleanup uncertainty remains; parent recovery required')
