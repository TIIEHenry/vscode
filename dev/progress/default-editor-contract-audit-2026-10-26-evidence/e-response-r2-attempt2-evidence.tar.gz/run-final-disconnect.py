from pathlib import Path
import json, subprocess, time, re, collections
base=Path(__file__).resolve().parent;episode=base/'transport-episode-2';session='D-E-attempt2-controlled-session';records=[]
ids={kind:'D-E-A2-disconnect-'+kind for kind in ['permission','question','clientTool']}
suffix={'permission':'[role="button"]','question':'.conversation-lens-question-actions [role="button"]','clientTool':'.conversation-process-fold-tool-respond'}
def control(value):
    with (episode/'fake-control.jsonl').open('a') as f:f.write(json.dumps(value)+'\n')
    time.sleep(.2)
def step(n,stage,**action):
    label=f'{n:02}-A2-disconnect-{stage}';action['label']=label
    r=subprocess.run(['rtk','proxy','node',str(base/'driver.cjs'),json.dumps(action)],capture_output=True,text=True)
    with (base/'driver-stdout.jsonl').open('a') as f:f.write(json.dumps({'action':action,'exit':r.returncode,'stdout':r.stdout,'stderr':r.stderr})+'\n')
    records.append(label)
    if r.returncode:raise RuntimeError(r.stdout+r.stderr)
    value=json.loads((base/'steps'/(label+'.json')).read_text());print(json.dumps({'label':label,'result':value.get('result'),'phase':value['state']['connection']['phase']}),flush=True);return value
def seats(value,id):return [s for s in value['state']['seats'] if s.get('sessionKey')==session and s.get('turnId')==id]
def sel(id,suffix):return f'[data-session-key="{session}"] [data-turn-id="{id}"] '+suffix
def counts():
    logs=[base/'fake-io.jsonl',episode/'fake-io.jsonl'];values=[v for p in logs for v in map(json.loads,p.read_text().splitlines())]
    traces=[base/'fake-grpc-trace.log',episode/'fake-grpc-trace.log'];paths=[path for p in traces for path in re.findall(r'Received call to method ([^\s]+)',p.read_text())]
    return {'grpcReceivedMethods':dict(collections.Counter(paths)),'responseUnary':sum(v.get('type')=='unary' and v.get('method') in ['Respond','RespondQuestion','SendClientToolResponse'] for v in values),'responseHeld':sum(v.get('type')=='response-held' for v in values),'chatWrite':sum(v.get('type')=='chat-write' for v in values),'chatResidentStreamOpens':paths.count('/agentservice.AgentService/Chat')}
try:
    for kind,id in ids.items():control({'op':'emit','kind':kind,'id':id,**({'itemId':'choose'} if kind=='question' else {})})
    pending=step(66,'three-real-pending-before',type='inspect')
    assert all(len(seats(pending,id))==2 and all(any(c.get('ariaDisabled')=='false' for c in s['controls']) for s in seats(pending,id)) for id in ids.values())
    step(67,'question-Alpha-before',type='click',selector=sel(ids['question'],'[role="checkbox"]'),index=0)
    ready=step(68,'question-draft-before',type='fill',selector=sel(ids['question'],'.conversation-lens-question-custom'),index=0,value='Final disconnected draft')
    before=counts();(base/'disconnect-counts-before.json').write_text(json.dumps(before,indent=2)+'\n')
    disconnected=step(69,'public-disconnect-observed',type='publicDisconnect',waitMs=800)
    assert not disconnected['state']['connected'] and disconnected['state']['connection']['channelAlive'] is False
    results={}
    for n,kind in enumerate(['permission','question','clientTool'],70):
        value=step(n,kind+'-normal-ui-attempt',type='normalNegativeClick',selector=sel(ids[kind],suffix[kind]),index=0)
        results[kind]={'result':value.get('result'),'targetSeatsBeforeAction':[s for s in seats(disconnected,ids[kind])],'targetSeatsAfterAction':seats(value,ids[kind])}
    final=step(73,'final-no-response-rpc-observed',type='inspect',waitMs=800)
    after=counts();(base/'disconnect-counts-after.json').write_text(json.dumps(after,indent=2)+'\n')
    assert after['responseUnary']==before['responseUnary'] and after['responseHeld']==before['responseHeld'] and after['chatWrite']==before['chatWrite']
    assert final['state']['uiErrors']==[]
    result={'state':'OBSERVED_NO_ADDITIONAL_RESPONSE_RPC','publicDisconnectObserved':True,'beforeCounts':before,'afterCounts':after,'responseUnaryDelta':after['responseUnary']-before['responseUnary'],'chatWriteDelta':after['chatWrite']-before['chatWrite'],'chatResidentStreamOpenDelta':after['chatResidentStreamOpens']-before['chatResidentStreamOpens'],'uiAttempts':results,'steps':records,'nextNumber':74,'boundary':'A missing post-disconnect response control is recorded as absent, not credited as an exercised disabled control. Enabled cached controls can mutate local stub state; final review classifies actual observed UI.'}
    (base/'disconnect-negative-result.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps({k:v for k,v in result.items() if k!='uiAttempts'}),flush=True)
except Exception as error:
    (base/'disconnect-negative-failure.json').write_text(json.dumps({'error':str(error),'steps':records},indent=2)+'\n');raise
