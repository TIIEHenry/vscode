import os, pathlib, subprocess, json, time, hashlib, re, fcntl, signal

scratch=pathlib.Path(__file__).parent
m=json.loads((scratch/'manifest.json').read_text())
root=pathlib.Path(m['root'])
task=scratch.parent
env=os.environ.copy()
env.pop('NODE_COMPILE_CACHE',None)
env.pop('ELECTRON_RUN_AS_NODE',None)
env.update(NODE_DISABLE_COMPILE_CACHE='1',VSCODE_SKIP_PRELAUNCH='1',TMPDIR=str(task/'tmp'),XDG_CACHE_HOME=str(task/'xdg-cache'),PYTHONDONTWRITEBYTECODE='1')
for p in [task/'tmp',task/'xdg-cache']:p.mkdir(exist_ok=True)
results=[]

def say(v):print(json.dumps(v,ensure_ascii=False),flush=True)
def sha(p):return hashlib.sha256(pathlib.Path(p).read_bytes()).hexdigest()
def check_inputs():
    assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip()==m['head']
    for rel,expected in m['frozenSha256'].items():assert sha(root/rel)==expected,rel
def identities(name):
    data=[]
    for x in m['entries']:
        p=pathlib.Path(x['out'])
        if p.exists():
            st=p.stat()
            data.append({'source':x['source'],'sourceSha256':sha(x['snapshot']),'out':str(p),'outSha256':sha(p),'bytes':st.st_size,'inode':st.st_ino,'mtimeNs':st.st_mtime_ns,'ctimeNs':st.st_ctime_ns})
    (scratch/(name+'-identities.json')).write_text(json.dumps(data,indent=2))
def run(name,command,timeout=150):
    check_inputs()
    log=scratch/(name+'.log')
    started=time.time()
    with log.open('w') as out:
        p=subprocess.Popen(command,cwd=root,env=env,stdout=out,stderr=subprocess.STDOUT,start_new_session=True)
        say({'stage':name,'pid':p.pid,'command':command,'log':str(log),'time':started})
        timed_out=False
        try:code=p.wait(timeout=timeout)
        except subprocess.TimeoutExpired:
            timed_out=True
            os.killpg(p.pid,signal.SIGTERM)
            try:code=p.wait(timeout=8)
            except subprocess.TimeoutExpired:os.killpg(p.pid,signal.SIGKILL);code=p.wait()
    raw=log.read_text(errors='replace')
    result={'stage':name,'exitCode':code,'timeout':timed_out,'started':started,'finished':time.time(),'logSha256':sha(log),'logBytes':log.stat().st_size}
    marker=raw.find('{\n  "stats"')
    if marker>=0:
        try:
            parsed=json.JSONDecoder().raw_decode(raw[marker:])[0]
            (scratch/(name+'-result.json')).write_text(json.dumps(parsed,indent=2))
            result['stats']=parsed.get('stats')
            result['failures']=[{'fullTitle':x.get('fullTitle'),'title':x.get('title'),'err':x.get('err')} for x in parsed.get('failures',[])]
        except Exception as e:result['jsonError']=str(e)
    if 'stats' not in result:result['tail']='\n'.join(raw.splitlines()[-20:])
    results.append(result)
    (scratch/'results.json').write_text(json.dumps(results,indent=2))
    say({k:v for k,v in result.items() if k != "failures"} | {"failureSummary":[{"title":x["fullTitle"],"message":str(x.get("err",{}).get("message",""))[:300]} for x in result.get("failures",[])]})
    check_inputs()
    return result

check_inputs()
anc=set();pid=os.getpid()
while pid>1:
    anc.add(pid)
    try:pid=int(pathlib.Path(f'/proc/{pid}/stat').read_text().split()[3])
    except Exception:break
active=[]
for p in pathlib.Path('/proc').iterdir():
    if not p.name.isdigit() or int(p.name) in anc:continue
    try:
        a=(p/'cmdline').read_bytes().replace(b'\0',b' ').decode(errors='replace')
        if re.search(r'(?:/|\s)(?:gulp\.js|tsc(?:\.js)?|tsgo)(?:\s|$)|npm run (?:compile|typecheck|transpile)|test/unit/(?:node|electron)/index\.js|scripts/test\.sh',a):active.append({'pid':p.name,'args':a[:400]})
    except Exception:pass
(scratch/'processes-before.json').write_text(json.dumps(active,indent=2))
assert not active,active
locks=[]
for name in ['/tmp/vscode-compile.lock','/tmp/vscode-loop-compile.lock']:
    f=open(name,'a');fcntl.flock(f,fcntl.LOCK_EX|fcntl.LOCK_NB);locks.append(f)
say({'locked':[f.name for f in locks],'slot':'C import-fix','frozen':m['frozenSha256'],'TMPDIR':env['TMPDIR']})

r=run('transpile-browser-test',['node',str(scratch/'transpile.mjs')])
if r['exitCode']!=0:raise SystemExit(2)
r=run('browser-full',['bash','scripts/test.sh','--run',m['tests'][1],'--no-sandbox','--disable-gpu','--reporter','json'])
if r['exitCode']!=0:raise SystemExit(3)
r=run('noemit',['npm','run','typecheck-client','--','--incremental','false'])
if r['exitCode']!=0:raise SystemExit(4)
r=run('eslint',['node','node_modules/eslint/bin/eslint.js','--no-cache','--format','json',*m['frozenSha256'].keys()])
parsed=json.loads((scratch/'eslint.log').read_text());say({'eslintErrors':sum(x['errorCount'] for x in parsed),'eslintWarnings':sum(x['warningCount'] for x in parsed)})
if r['exitCode']!=0:raise SystemExit(5)
rel=m['tests'][1];entry=next(x for x in m['entries'] if x['source']==rel);p=pathlib.Path(entry['out'])
meta={'source':rel,'sourceSha256':m['frozenSha256'][rel],'snapshot':str(scratch/'new'/rel),'out':str(p),'outSha256':sha(p),'outBytes':p.stat().st_size}
(scratch/'final-test-source-out.json').write_text(json.dumps(meta,indent=2));say({'DONE':'C import-only change revalidated','identity':meta})
