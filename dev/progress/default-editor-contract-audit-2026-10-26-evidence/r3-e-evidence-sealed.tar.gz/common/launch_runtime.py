from pathlib import Path
import json, os, select, subprocess, time
from gates import ROOT,read,guard

def main(phase):
    config=read(ROOT/'run-config.json');base=ROOT/phase;proof=guard(phase,'before-launch');notice=proof['notice'];auth=proof['authorization']
    assert not (base/'launch.json').exists() and not (base/'lease.json').exists(),'Never reuse a launch/lease'
    home=Path(config['engineHomes'][phase]);assert not list(home.iterdir())
    workspace=base/'after.code-workspace';assert workspace.exists(),'Run gated prepare.py first'
    readfd,writefd=os.pipe()
    with (base/'xvfb.log').open('x') as log: xvfb=subprocess.Popen(['rtk','proxy','Xvfb','-displayfd',str(writefd),'-screen','0','1920x1200x24','-nolisten','tcp'],pass_fds=(writefd,),stdin=subprocess.DEVNULL,stdout=log,stderr=subprocess.STDOUT,start_new_session=True)
    os.close(writefd);ticks=Path('/proc',str(xvfb.pid),'stat').read_text().split(') ')[-1].split()[19]
    lease={'createdBy':config['owner'],'phase':phase,'runId':config['runId'],'xvfbPid':xvfb.pid,'xvfbStartTimeTicks':ticks,'startedAt':time.time(),'released':False,'engineHome':str(home),'sourceHead':notice['sourceHead']}
    (base/'lease.json').write_text(json.dumps(lease,indent=2)+'\n')
    try:
        assert select.select([readfd],[],[],8)[0];display=':'+os.read(readfd,128).decode().strip();os.close(readfd);assert display[1:].isdigit();lease['display']=display
        (base/'lease.json').write_text(json.dumps(lease,indent=2)+'\n')
        env=os.environ.copy();env.update(DISPLAY=display,CODE_OSS_DEV_AUTHED_SHARED_DATA_DIR=str(base/'empty-shared'),UNIVERSE_AGENT_HOME=str(home),PYTHONDONTWRITEBYTECODE='1');env.pop('ELECTRON_RUN_AS_NODE',None)
        launcher=Path('/home/clarence/Projects/Agents/vscode/.agents/skills/launch/scripts/launch.sh')
        args=['rtk','proxy','bash',str(launcher),'--repo',config['runtimeRepo'],'--source-user-data-dir',str(base/'empty-seed'),'--skip-prelaunch','--disable-workspace-trust','--','--new-window','--enable-smoke-test-driver','--use-mock-keychain','--no-sandbox','--disable-gpu',str(workspace)]
        result=subprocess.run(args,env=env,capture_output=True,text=True,start_new_session=True);(base/'launcher.log').write_text(result.stdout+'\n'+result.stderr);assert result.returncode==0,result.stderr
        info=json.loads(result.stdout.strip().splitlines()[-1]);assert info['agents'] is False
        ticks=Path('/proc',str(info['pid']),'stat').read_text().split(') ')[-1].split()[19]
        info.update(phase=phase,createdBy=config['owner'],runId=config['runId'],display=display,xvfbPid=xvfb.pid,engineHome=str(home),mainStartTicks=ticks,explicitReadySource=notice['sourceHead'],explicitReadySourceTree=notice['sourceTree'],freezeNoticeSha256=auth['freezeNoticeSha256'],frozenOutputsSha256=auth['frozenOutputsSha256'],fullFreezeRawSha256=auth['fullFreezeRawSha256'],lineageSha256=auth['lineageSha256'],fullCompileOfFinalSourceTree=False,workspace=str(workspace))
        if phase=='J': info['fixture']=read(base/'fixture.json')['fixture']
        (base/'launch.json').write_text(json.dumps(info,indent=2)+'\n');lease.update(runDir=info['runDir'],electronPid=info['pid'],electronStartTimeTicks=ticks);(base/'lease.json').write_text(json.dumps(lease,indent=2)+'\n')
        print(json.dumps({key:info[key] for key in ['phase','runId','pid','cdpPort','mainPort','display','xvfbPid','runDir','engineHome','explicitReadySource']}))
    except BaseException:
        if xvfb.poll() is None:xvfb.terminate()
        raise
