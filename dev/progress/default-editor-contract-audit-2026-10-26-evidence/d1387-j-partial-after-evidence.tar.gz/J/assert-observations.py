import json, pathlib, collections, urllib.parse
b=pathlib.Path(__file__).resolve().parent
fixture=json.loads((b/'fixture-verification.json').read_text())
expected={pathlib.Path(r['root']).name:r['files'] for r in fixture['current']}
root=pathlib.Path(fixture['current'][0]['root']).parent
checks=[]
def check(ok, detail):
    checks.append({'pass':bool(ok),'detail':detail})
    assert ok, detail
def state(label): return json.loads((b/'steps'/f'{label}.json').read_text())['state']
def uri(repo,file): return (root/repo/file).as_uri()
def model(label,repo,file,readonly):
    s=state(label); ds=[d for d in s['diffs'] if d.get('modified')==uri(repo,file) and d.get('visibility',{}).get('connected') and d['visibility']['width']>0 and d['visibility']['height']>0 and [d['originalReadOnly'],d['modifiedReadOnly']]==readonly]
    check(bool(ds),f'{label}: actual visible model and readonly {readonly}')
    check(any(d['originalText']==expected[repo][file]['HEADtext'] and d['modifiedText']==expected[repo][file]['text'] and d['original'].startswith('git:') and '/'+repo+'/'+file in d['original'] for d in ds),f'{label}: full original/modified text and repository URI match real fixture')
    return s
def part(s,key): return next(p for p in s['conversationParts'] if p['sessionKey']==key)
def decoded(e):return urllib.parse.unquote(urllib.parse.unquote(e.get('resource') or e.get('modified') or ''))
def comparisons(s,key): return [g for g in part(s,key)['groups'] if not any(e.get('resource','').startswith('conversation-chat:')for e in g['editors'])]
def roots(s):
    for p in s['conversationParts']:
        rs=[e for g in p['groups']for e in g['editors']if e.get('resource','').startswith('conversation-chat:')]
        check(len(rs)==1 and rs[0]['resource']==f"conversation-chat:/session/{p['sessionKey']}/chat/default",f"{p['sessionKey']}: exact root retained")
def reviewed(s,repo,file):return next(e['reviewed']for e in s['changes']['entries']if e['resource']==uri(repo,file))
case_evidence={}
def case(cid,labels,status='PASS_RUNTIME',note=''):
    case_evidence[cid]={'status':status,'evidence':[f'steps/{x}.json'for x in labels],'note':note}
model('P01-preview-alpha-from-beta','alpha','shared.txt',[True,False]);model('P02-preview-beta-Enter','beta','shared.txt',[True,False]);model('P03-preview-alternate-replace','alpha','other.txt',[True,False]);model('P03-preview-openSelected-no-slot','beta','shared.txt',[True,False]);model('P04-changes-alpha-replace-beta','alpha','shared.txt',[True,False]);model('P05-changes-alpha-Enter-newTab','alpha','shared.txt',[True,False])
check(len(state('P04-changes-alpha-replace-beta')['mainGroups'][0]['editors'])==1,'P04 scoped replacement leaves only Alpha')
check(len(state('P05-changes-alpha-Enter-newTab')['mainGroups'][0]['editors'])==2,'P05 newTab preserves both Alpha/Beta')
for cid,labels in {'P01':['P01-preview-alpha-from-beta','P01-dispatch-counted-mouse'],'P02':['P02-preview-beta-Enter','P02-dispatch-counted-Enter'],'P03':['P03-preview-context-menu','P03-preview-alternate-replace','P03-preview-openSelected-no-slot','P03-dispatch-counted-alternate','P03-dispatch-counted-openSelected'],'P04':['P04-changes-alpha-replace-beta','P04-dispatch-counted-mouse'],'P05':['P05-changes-alpha-Enter-newTab','P05-dispatch-counted-Enter']}.items():case(cid,labels)
for label,repo,file in [('C01-conversation-alpha-first-replace','alpha','shared.txt'),('C02-conversation-beta-new-side-genuine','beta','shared.txt'),('C03-conversation-beta-openSelected-retry','beta','shared.txt'),('C04-conversation-beta-other-replace','beta','other.txt'),('C05-conversation-beta-shared-newTab','beta','shared.txt'),('C05-conversation-beta-shared-reveal-newTab','beta','shared.txt'),('C05-conversation-beta-shared-reveal-replace','beta','shared.txt'),('C06-beta-other-exact-target','beta','other.txt')]: roots(model(label,repo,file,[True,True]))
check(len(part(state('31-C02-genuine-root-only'),'visualize')['groups'])==1,'C02 genuine root-only before first newTab')
check(len(part(state('C02-conversation-beta-new-side-genuine'),'visualize')['groups'])==2,'C02 exactly root+one new comparison group')
check([g['id']for g in comparisons(state('C02-conversation-beta-new-side-genuine'),'visualize')]==[11],'C02 actual newly allocated exact group11')
for label,n in [('C04-conversation-beta-other-replace',1),('C05-conversation-beta-shared-newTab',2),('C05-conversation-beta-shared-reveal-newTab',2),('C05-conversation-beta-shared-reveal-replace',2)]:check(len(comparisons(state(label),'visualize')[0]['editors'])==n,f'{label}: exact comparison tab cardinality {n}')
check(part(state('28-C06-focus-alpha-comparison'),'untitled')['groups']==part(state('C06-beta-other-exact-target'),'untitled')['groups'],'C06 Alpha group/root/tab identities unaffected by Beta switch/open')
check(state('28-C06-focus-alpha-comparison')['activeSession']=='untitled' and state('29-C06-select-beta-session')['activeSession']=='visualize','C06 actual public focus and roster target switch observed')
for cid,labels in {'C01':['C01-conversation-alpha-first-replace'],'C02':['C02-conversation-beta-first-newTab','24-C02-clear-mistargeted-alpha','31-C02-genuine-root-only','C02-conversation-beta-new-side-genuine'],'C03':['C03-conversation-beta-openSelected-retry'],'C04':['C04-conversation-beta-other-replace'],'C05':['C05-conversation-beta-shared-newTab','C05-conversation-beta-shared-reveal-newTab','C05-conversation-beta-shared-reveal-replace'],'C06':['28-C06-focus-alpha-comparison','29-C06-select-beta-session','C06-beta-other-exact-target']}.items():case(cid,labels,note='Initial hidden Review targeting did not open Beta and is excluded; genuine root-only retry is positive evidence.' if cid=='C02' else '')
for label,file in [('B01-panel-alpha-mouse','shared.txt'),('B01-panel-alpha-other-Enter','other.txt')]:
    s=model(label,'alpha',file,[True,True]);check(s['panelRef']['modified']==uri('alpha',file),f'{label}: public panel ref correct');check(part(s,'visualize')['groups']==part(state('33-panel-owner-config'),'visualize')['groups'],f'{label}: Beta Conversation unchanged')
case('B01',['B01-panel-alpha-mouse','B01-panel-alpha-other-Enter'])
for label,readonly in [('M01-panel-to-preview',[True,False]),('M01-preview-to-conversation',[True,True]),('M01-normal-preview-to-panel',[True,True]),('M01-normal-panel-to-conversation',[True,True])]:roots(model(label,'alpha','other.txt',readonly))
for label,repo,file in [('M01-conversation-to-preview-real-button','alpha','other.txt'),('M01-normal-beta-conversation-preview-button','beta','shared.txt')]:
    s=model(label,repo,file,[True,True]);check(not any(g['editors']for g in s['mainGroups']),f'{label}: actual defect, Preview remains empty');check(s['activeEditor']is None and s['activeGroup']==0,f'{label}: global host null/group0');check(s['events'][-1]['id']=='sources.diff.moveToPreview' and s['events'][-1]['args']==[],f'{label}: actual button dispatched public command once');roots(s)
case('M01',['M01-panel-to-preview','M01-preview-to-conversation','M01-conversation-to-preview-real-button','M01-normal-beta-conversation-preview-button','M01-normal-preview-to-panel','M01-normal-panel-to-conversation'],'PARTIAL_FAIL','I1: actual Conversation Open Diff in Preview button no-op in two real comparisons; other four supported move commands opened correct content. Initial global-command no-ops are not pass evidence.')
s=state('E01-actual-open-rejected');check(len(s['fault']['hits'])==1 and not reviewed(s,'alpha','other.txt'),'E01 own DTO rejected once, not reviewed');check(s['reviewStatus']=='Unable to open diff: D1387 controlled own Git open rejection','E01 actual inline error');check(not any(g['editors']for g in s['mainGroups']),'E01 rejected API did not open a main tab')
s=model('E01-actual-reopen-success','alpha','other.txt',[True,False]);check(reviewed(s,'alpha','other.txt') and s['reviewStatus']=='Showing local source control changes only.' and not s['fault']['registered'],'E01 official API restored, successful content marks and clears own error')
case('E01',['40-E01-alpha-other-unreview','41-E01-public-api-fault-installed','E01-actual-open-rejected','42-E01-official-api-restored','E01-actual-reopen-success'])
for label,result,mark in [('E02-old-beta-late-reject','reject',False),('E02-old-beta-late-void','void',True)]:
    s=state(label);check(s['fault']['settled']==result and len(s['fault']['hits'])==1 and not s['fault']['registered'],'E02 controlled promise settled and disposed');check(s['reviewStatus']=='Showing local source control changes only.','E02 stale status result did not replace newer normal status');check(reviewed(s,'beta','other.txt')==mark,f'E02 {result} actual reviewed={mark}');check(not any(e.get('modified')==uri('beta','other.txt')for g in s['mainGroups']for e in g['editors']),'E02 no Beta other pane claimed from controlled completion')
case('E02',['E02-old-beta-reject-pending','E02-new-alpha-real-open','E02-old-beta-late-reject','E02-old-beta-void-pending','E02-new-alpha-other-real-open','E02-old-beta-late-void'],note='Late void remains delegated SCM success and marks Beta reviewed, without an opened Beta pane; status generation does not cancel marking.')
lane=json.loads((b/'lane-provenance/je-fourth-J-suite-continuity.json').read_text());check(lane['allPass'] and lane['identityScopeCount']==29 and all(x['oldAndFinalSourceAndNativeExact']for x in lane['rows']),'F01/E03 exact29 source/native continuity checked')
log=(b/'lane-provenance/je-formal-J-full.log').read_text();names=['markReviewedAfterSuccessfulOpen ignores stale and false without marking','stale review open does not mark reviewed or overwrite a newer direct-open failure','public finder and EditorService retain the exact typed Conversation object target','public finder and EditorService retain the exact typed Conversation id target','ordinary file, untitled, chat and writable diff stay outside Conversation for tokens and concrete targets','typed Conversation input rejects missing, wrong, removed and same-id forged concrete targets','an excluded non-Conversation part flag cannot authorize a typed Conversation input']
for n in names:check(n in log and '✔'in next(l for l in log.splitlines()if n in l),f'Lane actual passing assertion: {n}')
case('E03',[],'PASS_LANE_CONTINUITY','Explicit helper stale/no-mark uses prior actual J386 and exact29 source/native continuity; no fabricated UI stale, no D rerun.')
case('F01',[],'PASS_LANE_CONTINUITY','Actual public finder/EditorService object/id and negative fences read from immutable lane log; J386 prior run, not fourth-round or D rerun.')
loaded=json.loads((b/'loaded-manifest.json').read_text());check(len(loaded['files'])==18 and not loaded['missingCore'] if 'missingCore'in loaded else len(loaded['files'])==18,'J18 actual Debugger evidence count18')
for f in loaded['files']:check(f['sha256']==f['diskSha256'] and all(x['matchesCurrentDiskSource']for x in f['sourceMap']['sources']),'Actual J18 loaded bytes/source map match frozen disk')
assets=json.loads((b.parent/'e-response-after-preparation-20261027/runtime-assets-J.json').read_text());counts=collections.Counter(a['runtimeEvidenceStatus']for a in assets['assets']);check(counts['renderer-js-loaded']==39 and counts['renderer-css-loaded']==1 and counts['manifest-only']==12,'Additional loaded scope39 JS+1 CSS;12 manifest-only')
zero=json.loads((b/'zero-engine-rpc.json').read_text());check(zero['zeroEngineRpc'] and len(zero['snapshots'])==101,'101 actual disconnected/idle snapshots, empty-home route, zero engine RPC')
cleanup=json.loads((b/'cleanup-exit-proof.json').read_text());check(all(not p['procExists']for p in cleanup['pids'].values()) and not any(cleanup['portsAccepting'].values()) and cleanup['engineHomeRemoved'] and cleanup['profileRemoved'],'Exact owned PIDs/ports/home/profile cleaned')
check(fixture['matchesBaseline'] and all(not r['cachedDiffHex']for r in fixture['current']),'Fixture HEAD/index/worktree/file semantics unchanged')
case('X01',[],'PASS_ISOLATION','No stage/revert/checkout/commit after fixture creation; original fixtures preserved, own process/profile/empty engine-home cleanup proven.')
for x in json.loads((b/'dispatch-counts.json').read_text()):
    if x['label'].startswith(('P01-','P02-','P03-dispatch-counted-alternate','P03-dispatch-counted-openSelected','P04-','P05-')):check(x['apiDiffDispatchDelta']==1,f"{x['label']}: one official API dispatch")
check(all(not d['state']['uiErrors']for p in (b/'steps').glob('*.json')if 'state'in(d:=json.loads(p.read_text()))),'No browser unhandled error/rejection in all actual states')
m=json.loads((b/'matrix.json').read_text());m.update(phase='J-partial-after-completed',runtimeStarted=True,sourceHead='ce6d977a4316c1f903869089638a2cd7262dc7db',sourceTree='92801b513611ed3ae1ba36862a58131c609f6aa2',nativeProducer='8b4ddaa99a8cc88ed645407ee42075a8497c4f34',eServerStarted=False,critical=0,important=1,claim='15 own-runtime/isolation pass;2 lane-continuity only;1 partial fail. D1387 remains open; E never started.')
for c in m['cases']:c.update(case_evidence[c['id']])
(b/'matrix.json').write_text(json.dumps(m,indent=2)+'\n')
result={'checks':len(checks),'allPass':True,'critical':0,'important':1,'caseCounts':dict(collections.Counter(c['status']for c in m['cases'])),'runtimeAssetsCounts':dict(counts),'checksDetail':checks}
(b/'observation-assertions.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps({k:v for k,v in result.items()if k!='checksDetail'}))
