from pathlib import Path
import os,json,hashlib,stat,subprocess,datetime,sys
R=Path('/home/clarence/Projects/Agents/vscode-WorkTrees/merge')
P=Path('/sdd/tmp/vscode-conversation-visible-lease-old-business-20261028-prep3');D=Path(str(P)+'-review')
OLD=Path('/sdd/tmp/vscode-conversation-visible-lease-old-business-20261028-prep2');OD=Path(str(OLD)+'-review')
N=Path('/tmp/vscode-conversation-visible-lease-work-root-mount-isolated-diagnostics-20261027-prep2')
H='64934a7772b667c6a3aba9739fc4f935b5aeb115';T='3dc1205763451e60e70c1a8a84465613990aa526';SRC='5f36ed8809300700cfebf9c140d3e938327c024b'
V=Path('/sdd/tmp/lease-business-semantic-source-v3-20261028');VR=Path(str(V)+'-review')
sha=lambda b:hashlib.sha256(b).hexdigest()
now=lambda:datetime.datetime.now(datetime.timezone.utc).isoformat()
def git(*a):return subprocess.check_output(['rtk','proxy','git',*a],cwd=R)
def readj(p):return json.loads(Path(p).read_bytes())
def meta(p):
 p=Path(p);s=p.lstat();return dict(type=stat.S_IFMT(s.st_mode),fullMode=s.st_mode,size=s.st_size,mtimeNs=s.st_mtime_ns,ctimeNs=s.st_ctime_ns,symlinkTarget=os.readlink(p) if stat.S_ISLNK(s.st_mode) else None)
def nmeta(p):
 s=Path(p).lstat();return dict(type=stat.S_IFMT(s.st_mode),mode=stat.S_IMODE(s.st_mode),uid=s.st_uid,gid=s.st_gid,size=s.st_size,mtimeNs=s.st_mtime_ns,ctimeNs=s.st_ctime_ns)
digests={};hashed_bytes=0
def digest(p):
 global hashed_bytes
 p=Path(p);key=str(p)
 if key not in digests:
  h=hashlib.sha256()
  with p.open('rb') as f:
   while b:=f.read(1048576):h.update(b)
  digests[key]=h.hexdigest();hashed_bytes+=p.stat().st_size
 return digests[key]
def row(p,base=None):
 p=Path(p);x=dict(path=p.relative_to(base).as_posix() if base else str(p),**meta(p))
 if x['type']==stat.S_IFREG:x['sha256']=digest(p)
 return x
def rawjson(v):return (json.dumps(v,ensure_ascii=False,indent=2)+'\n').encode()
def fsyncdir(p):
 fd=os.open(p,os.O_RDONLY|os.O_DIRECTORY);os.fsync(fd);os.close(fd)
def write(p,b,mode=0o444):
 p=Path(p);assert p.is_relative_to(P) or p.is_relative_to(D),str(p)
 missing=[];parent=p.parent
 while not parent.exists():missing.append(parent);parent=parent.parent
 for parent in reversed(missing):parent.mkdir(mode=0o700)
 assert p.parent.resolve(strict=True)==p.parent
 with p.open('xb') as f:f.write(b);f.flush();os.fchmod(f.fileno(),mode);os.fsync(f.fileno())
 return dict(path=str(p),bytes=len(b),sha256=sha(b))
def xjson(p,v,mode=0o444):return write(p,rawjson(v),mode)
def workspace():
 assert git('rev-parse','HEAD').decode().strip()==H
 assert git('rev-parse','HEAD:src').decode().strip()==T
 assert git('branch','--show-current').decode().strip()=='loop/merge'
 assert git('status','--porcelain=v1','-z')==b''
def resources():
 capacity={}
 for k,p in [('sdd',P),('home',Path('/home/clarence/.codex/tmp')),('tmp',Path('/tmp'))]:
  v=os.statvfs(p);capacity[k]=dict(path=str(p),canonical=str(p.resolve()),device=p.stat().st_dev,availableBytes=v.f_bavail*v.f_frsize,availableInodes=v.f_favail,blockSize=v.f_frsize)
 memory={}
 for line in Path('/proc/meminfo').read_text().splitlines():
  k,v=line.split(':',1)
  if k in ['MemTotal','MemAvailable','SwapTotal','SwapFree','Shmem']:memory[k]=v.strip()
 def safe(p):
  try:return dict(value=Path(p).read_text(),error=None)
  except OSError as e:return dict(value=None,error=str(e))
 mounts={}
 for p in ['/sdd/tmp','/home/clarence/.codex/tmp','/tmp']:
  r=subprocess.run(['rtk','proxy','findmnt','-J','-T',p,'-o','TARGET,SOURCE,FSTYPE,OPTIONS,MAJ:MIN'],capture_output=True);mounts[p]=dict(actualExitCode=r.returncode,stdout=r.stdout.decode(),stderr=r.stderr.decode());assert r.returncode==0
 ns={}
 for k,p in [('self','/proc/self/ns/mnt'),('pid1','/proc/1/ns/mnt')]:
  try:ns[k]=dict(value=os.readlink(p),error=None)
  except OSError as e:ns[k]=dict(value=None,error=str(e))
 cgraw=Path('/proc/self/cgroup').read_text();cgroups={}
 for line in cgraw.splitlines():
  hierarchy,controllers,path=line.split(':',2)
  if hierarchy=='0':
   cg=Path('/sys/fs/cgroup')/path.lstrip('/')
   for q in [cg,*cg.parents]:
    if not q.is_relative_to('/sys/fs/cgroup'):break
    cgroups[str(q)]={n:safe(q/n) for n in ['memory.max','memory.current','memory.events','memory.swap.max','memory.swap.current']}
 return dict(capturedAtUtc=now(),uid=os.getuid(),gid=os.getgid(),capacity=capacity,memory=memory,mountNamespace=ns,mounts=mounts,procSelfCgroup=cgraw,cgroupAndAncestors=cgroups,noLockProbeOrAcquisition=True,noRuntimeMemoryOrLaneReadinessClaim=True)
def protect(phase):
 workspace()
 a_raw=(N/'guard-after-restore.json').read_bytes();b_raw=(OLD/'guard-after-restore.json').read_bytes()
 assert sha(a_raw)=='715f604de0029670e213bf808f20a9b18184d303257d273142003cc5dd119f25'
 assert len(b_raw)==20158278 and sha(b_raw)=='e182d89f5c85fe1ae57df4d5190d15f1590929b9713a6e18247213cd431798d4'
 a=json.loads(a_raw);b=json.loads(b_raw)
 for k in ['outMetadata','sourceNativePairs','freezeFiles','cacheSymlinks']:assert a[k]==b[k],k
 assert a['repositoryMetadata']['tuples']==b['repositoryMetadata']['tuples']
 assert a['nativeOverrides']==b['nativeOverrides']=={} and b['qualifiedCompletedPaths']==[] and b['provisionalActivePath'] is None and b['authorizedCtimeDifferences']==[]
 out={p.relative_to(R).as_posix():nmeta(p) for p in [R/'out',*(R/'out').rglob('*')]};assert out==a['outMetadata'];assert len(out)==15500
 counts={};tuples={}
 for scope in ['src','.build','node_modules']:
  rows=[]
  for p in sorted([R/scope,*(R/scope).rglob('*')],key=lambda q:q.relative_to(R).as_posix()):
   m=meta(p);rows.append([p.relative_to(R).as_posix(),m['type'],m['fullMode'],m['size'],m['mtimeNs'],m['ctimeNs'],m['symlinkTarget']])
  assert rows==a['repositoryMetadata']['tuples'][scope],scope;counts[scope]=len(rows);tuples[scope]=rows
 assert counts=={'src':15716,'.build':6778,'node_modules':48773}
 for name,x in a['freezeFiles'].items():assert digest(R/name)==x['sha256'] and nmeta(R/name)==x['metadata']
 for name,x in a['cacheSymlinks'].items():assert os.readlink(R/name)==x['target'] and str((R/name).resolve())==x['resolved'] and nmeta(R/name)==x['metadata']
 for x in a['sourceNativePairs']:
  data=(R/x['sourcePath']).read_bytes();assert len(data)==x['currentSourceBytes'] and sha(data)==x['currentSourceSha256'] and hashlib.sha1(b'blob '+str(len(data)).encode()+b'\0'+data).hexdigest()==x['currentSourceBlob'] and stat.S_IMODE((R/x['sourcePath']).stat().st_mode)==x['sourceMode'];assert digest(R/x['nativePath'])==x['nativeSha256'] and stat.S_IMODE((R/x['nativePath']).stat().st_mode)==x['nativeMode']
 for x in readj(OLD/'bound-tool-and-config-files.json'):
  p=Path(x['path']);assert p.stat().st_size==x['bytes'] and digest(p)==x['sha256'] and stat.S_IMODE(p.stat().st_mode)==x['mode']
 oldim=readj(OLD/'immutable-protection-inventory.json');assert len(oldim['rows'])==2018 and len(oldim['additionalRootInclusiveRows'])==1220
 assert oldim['oldFileCount']==797 and oldim['oldNonRegularCount']==215 and oldim['proofFileCounts']==[280,244,235]
 assert {str(p) for root in oldim['roots'] for p in Path(root).rglob('*')}=={x['path'] for x in oldim['rows']}
 assert {str(p) for root in oldim['additionalRootInclusiveRoots'] for p in [Path(root),*Path(root).rglob('*')]}=={x['path'] for x in oldim['additionalRootInclusiveRows']}
 for x in oldim['rows']+oldim['additionalRootInclusiveRows']:assert row(Path(x['path']))==x,x['path']
 nine=[OLD,OD,Path('/home/clarence/.codex/tmp/vscode-conversation-visible-lease-old-business-20261028-prep1-review'),Path(str(N)+'-review'),Path('/home/clarence/.codex/tmp/lease-business-semantic-source-v1-20261028'),Path('/home/clarence/.codex/tmp/lease-business-semantic-source-v2-20261028'),Path('/home/clarence/.codex/tmp/lease-business-semantic-source-v2-20261028-review'),V,VR]
 allroots=[Path(s) for s in oldim['roots']+oldim['additionalRootInclusiveRoots']]+nine
 assert len(allroots)==len(set(allroots))==20
 for i,root in enumerate(allroots):
  assert root.is_absolute() and root.resolve(strict=True)==root and root.is_dir() and not root.is_symlink()
  for other in allroots[i+1:]+[P,D]:assert not root.is_relative_to(other) and not other.is_relative_to(root)
 extra=[];counts9={}
 for root in nine:
  actual=[row(p) for p in sorted([root,*root.rglob('*')],key=str)];counts9[str(root)]=len(actual);extra+=actual
 post=readj(OD/'authorized-old-once-20261027T184023447555Z/postrun-package-inventory.json')
 actual={x['path']:x for x in extra if Path(x['path']).is_relative_to(OLD)}
 expected={str(OLD/x['path']):{**{k:v for k,v in x.items() if k!='artifactGroup'},'path':str(OLD/x['path'])} for x in post['rows']}
 assert actual==expected
 for source_root in [Path('/home/clarence/.codex/tmp/lease-business-semantic-source-v2-20261028'),V]:
  inv=readj(Path(str(source_root)+'-review')/'final-source-only-directory-inventory.json')
  assert {p.relative_to(source_root).as_posix() for p in [source_root,*source_root.rglob('*')]}=={x['path'] for x in inv['rows']}
  for x in inv['rows']:assert row(source_root/x['path'],source_root)==x
 combined=oldim['rows']+oldim['additionalRootInclusiveRows']+extra;assert len({x['path'] for x in combined})==len(combined)
 inv={**oldim,'additionalRootInclusiveRoots':oldim['additionalRootInclusiveRoots']+[str(x) for x in nine],'additionalRootInclusiveRows':oldim['additionalRootInclusiveRows']+extra}
 if phase=='before-assembly':xjson(D/'immutable-originals-before.json',inv)
 else:assert inv==readj(D/'immutable-originals-before.json'),'immutable original drift'
 log=R/'.build/log';assert log.read_bytes()==b'[]' and log.stat().st_mtime_ns==log.stat().st_ctime_ns==1793100181156749660
 result=dict(capturedAtUtc=now(),phase=phase,workspaceHead=H,sourceTree=T,gitClean=True,runtimePredecessorPath=str(N/'guard-after-restore.json'),runtimePredecessorSha256=sha(a_raw),consumedFailureProvenancePath=str(OLD/'guard-after-restore.json'),consumedFailureProvenanceSha256=sha(b_raw),currentEqualsE182Equals715RelevantDomain=True,domain=['outMetadata','sourceNativePairs','freezeFiles','cacheSymlinks','repositoryMetadata.tuples'],zeroFreshMetadataByteWriteOrCtimeDifferences=True,zeroFreshWritesQualifiedPathsOverridesOrRestorations=True,original715HistoricalCtimeAnnotationPreservedNotReinterpretedAsCurrentDifference=a['authorizedCtimeDifferences'],legacyDescendantOnlyRoots=8,legacyRows=2018,originalClassificationsUnchanged=True,priorInclusiveRoots=3,priorInclusiveRows=1220,original3238RowsUnchanged=True,nineFreshRootInclusiveCounts=counts9,nineFreshRootInclusiveRows=len(extra),combinedImmutableRows=len(combined),allCanonicalNoAliasContainmentOrDuplicateRoots=True,currentPackageAndReviewExcluded=True,ongoingIAreaExcluded=True,listedTargetedFilesFreshlyHashed=len(digests),listedTargetedBytesFreshlyHashed=hashed_bytes,full119095ContextOr27318ExternalRegularContentRehashed=False,bound149Exact=True,sourceNative256Exact=True,freeze4Cache3Exact=True,out15500MetadataExact=True,protectedRepositoryCounts=counts,buildLogExact=True,invocations=0,candidateImports=0,candidateExecutions=0,syntaxInvocations=0,lockProbePerformed=False,wholeBuildProtectionPassed=False)
 xjson(Path(__file__).parent/'targeted-original-protection.json',result);return result
if __name__=='__main__':
 phase=sys.argv[1]
 if phase=='preflight':
  x=resources();assert x['capacity']['sdd']['availableBytes']>=10200547328 and x['capacity']['sdd']['availableInodes']>=200000;assert x['capacity']['home']['availableBytes']>=67108864 and x['capacity']['tmp']['availableBytes']>=134217728
  xjson(D/'initial-preflight.json',x)
  xjson(D/'capacity-budget.json',dict(capturedAtUtc=now(),capacity=x['capacity'],sddBudgetsBytes=dict(staticPackage=268435456,review=268435456,futureOldRuntime=4294967296,futureAfterAllowanceOnlyNoReservation=4294967296,margin=1073741824),sddTotalEstimatedBytes=10200547328,sddInodeAllowance=200000,homeFuturePublicationBytes=67108864,tmpFutureLockXvfbBytes=134217728,existingOriginalsAlreadyRetainedAndNotSubtractedAgain=True,noReservationOrQuota=True,noCurrentLaneOrRuntimeMemoryReadinessClaim=True,futureExecutionMustRecaptureResources=True))
  print(json.dumps({'resourcePreflight':True,'capacity':x['capacity']}))
 else:print(json.dumps(protect(phase)))
