const fs=require('node:fs'),path=require('node:path');
const {chromium}=require('/home/clarence/Projects/Agents/vscode-WorkTrees/merge/node_modules/playwright-core');
const base=__dirname;
(async()=>{
 const info=JSON.parse(fs.readFileSync(path.join(base,'launch.json')));
 const browser=await chromium.connectOverCDP('http://127.0.0.1:'+info.cdpPort);
 try{
  const page=browser.contexts().flatMap(c=>c.pages()).find(p=>p.url().includes('/workbench-dev.html')&&p.url().includes(info.repo+'/out/'));
  if(!page)throw Error('own default editor target absent');
  if(info.runId!=='sources-m01-after-20261027-r2'||!info.freezeNoticeSha256||!info.frozenOutputsSha256)throw Error('launch is not bound to this fresh run');
  await page.waitForFunction(()=>!!window.driver);await page.evaluate(()=>window.driver.whenWorkbenchRestored());
  const result=await page.evaluate(async()=>{
   const root=location.href.split('/out/')[0]+'/out/';
   let bag=window.__d1387;
   if(!bag){
    bag=window.__d1387={events:[],connectionEvents:[],uiErrors:[],startedAt:Date.now()};
    const {CommandsRegistry,ICommandService}=await import(root+'vs/platform/commands/common/commands.js');
    const {IInstantiationService}=await import(root+'vs/platform/instantiation/common/instantiation.js');
    const {IEditorService}=await import(root+'vs/workbench/services/editor/common/editorService.js');
    const {IEditorGroupsService}=await import(root+'vs/workbench/services/editor/common/editorGroupsService.js');
    const {ICodeEditorService}=await import(root+'vs/editor/browser/services/codeEditorService.js');
    const {IConfigurationService}=await import(root+'vs/platform/configuration/common/configuration.js');
    const {IConversationRosterService}=await import(root+'vs/workbench/contrib/conversation/browser/conversationStubService.js');
    const {IUniverseAgentConnection}=await import(root+'vs/platform/universeAgent/common/universeAgentConnection.js');
    const {ISourcesReviewHostService}=await import(root+'vs/workbench/contrib/sources/common/sourcesReviewHostService.js');
    const {IWorkbenchEnvironmentService}=await import(root+'vs/workbench/services/environment/common/environmentService.js');
    const {URI}=await import(root+'vs/base/common/uri.js');
    const capture=CommandsRegistry.registerCommand('d1387.independent.capture',accessor=>{
     Object.assign(bag,{registry:CommandsRegistry,URI,inst:accessor.get(IInstantiationService),commands:accessor.get(ICommandService),editors:accessor.get(IEditorService),groups:accessor.get(IEditorGroupsService),code:accessor.get(ICodeEditorService),config:accessor.get(IConfigurationService),roster:accessor.get(IConversationRosterService),connection:accessor.get(IUniverseAgentConnection),reviewHost:accessor.get(ISourcesReviewHostService),environment:accessor.get(IWorkbenchEnvironmentService)});
    });
    try{await window.driver.executeCommand('d1387.independent.capture');}finally{capture.dispose();}
    bag.describe=input=>input?({ctor:input.constructor.name,typeId:input.typeId,resource:input.resource?.toString(),name:input.getName?.(),original:input.original?.resource?.toString()??(input.original?.scheme?input.original.toString():undefined),modified:input.modified?.resource?.toString()??(input.modified?.scheme?input.modified.toString():undefined)}):null;
    bag.commandListener=bag.commands.onWillExecuteCommand(event=>{if(/^(git\.|sources\.|conversation\.|workbench.action.*(Editor|Group|Panel))/.test(event.commandId))bag.events.push({at:Date.now(),id:event.commandId,args:event.args?.map(value=>value?.scheme?value.toString():value&&typeof value==='object'?Object.fromEntries(Object.entries(value).filter(([k,v])=>v===null||['string','number','boolean'].includes(typeof v)||v?.scheme).map(([k,v])=>[k,v?.scheme?v.toString():v])):value)});});
    bag.connectionListener=bag.connection.onDidChangeConnection(value=>bag.connectionEvents.push({at:Date.now(),snapshot:value}));
    window.addEventListener('error',event=>bag.uiErrors.push({at:Date.now(),message:event.message}));
    window.addEventListener('unhandledrejection',event=>bag.uiErrors.push({at:Date.now(),rejection:String(event.reason)}));
   }
   return {url:location.href,isSessionsWindow:bag.environment.isSessionsWindow,connected:bag.connection.isEngineConnected(),connection:bag.connection.getConnectionSnapshot(),body:document.body.innerText,groups:bag.groups.groups.map(group=>({id:group.id,label:group.label,active:bag.describe(group.activeEditor),editors:group.editors.map(input=>({...bag.describe(input),pinned:group.isPinned(input)}))})),active:bag.describe(bag.editors.activeEditor),visible:bag.editors.visibleEditorPanes.map(pane=>({id:pane.getId(),group:pane.group?.id,input:bag.describe(pane.input)})),diffs:bag.code.listDiffEditors().map(editor=>({id:editor.getId(),original:editor.getModel()?.original.uri.toString(),modified:editor.getModel()?.modified.uri.toString(),originalText:editor.getModel()?.original.getValue(),modifiedText:editor.getModel()?.modified.getValue()})),commands:[...bag.registry.getCommands().keys()].filter(id=>/sources\.|conversation\.|git\.openChange/.test(id)),events:bag.events,connectionEvents:bag.connectionEvents,uiErrors:bag.uiErrors};
  });
  await page.evaluate(binding=>{Object.assign(window.__d1387,{runId:binding.runId,frozenSourceHead:binding.sourceHead,frozenSourceTree:binding.sourceTree,freezeNoticeSha256:binding.freezeNoticeSha256,frozenOutputsSha256:binding.frozenOutputsSha256});},{runId:info.runId,sourceHead:info.explicitReadySource,sourceTree:info.explicitReadySourceTree,freezeNoticeSha256:info.freezeNoticeSha256,frozenOutputsSha256:info.frozenOutputsSha256});
  Object.assign(result,{runId:info.runId,sourceHead:info.explicitReadySource,sourceTree:info.explicitReadySourceTree,freezeNoticeSha256:info.freezeNoticeSha256,frozenOutputsSha256:info.frozenOutputsSha256});
  fs.mkdirSync(path.join(base,'shots'),{recursive:true});
  fs.writeFileSync(path.join(base,'probe.json'),JSON.stringify(result,null,2));
  await page.screenshot({path:path.join(base,'shots','00-initial-default-editor.png')});
  console.log(JSON.stringify(result,null,2));
 }finally{await browser.close();}
})().catch(error=>{console.error(error);process.exitCode=1;});
