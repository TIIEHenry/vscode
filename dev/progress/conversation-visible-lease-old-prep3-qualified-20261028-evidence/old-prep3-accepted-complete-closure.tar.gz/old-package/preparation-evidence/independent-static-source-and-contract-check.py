from pathlib import Path
import re
D=Path('/sdd/tmp/vscode-conversation-visible-lease-old-business-20261028-prep3-review')
ns={'__name__':'own_support'}
exec(compile((D/'static-support-and-protection.py').read_bytes(),str(D/'static-support-and-protection.py'),'exec'),ns)
globals().update({k:v for k,v in ns.items() if not k.startswith('__')})
workspace()
schema=readj(P/'package-contract.schema.json')
def validate_data(value,s,path='$'):
 errors=[]
 typ=s.get('type')
 kinds={'object':lambda x:isinstance(x,dict),'array':lambda x:isinstance(x,list),'string':lambda x:isinstance(x,str),'integer':lambda x:isinstance(x,int) and not isinstance(x,bool),'number':lambda x:isinstance(x,(int,float)) and not isinstance(x,bool),'boolean':lambda x:isinstance(x,bool),'null':lambda x:x is None}
 if typ and not kinds[typ](value):return [path+': type '+typ]
 if 'const' in s and (value!=s['const'] or type(value)!=type(s['const'])):errors.append(path+': const')
 if 'enum' in s and value not in s['enum']:errors.append(path+': enum')
 if isinstance(value,str):
  if len(value)<s.get('minLength',0):errors.append(path+': minLength')
  if 'pattern' in s and re.search(s['pattern'],value) is None:errors.append(path+': pattern')
 if isinstance(value,int) and not isinstance(value,bool) and 'minimum' in s and value<s['minimum']:errors.append(path+': minimum')
 if isinstance(value,list):
  if len(value)<s.get('minItems',0):errors.append(path+': minItems')
  if 'maxItems' in s and len(value)>s['maxItems']:errors.append(path+': maxItems')
  for i,x in enumerate(value):
   if 'items' in s:errors+=validate_data(x,s['items'],path+'['+str(i)+']')
 if isinstance(value,dict):
  for k in s.get('required',[]):
   if k not in value:errors.append(path+'.'+k+': required')
  props=s.get('properties',{})
  for k,x in value.items():
   if k in props:errors+=validate_data(x,props[k],path+'.'+k)
   elif s.get('additionalProperties') is False:errors.append(path+'.'+k+': additionalProperties')
   elif isinstance(s.get('additionalProperties'),dict):errors+=validate_data(x,s['additionalProperties'],path+'.'+k)
 return errors

manifest=readj(P/'input-manifest.json');policy=readj(P/'policy.json');seals=readj(P/'sealed-originals.json');profile=readj(P/'business-profile.json')
for name,value in {'inputManifest':manifest,'policy':policy,'sealedOriginals':seals}.items():
 errors=validate_data(value,schema['properties'][name],name);assert not errors,errors
assert manifest['sourceOnlyDirectory']=='/home/clarence/.codex/tmp/lease-business-semantic-source-v1-20261028' and manifest['sourceOnlyDirectoryIsActualRuntimeSource'] is False and 'exclusion' in manifest['sourceOnlyDirectoryPurpose']
assert manifest['runtimeSourcePublicationCommit']==SRC and manifest['runtimeSourceFreezeDirectory']==str(V)
assert manifest['expectedHead']==H and manifest['sourceTree']==T
provenance=readj(P/'source-provenance.json');assert len(provenance['runtimeSourceFiles'])==13 and provenance['workspaceHead']==H and provenance['runtimeSourcePublicationCommit']==SRC
for source in provenance['runtimeSourceFiles']:
 b=(P/source['name']).read_bytes();assert b==git('show',SRC+':'+source['sourcePath'])==(V/'candidate'/source['name']).read_bytes() and len(b)==source['bytes'] and sha(b)==source['sha256']
 if source['name']!='linter.mjs':assert b==(OLD/source['name']).read_bytes()
assert provenance['sourceV3FreezeSha256']=='ddab6b01d9351bd52e2f61268644d4edd8d9cf5ed69db93060f2bd4b811e28f4'
assert sha((V/'source-freeze.json').read_bytes())==provenance['sourceV3FreezeSha256']
assert readj(V/'source-freeze.json')['state']=='SOURCE_V3_STATIC_FROZEN_SYNTAX_PENDING'
syntax=provenance['acceptedUniqueSyntaxReceipt'];syntax_raw=(P/syntax['copyPath']).read_bytes();assert len(syntax_raw)==5972 and sha(syntax_raw)==syntax['sha256']=='5ca196b436a55a8588a10c8e1a09271e87f2ea4b5ea8e07372a244b39856b5c0'
assert syntax_raw==Path(syntax['originalPath']).read_bytes() and json.loads(syntax_raw)['actualExitCode']==0
for source in provenance['reviewedV3PublicationCopies']:
 b=(P/source['copyPath']).read_bytes();assert b==git('show',source['sourceRef']+':'+source['path']) and len(b)==source['bytes'] and sha(b)==source['sha256']
for source in provenance['historicalInertPublicationAndSupportCopies']:
 b=(P/source['copyPath']).read_bytes();assert b==Path(source['originalPath']).read_bytes() and len(b)==source['bytes'] and sha(b)==source['sha256']
selection=readj(P/'selection.json');assert selection==profile['modes']['old']['selection'] and selection['expectedSelectionCount']==2 and selection['expectedHookPairs']==10 and sum(selection['expectedHookTitleCounts'].values())==10
assert (P/'expected-L1-plus-meta-fullTitles.txt').read_bytes()==('\n'.join(selection['requiredFullTitles'])+'\n').encode()
assert policy['stageOrder']==profile['stageOrder']==['checker','lint','dry','emit-pane','emit-reveal','official']
assert policy['emissionPhases']==profile['emissionPhases'] and policy['writableOutputPaths']==profile['outputPaths']
assert manifest['sourceFiles']==readj(P/'source-inputs.json') and len(manifest['sourceFiles'])==2
fixed=[('pane','a4a70322795c509e8e9b8274cf295a1b65db663a','8678204094b429fd4280dd528a70e83b9fcf5289',14186,'51cfc03a3be5dc2077c30e4a4ba72ca57b150a71c5a5649239087a0d339fcc65'),('reveal','b078a9a7613ee8459bf230c659e933dd5b3d701a','feb55eeed2013c948ae487bdba8217887d2fc0b5',81721,'8a9c3245ae661b68e160c6a1c0d79924159618da7b342c5b09cd46caa1f35e61')]
for source,expected in zip(manifest['sourceFiles'],fixed):
 assert tuple(source[k] for k in ['role','sourceRef','sourceBlob','sourceBytes','sourceSha256'])==expected
 b=Path(source['inputCopyPath']).read_bytes();assert b.decode().encode()==b and b==git('show',source['sourceRef']+':'+source['sourcePath']) and len(b)==source['sourceBytes'] and sha(b)==source['sourceSha256']
 assert git('rev-parse',source['sourceRef']+':'+source['sourcePath']).decode().strip()==source['sourceBlob']
 seal=next(x for x in seals if x['path']==source['outputPath']);assert Path(seal['sealedBytesPath']).read_bytes()==(R/seal['path']).read_bytes() and sha(Path(seal['sealedBytesPath']).read_bytes())==seal['sha256']
 assert all(nmeta(R/seal['path'])[k]==seal[k] for k in ['mode','mtimeNs','ctimeNs']) and seal['restoreAuthority'] is False and seal['writeAuthorizedNow'] is False
anchor_raw=(N/'guard-after-restore.json').read_bytes();assert sha(anchor_raw)=='715f604de0029670e213bf808f20a9b18184d303257d273142003cc5dd119f25';anchor=json.loads(anchor_raw)
fresh_raw=Path(manifest['currentNativeGuardFile']).read_bytes();fresh=json.loads(fresh_raw);assert sha(fresh_raw)==manifest['currentNativeGuardSha256'] and len(fresh_raw)==manifest['currentNativeGuardBytes']
assert fresh['schemaVersion']==manifest['guardSchemaVersion']==manifest['schemaVersion']==6 and fresh['packageId']==P.name and fresh['outMetadata']==anchor['outMetadata'] and fresh['sourceNativePairs']==anchor['sourceNativePairs']==manifest['boundSourceNativePairs']
rep_raw=Path(manifest['repositoryMetadataBaselineFile']).read_bytes();rep=json.loads(rep_raw);assert sha(rep_raw)==manifest['repositoryMetadataBaselineSha256'] and rep['schemaVersion']==manifest['repositoryMetadataSchemaVersion']==2 and rep['tuples']==anchor['repositoryMetadata']['tuples']
assert manifest['baselineLineage']['predecessorGuardFile']==str(N/'guard-after-restore.json') and manifest['baselineLineage']['predecessorGuardSha256']==sha(anchor_raw)
assert readj(P/'consumed-old-prep2-provenance.json')['runtimePredecessorIsStillActual715'] is True
im=readj(P/'immutable-protection-inventory.json');oldim=readj(OLD/'immutable-protection-inventory.json')
assert im==readj(D/'immutable-originals-before.json')
assert im['rows']==oldim['rows'] and im['additionalRootInclusiveRows'][:len(oldim['additionalRootInclusiveRows'])]==oldim['additionalRootInclusiveRows'] and im['additionalRootInclusiveRoots'][:3]==oldim['additionalRootInclusiveRoots']
assert len(im['rows'])==2018 and len(im['additionalRootInclusiveRoots'])==12 and len(im['additionalRootInclusiveRows'])==2151
assert len({x['path'] for x in im['rows']+im['additionalRootInclusiveRows']})==4169
assert sha((P/'immutable-protection-inventory.json').read_bytes())==manifest['immutableProtectionInventorySha256']
native=(P/'native-asset-manifest.json').read_bytes();original=(N/'native-asset-manifest.json').read_bytes();pv=readj(P/'native-asset-manifest-provenance.json');replay=original
for k,v in pv['exactTwoFieldDelta'].items():
 a=json.dumps(v['before']).encode();b=json.dumps(v['after']).encode();assert replay.count(a)==1;replay=replay.replace(a,b,1)
assert replay==native
for k,v in pv['exactTwoFieldDelta'].items():
 a=json.dumps(v['before']).encode();b=json.dumps(v['after']).encode();assert replay.count(b)==1;replay=replay.replace(b,a,1)
assert replay==original
oldj=json.loads(original);newj=json.loads(native);assert len(newj['files'])==11168 and {k:v for k,v in newj.items() if k!='files'}=={k:v for k,v in oldj.items() if k!='files'}
diffs=[]
for old,new in zip(oldj['files'],newj['files']):
 assert old['path']==new['path']
 if old!=new:diffs.append((old['path'],sorted(k for k in old if old[k]!=new[k])))
assert diffs==[(next(x['outputPath'] for x in manifest['sourceFiles'] if x['role']=='reveal'),['currentSourceBlob','currentSourceSha256'])]
for name in ['dry-output-seals.json','execution-consumed.json','generated','dry','stages','runtime','stage-checker','stage-lint','execution-release.json','package-final-audit.json']:assert not (P/name).exists()
report=dict(capturedAtUtc=now(),scope='Independent executor-owned static schema/data/identity verification of source, immutable inputs, lineage, protected-original inventory and native two-field replay only. No candidate parse/import/execution or syntax repetition. Seven historical/live-doc reference disposition is excluded pending root and Original Astra narrow review.',schemaErrors=[],checkedSchemaDocuments=['inputManifest','policy','sealedOriginals'],workspaceHead=H,runtimeSourcePublicationCommit=SRC,sourceTree=T,runtime13Exact5fV3=True,other12ExactV2C6=True,linter17913Sha256='89908e85de9e4a5b416fb9706f7dfd78155ca03d4c839cbcf2290c0df4e163ca',originalFreezePendingLabelPreserved=True,acceptedPriorUniqueSyntaxReceiptExact=True,v3PublicationCopies=len(provenance['reviewedV3PublicationCopies']),historicalInertCopies=len(provenance['historicalInertPublicationAndSupportCopies']),exactImmutableInputCount=2,fullTitlesAndTenHookPairsExact=True,sixStageOrderExact=True,runtime715PredecessorNotE182=True,legacy2018AndPrior1220Unchanged=True,additionalInclusiveRows=2151,combinedImmutableRows=4169,nativeOnlyTwoRevealCurrentSourceFieldsChanged=True,entireOriginalForwardInverseExact=True,noWriteRestorationDryOrExecutionAuthority=True,executionReleaseRuntimeSchemaIntentionallyNotEvaluatedAsPass=True,candidateInvocations=0,syntaxCalls=0)
xjson(D/'independent-static-source-and-contract-check.json',report);workspace();print(json.dumps(report))
