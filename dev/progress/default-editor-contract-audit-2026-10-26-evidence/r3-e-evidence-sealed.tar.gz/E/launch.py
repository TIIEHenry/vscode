from pathlib import Path
import sys
sys.path.insert(0,str(Path(__file__).resolve().parent.parent/'common'))
from launch_runtime import main
if __name__=='__main__':main('E')
