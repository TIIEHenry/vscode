"""Seal only completed actual J observations. Never launches an app or issues completion."""
from pathlib import Path
import datetime,hashlib,json,stat,tarfile
ROOT=Path(__file__).resolve().parent.parent
BASE=ROOT/'J'
read=lambda p:json.loads(Path(p).read_text())
sha=lambda data:hashlib.sha256(data).hexdigest()
def row(path):
    assert path.is_file()and not path.is_symlink()
    return {'path':str(path.relative_to(ROOT)),'bytes':path.stat().st_size,'mode':stat.S_IMODE(path.stat().st_mode),'sha256':sha(path.read_bytes())}
def main():
    archive=BASE/'J-evidence-sealed.tar.gz';inventory=BASE/'artifact-inventory.json';verification=BASE/'archive-member-verification.json';seal=BASE/'J-stage-seal.json'
    assert all(not p.exists()for p in [archive,inventory,verification,seal])
    assert not(BASE/'phase-complete.json').exists()and not(ROOT/'E/execution-authorization.json').exists()and not(ROOT/'E/server-started.json').exists()
    facts=read(BASE/'J-stage-facts.json');cleanup=read(BASE/'cleanup-independent-verification.json');assert facts['assertions']['count']==510 and facts['assertions']['failed']==0 and facts['runtimeSnapshots']==67
    assert cleanup['profileAbsent']and cleanup['JHomeAbsent']and not cleanup['remainingOriginalOwnedLive']and not cleanup['remainingOwnRunDirOrEngineHomeLive']
    assert not Path(read(BASE/'launch.json')['runDir']).exists()and not Path(read(BASE/'launch.json')['engineHome']).exists()
    excluded={str(p.relative_to(ROOT))for p in [archive,inventory,verification,seal]}
    paths=[p for p in sorted(ROOT.rglob('*'))if p.is_file()and str(p.relative_to(ROOT))not in excluded]
    assert not any(p.is_symlink()for p in ROOT.rglob('*'))
    originals=[row(p)for p in paths]
    record={'runId':facts['runId'],'phase':'J','state':'INVENTORY_OF_ACTUAL_STAGE_AWAITING_ROOT_REVIEW','createdAt':datetime.datetime.now(datetime.timezone.utc).isoformat(),'sourceHead':facts['finalSourceHead'],'sourceTree':facts['finalSourceTree'],'lineageSha256':facts['lineageSha256'],'regularOriginalFiles':len(originals),'archiveMemberCountIncludingThisInventory':len(originals)+1,'inventorySelfDigestExcludedToAvoidRecursion':True,'files':originals,'noPhaseCompleteOrEAuthorization':True}
    inventory.write_text(json.dumps(record,indent=2)+'\n');allRows=originals+[row(inventory)]
    with tarfile.open(archive,'w:gz',format=tarfile.PAX_FORMAT)as tar:
        for item in allRows:tar.add(ROOT/item['path'],arcname=item['path'],recursive=False)
    expected={item['path']:item for item in allRows};checks=[]
    with tarfile.open(archive,'r:gz')as tar:
        members=tar.getmembers();assert len(members)==len(expected)and len({m.name for m in members})==len(expected)
        assert {m.name for m in members}==set(expected)
        for member in members:
            assert member.isfile()and not member.issym()and not member.islnk()and'..'not in Path(member.name).parts and not Path(member.name).is_absolute()
            original=expected[member.name];data=tar.extractfile(member).read();assert len(data)==original['bytes']and sha(data)==original['sha256']and member.mode==original['mode']
            assert row(ROOT/member.name)==original
            checks.append({'path':member.name,'bytes':len(data),'sha256':sha(data),'mode':member.mode,'matchesOriginal':True})
    archiveSha=sha(archive.read_bytes());inventorySha=sha(inventory.read_bytes())
    result={'runId':facts['runId'],'phase':'J','method':'reopened archive; every regular member byte count/SHA256/mode and current original rechecked; no external extraction writes','archive':str(archive.relative_to(ROOT)),'archiveSha256':archiveSha,'archiveBytes':archive.stat().st_size,'inventory':str(inventory.relative_to(ROOT)),'inventorySha256':inventorySha,'originalFileCount':len(originals),'archiveRegularMemberCount':len(checks),'allMemberBytesShaModesMatch':True,'allCurrentOriginalsStillIdentical':True,'members':checks}
    verification.write_text(json.dumps(result,indent=2)+'\n')
    summary={'runId':facts['runId'],'phase':'J','state':'SEALED_AWAITING_ROOT_INDEPENDENT_ARCHIVE_REVIEW','sealedAt':datetime.datetime.now(datetime.timezone.utc).isoformat(),'sourceHead':facts['finalSourceHead'],'sourceTree':facts['finalSourceTree'],'fullCompileOfFinalSourceTree':False,'lineageSha256':facts['lineageSha256'],'frozenOutputsSha256':facts['frozenOutputsSha256'],'commonAssets':138,'fullAssets':254,'runtimeSnapshots':67,'assertionCount':510,'assertionFailures':0,'observedMatrixRows':18,'M01':'one real Pane button + four public Move commands = five owner paths','loadedRendererJs':124,'loadedRendererCss':1,'manifestOnly':13,'ownedLifetimesVerified':15,'remainingOwnedLive':0,'profileRemoved':True,'JHomeRemoved':True,'supplementaryObserverFailurePreserved':'J/cleanup-independent-verification-attempt1.failure.json','archive':result['archive'],'archiveSha256':archiveSha,'archiveBytes':result['archiveBytes'],'inventory':result['inventory'],'inventorySha256':inventorySha,'originalFiles':len(originals),'archiveMembers':len(checks),'memberVerification':str(verification.relative_to(ROOT)),'memberVerificationSha256':sha(verification.read_bytes()),'stageFactsSha256':sha((BASE/'J-stage-facts.json').read_bytes()),'runtimeReportSha256':sha((BASE/'J-RUNTIME-REPORT.md').read_bytes()),'assertionsSha256':sha((BASE/'assertions.json').read_bytes()),'matrixSha256':sha((BASE/'matrix.json').read_bytes()),'phaseCompleteCreated':False,'EAuthorized':False}
    seal.write_text(json.dumps(summary,indent=2)+'\n');print(json.dumps({**summary,'stageSealSha256':sha(seal.read_bytes())}))
if __name__=='__main__':main()
