import hashlib
import json
import pathlib
import re
import subprocess

base = pathlib.Path(__file__).resolve().parent
merge = pathlib.Path('/home/clarence/Projects/Agents/vscode-WorkTrees/merge')
modules = [
    'vs/workbench/contrib/sources/browser/sourcesChangeEntryOpen',
    'vs/workbench/services/editor/browser/editorOpenSlot',
    'vs/workbench/services/editor/common/editorGroupFinder',
    'vs/workbench/services/editor/browser/editorService',
    'vs/workbench/contrib/conversation/common/conversationEditorRouting',
    'vs/workbench/contrib/sources/browser/sourcesChangesList',
    'vs/workbench/contrib/sources/browser/sourcesReviewList',
    'vs/workbench/contrib/sources/browser/sourcesReviewCommands.contribution',
    'vs/workbench/contrib/sources/browser/sourcesDiffActions',
    'vs/workbench/contrib/sources/browser/sourcesOpenStatus',
    'vs/workbench/contrib/sources/browser/sourcesTabsHost',
    'vs/workbench/contrib/sources/common/sourcesReviewHostService',
    'vs/workbench/contrib/sources/browser/conversationDiffReviewPane',
    'vs/workbench/contrib/sources/browser/conversationDiffReviewInput',
    'vs/workbench/contrib/sources/browser/sourcesDiffPanelService',
    'vs/workbench/contrib/sources/browser/sourcesDiffPanelView',
    'vs/workbench/browser/parts/editor/editorCommands',
    'vs/workbench/api/browser/mainThreadSCM',
]
original_required = {'out/' + module + '.js' for module in modules}
contract = json.loads((base.parent / 'e-response-after-preparation-20261027' / 'final-freeze-contract.json').read_text())
assert set(contract['originalJ18']) == original_required and len(original_required) == 18
required = original_required | {item['path'] for item in contract['mandatoryAdditions']}


def git(*args):
    return subprocess.check_output(['rtk', 'proxy', 'git', *args], cwd=merge, text=True).strip()


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def verify():
    notice_path = base / 'fresh-notice.json'
    if not notice_path.exists():
        raise RuntimeError('NOT READY: explicit frozen-production notice from /root/baseline_executor is absent')
    notice = json.loads(notice_path.read_text())
    assert notice['phase'] == 'D1387-production-frozen'
    assert notice['reportedBy'] == '/root/baseline_executor'
    assert notice['consumer'] == '/root/sources_audit'
    assert notice['outFrozen'] is True
    assert re.fullmatch('[0-9a-f]{40}', notice['sourceHead'])
    assert notice['fixedExternalBaselineCommit'] == contract['fixedExternalBaselineCommit']
    subprocess.run(['rtk', 'proxy', 'git', 'merge-base', '--is-ancestor', contract['fixedExternalBaselineCommit'], notice['sourceHead']], cwd=merge, check=True)
    subprocess.run(['rtk', 'proxy', 'git', 'merge-base', '--is-ancestor', notice['sourceHead'], 'HEAD'], cwd=merge, check=True)
    source_tree = git('rev-parse', notice['sourceHead'] + ':src')
    assert source_tree == notice['sourceTree'] == git('rev-parse', 'HEAD:src'), 'source tree changed since freeze'
    assert git('status', '--porcelain', '--', 'src') == '', 'source has uncommitted edits'
    outputs = notice['outputs']
    assert len(outputs) == len({item['path'] for item in outputs}), 'freeze duplicates native paths'
    assert required.issubset({item['path'] for item in outputs}), 'freeze omits required modules'
    checked = []
    for item in outputs:
        rel = pathlib.PurePosixPath(item['path'])
        assert rel.parts[:2] == ('out', 'vs') and '..' not in rel.parts and rel.suffix in ('.js', '.css')
        assert re.fullmatch('[0-9a-f]{64}', item['sha256'])
        target = merge / rel
        actual = sha(target)
        assert actual == item['sha256'], str(target) + ' differs from frozen output'
        source = pathlib.PurePosixPath('src', *rel.parts[1:])
        if rel.suffix == '.js':
            source = source.with_suffix('.ts')
        assert item['sourcePath'] == str(source), 'wrong source/native mapping'
        assert re.fullmatch('[0-9a-f]{64}', item['sourceSha256'])
        source_sha = sha(merge / source)
        assert source_sha == item['sourceSha256'], str(source) + ' differs from frozen source hash'
        checked.append({'path': str(target), 'sha256': actual, 'mtimeNs': target.stat().st_mtime_ns, 'bytes': target.stat().st_size, 'source': str(source), 'sourceSha256': source_sha, 'runtimeEvidenceStatus': 'manifest-only', 'kind': 'stylesheet' if rel.suffix == '.css' else 'javascript'})
    return {'notice': notice, 'verifiedOutputs': checked, 'mergeHeadAtCheck': git('rev-parse', 'HEAD'), 'sourceTree': source_tree, 'evidenceScope': 'source/native hashes only; actual runtime JS/CSS evidence is recorded separately'}


if __name__ == '__main__':
    try:
        result = verify()
        (base / 'readiness-check.json').write_text(json.dumps(result, indent=2) + '\n')
        print(json.dumps({'ready': True, 'sourceHead': result['notice']['sourceHead'], 'modules': len(result['verifiedOutputs'])}))
    except Exception as error:
        result = {'ready': False, 'runtimeStarted': False, 'reason': str(error)}
        (base / 'readiness-blocked.json').write_text(json.dumps(result, indent=2) + '\n')
        print(json.dumps(result))
        raise SystemExit(2)
