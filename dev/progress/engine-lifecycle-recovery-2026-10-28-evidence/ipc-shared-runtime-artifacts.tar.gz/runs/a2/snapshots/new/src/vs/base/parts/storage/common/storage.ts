/*---------------------------------------------------------------------------------------------
 *  Copyright (c) Microsoft Corporation. All rights reserved.
 *  Licensed under the MIT License. See License.txt in the project root for license information.
 *--------------------------------------------------------------------------------------------*/

import { Delayer, Sequencer } from '../../../common/async.js';
import { onUnexpectedError } from '../../../common/errors.js';
import { Event, PauseableEmitter } from '../../../common/event.js';
import { Disposable, IDisposable, toDisposable } from '../../../common/lifecycle.js';
import { parse, stringify } from '../../../common/marshalling.js';
import { isObject, isUndefined, isUndefinedOrNull } from '../../../common/types.js';

export enum StorageHint {

	// A hint to the storage that the storage
	// does not exist on disk yet. This allows
	// the storage library to improve startup
	// time by not checking the storage for data.
	STORAGE_DOES_NOT_EXIST,

	// A hint to the storage that the storage
	// is backed by an in-memory storage.
	STORAGE_IN_MEMORY
}

export interface IStorageOptions {
	readonly hint?: StorageHint;
}

export interface IUpdateRequest {
	readonly insert?: Map<string, string>;
	readonly delete?: Set<string>;
}

export interface IStorageItemsChangeEvent {
	readonly changed?: Map<string, string>;
	readonly deleted?: Set<string>;
}

export function isStorageItemsChangeEvent(thing: unknown): thing is IStorageItemsChangeEvent {
	const candidate = thing as IStorageItemsChangeEvent | undefined;

	return candidate?.changed instanceof Map || candidate?.deleted instanceof Set;
}

export interface IStorageDatabase {

	readonly onDidChangeItemsExternal: Event<IStorageItemsChangeEvent>;

	getItems(): Promise<Map<string, string>>;
	updateItems(request: IUpdateRequest): Promise<void>;

	optimize(): Promise<void>;

	close(recovery?: () => Map<string, string>): Promise<void>;
}

export interface IStorageChangeEvent {

	/**
	 * The `key` of the storage entry that was changed
	 * or was removed.
	 */
	readonly key: string;

	/**
	 * A hint how the storage change event was triggered. If
	 * `true`, the storage change was triggered by an external
	 * source, such as:
	 * - another process (for example another window)
	 * - operations such as settings sync or profiles change
	 */
	readonly external?: boolean;
}

export type StorageValue = string | boolean | number | undefined | null | object;

export interface IStorage extends IDisposable {

	readonly onDidChangeStorage: Event<IStorageChangeEvent>;

	readonly items: Map<string, string>;
	readonly size: number;

	init(): Promise<void>;

	get(key: string, fallbackValue: string): string;
	get(key: string, fallbackValue?: string): string | undefined;

	getBoolean(key: string, fallbackValue: boolean): boolean;
	getBoolean(key: string, fallbackValue?: boolean): boolean | undefined;

	getNumber(key: string, fallbackValue: number): number;
	getNumber(key: string, fallbackValue?: number): number | undefined;

	getObject<T extends object>(key: string, fallbackValue: T): T;
	getObject<T extends object>(key: string, fallbackValue?: T): T | undefined;

	set(key: string, value: StorageValue, external?: boolean): Promise<void>;
	delete(key: string, external?: boolean): Promise<void>;

	flush(delay?: number): Promise<void>;
	whenFlushed(): Promise<void>;

	optimize(): Promise<void>;

	close(): Promise<void>;
}

export enum StorageState {
	None,
	Initialized,
	Closed
}

interface IFlushScheduleBatch {
	readonly promise: Promise<void>;
	settled: boolean;
	resolve: () => void;
	reject: (error: unknown) => void;
}

export class Storage extends Disposable implements IStorage {

	private static readonly DEFAULT_FLUSH_DELAY = 100;

	private readonly _onDidChangeStorage = this._register(new PauseableEmitter<IStorageChangeEvent>());
	readonly onDidChangeStorage = this._onDidChangeStorage.event;

	protected state = StorageState.None;

	private cache = new Map<string, string>();

	// ThrottledDelayer queues through Throttler. A flush that starts while an
	// earlier flushPending is still running is that queued task. If it rejects,
	// `activePromise.then(onComplete, onComplete).then(resolve)` never settles
	// the caller and leaves the rejection unhandled. Debounce here, sequence
	// below, and settle the delay window ourselves.
	private flushSchedulingDisposed = false;
	private readonly flushDelayer = this.createFlushDelayer();
	private readonly flushSequencer = new Sequencer();
	private flushScheduleBatch: IFlushScheduleBatch | undefined;

	private pendingDeletes = new Set<string>();
	private pendingInserts = new Map<string, string>();

	// Removals from cache while state is still None. Flush can clear
	// pendingDeletes before getItems resolves, so the pending map is not a
	// replay source.
	private readonly keysRemovedWhileUninitialized = new Set<string>();

	private pendingClose: Promise<void> | undefined = undefined;
	private pendingInit: Promise<void> | undefined = undefined;

	private readonly whenFlushedCallbacks: { resolve: () => void; reject: (error: Error) => void }[] = [];
	private currentFlushPromise: Promise<void> | undefined;

	constructor(
		protected readonly database: IStorageDatabase,
		private readonly options: IStorageOptions = Object.create(null)
	) {
		super();

		this.registerListeners();
	}

	private registerListeners(): void {
		this._register(this.database.onDidChangeItemsExternal(e => this.onDidChangeItemsExternal(e)));
	}

	private onDidChangeItemsExternal(e: IStorageItemsChangeEvent): void {
		this._onDidChangeStorage.pause();

		try {
			// items that change external require us to update our
			// caches with the values. we just accept the value and
			// emit an event if there is a change.

			e.changed?.forEach((value, key) => this.acceptExternal(key, value));
			e.deleted?.forEach(key => this.acceptExternal(key, undefined));

		} finally {
			this._onDidChangeStorage.resume();
		}
	}

	private acceptExternal(key: string, value: string | undefined): void {
		if (this.state === StorageState.Closed) {
			return; // Return early if we are already closed
		}

		let changed = false;

		// Item got removed, check for deletion
		if (isUndefinedOrNull(value)) {
			changed = this.cache.delete(key);
			// Drop an unflushed set() so flush does not write that string back.
			// A cache miss is not a storage change and does not enter pending.
			if (changed) {
				this.pendingInserts.delete(key);
			}
			// A key that has not entered the cache can still sit in the snapshot
			// getItems is about to return. While uninitialized, remember that
			// removal too. A cache miss is not a storage change and is not a
			// pending delete.
			if (changed || this.state === StorageState.None) {
				this.noteUninitializedRemoval(key);
			}
		}

		// Item got updated, check for change
		else {
			const currentValue = this.cache.get(key);
			if (currentValue !== value) {
				this.cache.set(key, value);
				this.noteUninitializedUpdate(key);
				changed = true;

				// Only keys already queued are adjusted. Do not create pending work.
				if (this.pendingInserts.has(key)) {
					this.pendingInserts.set(key, value);
				}
				if (this.pendingDeletes.has(key)) {
					this.pendingDeletes.delete(key);
				}
			}
		}

		// Signal to outside listeners
		if (changed) {
			this._onDidChangeStorage.fire({ key, external: true });
		}
	}

	get items(): Map<string, string> {
		return this.cache;
	}

	get size(): number {
		return this.cache.size;
	}

	async init(): Promise<void> {
		if (this.state === StorageState.Closed) {
			return; // Return early if we are already closed
		}

		if (this.state === StorageState.Initialized) {
			return; // already initialized
		}

		// Join an in-flight load. State stays None until getItems settles, so a
		// second caller must not treat this init as finished.
		if (this.pendingInit) {
			return this.pendingInit;
		}

		this.pendingInit = this.doInit();
		try {
			await this.pendingInit;
		} finally {
			this.pendingInit = undefined;
		}
	}

	private noteUninitializedRemoval(key: string): void {
		if (this.state === StorageState.None) {
			this.keysRemovedWhileUninitialized.add(key);
		}
	}

	private noteUninitializedUpdate(key: string): void {
		if (this.state === StorageState.None) {
			this.keysRemovedWhileUninitialized.delete(key);
		}
	}

	private async doInit(): Promise<void> {
		if (this.options.hint === StorageHint.STORAGE_DOES_NOT_EXIST) {
			// return early if we know the storage file does not exist. this is a performance
			// optimization to not load all items of the underlying storage if we know that
			// there can be no items because the storage does not exist.
			this.keysRemovedWhileUninitialized.clear();
			this.state = StorageState.Initialized;
			return;
		}

		const loadedItems = await this.database.getItems();

		// getItems can settle after close(). The pre-await check narrowed
		// `this.state` to None, so read it back before deciding it is initialized.
		const stateAfterLoad = this.state as StorageState;
		if (stateAfterLoad === StorageState.Closed) {
			this.keysRemovedWhileUninitialized.clear();
			this.cache = loadedItems;
			return;
		}

		// Loaded rows are the base. Keys still in cache — written before this
		// await, or set / accepted while it was in flight — win. Keys removed
		// from cache while uninitialized must not come back from the snapshot.
		this.cache = this.mergeLoadedItems(loadedItems);
		this.state = StorageState.Initialized;
		this.keysRemovedWhileUninitialized.clear();
	}

	private mergeLoadedItems(loadedItems: Map<string, string>): Map<string, string> {
		const removed = this.keysRemovedWhileUninitialized;
		if (this.cache.size === 0 && removed.size === 0) {
			return loadedItems;
		}

		const merged = new Map(loadedItems);
		for (const key of removed) {
			if (!this.cache.has(key)) {
				merged.delete(key);
			}
		}

		for (const [key, value] of this.cache) {
			merged.set(key, value);
		}

		return merged;
	}

	get(key: string, fallbackValue: string): string;
	get(key: string, fallbackValue?: string): string | undefined;
	get(key: string, fallbackValue?: string): string | undefined {
		const value = this.cache.get(key);

		if (isUndefinedOrNull(value)) {
			return fallbackValue;
		}

		return value;
	}

	getBoolean(key: string, fallbackValue: boolean): boolean;
	getBoolean(key: string, fallbackValue?: boolean): boolean | undefined;
	getBoolean(key: string, fallbackValue?: boolean): boolean | undefined {
		const value = this.get(key);

		if (isUndefinedOrNull(value)) {
			return fallbackValue;
		}

		return value === 'true';
	}

	getNumber(key: string, fallbackValue: number): number;
	getNumber(key: string, fallbackValue?: number): number | undefined;
	getNumber(key: string, fallbackValue?: number): number | undefined {
		const value = this.get(key);

		if (isUndefinedOrNull(value)) {
			return fallbackValue;
		}

		return parseInt(value, 10);
	}

	getObject(key: string, fallbackValue: object): object;
	getObject(key: string, fallbackValue?: object | undefined): object | undefined;
	getObject(key: string, fallbackValue?: object): object | undefined {
		const value = this.get(key);

		if (isUndefinedOrNull(value)) {
			return fallbackValue;
		}

		return parse(value);
	}

	async set(key: string, value: string | boolean | number | null | undefined | object, external = false): Promise<void> {
		if (this.state === StorageState.Closed) {
			return; // Return early if we are already closed
		}

		// We remove the key for undefined/null values
		if (isUndefinedOrNull(value)) {
			return this.delete(key, external);
		}

		// Otherwise, convert to String and store
		const valueStr = isObject(value) || Array.isArray(value) ? stringify(value) : String(value);

		// Return early if value already set
		const currentValue = this.cache.get(key);
		if (currentValue === valueStr) {
			return;
		}

		// Update in cache and pending
		this.cache.set(key, valueStr);
		this.noteUninitializedUpdate(key);
		this.pendingInserts.set(key, valueStr);
		this.pendingDeletes.delete(key);

		// Event
		this._onDidChangeStorage.fire({ key, external });

		// Accumulate work by scheduling after timeout
		return this.doFlush();
	}

	async delete(key: string, external = false): Promise<void> {
		if (this.state === StorageState.Closed) {
			return; // Return early if we are already closed
		}

		// Remove from cache and add to pending
		const wasDeleted = this.cache.delete(key);
		if (!wasDeleted) {
			// The key was never in memory. While getItems is still outstanding,
			// remember it so the snapshot cannot bring it back. A cache miss is
			// not a pending insert or delete.
			if (this.state === StorageState.None) {
				this.noteUninitializedRemoval(key);
			}
			return; // Return early if value already deleted
		}

		this.noteUninitializedRemoval(key);

		if (!this.pendingDeletes.has(key)) {
			this.pendingDeletes.add(key);
		}

		this.pendingInserts.delete(key);

		// Event
		this._onDidChangeStorage.fire({ key, external });

		// Accumulate work by scheduling after timeout
		return this.doFlush();
	}

	async optimize(): Promise<void> {
		if (this.state === StorageState.Closed) {
			return; // Return early if we are already closed
		}

		// Await pending data to be flushed to the DB
		// before attempting to optimize the DB
		await this.flush(0);

		return this.database.optimize();
	}

	async close(): Promise<void> {
		if (!this.pendingClose) {
			this.pendingClose = this.doClose();
		}

		return this.pendingClose;
	}

	private async doClose(): Promise<void> {

		// Update state
		this.state = StorageState.Closed;

		// Trigger new flush to ensure data is persisted and then close
		// even if there is an error flushing. We must always ensure
		// the DB is closed to avoid corruption.
		//
		// Recovery: we pass our cache over as recovery option in case
		// the DB is not healthy.
		try {
			await this.doFlush(0 /* as soon as possible */);
		} catch {
			// Ignore
		}

		await this.database.close(() => this.cache);
	}

	private get hasPending() {
		return this.pendingInserts.size > 0 || this.pendingDeletes.size > 0;
	}

	private mergePendingAfterFailedFlush(failedInserts: Map<string, string>, failedDeletes: Set<string>): void {
		// A newer pending insert or delete for the same key wins. Do not put
		// a string back into pendingInserts after it has left the cache.
		for (const [key, value] of failedInserts) {
			if (this.pendingDeletes.has(key)) {
				continue;
			}
			if (this.pendingInserts.has(key)) {
				continue;
			}
			if (this.cache.get(key) !== value) {
				continue;
			}
			this.pendingInserts.set(key, value);
		}

		for (const key of failedDeletes) {
			if (this.pendingInserts.has(key)) {
				continue;
			}
			if (this.cache.has(key)) {
				continue;
			}
			this.pendingDeletes.add(key);
		}
	}

	private async flushPending(): Promise<void> {
		if (!this.hasPending) {
			return; // return early if nothing to do
		}

		// The original batch is what failure merge retries. updateItems may
		// await before it reads (SQLite awaits whenConnected, then reads the
		// Map). Copies below are updated from the cache when an external
		// change arrives during that wait, so this call does not observe a
		// string that has already left the cache.
		const failedInserts = this.pendingInserts;
		const failedDeletes = this.pendingDeletes;
		const requestInserts = new Map(failedInserts);
		const requestDeletes = new Set(failedDeletes);
		const updateRequest: IUpdateRequest = { insert: requestInserts, delete: requestDeletes };

		// Reset pending data for next run
		this.pendingDeletes = new Set<string>();
		this.pendingInserts = new Map<string, string>();

		const syncInFlightKey = (key: string): void => {
			if (failedInserts.has(key)) {
				const cached = this.cache.get(key);
				if (cached === undefined) {
					requestInserts.delete(key);
				} else {
					requestInserts.set(key, cached);
				}
			}
			if (failedDeletes.has(key) && this.cache.has(key)) {
				requestDeletes.delete(key);
			}
		};

		const externalListener = this.database.onDidChangeItemsExternal(change => {
			const keys: string[] = [];
			if (change.deleted) {
				keys.push(...change.deleted);
			}
			if (change.changed) {
				keys.push(...change.changed.keys());
			}
			for (const key of keys) {
				syncInFlightKey(key);
			}
		});

		// Snapshot callbacks waiting for this flush batch
		const callbacks = this.whenFlushedCallbacks.splice(0, this.whenFlushedCallbacks.length);

		const promise: Promise<void> = (async () => {
			try {
				try {
					await this.database.updateItems(updateRequest);

					for (const callback of callbacks) {
						callback.resolve();
					}
				} catch (error) {
					this.mergePendingAfterFailedFlush(failedInserts, failedDeletes);
					const err = error instanceof Error ? error : new Error(String(error));
					for (const callback of callbacks) {
						callback.reject(err);
					}
					throw error;
				}
			} finally {
				externalListener.dispose();
			}
		})().finally(() => {
			if (this.currentFlushPromise === promise) {
				this.currentFlushPromise = undefined;
			}
		});

		this.currentFlushPromise = promise;

		return promise;
	}

	async flush(delay?: number): Promise<void> {
		if (
			this.state === StorageState.Closed || 	// Return early if we are already closed
			this.pendingClose 						// return early if nothing to do
		) {
			return;
		}

		return this.doFlush(delay);
	}

	private doFlush(delay?: number): Promise<void> {
		if (this.options.hint === StorageHint.STORAGE_IN_MEMORY) {
			return this.flushPending(); // return early if in-memory
		}

		return this.scheduleFlush(delay);
	}

	private createFlushDelayer(): Delayer<void> {
		const delayer = new Delayer<void>(Storage.DEFAULT_FLUSH_DELAY);
		this._register(toDisposable(() => {
			this.flushSchedulingDisposed = true;
			delayer.dispose();
		}));
		return delayer;
	}

	private scheduleFlush(delay?: number): Promise<void> {
		const batch = this.flushScheduleBatch ?? this.openFlushBatch();
		// Each call resets the debounce. One delay window shares one promise.
		const scheduled = this.flushDelayer.trigger(() => {
			return this.queueFlushBatch(this.detachFlushBatch(batch));
		}, delay);
		scheduled.catch(error => this.rejectFlushBatch(batch, error));
		return batch.promise;
	}

	private openFlushBatch(): IFlushScheduleBatch {
		let resolve!: () => void;
		let reject!: (error: unknown) => void;
		const promise = new Promise<void>((res, rej) => {
			resolve = res;
			reject = rej;
		});
		const batch: IFlushScheduleBatch = {
			promise,
			settled: false,
			resolve: () => { },
			reject: () => { },
		};
		batch.resolve = () => {
			if (batch.settled) {
				return;
			}
			batch.settled = true;
			resolve();
		};
		batch.reject = (error: unknown) => {
			if (batch.settled) {
				return;
			}
			batch.settled = true;
			reject(error);
		};
		this.flushScheduleBatch = batch;
		return batch;
	}

	private detachFlushBatch(batch: IFlushScheduleBatch): IFlushScheduleBatch {
		if (this.flushScheduleBatch === batch) {
			this.flushScheduleBatch = undefined;
		}
		return batch;
	}

	private rejectFlushBatch(batch: IFlushScheduleBatch, error: unknown): void {
		if (this.flushScheduleBatch === batch) {
			this.flushScheduleBatch = undefined;
		}
		batch.reject(error);
	}

	private queueFlushBatch(batch: IFlushScheduleBatch): Promise<void> {
		return this.flushSequencer.queue(() => {
			if (batch.settled) {
				return Promise.resolve();
			}

			// Already handed to the sequencer, then disposed. Throttler skips that
			// queued task and resolves it (cancelled onComplete returns undefined).
			if (this.flushSchedulingDisposed) {
				batch.resolve();
				return Promise.resolve();
			}

			// Do not rethrow. The caller is batch.promise; a rejection here would
			// be the sequencer/delayer promise, which is not that caller.
			return this.flushPending().then(() => {
				batch.resolve();
			}, error => {
				batch.reject(error);
			});
		});
	}

	async whenFlushed(): Promise<void> {
		if (this.hasPending) {
			return new Promise((resolve, reject) => this.whenFlushedCallbacks.push({ resolve, reject }));
		}

		if (this.currentFlushPromise) {
			return this.currentFlushPromise;
		}

		return; // return early if nothing to do
	}

	isInMemory(): boolean {
		return this.options.hint === StorageHint.STORAGE_IN_MEMORY;
	}
}

export class InMemoryStorageDatabase implements IStorageDatabase {

	readonly onDidChangeItemsExternal = Event.None;

	private readonly items = new Map<string, string>();

	async getItems(): Promise<Map<string, string>> {
		return this.items;
	}

	async updateItems(request: IUpdateRequest): Promise<void> {
		request.insert?.forEach((value, key) => this.items.set(key, value));

		request.delete?.forEach(key => this.items.delete(key));
	}

	async optimize(): Promise<void> { }
	async close(): Promise<void> { }
}


export const MIGRATED_KEY = '__$__migratedStorageMarker';

export class MigratingStorage extends Storage {

	private migratedKeys: Set<string> = new Set();
	private fallbackStorage: IStorage | undefined = undefined;
	private isFallbackStorageReadonly: boolean = false;
	private migrationInProgress = new Set<string>();

	override async init(): Promise<void> {
		await super.init();

		// Load the set of keys already migrated from fallback
		this.migratedKeys = this.loadMigratedKeys();
	}

	public setFallbackStorage(storage: IStorage, isReadonly: boolean): void {
		this.fallbackStorage = storage;
		this.isFallbackStorageReadonly = isReadonly;
	}

	private static readonly INTERNAL_KEY_PREFIX = '__$__';

	override get(key: string, fallbackValue: string): string;
	override get(key: string, fallbackValue?: string): string | undefined;
	override get(key: string, fallbackValue?: string): string | undefined {
		if (!key.startsWith(MigratingStorage.INTERNAL_KEY_PREFIX) && !this.migratedKeys.has(key) && !this.migrationInProgress.has(key) && isUndefined(super.get(key))) {
			const value = this.fallbackStorage?.items.get(key);
			if (!isUndefined(value)) {
				this.scheduleFallbackMigration(key, value);
			}
		}
		return super.get(key, fallbackValue);
	}

	private scheduleFallbackMigration(key: string, value: string): void {
		if (this.state === StorageState.Closed) {
			return;
		}

		if (this.migrationInProgress.has(key)) {
			return;
		}

		this.migrationInProgress.add(key);

		void this.set(key, value).then(async () => {
			if (this.state === StorageState.Closed) {
				return;
			}

			if (isUndefined(super.get(key))) {
				return;
			}

			try {
				await this.flush(0);
			} catch {
				return;
			}

			// `flush` can close storage while this migration is suspended. The
			// earlier closed check narrows `this.state`, so read it back through
			// the full enum before checking again.
			const stateAfterFlush = this.state as StorageState;
			if (stateAfterFlush === StorageState.Closed) {
				return;
			}

			this.migratedKeys.add(key);
			this.persistMigratedKeys();

			if (!this.isFallbackStorageReadonly && this.fallbackStorage) {
				await this.fallbackStorage.delete(key);
			}
		}).catch(onUnexpectedError).catch(onUnexpectedError).finally(() => {
			this.migrationInProgress.delete(key);
		});
	}

	private loadMigratedKeys(): Set<string> {
		const raw = super.get(MIGRATED_KEY);
		if (raw) {
			try {
				return new Set(JSON.parse(raw));
			} catch {
				// Fail gracefully
			}
		}
		return new Set();
	}

	private persistMigratedKeys(): void {
		this.set(MIGRATED_KEY, JSON.stringify([...this.migratedKeys])).catch(onUnexpectedError).catch(onUnexpectedError);
	}
}

