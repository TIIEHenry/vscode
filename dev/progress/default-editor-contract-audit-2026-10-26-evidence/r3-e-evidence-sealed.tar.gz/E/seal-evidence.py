"""Seal actual E evidence only; never launches, issues phase completion, or changes old originals."""
from pathlib import Path
import datetime,hashlib,json,stat,tarfile
ROOT=Path(__file__).resolve().parent.parent
BASE=ROOT/'E'
read=lambda p:json.loads(Path(p).read_text())
sha=lambda data:hashlib.sha256(data).hexdigest()
def row(path):
    assert path.is_file() and not path.is_symlink()
    return {'path':str(path.relative_to(ROOT)),'bytes':path.stat().st_size,'mode':stat.S_IMODE(path.stat().st_mode),'sha256':sha(path.read_bytes())}
def main():
    archive=BASE/'E-evidence-sealed.tar.gz';inventory=BASE/'artifact-inventory.json';verification=BASE/'archive-member-verification.json';seal=BASE/'E-stage-seal.json'
    assert all(not p.exists() for p in [archive,inventory,verification,seal,BASE/'phase-complete.json'])
    facts=read(BASE/'E-stage-facts.json');cleanup=read(BASE/'cleanup-independent-verification.json');grpc=read(BASE/'grpc-full-lifetime-summary.json')
    assert facts['runtimeSnapshots']==75 and facts['passedTemplateExecutableRows']==8 and facts['canonicalBoundaryRows']==1
    assert facts['retainedObserverScriptFailures']==2 and not facts['everyScriptInvocationSucceeded']
    assert cleanup['profileAbsent'] and cleanup['EHomeAbsent'] and cleanup['JHomeAbsent'] and cleanup['JProfileAbsent']
    assert not cleanup['remainingOriginalOwnedLive'] and not cleanup['remainingOwnRunDirOrEngineHomeLive'] and cleanup['originalOwnedLifetimeCount']==15
    assert all(e['completeLifetime'] for e in grpc['episodes']) and grpc['receivedCalls']==43 and grpc['responseUnary']==19 and grpc['chatWritePayloads']==0 and grpc['unknownMethodCount']==0
    assert not Path(read(BASE/'launch.json')['runDir']).exists() and not Path(read(BASE/'launch.json')['engineHome']).exists()
    assert sha((ROOT/'J/phase-complete.json').read_bytes())=='3bdd49ea1623a535544c4c79d59e22a1068dd98b3a71f7567a04cf9689ab3186'
    assert sha((ROOT/'J/J-evidence-sealed.tar.gz').read_bytes())=='eba7ee63112928d4dbc5c27fed46c886dbdabcbc60bb1ed7edeab3e1d89f3e0b'
    excluded={str(p.relative_to(ROOT)) for p in [archive,inventory,verification,seal]}
    paths=[p for directory in [ROOT/'E',ROOT/'common'] for p in sorted(directory.rglob('*')) if p.is_file() and str(p.relative_to(ROOT)) not in excluded]
    paths += [p for p in sorted(ROOT.iterdir()) if p.is_file()]
    paths += [p for p in sorted((ROOT/'J').iterdir()) if p.is_file() and p.name!='J-evidence-sealed.tar.gz']
    paths=sorted(set(paths));assert all(not p.is_symlink() for p in paths)
    originals=[row(p) for p in paths]
    record={'runId':facts['runId'],'phase':'E','state':'INVENTORY_OF_ACTUAL_E_AWAITING_ROOT_REVIEW','createdAt':datetime.datetime.now(datetime.timezone.utc).isoformat(),'sourceHead':facts['finalSourceHead'],'sourceTree':facts['finalSourceTree'],'lineageSha256':facts['lineageSha256'],'scope':'All E and common regular files, root static/control regular files, and J root regular control/reference files; separately accepted J archive is referenced by exact SHA and is not nested; J nested runtime evidence stays in its separately sealed archive','JArchiveReferencedExternally':{'path':'J/J-evidence-sealed.tar.gz','sha256':'eba7ee63112928d4dbc5c27fed46c886dbdabcbc60bb1ed7edeab3e1d89f3e0b'},'regularOriginalFiles':len(originals),'archiveMemberCountIncludingThisInventory':len(originals)+1,'inventorySelfDigestExcludedToAvoidRecursion':True,'files':originals,'noEPhaseComplete':True,'retainedObserverScriptFailures':2,'everyScenarioScriptInvocationSucceeded':False}
    inventory.write_text(json.dumps(record,indent=2)+'\n');allRows=originals+[row(inventory)]
    with tarfile.open(archive,'w:gz',format=tarfile.PAX_FORMAT) as tar:
        for item in allRows:tar.add(ROOT/item['path'],arcname=item['path'],recursive=False)
    expected={item['path']:item for item in allRows};checks=[]
    with tarfile.open(archive,'r:gz') as tar:
        members=tar.getmembers();assert len(members)==len(expected) and len({m.name for m in members})==len(expected) and {m.name for m in members}==set(expected)
        for member in members:
            assert member.isfile() and not member.issym() and not member.islnk() and '..' not in Path(member.name).parts and not Path(member.name).is_absolute()
            original=expected[member.name];data=tar.extractfile(member).read();assert len(data)==original['bytes'] and sha(data)==original['sha256'] and member.mode==original['mode']
            assert row(ROOT/member.name)==original
            checks.append({'path':member.name,'bytes':len(data),'sha256':sha(data),'mode':member.mode,'matchesOriginal':True})
    result={'runId':facts['runId'],'phase':'E','method':'reopened archive; every regular member byte count/SHA256/mode and current original rechecked; no external extraction writes','archive':str(archive.relative_to(ROOT)),'archiveSha256':sha(archive.read_bytes()),'archiveBytes':archive.stat().st_size,'inventory':str(inventory.relative_to(ROOT)),'inventorySha256':sha(inventory.read_bytes()),'originalFileCount':len(originals),'archiveRegularMemberCount':len(checks),'allMemberBytesShaModesMatch':True,'allCurrentOriginalsStillIdentical':True,'members':checks}
    verification.write_text(json.dumps(result,indent=2)+'\n')
    summary={'runId':facts['runId'],'phase':'E','state':'SEALED_AWAITING_ROOT_INDEPENDENT_ARCHIVE_REVIEW','sealedAt':datetime.datetime.now(datetime.timezone.utc).isoformat(),'sourceHead':facts['finalSourceHead'],'sourceTree':facts['finalSourceTree'],'fullCompileOfFinalSourceTree':False,'lineageSha256':facts['lineageSha256'],'frozenOutputsSha256':facts['frozenOutputsSha256'],'freezeJRawSha256':facts['freezeJRawSha256'],'freezeERawSha256':facts['freezeERawSha256'],'fullFreezeRawSha256':facts['fullFreezeRawSha256'],'laneProvenanceRawSha256':facts['laneProvenanceRawSha256'],'JPhaseCompleteSha256':facts['JPhaseCompleteSha256'],'commonAssets':138,'fullAssets':254,'runtimeSnapshots':75,'templateExecutableRowsObserved':8,'canonicalBoundaryRows':1,'scenarioOrchestratorInvocations':13,'successfulScenarioOrchestratorInvocations':11,'retainedObserverScriptFailures':2,'everyScenarioScriptInvocationSucceeded':False,'loadedRendererJs':124,'loadedRendererCss':1,'manifestOnly':13,'completeFakeLifetimes':2,'receivedCalls':43,'responseUnary':19,'residentChatStreamOpens':2,'chatWritePayloads':0,'getQueueReceived':0,'saveSkillContentReceived':0,'unknownMethodCount':0,'realEngineRpcUsed':0,'ownedLifetimesVerified':15,'remainingOwnedLive':0,'profileRemoved':True,'EHomeRemoved':True,'originalFailuresRetained':['E/transport-new-link-failure.json','E/disconnect-negative-driver-failure.json'],'archive':result['archive'],'archiveSha256':result['archiveSha256'],'archiveBytes':result['archiveBytes'],'inventory':result['inventory'],'inventorySha256':result['inventorySha256'],'originalFiles':len(originals),'archiveMembers':len(checks),'memberVerification':str(verification.relative_to(ROOT)),'memberVerificationSha256':sha(verification.read_bytes()),'stageFactsSha256':sha((BASE/'E-stage-facts.json').read_bytes()),'runtimeReportSha256':sha((BASE/'E-RUNTIME-REPORT.md').read_bytes()),'assertionOutcomesSha256':sha((BASE/'assertions.json').read_bytes()),'matrixSha256':sha((BASE/'matrix.json').read_bytes()),'phaseCompleteCreated':False,'waveOrPlanCompletionClaimed':False}
    seal.write_text(json.dumps(summary,indent=2)+'\n');print(json.dumps({**summary,'stageSealSha256':sha(seal.read_bytes())}))
if __name__=='__main__':main()
