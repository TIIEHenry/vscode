from pathlib import Path
import json,sys
base=Path(__file__).resolve().parent;sys.path.insert(0,str(base.parent/'common'))
from gates import verify,read
if __name__=='__main__':
    proof=verify('E',native=False);fixture=read(base.parent/'J/fixture.json');root=Path(fixture['fixture']);workspace=base/'after.code-workspace';assert not workspace.exists()
    workspace.write_text(json.dumps({'folders':[{'name':'D1387 Alpha','path':str(root/'alpha')},{'name':'D1387 Beta','path':str(root/'beta')}],'settings':{}},indent=2)+'\n')
    print(json.dumps({'runId':proof['runId'],'freshEWorkspacePrepared':True,'runtimeStarted':False}))
