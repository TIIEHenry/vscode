import hashlib,json,pathlib,subprocess,tempfile,sys
sys.path.insert(0,str(pathlib.Path(__file__).resolve().parent.parent/'common'))
from gates import verify
base=pathlib.Path(__file__).resolve().parent

def git(root,*args):
    return subprocess.check_output(['rtk','proxy','git','-C',str(root),*args])
def snapshot(root):
    return {
      'root':str(root),
      'HEAD':git(root,'rev-parse','HEAD').decode().strip(),
      'indexEntriesHex':git(root,'ls-files','--stage','-z').hex(),
      'cachedDiffHex':git(root,'diff','--cached','--binary').hex(),
      'statusPorcelainHex':git(root,'status','--porcelain=v1','-z').hex(),
      'worktreeDiffHex':git(root,'diff','--binary').hex(),
      'files':{name:{'sha256':hashlib.sha256((root/name).read_bytes()).hexdigest(),'text':(root/name).read_text(),'HEADtext':git(root,'show','HEAD:'+name).decode()} for name in ['shared.txt','other.txt']}
    }

def main():
    proof=verify('J',native=False)
    manifest=base/'fixture.json'
    if manifest.exists():
        info=json.loads(manifest.read_text())
        current=[snapshot(pathlib.Path(info['fixture'])/k) for k in ['alpha','beta']]
        assert current==json.loads((base/'fixture-baseline.json').read_text()),'existing fixture changed; do not reset or overwrite'
        print(json.dumps({'fixture':info['fixture'],'reused':True,'matchesBaseline':True}))
        return
    root=pathlib.Path(tempfile.mkdtemp(prefix='vscode-d1387-r3-sources-audit-'))
    info={'fixture':str(root),'createdBy':'/root/sources_audit','authorWorktree':str(base.parent.parent.parent),'preparationRole':'independent non-author','runtimeStarted':False}
    for label in ['alpha','beta']:
        repo=root/label;repo.mkdir()
        git(repo,'init','-b','main')
        for name in ['shared.txt','other.txt']:
            tag=label.upper()+(' OTHER' if name=='other.txt' else '')
            (repo/name).write_text('D1387 INDEPENDENT SOURCES_AUDIT '+tag+' BASELINE\nunchanged '+label+' sentinel\n')
        git(repo,'add','shared.txt','other.txt')
        git(repo,'-c','user.name=D1387 Independent After','-c','user.email=d1387-after@invalid.example','-c','commit.gpgsign=false','commit','-m','D1387 independent fixture baseline')
        for name in ['shared.txt','other.txt']:
            tag=label.upper()+(' OTHER' if name=='other.txt' else '')
            (repo/name).write_text('D1387 INDEPENDENT SOURCES_AUDIT '+tag+' MODIFIED FOR AFTER\nunchanged '+label+' sentinel\n')
    manifest.write_text(json.dumps(info,indent=2)+'\n')
    baseline=[snapshot(root/k) for k in ['alpha','beta']]
    (base/'fixture-baseline.json').write_text(json.dumps(baseline,indent=2)+'\n')
    workspace=base/'after.code-workspace'
    workspace.write_text(json.dumps({'folders':[{'name':'D1387 Alpha','path':str(root/'alpha')},{'name':'D1387 Beta','path':str(root/'beta')}],'settings':{}},indent=2)+'\n')
    settings={'workbench.startupEditor':'none','window.restoreWindows':'none','git.autofetch':False,'git.confirmSync':True,'git.openRepositoryInParentFolders':'never','git.autoRepositoryDetection':True,'security.workspace.trust.enabled':False,'telemetry.telemetryLevel':'off','update.mode':'none','extensions.autoCheckUpdates':False,'extensions.autoUpdate':False,'agents.voice.enabled':False,'workbench.colorTheme':'Default Dark Modern'}
    (base/'empty-seed'/'User'/'settings.json').write_text(json.dumps(settings,indent=2)+'\n')
    print(json.dumps({'fixture':str(root),'HEADs':{x['root']:x['HEAD'] for x in baseline},'indexEmpty':all(not x['cachedDiffHex'] for x in baseline),'runtimeStarted':False}))
if __name__=='__main__':main()
