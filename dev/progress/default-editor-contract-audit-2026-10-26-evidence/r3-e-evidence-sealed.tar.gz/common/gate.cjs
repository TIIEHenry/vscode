const fs=require('node:fs'),path=require('node:path'),crypto=require('node:crypto'),assert=require('node:assert/strict'),cp=require('node:child_process');
const root=path.resolve(__dirname,'..'),read=p=>{if(!fs.existsSync(p))throw Error('NOT AUTHORIZED/NOT READY missing actual '+p);return JSON.parse(fs.readFileSync(p));},sha=b=>crypto.createHash('sha256').update(b).digest('hex');
const stable=x=>Array.isArray(x)?x.map(stable):x&&typeof x==='object'?Object.fromEntries(Object.keys(x).sort().map(k=>[k,stable(x[k])])):x;
const identityKeys=['path','sourcePath','sha256','sourceSha256','sourceBlob','sourceMode','nativeMode','provenanceRef'];
const canonical=notice=>sha(JSON.stringify(stable({finalSourceHead:notice.finalSourceHead,finalSourceTree:notice.finalSourceTree,outputs:[...notice.outputs].sort((a,b)=>a.path<b.path?-1:a.path>b.path?1:0).map(row=>Object.fromEntries(identityKeys.map(key=>[key,row[key]]))),lineage:notice.lineage})));
function loadRuntime(phase,{launch=false,fake=false}={}){
 assert.ok(['J','E'].includes(phase));
 // One V4 validator owns record/pair/member/mode/lineage and historical-input checks.
 // This context path never reads native out; explicit before/after guard does.
 const result=cp.spawnSync('rtk',['proxy','python3',path.join(root,'common/gates.py'),'--runtime-context',phase,launch?'launch':'no-launch',fake?'fake':'no-fake'],{encoding:'utf8',maxBuffer:16*1024*1024,env:{...process.env,PYTHONDONTWRITEBYTECODE:'1'}});
 if(result.status!==0)throw Error('NOT AUTHORIZED/NOT READY V4 gate: '+result.stderr+result.stdout);
 const checked=JSON.parse(result.stdout),base=path.join(root,phase),{config,contract,notice}=checked,auth=checked.authorization,full=checked.fullFreeze,info=checked.launch;
 assert.equal(canonical(notice),auth.frozenOutputsSha256);
 return {root,base,config,contract,auth,notice,full,info,sha,canonical};
}
module.exports={loadRuntime,root,read,sha,canonical};
