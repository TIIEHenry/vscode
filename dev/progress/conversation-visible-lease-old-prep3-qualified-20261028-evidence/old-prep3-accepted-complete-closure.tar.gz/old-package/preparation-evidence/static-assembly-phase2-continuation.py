from pathlib import Path
D=Path('/sdd/tmp/vscode-conversation-visible-lease-old-business-20261028-prep3-review')
ns={'__name__':'own_support'}
exec(compile((D/'static-support-and-protection.py').read_bytes(),str(D/'static-support-and-protection.py'),'exec'),ns)
globals().update({k:v for k,v in ns.items() if not k.startswith('__')})
workspace();assert readj(D/'phase2.actual-result.json')['actualExitCode']==1
context=readj(P/'context-content-inventory.json');rows=context['rows'];counts=context['counts'];newmap={x['path']:x for x in rows}
old_external_raw=(OLD/'external-reference-closure.json').read_bytes();old_external=json.loads(old_external_raw);groups=old_external['externalSymlinkTargets']
provenance=[]
for q in (P/'current-workspace-provenance').rglob('*'):
 if q.is_file():
  name=q.relative_to(P/'current-workspace-provenance').as_posix();src=R/name;b=src.read_bytes();assert b==q.read_bytes()==git('show',H+':'+name)
  provenance.append(dict(path=str(src),sourceRef=H,bytes=len(b),sha256=sha(b),metadata=meta(src),copyPath=q.relative_to(P).as_posix()))
preserve=[(OLD/'immutable-protection-inventory.json','prior3238-immutable-inventory.original.json'),(OD/'authorized-old-once-20261027T184023447555Z/postrun-package-inventory.json','consumed-old-prep2-postrun.original.json'),(OD/'package-final-audit.anchor.json','consumed-old-prep2-prepared0-audit-anchor.original.json'),(VR/'final-source-only-directory-inventory.json','source-v3-all75-frozen.original.json')]
direct={};historical_superseded=[]
def ref(path,role):
 q=Path(path);key=str(q);b=q.read_bytes();m=meta(q)
 if key in direct:
  assert direct[key]['originalMetadata']==m and direct[key]['sha256']==sha(b)
  if role not in direct[key]['roles']:direct[key]['roles'].append(role)
 else:direct[key]=dict(originalPath=key,roles=[role],originalMetadata=m,bytes=len(b),sha256=sha(b),operationalPathUnchanged=True,originalBytesCopiedIntoPackage=False)
allowed={'dev/parallel/active/sources-accept-post-read-authorization.md','dev/plans/INDEX.md','dev/plans/conversation-visible-lease-recovery.md','dev/progress/INDEX.md','dev/progress/status.md','docs/INDEX.md','docs/architecture/cross-cutting/testing.md'}
for x in old_external['directFileReferences']:
 q=Path(x['originalPath']);same=meta(q)==x['originalMetadata'] and q.stat().st_size==x['bytes'] and digest(q)==x['sha256']
 if same:ref(q,'historical-prep2-direct-reference-still-live-exact');continue
 name=q.relative_to(R).as_posix();assert name in allowed and x['roles']==['c6-current85-publication-original-live-equals-c6-git']
 frozen=git('show','c6ded6c918c4f69b0e89037e85b8f49ddc5512b4:'+name);copy=P/'reviewed-guard-v2-publication'/name
 assert frozen==copy.read_bytes() and len(frozen)==x['bytes'] and sha(frozen)==x['sha256']
 b=q.read_bytes();assert b==git('show',H+':'+name)
 historical_superseded.append(dict(originalFrozenDescription=x,historicalAuthorityCommit='c6ded6c918c4f69b0e89037e85b8f49ddc5512b4',historicalExactCopyPath=copy.relative_to(P).as_posix(),currentWorkspaceHead=H,currentPath=str(q),currentBytes=len(b),currentSha256=sha(b),currentMetadata=meta(q),classification='Accepted documentation evolution outside protected roots and119095 context; not original/protection/source drift. Frozen historical description is not a current live binding.'))
 ref(q,'current649-workspace-document-separate-from-historical-c6-description')
assert {Path(x['currentPath']).relative_to(R).as_posix() for x in historical_superseded}==allowed
clarification=dict(capturedAtUtc=now(),classification='Own assembler collector assumption error; not candidate/runtime failure, source/contract change, protected-original drift or baseline update.',firstActualExitCode=1,firstReceipt=str(D/'phase2.actual-result.json'),cause='Blindly requiring historical c6 live-document references to remain live current bytes after accepted5f/649 publication.',allSevenHistoricalCopiesExactC6GitAndFrozenOldPackage=True,currentSevenDocumentsExact649Git=True,fullContextAndExternalMetadataPathsetsAlreadyPassed=True,oldOriginalsSourcesAndBaselinesUnmodified=True,records=historical_superseded,continuationScope='Continue after first failed historical-direct-reference loop; no rerun or overwrite of completed package files.')
xjson(D/'own-phase2-historical-reference-clarification.json',clarification)
xjson(P/'historical-document-reference-clarification.json',clarification)
manifest=readj(P/'input-manifest.json')
for k in ['baselineFile','oldD8ePreservationInventory','oldF33PreservationInventory','oldOwnedReport']:ref(manifest[k],'runtime-direct-'+k)
for q,role in [(N/'guard-after-restore.json','runtime-only-715-predecessor'),(OLD/'guard-after-restore.json','consumed-failure-e182-not-runtime-predecessor'),(V/'source-freeze.json','original-v3-freeze-pending-label-preserved'),(VR/'authorized-single-mjs-syntax-20261027T190551935133Z/syntax-receipt.json','accepted-prior-single-syntax-receipt'),(OLD/'context-content-inventory.json','accepted-context-content-hash-authority'),(OLD/'external-reference-closure.json','accepted-external-content-hash-authority')]:ref(q,role)
for src,dest in preserve:ref(src,'closed-original-preservation-anchor')
for source in readj(P/'source-provenance.json')['runtimeSourceFiles']:ref(V/'candidate'/source['name'],'fixed-v3-source-original')
for x in manifest['boundToolAndConfigFiles']:ref(x['path'],'runtime-bound-tool-or-config')
for source in readj(P/'source-provenance.json')['reviewedV3PublicationCopies']:ref(R/source['path'],'fixed5f-publication-original-live-equals-git')
for n in sorted(p.name for p in D.iterdir() if p.is_file()):
 q=D/n;ref(q,'current-executor-static-preparation-evidence');write(P/'preparation-evidence'/n,q.read_bytes())
executables=[]
for q in [Path('/usr/bin/python3'),Path('/usr/bin/python3.10'),Path('/usr/bin/xvfb-run'),Path('/home/clarence/.hermes/node/bin/node')]:
 b=q.read_bytes();executables.append(dict(path=str(q),metadata=meta(q),resolvedPath=str(q.resolve()),resolvedMetadata=meta(q.resolve()),bytes=len(b),sha256=sha(b),executedNow=False))
 if q.resolve()!=q:ref(q.resolve(),'resolved-executable-static-identity')
xjson(P/'external-reference-closure.json',dict(historicalSupersededDocumentReferences=historical_superseded,capturedAtUtc=now(),scope='Fresh metadata/pathset closure with accepted frozen hashes for full external targets. Direct file references freshly content/metadata checked. Static filesystem evidence only; no universal OS/ELF closure or dynamically observed loads.',directFileReferences=sorted(direct.values(),key=lambda x:x['originalPath']),currentProvenance=provenance,externalSymlinkTargets=groups,executableResolutions=executables,acceptedExternalHashAuthority=dict(path=str(OLD/'external-reference-closure.json'),bytes=len(old_external_raw),sha256=sha(old_external_raw)),fullExternalRegularContentRehashed=False,allExternalMetadataAndPathsetsFreshlyExact=True,originalInventoryReferences=[dict(path='immutable-protection-inventory.json',legacyRows=2018,additionalRootInclusiveRows=len(readj(P/'immutable-protection-inventory.json')['additionalRootInclusiveRows']),combinedRows=readj(D/'targeted-protection-before-assembly.json')['combinedImmutableRows'])],runtimeMutablePathsNotInputs=['/tmp/vscode-compile.lock','/tmp/.X11-unix/automatic-display','/tmp/automatic-display-lock'],platformBoundary='System shared ELF/OS packages, X server binaries, kernel and environment remain platform dependencies. Child mount namespace inheritance remains source inference; no future runtime child observed.',executionAuthorized=False,activationAuthorized=False))
xjson(P/'static-versus-runtime-protection-scope.json',dict(capturedAtUtc=now(),freshFullMetadataContextCounts=counts,acceptedFullContentHashesRetainFrozenProvenance=True,fullContextAndExternalHashRepeatCount=0,runtimeGuardMetadataRoots=['src','.build','node_modules','out'],runtimeGuardContentBound='Listed source/native256 pairs,149 tool/config bindings, freeze4/cache3, listed legacy2018 and root-inclusive2151 original regular files, historical reports/pins and original output backups; independent metadata pre/post/poststream scope.',prePostSamplingNotEverySyscall=True,atimeExcluded=True,noRuntimeBlanketFiveGigabyteHashClaim=True,wholeBuildProtectionPassed=False,goEsbuildWritesOutsideNodeHooksRemainPossible=True,metadataAndIndependentPoststreamProtectionRequired=True))
xjson(P/'ambient-dependency-closure.json',dict(capturedAtUtc=now(),fullRepositoryContext='context-content-inventory.json',fullExternalTargets='external-reference-closure.json',contentHashProvenance='accepted-content-hash-provenance.json',protectionScope='static-versus-runtime-protection-scope.json',boundToolAndConfigFileCount=149,boundFileList='bound-tool-and-config-files.json',ambientRoots=list(counts),counts=counts,futureNodeCompileCacheDisabled=True,goEsbuildWritesOutsideNodeHooksRemainPossible=True,completeMetadataGuardAndIndependentPoststreamGuardRequired=True,originalWholeBuildProtectionPassed=False,noRuntimeCredit=True))
xjson(P/'preparation-invocations.json',dict(preparedInvocations=0,candidateImports=0,candidateExecutions=0,syntaxCalls=0,programOrCheckerInvocations=0,eslintInvocations=0,dryInvocations=0,emitInvocations=0,officialInvocations=0,engineInvocations=0,uiInvocations=0,lockProbeInvocations=0,recordersExecuted='Executor-owned Python static recorders/builders only',sourceEdits=0))
summary=dict(capturedAtUtc=now(),workspaceHead=H,sourceTree=T,contextEntryCount=len(rows),acceptedContextRegularHashes=sum('sha256' in x for x in rows),acceptedContextRegularBytes=sum(x['size'] for x in rows if 'sha256' in x),contextCounts=counts,externalTargetGroups=len(groups),externalTargetEntries=sum(len(g['rows']) for g in groups),acceptedExternalRegularHashes=sum('sha256' in x for g in groups for x in g['rows']),acceptedExternalRegularBytes=sum(x['size'] for g in groups for x in g['rows'] if 'sha256' in x),wholeContextOrExternalContentHashesRepeated=0,directExternalFileReferences=len(direct),combinedImmutableRows=readj(D/'targeted-protection-before-assembly.json')['combinedImmutableRows'],candidateInvocations=0,packageNotFinalYet=True)
xjson(D/'phase2-static-closure.json',summary);workspace();print(json.dumps(summary))
