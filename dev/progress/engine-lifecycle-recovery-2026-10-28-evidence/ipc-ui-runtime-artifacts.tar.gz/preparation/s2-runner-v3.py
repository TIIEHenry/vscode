#!/usr/bin/env python3
"""Prepared S2 single-lane driver. Requires final frozen manifest AND new parent lane token."""
import argparse
from datetime import datetime, timezone
import fcntl
import hashlib
import json
import os
from pathlib import Path
import re
import signal
import subprocess
import time

parser=argparse.ArgumentParser(description=__doc__)
parser.add_argument('--manifest',type=Path,required=True)
parser.add_argument('--stage',choices=['old','new','quality'],required=True)
parser.add_argument('--lane-token',type=Path,required=True)
parser.add_argument('--old-qualification',type=Path)
args=parser.parse_args()
manifest_path=args.manifest.resolve(); manifest=json.loads(manifest_path.read_text())
token=json.loads(args.lane_token.read_text())
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
assert manifest.get('frozen') is True and manifest.get('candidateOnly') is False
assert manifest.get('runtimeAuthorized') is True and not manifest.get('baselineReferenceOnly')
assert token['manifestSha256']==sha(manifest_path)
assert token['runnerSha256']==sha(__file__)
assert token['authorizedBy']=='/root' and token['externalLaneCoordinated'] is True
assert token['directOfficialElectronApproved'] is True
assert args.stage in token['authorizedStages']
assert datetime.now(timezone.utc)<datetime.fromisoformat(token['expiresUtc'])
assert token['authorizationId']
repo=Path(manifest['repo']).resolve(); scratch=Path(manifest['scratch']).resolve()
assert repo.name in ['C','F'] and str(scratch).startswith('/sdd/tmp/')
here=Path(__file__).resolve().parent
assert sha(here/'s2-transpile.mjs')==manifest['transpileDriverSha256']

def git(*a):return subprocess.check_output(['git',*a],cwd=repo)
def check_frozen():
    assert git('rev-parse','HEAD').decode().strip()==manifest['frozenHead']
    assert hashlib.sha256(git('diff','HEAD','--','src')).hexdigest()==manifest['sourceDiffSha256']
    assert not git('ls-files','--others','--exclude-standard','--','src').strip()
    for relative,digest in manifest['sourceSha256'].items():assert sha(repo/relative)==digest,relative
    for entry in manifest['controls']:assert sha(entry['path'])==entry['sha256'],entry['path']
    for row in manifest['packages']:
        root=Path(row['root']); metadata=root/'package.json'
        assert metadata.is_file()==row['installed'],row['specifier']
        if row['installed']:
            assert sha(metadata)==row['packageJsonSha256'],str(metadata)
            for entry in row['entryCandidates']:assert sha(entry['path'])==entry['sha256'],entry['path']
    for entry in manifest['electron']['files']:assert sha(entry['path'])==entry['sha256'],entry['path']
    for entry in manifest['executables']:assert sha(entry['path'])==entry['sha256'],entry['path']

def check_out_topology():
    root=repo/'out'
    assert root.resolve()==root and not root.is_symlink()
    count=0
    for path in [root,*root.rglob('*')]:
        stat=path.lstat();assert not path.is_symlink(),str(path)
        if path.is_file():assert stat.st_nlink==1,str(path);count+=1
    return count

check_frozen()
for phase,rows in manifest['phases'].items():
    assert rows,phase
    for entry in rows:
        assert sha(entry['snapshot'])==entry['sha256'],entry['source']
        target=Path(entry['out']);assert target.is_relative_to(repo/'out')
        if phase=='old' and entry['role']=='raw-baseline':
            assert hashlib.sha256(git('show',manifest['baseline']+':'+entry['source'])).hexdigest()==entry['sha256']
        if phase=='old':assert 'universeAgentExpectedOwner' not in entry['source'],'green-only helper leaked into old'
if args.stage=='new':
    assert args.old_qualification,'Parent-reviewed old business red qualification is required.'
    qualification=json.loads(args.old_qualification.read_text())
    assert qualification['acceptedBy']=='/root' and qualification['manifestSha256']==sha(manifest_path)
    assert qualification['businessFailures'] and qualification['fixtureFailures']==0
    assert qualification['loadFailures']==0 and qualification['infrastructureFailures']==0

# Fresh process check precedes both nonblocking locks. Never hold a lock while waiting.
ancestors=set();pid=os.getpid()
while pid>1:
    ancestors.add(pid)
    try:pid=int(Path(f'/proc/{pid}/stat').read_text().split()[3])
    except (OSError,ValueError):break
active=[]
for process in Path('/proc').iterdir():
    if not process.name.isdigit() or int(process.name) in ancestors:continue
    try:
        command=(process/'cmdline').read_bytes().replace(b'\0',b' ').decode(errors='replace')
        if re.search(r'(?:/|\s)(?:gulp\.js|tsc(?:\.js)?|tsgo)(?:\s|$)|npm run (?:compile|typecheck|transpile)|test/unit/(?:node|electron)/index\.js|scripts/test\.sh|node[^\n]*transpile[^\n]*\.mjs',command):active.append({'pid':process.name,'command':command[:700]})
    except OSError:pass
assert not active,active
locks=[]
try:
    for name in ['/tmp/vscode-compile.lock','/tmp/vscode-loop-compile.lock']:
        lock=open(name,'a')
        try:fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
        except BaseException:lock.close();raise
        locks.append(lock)
    assert datetime.now(timezone.utc)<datetime.fromisoformat(token['expiresUtc'])
    capacity={str(p):os.statvfs(p).f_bavail*os.statvfs(p).f_frsize for p in [repo,scratch]}
    assert capacity[str(scratch)]>5*1024**3 and capacity[str(repo)]>512*1024**2,capacity
    stage=scratch/('stage-'+args.stage);stage.mkdir(exist_ok=False)
    for name in ['tmp','xdg-cache','npm-cache','npm-logs','artifacts','crashes','profile']:(stage/name).mkdir()
    env=os.environ.copy()
    for name in ['NODE_COMPILE_CACHE','ELECTRON_RUN_AS_NODE','NPM_CONFIG_CACHE','NPM_CONFIG_LOGS_DIR']:env.pop(name,None)
    env.update(NODE_DISABLE_COMPILE_CACHE='1',VSCODE_SKIP_PRELAUNCH='1',GIT_OPTIONAL_LOCKS='0',
        TMPDIR=str(stage/'tmp'),XDG_CACHE_HOME=str(stage/'xdg-cache'),XDG_CONFIG_HOME=str(stage/'profile'),
        npm_config_cache=str(stage/'npm-cache'),npm_config_logs_dir=str(stage/'npm-logs'),
        BUILD_ARTIFACTSTAGINGDIRECTORY=str(stage/'artifacts'))
    # HOME remains unchanged. Official Electron runner creates its userData under TMPDIR.
    results=[]
    protected_rows=[]
    def write(name,value):
        with (stage/name).open('x') as f:json.dump(value,f,indent=2);f.write('\n')
    write('lane-preflight.json',{'createdUtc':datetime.now(timezone.utc).isoformat(),'authorizationId':token['authorizationId'],'manifestSha256':sha(manifest_path),'pid':os.getpid(),'activeProcessesBeforeLocks':active,'locksHeld':[{'path':l.name,'inode':os.fstat(l.fileno()).st_ino} for l in locks],'capacity':capacity,'outFilesBefore':check_out_topology(),'privateEnvironment':{k:env[k] for k in ['NODE_DISABLE_COMPILE_CACHE','TMPDIR','XDG_CACHE_HOME','XDG_CONFIG_HOME','npm_config_cache','npm_config_logs_dir','BUILD_ARTIFACTSTAGINGDIRECTORY']},'HOMEUnchanged':env.get('HOME')==os.environ.get('HOME')})

    def identities(phase):
        selected={e['out']:e for e in manifest['phases']['old']}
        if phase=='new':selected.update({e['out']:e for e in manifest['phases']['new']})
        rows=[]
        for target,entry in sorted(selected.items()):
            output=Path(target);stat=output.lstat()
            assert not output.is_symlink() and stat.st_nlink==1
            rows.append({'source':entry['source'],'snapshot':entry['snapshot'],'sourceSha256':entry['sha256'],'role':entry['role'],'out':target,'outSha256':sha(output),'bytes':stat.st_size})
        write(phase+'-source-out-identities.json',rows)
        return rows

    def check_identities(rows):
        for entry in rows:assert sha(entry['out'])==entry['outSha256'],'runtime mutated '+entry['out']

    def emitted_graph_check(phase):
        entries=manifest['phases']['old'] if phase=='old' else manifest['completeNew']
        outputs={e['out'] for e in entries};edges=[];dynamic=[]
        pattern=re.compile(r"(?m)^\s*(?:import|export)\s+(?:[^;]*?\bfrom\s*)?['\"]([^'\"]+)['\"]|\bimport\s*\(\s*['\"]([^'\"]+)['\"]\s*\)")
        for entry in entries:
            path=Path(entry['out'])
            if path.suffix!='.js':continue
            text=path.read_text()
            for m in pattern.finditer(text):
                spec=m[1] or m[2]
                if not spec.startswith('.'):continue
                target=(path.parent/spec.split('?',1)[0]).resolve()
                assert str(target) in outputs,('emitted dependency absent from exact snapshot graph',entry['source'],spec,str(target))
                edges.append({'out':str(path),'specifier':spec,'target':str(target)})
                if phase=='old':assert 'universeAgentExpectedOwner' not in str(target)
            if re.search(r'\bimport\s*\(\s*[^\s\'\"]',text):dynamic.append(str(path))
        write(phase+'-emitted-graph.json',{'edges':edges,'nonliteralDynamicCandidates':dynamic,'exactRelativeEdgesCovered':True,'noNewOwnerRuntimeInOld':phase=='old'})

    def run(label,command,timeout=240):
        check_frozen();check_out_topology();check_identities(protected_rows)
        assert datetime.now(timezone.utc)<datetime.fromisoformat(token['expiresUtc'])
        log=stage/(label+'.log');started=time.time();timed_out=False
        with log.open('x') as stream:
            child=subprocess.Popen(command,cwd=repo,env=env,stdout=stream,stderr=subprocess.STDOUT,start_new_session=True)
            print(json.dumps({'stage':label,'pid':child.pid,'command':command,'log':str(log)}),flush=True)
            try:code=child.wait(timeout=timeout)
            except subprocess.TimeoutExpired:
                timed_out=True;os.killpg(child.pid,signal.SIGTERM)
                try:child.wait(timeout=8)
                except subprocess.TimeoutExpired:os.killpg(child.pid,signal.SIGKILL);child.wait()
                code=-999
        lingering=[]
        for proc in Path('/proc').iterdir():
            if not proc.name.isdigit():continue
            try:
                if os.getpgid(int(proc.name))==child.pid:lingering.append({'pid':proc.name,'command':(proc/'cmdline').read_bytes().replace(b'\0',b' ').decode(errors='replace')[:500]})
            except (OSError,ProcessLookupError):pass
        record={'stage':label,'lingeringProcessGroup':lingering,'command':command,'exitCode':code,'timedOut':timed_out,'seconds':time.time()-started,'logSha256':sha(log),'logBytes':log.stat().st_size}
        raw=log.read_text(errors='replace')
        if label.endswith('-targets'):
            parsed=None
            for marker in re.finditer(r'\{\s*"stats"\s*:',raw):
                try:
                    value=json.JSONDecoder().raw_decode(raw[marker.start():])[0]
                    if isinstance(value,dict) and 'failures' in value:parsed=value
                except (ValueError,TypeError):pass
            if parsed is not None:
                write(label+'-official-result.json',parsed)
                record['stats']=parsed['stats'];record['failureTitles']=[x.get('fullTitle') for x in parsed.get('failures',[])]
                record['officialCleanStateMetaPassed']=any(x.get('title')=='assertCleanState - check that registries are clean at the start of test running' for x in parsed.get('passes',[]))
            else:record['missingOfficialJson']=True
        if label=='lint' and code==0:
            lint=json.loads(raw);record['errors']=sum(x['errorCount'] for x in lint);record['warnings']=sum(x['warningCount'] for x in lint)
        results.append(record);write(args.stage+'-driver-results-'+str(len(results)).zfill(2)+'.json',results)
        check_frozen();check_out_topology();check_identities(protected_rows);print(json.dumps(record),flush=True)
        assert not lingering,'Child process group must be quiet before next step/lane release'
        return code,record

    node=next(x['path'] for x in manifest['executables'] if x['name']=='node')
    npm=next(x['path'] for x in manifest['executables'] if x['name']=='npm')
    if args.stage in ['old','new']:
        if args.stage=='new':
            prior=json.loads((scratch/'stage-old'/'old-source-out-identities.json').read_text());check_identities(prior)
        code,_=run(args.stage+'-transpile',[node,str(here/'s2-transpile.mjs'),str(manifest_path),args.stage])
        if code:raise SystemExit(code)
        rows=identities(args.stage);protected_rows=rows;emitted_graph_check(args.stage)
        command=[manifest['electron']['entry'],'test/unit/electron/index.js','--no-sandbox','--disable-gpu','--crash-reporter-directory='+str(stage/'crashes')]
        for test in manifest['oldTests' if args.stage=='old' else 'newTests']:command.extend(['--run',test])
        if args.stage=='old' and manifest.get('oldGrep'):command.extend(['--grep',manifest['oldGrep']])
        command.extend(['--reporter','json'])
        code,record=run(args.stage+'-targets',command)
        check_identities(rows)
        if args.stage=='new' and code==0:
            assert not record.get('missingOfficialJson') and record['stats']['failures']==0
            assert record['officialCleanStateMetaPassed'],'full green must include official clean-state meta'
        write('completed.json',{'stage':args.stage,'exitCode':code,'finishedUtc':datetime.now(timezone.utc).isoformat(),'sourceOutStable':True,'businessQualification':'separate parent review required for old; no auto-classification','CanceledConsumption':'explicit test assertions and local listeners; official cancellation suppression is not proof'})
        raise SystemExit(code)
    assert manifest['lintPaths']
    protected_rows=json.loads((scratch/'stage-new'/'new-source-out-identities.json').read_text())
    check_identities(protected_rows)
    code,_=run('noemit',[npm,'run','typecheck-client','--','--incremental','false'],timeout=420)
    if code:raise SystemExit(code)
    code,_=run('lint',[node,'node_modules/eslint/bin/eslint.js','--no-cache','--format','json',*manifest['lintPaths']])
    raise SystemExit(code)
finally:
    for lock in locks:fcntl.flock(lock,fcntl.LOCK_UN);lock.close()
