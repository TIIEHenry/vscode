from pathlib import Path
import collections, hashlib, json, os, re, sys
base=Path(__file__).resolve().parent
ebase=base.parent/'e-response-after-m01-20261027-r2'
runid='sources-m01-after-20261027-r2'
head='800d383ba65fdefb36da324b380941c7574c4bf3'
tree='2b5df2b37ca926e38888443e371cf65e2883dba2'
notice_sha='671cb3c8d944cd785772b8c8326415f0c2263c29e47cc0bfc991f2454e62479b'
outputs_sha='f9dd6bc5f3923a4bd57f6b70ab01ac5070bcbd991c67cbef667d8cbfcbfc23d6'
read=lambda p:json.loads(p.read_text())
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
steps={int(p.name.split('-')[0]):(p,read(p)['state'])for p in (base/'steps').glob('*.json')if re.match(r'^\d+-',p.name)}
records=[]
def ck(case,detail,value,*evidence):
 records.append({'case':case,'detail':detail,'passed':bool(value),'evidence':[str(steps[i][0].relative_to(base))if isinstance(i,int)else str(i)for i in evidence]})
def st(i):return steps[i][1]
def uri(repo,file='shared.txt'):return 'file:///tmp/vscode-d1387-sources-audit-after-uvyx1ei3/'+repo+'/'+file
def part(i,session):return next(p for p in st(i)['conversationParts']if p['sessionKey']==session)
def group(i,id,session=None):return next(g for g in (part(i,session)['groups']if session else st(i)['mainGroups'])if g['id']==id)
def tabs(i,id=0,session=None):return [e.get('modified',e.get('resource'))for e in group(i,id,session)['editors']]
def hasdiff(i,repo,file='shared.txt',readonly=None):
 return any(d.get('modified')==uri(repo,file)and d.get('visibility',{}).get('width',0)>0 and d['visibility'].get('height',0)>0 and (readonly is None or [d['originalReadOnly'],d['modifiedReadOnly']]==readonly)for d in st(i)['diffs'])
def reviewed(i,repo,file='shared.txt'):return any(e['resource']==uri(repo,file)and e['reviewed']for e in st(i)['changes']['entries'])
def count(i,command):return sum(e['id']==command for e in st(i)['events'])
fixtures={row['root']:row for row in read(base/'fixture-baseline.json')}
ck('X01','67 unique fresh runtime snapshots',len(steps)==67 and set(steps)==set(range(1,68)))
for i,(path,s)in steps.items():
 ck('X01','Fresh run/source/raw notice/canonical binding',s['runId']==runid and s['sourceHead']==head and s['sourceTree']==tree and s['freezeNoticeSha256']==notice_sha and s['frozenOutputsSha256']==outputs_sha,i)
 ck('X01','Actual disconnected idle with no live channel or connection events',not s['connected']and s['connection']['phase']['kind']=='disconnected'and s['connection']['transport']=='idle'and s['connection']['channelAlive']is False and not s['connectionEvents'],i)
 ck('X01','Clean attempt2 has no UI errors',s['uiErrors']==[],i)
 ck('X01','Default editor and pinned untitled Conversation root retained',s['isSessionsWindow']is False and group(i,7,'untitled')['editors'][0]['resource']=='conversation-chat:/session/untitled/chat/default'and group(i,7,'untitled')['editors'][0]['pinned'],i)
 ck('X01','No empty duplicate Conversation group',all(g['editors']for p in s['conversationParts']for g in p['groups']),i)
 for d in s['diffs']:
  modified=d.get('modified')
  if not modified:continue
  local=Path(modified.removeprefix('file://'));root=str(local.parent);f=fixtures[root]['files'][local.name]
  ck('CONTENT','Complete real original/modified sentinel model pair',d['originalText']==f['HEADtext']and d['modifiedText']==f['text']and d['original'].startswith('git:')and str(local)in d['original'],i)
for before,after,repo,case in [(2,3,'alpha','P01'),(4,5,'beta','P02'),(11,12,'alpha','P04'),(15,16,'alpha','P05')]:
 ck(case,'Real visible full diff for intended resource',hasdiff(after,repo),after)
 ck(case,'Exactly one official _workbench.diff dispatch for normal entry',count(after,'_workbench.diff')-count(before,'_workbench.diff')==1,before,after)
ck('P01','Beta active before Alpha replace; only Alpha remains pinned',tabs(2)==[uri('beta')]and tabs(3)==[uri('alpha')]and group(3,0)['editors'][0]['pinned']and reviewed(3,'alpha')and not reviewed(3,'beta'),2,3)
ck('P02','newTab retains Alpha then pinned Beta and marks captured Beta',tabs(5)==[uri('alpha'),uri('beta')]and all(e['pinned']for e in group(5,0)['editors'])and reviewed(5,'beta'),5)
ck('P03','Context menu alone does not dispatch; alternate replaces only active Beta',count(6,'_workbench.diff')==count(5,'_workbench.diff')and count(7,'_workbench.diff')==count(6,'_workbench.diff')+1 and tabs(7)==[uri('alpha'),uri('alpha','other.txt')]and hasdiff(7,'alpha','other.txt'),5,6,7)
ck('P03','No-slot public openSelected opens actual selected Beta once',st(8)['selectedReview']==uri('beta')and count(8,'_workbench.diff')==count(7,'_workbench.diff')+1 and hasdiff(8,'beta'),7,8)
ck('P04','Changes replace closes seeded Beta only and leaves Review progress unchanged',tabs(11)==[uri('beta')]and tabs(12)==[uri('alpha')]and [e['reviewed']for e in st(11)['changes']['entries']]==[e['reviewed']for e in st(12)['changes']['entries']],11,12)
ck('P05','Changes Enter newTab preserves pinned Beta and Alpha; progress unchanged',tabs(16)==[uri('beta'),uri('alpha')]and all(e['pinned']for e in group(16,0)['editors'])and [e['reviewed']for e in st(15)['changes']['entries']]==[e['reviewed']for e in st(16)['changes']['entries']],15,16)
ck('C01','First replace opens actual readonly Alpha in new exact side group8',len(part(18,'untitled')['groups'])==1 and tabs(19,8,'untitled')==[uri('alpha')]and hasdiff(19,'alpha',readonly=[True,True])and part(19,'untitled')['activeGroup']==8,18,19)
ck('C02','First newTab Enter opens readonly Beta into group10 from root-only Beta leaf',len(part(21,'visualize')['groups'])==1 and tabs(22,10,'visualize')==[uri('beta')]and hasdiff(22,'beta',readonly=[True,True])and group(22,9,'visualize')['editors'][0]['resource']=='conversation-chat:/session/visualize/chat/default',21,22)
ck('C03','No-slot public openSelected reveals same actual Beta input without extra group',part(22,'visualize')==part(23,'visualize')and hasdiff(23,'beta',readonly=[True,True]),22,23)
ck('C04','Typed replace stays group10 and removes only shared side tab',tabs(25,10,'visualize')==[uri('beta','other.txt')]and hasdiff(25,'beta','other.txt',[True,True])and part(25,'untitled')==part(23,'untitled'),23,25)
ck('C05','NewTab preserves other and shared; repeated reveals under both slot settings add nothing',tabs(27,10,'visualize')==[uri('beta','other.txt'),uri('beta')]and part(27,'visualize')==part(28,'visualize')==part(30,'visualize')and hasdiff(30,'beta',readonly=[True,True]),27,28,30)
ck('C06','Actual Beta target after Alpha focus does not take over Alpha leaf',part(31,'untitled')==part(33,'untitled')and group(33,10,'visualize')['active']['modified']==uri('beta','other.txt')and hasdiff(33,'beta','other.txt',[True,True]),31,32,33)
ck('B01','Panel Alpha mouse/Enter shows own readonly comparison while Beta Conversation is unchanged',st(35)['panelRef']['modified']==uri('alpha')and st(36)['panelRef']['modified']==uri('alpha','other.txt')and hasdiff(35,'alpha',readonly=[True,True])and hasdiff(36,'alpha','other.txt',[True,True])and part(33,'visualize')==part(35,'visualize')==part(36,'visualize'),33,35,36)
ck('M01','Panel to Conversation transfers full ref, closes Panel, retains source roots',st(37)['panelRef']is None and group(37,10,'visualize')['active']['modified']==uri('alpha','other.txt')and hasdiff(37,'alpha','other.txt',[True,True])and part(36,'untitled')==part(37,'untitled'),36,37)
b=st(40);a=st(41);source=[e for e in a['events']if e['id']=='sources.diff.moveToPreview'][-1]['args'][0]
ck('M01','Actual pane button sends original typed source with exact editor/group/pane identities',source['kind']=='conversationPane'and source['editor']['modified']==uri('alpha','other.txt')and source['group']['id']==10 and source['group']['containsExactEditor']and source['pane']['sameEditor']and source['pane']['sameGroup']and source['pane']['sameActivePane'],40,41)
ck('M01','Actual button closes exactly captured Alpha, preserves Beta tab ordering and other leaf/root',tabs(41,10,'visualize')==[x for x in tabs(40,10,'visualize')if x!=uri('alpha','other.txt')]and part(40,'untitled')==part(41,'untitled')and group(40,9,'visualize')==group(41,9,'visualize'),40,41)
ck('M01','Actual button preserves unrelated Preview Beta and opens pinned actual Alpha complete sides',tabs(40)==[uri('beta','other.txt')]and tabs(41)==[uri('beta','other.txt'),uri('alpha','other.txt')]and all(e['pinned']for e in group(41,0)['editors'])and hasdiff(41,'alpha','other.txt',[True,False]),40,41)
ck('M01','Preview to Conversation closes only actual Preview source, preserves Beta and full target',tabs(43)==[uri('beta','other.txt')]and group(43,10,'visualize')['active']['modified']==uri('alpha','other.txt')and hasdiff(43,'alpha','other.txt',[True,True])and part(42,'untitled')==part(43,'untitled'),42,43)
ck('M01','Preview to Panel closes exact Alpha only, Panel full sides visible and Conversation unchanged',tabs(46)==[uri('beta','other.txt')]and st(46)['panelRef']['modified']==uri('alpha')and st(46)['panelRef']['original']==group(45,0)['active']['original']and hasdiff(46,'alpha',readonly=[True,True])and st(45)['conversationParts']==st(46)['conversationParts'],45,46)
ck('M01','Panel to Preview closes Panel only, opens correct pinned Alpha and preserves Beta/Conversation',st(47)['panelRef']is None and tabs(47)==[uri('beta','other.txt'),uri('alpha')]and hasdiff(47,'alpha',readonly=[True,False])and st(46)['conversationParts']==st(47)['conversationParts'],46,47)
ck('E01','Controlled official API rejection has one own-target hit, no Preview open or reviewed mark',len(st(52)['fault']['hits'])==1 and not tabs(52)and not reviewed(52,'alpha','other.txt')and st(52)['reviewStatus']=='Unable to open diff: D1387 controlled own Git open rejection',50,51,52)
ck('E01','Restored official handler real reopen shows complete content, marks only real target and clears old error',not st(54)['fault']['registered']and hasdiff(54,'alpha','other.txt')and reviewed(54,'alpha','other.txt')and 'Unable to open'not in st(54)['reviewStatus'],53,54)
ck('E02','Older rejected pending open does not mark or overwrite later Alpha success',st(57)['fault']['pending']and not reviewed(57,'beta','other.txt')and st(60)['fault']['settled']=='reject'and not reviewed(60,'beta','other.txt')and tabs(60)==[uri('alpha')]and 'Unable to open'not in st(60)['reviewStatus'],57,59,60)
ck('E02','Older void settlement cannot overwrite new status; marks delegation only, not a Preview pane proof',st(62)['fault']['pending']and not reviewed(62,'beta','other.txt')and st(65)['fault']['settled']=='void'and reviewed(65,'beta','other.txt')and tabs(65)==[uri('alpha','other.txt')]and 'Unable to open'not in st(65)['reviewStatus'],62,64,65)
loaded=read(base/'loaded-manifest.json');assets=read(ebase/'runtime-assets-J.json')
ck('M01','Actual loaded19 subset includes all three M01 native bytes and original core',len(loaded['files'])==19 and not loaded['missingCore']and all(f['sha256']==f['diskSha256']for f in loaded['files'])and all(any(f['url'].endswith('/'+name+'.js')for f in loaded['files'])for name in ['conversationDiffReviewPane','sourcesDiffActions','sourcesDiffRefHelpers']),'loaded-manifest.json')
counts=collections.Counter(x['runtimeEvidenceStatus']for x in assets['assets'])
ck('X01','53 source/native frozen manifest separates 40 actual JS and 1 CSS from 12 manifest-only',len(assets['assets'])==53 and counts['renderer-js-loaded']==40 and counts['manifest-only']==12 and not assets['missingRequiredRendererEvidence']and all(e.get('matchesFrozenNativeBytes')for row in assets['assets']for e in row['runtimeEvidence']),'../e-response-after-m01-20261027-r2/runtime-assets-J.json')
ck('X01','After53 and full163 source/native/Git identities still exact',len(read(base/'guard-after.json')['verifiedOutputs'])==53 and read(base/'full163-guard-after.json')['sourceNativeGitCount']==163 and read(base/'full163-guard-after.json')['allMatch'],'guard-after.json','full163-guard-after.json')
ck('X01','Fixture HEAD/index/worktree/files byte-exact with no staged diff',read(base/'fixture-after.json')['matchesBaseline']and all(not x['cachedDiffHex']for x in read(base/'fixture-after.json')['current']),'fixture-after.json')
main=read(base/'main-runtime.json');home=Path(main['engineHome']);ck('X01','Actual main uses own empty0700 home; no fake server or E authorization',main['engineHome']=='/tmp/vscode-e-after-home-rj0yzdkr'and home.stat().st_mode&0o777==0o700 and not list(home.iterdir())and not(ebase/'server-started.json').exists()and not(ebase/'e-phase-authorization.json').exists(),'main-runtime.json')
ck('X01','No observed stage/revert/checkout/commit command',not any(re.search(r'(?:git\.(?:stage|revert|checkout|commit)|sources.*(?:stage|revert))',e['id'],re.I)for e in st(67)['events']),67)
full=read(base/'lane-provenance'/'m01-eighth-J-complete-11.json');focused=read(base/'lane-provenance'/'m01-eighth-J-focused.json');raw=(base/'lane-provenance'/'m01-eighth-J-complete-11.log').read_text()
for case,needles in [('E03',['markReviewedAfterSuccessfulOpen ignores stale and false without marking','stale review open does not mark reviewed or overwrite a newer direct-open failure']),('F01',['public finder and EditorService retain the exact typed Conversation object target','public finder and EditorService retain the exact typed Conversation id target','ordinary file, untitled, chat and writable diff stay outside Conversation','typed Conversation input rejects missing, wrong, removed and same-id forged concrete targets','an excluded non-Conversation part flag cannot authorize'])]:
 ck(case,'Read-only provenance of current sole-lane actual green; D does not run these regressions',full['sourceTree']==tree and full['exitCode']==0 and '425 passing' in ''.join(full['mochaSummaries'])and focused['exitCode']==0 and all(needle in raw for needle in needles),'lane-provenance/m01-eighth-J-complete-11.json','lane-provenance/m01-eighth-J-complete-11.log','lane-provenance/m01-eighth-J-focused.json')
failed=[r for r in records if not r['passed']]
result={'runId':runid,'sourceHead':head,'sourceTree':tree,'freezeNoticeSha256':notice_sha,'frozenOutputsSha256':outputs_sha,'runtimeAttempt':2,'runtimeSnapshots':len(steps),'assertionCount':len(records),'failed':len(failed),'records':records,'lateVoidBoundary':'Official SCM void delegation completion is not observed-pane proof; Beta Review mark does not imply Preview created','priorAttempt':'observer-attempt-1 retains two observer-induced toJSON IPC errors and all original snapshots/logs; not a product pass/failure substitution'}
(base/'assertions.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps({'assertions':len(records),'failed':failed,'runtimeSnapshots':len(steps),'runtimeStatuses':dict(counts)}));raise SystemExit(1 if failed else 0)
