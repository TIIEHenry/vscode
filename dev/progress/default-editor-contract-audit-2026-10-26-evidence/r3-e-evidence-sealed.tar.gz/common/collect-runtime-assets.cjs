'use strict';
const fs=require('node:fs'),path=require('node:path'),crypto=require('node:crypto'),assert=require('node:assert/strict');
const {loadRuntime}=require('./gate.cjs');
const phase=process.argv.find(v=>v.startsWith('--phase='))?.split('=')[1];
const ctx=loadRuntime(phase,{launch:true}),{config,contract,notice,info}=ctx,base=ctx.base,repo=config.runtimeRepo,owner=config.owner;
const {chromium}=require(path.join(repo,'node_modules/playwright-core'));
const sha=bytes=>crypto.createHash('sha256').update(bytes).digest('hex'),mainAsset=file=>file.includes('/node/')||file.includes('/electron-main/');
const ownPrefix='vscode-file://vscode-app'+repo+'/out/',normalizedUrl=url=>url.split(/[?#]/)[0];
const frozen=new Map(notice.outputs.map(file=>[file.path,file]));
const assets = [];
for (const file of frozen.values()) {
  assert.ok(file.path.startsWith('out/vs/') && !file.path.includes('..') && /\.(js|css)$/.test(file.path));
  const sourcePath = file.path.replace(/^out\//, 'src/').replace(/\.js$/, '.ts');
  assert.equal(file.sourcePath, sourcePath);
  assert.equal(sha(fs.readFileSync(path.join(repo, file.path))), file.sha256);
  assert.equal(sha(fs.readFileSync(path.join(repo, sourcePath))), file.sourceSha256);
  assets.push({ ...file, runtimeEvidenceStatus: 'manifest-only', runtimeEvidence: [], reason: mainAsset(file.path) ? 'No main-process inspector collection performed; renderer CDP cannot prove node-main loading' : 'Not yet observed in the actual renderer' });
}
const jsAssets = assets.filter(file => file.path.endsWith('.js') && !mainAsset(file.path));
const cssAssets = assets.filter(file => file.path.endsWith('.css'));
const evidenceDir = path.join(base, 'runtime-' + phase);
assert.ok(!fs.existsSync(evidenceDir),'Never overwrite runtime copies');
assert.ok(!fs.existsSync(path.join(base,'runtime-assets-'+phase+'.json')),'Never overwrite runtime evidence');
fs.mkdirSync(evidenceDir, { recursive: true });

(async () => {
  const browser = await chromium.connectOverCDP('http://127.0.0.1:' + info.cdpPort);
  try {
    const page = browser.contexts().flatMap(c => c.pages()).find(p => p.url().startsWith(ownPrefix) && p.url().includes('/workbench-dev.html'));
    assert.ok(page, 'Own real default editor is absent');
    await page.waitForFunction(() => !!window.driver);
    await page.evaluate(() => window.driver.whenWorkbenchRestored());
    const cdp = await page.context().newCDPSession(page);
    const scripts = new Map();
    const styles = new Map();
    const cssErrors = [];
    cdp.on('Debugger.scriptParsed', script => {
      const url = normalizedUrl(script.url ?? '');
      if (url.startsWith(ownPrefix) && jsAssets.some(file => url === ownPrefix + file.path.slice(4))) scripts.set(script.scriptId, script);
    });
    cdp.on('CSS.styleSheetAdded', ({ header }) => styles.set(header.styleSheetId, header));
    await cdp.send('Debugger.enable');
    try { await cdp.send('DOM.enable'); await cdp.send('CSS.enable'); } catch (error) { cssErrors.push(String(error)); }
    await new Promise(resolve => setTimeout(resolve, 150));
    for (const script of scripts.values()) {
      const url = normalizedUrl(script.url);
      const asset = jsAssets.find(file => url === ownPrefix + file.path.slice(4));
      const { scriptSource } = await cdp.send('Debugger.getScriptSource', { scriptId: script.scriptId });
      const bytes = Buffer.from(scriptSource);
      const copy = path.join(evidenceDir, asset.path.replaceAll('/', '__') + '.loaded.txt');
      fs.writeFileSync(copy, bytes);
      asset.runtimeEvidenceStatus = 'renderer-js-loaded';
      asset.reason = 'Actual Debugger.scriptParsed URL and Debugger.getScriptSource';
      asset.runtimeEvidence.push({ surface: 'renderer', url: script.url, scriptId: script.scriptId, sha256: sha(bytes), bytes: bytes.length, copy, matchesFrozenNativeBytes: sha(bytes) === asset.sha256 });
    }
    for (const header of styles.values()) {
      const url = normalizedUrl(header.sourceURL ?? '');
      const asset = cssAssets.find(file => url === ownPrefix + file.path.slice(4));
      if (!asset) continue;
      try {
        const { text } = await cdp.send('CSS.getStyleSheetText', { styleSheetId: header.styleSheetId });
        const copy = path.join(evidenceDir, asset.path.replaceAll('/', '__') + '.' + header.styleSheetId + '.css.loaded.txt');
        fs.writeFileSync(copy, text);
        asset.runtimeEvidenceStatus = 'renderer-css-loaded';
        asset.reason = 'Actual CSS.styleSheetAdded sourceURL and CSS.getStyleSheetText';
        asset.runtimeEvidence.push({ surface: 'renderer', source: 'CDP CSS', url: header.sourceURL, styleSheetId: header.styleSheetId, sha256: sha(Buffer.from(text)), copy, matchesFrozenNativeBytes: sha(Buffer.from(text)) === asset.sha256 });
      } catch (error) { cssErrors.push(String(error)); }
    }
    // Dev CSS loaders can insert connected <style> nodes without a CSS URL.
    // Only an actual stylesheet node whose whole body equals the frozen CSS
    // bytes can identify the asset; disk existence alone never counts.
    const inline = await page.evaluate(() => [...document.querySelectorAll('style')].filter(node => node.sheet).map((node, index) => ({ index, text: node.textContent ?? '', disabled: node.sheet.disabled, attributes: [...node.attributes].map(a => [a.name, a.value]) })));
    for (const node of inline) {
      const hash = sha(Buffer.from(node.text));
      const asset = cssAssets.find(file => file.sha256 === hash);
      if (!asset) continue;
      const copy = path.join(evidenceDir, asset.path.replaceAll('/', '__') + '.style-' + node.index + '.loaded.txt');
      fs.writeFileSync(copy, node.text);
      asset.runtimeEvidenceStatus = 'renderer-css-loaded';
      asset.reason = 'Actual connected DOM stylesheet whose complete text equals frozen native CSS';
      asset.runtimeEvidence.push({ surface: 'renderer', source: 'DOM stylesheet text', styleIndex: node.index, disabled: node.disabled, attributes: node.attributes, sha256: hash, copy, matchesFrozenNativeBytes: true });
    }
    const requiredRenderer = [...new Set([...contract.mustObserveRenderer, ...cssAssets.map(file => file.path)])];
    const missing = requiredRenderer.filter(file => !assets.find(a => a.path === file)?.runtimeEvidence.length);
    const record = { runId: contract.runId, freezeNoticeSha256: info.freezeNoticeSha256, frozenOutputsSha256: info.frozenOutputsSha256, at: new Date().toISOString(), createdBy: owner, phase, sourceHead: notice.sourceHead, sourceTree: notice.sourceTree, windowUrl: page.url(), loadedEvidenceScope: 'Only actual renderer Debugger/CSS/DOM observations; node-main stays manifest-only', fakeIoScope: 'E response recovery with queue unsupported; no queue/skills acceptance credit', assets, missingRequiredRendererEvidence: missing, cssErrors };
    const recordPath=path.join(base,'runtime-assets-'+phase+'.json');assert.ok(!fs.existsSync(recordPath),'Never overwrite collected runtime evidence');fs.writeFileSync(recordPath,JSON.stringify(record,null,2)+'\n');
    console.log(JSON.stringify({ phase, frozenAssets: assets.length, observedJs: assets.filter(a => a.runtimeEvidenceStatus === 'renderer-js-loaded').length, observedCss: assets.filter(a => a.runtimeEvidenceStatus === 'renderer-css-loaded').length, manifestOnly: assets.filter(a => a.runtimeEvidenceStatus === 'manifest-only').length, missingRequiredRendererEvidence: missing }));
    assert.equal(missing.length, 0, 'Missing actual required renderer evidence; retain the boundary, do not relabel manifest-only assets');
  } finally { await browser.close(); }
})().catch(error => { console.error(error); process.exitCode = 1; });
