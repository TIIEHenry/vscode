#!/usr/bin/env python3
"""Python-only S2 candidate closure assembly. No Node, out mutation, locks or refs."""
import argparse
import ast
from collections import deque
from datetime import datetime, timezone
import hashlib
import json
import os
from pathlib import Path, PurePosixPath
import re
import shutil
import subprocess

parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument('--config', type=Path, required=True)
parser.add_argument('--attempt', type=Path, required=True)
parser.add_argument('--baseline-only', action='store_true')
args = parser.parse_args()
config = json.loads(args.config.read_text())
repo = Path(config['repo']).resolve()
attempt = args.attempt.resolve()
assert repo.name in ['C', 'F'] and str(attempt).startswith('/sdd/tmp/')
assert not attempt.exists(), 'Every candidate/attempt is exclusive; never overwrite evidence.'
attempt.mkdir()
sha = lambda data: hashlib.sha256(data).hexdigest()
git = lambda *a: subprocess.check_output(['git', *a], cwd=repo)
assert git('rev-parse', 'HEAD').decode().strip() == config['head']
# Final test counts are author-expanded declarations, never historical runner totals.
OFFICIAL_META = 'Tests are using suiteSetup and setup correctly assertCleanState - check that registries are clean at the start of test running'
test_plan = config.get('testPlan')
if not args.baseline_only:
    assert test_plan and test_plan['mode'] == 'complete-files'
    assert {row['source'] for row in test_plan['files']} == set(config['tests'])
    assert test_plan['expectedPending'] == 0
    assert test_plan['officialMeta'] == [{'fullTitle': OFFICIAL_META, 'expectedCount': 1}]
    for row in test_plan['files']:
        assert isinstance(row['expectedBusinessTests'], int) and row['expectedBusinessTests'] > 0
        assert row['suitePrefixes'] and all(isinstance(p, str) and p for p in row['suitePrefixes'])
        assert isinstance(row['sourceScanFullTitles'], list)
    computed_total = sum(row['expectedBusinessTests'] + len(row['sourceScanFullTitles']) for row in test_plan['files']) + 1
    assert test_plan['expectedTotalTests'] == computed_total
    assert config.get('oldGrep') is None, 'Old and new both run complete selected files.'

freeze = config['sourceSha256']
frozen = {path: (repo/path).read_bytes() for path in freeze}
assert all(sha(frozen[p]) == h for p,h in freeze.items()), 'author freeze mismatch'
# Compare whole source WIP scope; prevents an unrecorded source influencing project noEmit.
source_diff = git('diff', 'HEAD', '--', 'src')
if not args.baseline_only: assert set(git('diff', '--name-only', 'HEAD', '--', 'src').decode().splitlines()) == set(config['production'] + config['tests'])
if not args.baseline_only: assert not git('ls-files', '--others', '--exclude-standard', '--', 'src').strip()

trees = {}
for revision in set([config['head'], config['baseline']]):
    table = {}
    for row in git('ls-tree', '-r', '-z', revision).split(b'\0'):
        if row:
            meta,name = row.split(b'\t', 1)
            mode,kind,blob = meta.decode().split()
            if kind == 'blob': table[name.decode()] = blob
    trees[revision] = table
cache = {}
def raw(revision, path):
    key = (revision,path)
    if key not in cache: cache[key] = git('cat-file', 'blob', trees[revision][path])
    return cache[key]

# Conservative lexical import closure: explicit type-only imports are erased;
# unmarked TS imports are retained, even where esbuild may later erase type usage.
lex = re.compile(r"(?P<string>'(?:\\.|[^'\\\r\n])*'|\"(?:\\.|[^\"\\\r\n])*\"|`(?:\\.|[^`\\])*`)|(?P<line>//[^\n]*)|(?P<block>/\*[\s\S]*?\*/)")
def clean(text):
    return lex.sub(lambda m: m.group() if m.lastgroup == 'string' else ''.join('\n' if c == '\n' else ' ' for c in m.group()),text)
statement = re.compile(r"(?m)^\s*(?P<kind>import|export)\s+(?P<body>[^;]*?);",re.M)
spec_re = re.compile(r"\bfrom\s*['\"]([^'\"]+)['\"]")
literal = re.compile(r"\b(?P<kind>import|require)\s*\(\s*['\"](?P<spec>[^'\"]+)['\"]\s*\)")
resource_call = re.compile(r"\b(?:FileAccess\.(?:asBrowserUri|asFileUri)|registerAssets)\(\s*['\"]([^'\"]+)['\"]")
css_url = re.compile(r"url\(\s*['\"]?([^)'\"]+)['\"]?\s*\)|@import\s+['\"]([^'\"]+)['\"]")

def imports(data,source):
    text=clean(data.decode(errors='strict')); refs=[]; omitted=[]
    for m in statement.finditer(text):
        body=m['body'].strip()
        if m['kind']=='export' and not body.startswith(('{','*','type {','type *')): continue
        sm=spec_re.search(body)
        if sm: spec=sm[1]
        elif m['kind']=='import' and body[:1] in ["'",'"']: spec=body[1:].split(body[0],1)[0]
        else: continue
        if body.startswith('type ') or re.fullmatch(r"\{\s*(?:type\s+[^,}]+\s*,?\s*)+\}\s+from[\s\S]*",body): omitted.append(spec)
        else: refs.append((m['kind'],spec))
    for m in literal.finditer(text): refs.append((m['kind']+'-literal',m['spec']))
    for m in resource_call.finditer(text): refs.append(('fileaccess',m[1]))
    return refs,omitted

def resolve(source,spec,available,resource=False):
    spec=spec.split('?',1)[0].split('#',1)[0]
    if not spec or spec.startswith(('data:','http:','https:','//','#')): return None
    if spec.startswith('.'): rel=os.path.normpath(str(PurePosixPath(source).parent/spec))
    elif spec.startswith('vs/'): rel='src/'+spec
    elif resource: rel=os.path.normpath(str(PurePosixPath(source).parent/spec))
    else: return None
    candidates=[rel]
    if rel.endswith('.js'): candidates=[rel[:-3]+'.ts',rel]
    elif not PurePosixPath(rel).suffix: candidates += [rel+'.ts',rel+'.js',rel+'/index.ts',rel+'/index.js']
    found=next((x for x in candidates if x in available and not x.endswith('.d.ts')),None)
    if found: return found
    if any((x[:-3]+'.d.ts') in available for x in candidates if x.endswith('.js')): return '@declaration-only:'+rel
    # Published CSS copies codicons from the readonly package; bind bytes explicitly.
    if rel.startswith('src/vs/base/browser/ui/codicons/codicon/'): return '@package-resource:@vscode/codicons/dist/'+PurePosixPath(rel).name
    raise RuntimeError(('unresolved internal resource/import',source,spec,candidates))

# These tests intentionally read current source, even when old emitted runtime is under test.
# Bind the exact actual path/hash; do not redirect cwd/fs or call this a raw-baseline runtime input.
source_read_inputs = []
for item in config.get('sourceReadInputs', []):
    assert item['role'] == 'current-live-source-scan-not-raw-baseline-runtime'
    assert item['excludedFromRawBaselineBusinessEvidence'] is True
    assert item['source'] in freeze and item['testSource'] in config['tests']
    path = repo / item['source']
    current = path.read_bytes()
    assert sha(current) == freeze[item['source']]
    baseline = raw(config['baseline'], item['source'])
    row = dict(item, actualPath=str(path), sha256=sha(current), bytes=len(current),
               baselineSha256=sha(baseline), phases=['old', 'new'])
    if item['assertionKind'] == 'fire-and-forget-double-catch':
        required = 'void loadConnectedComposerCatalogs(host, generation).catch(onUnexpectedError).catch(onUnexpectedError);'
        forbidden = 'void loadConnectedComposerCatalogs(host, generation);'
        samples = {}
        for label, data in [('rawBaseline', baseline), ('currentLive', current)]:
            text = data.decode()
            samples[label] = {'requiredPresent': required in text, 'forbiddenAbsent': forbidden not in text,
                              'matchedLines': [line.strip() for line in text.splitlines() if required in line]}
        assert all(v['requiredPresent'] and v['forbiddenAbsent'] for v in samples.values())
        row['readOnlyAssertionSamples'] = samples
    source_read_inputs.append(row)
if not args.baseline_only:
    declared_scans = {title for f in test_plan['files'] for title in f['sourceScanFullTitles']}
    assert declared_scans == {row['fullTitle'] for row in source_read_inputs}
    if repo.name == 'C':
        assert declared_scans == {'conversationComposerCatalog refreshComposerCatalogs loadConnectedComposerCatalogs fire-and-forget void double-catch onUnexpectedError'}

# Source roots explicitly include official renderer meta dependencies. No repository-wide transpile.
roots=config['tests']+['src/vs/base/common/errors.ts','src/vs/workbench/test/common/utils.ts']
phases={}; graphs={}; externals={}; omitted={}; package_resources={}
for phase in (['old'] if args.baseline_only else ['old','new']):
    revision=config['baseline'] if phase=='old' else config['head']
    active_frozen=set() if args.baseline_only else set(config['tests']) if phase=='old' else set(freeze)
    available=set(trees[revision])|active_frozen
    queue=deque(roots+([] if phase=='old' else config['production']))
    seen={}; edges=[]; external=[]; types=[]
    while queue:
        source=queue.popleft()
        if source in seen: continue
        data=frozen[source] if source in active_frozen else raw(revision,source)
        role='frozen-test' if source in active_frozen and source in config['tests'] else 'frozen-production' if source in active_frozen else 'raw-baseline' if phase=='old' else 'fixed-head'
        seen[source]=(data,role)
        refs=[]
        if source.endswith(('.ts','.js')):
            refs,ts=imports(data,source)
            types.extend({'source':source,'specifier':s,'reason':'explicit-type-only'} for s in ts)
        elif source.endswith('.css'):
            css=clean(data.decode())
            refs=[('css-resource',m[1] or m[2]) for m in css_url.finditer(css)]
        for kind,spec in refs:
            target=resolve(source,spec,available,resource=kind=='css-resource')
            if target and target.startswith('@declaration-only:'):
                types.append({'source':source,'specifier':spec,'reason':'declaration-only, erased TS import'})
            elif target and target.startswith('@package-resource:'):
                package_resources[target.split(':',1)[1]]='src/vs/base/browser/ui/codicons/codicon/'+PurePosixPath(target).name
                edges.append({'source':source,'target':target,'kind':kind,'specifier':spec})
            elif target:
                queue.append(target); edges.append({'source':source,'target':target,'kind':kind,'specifier':spec})
            else: external.append({'source':source,'kind':kind,'specifier':spec})
    entries=[]
    for source,(data,role) in sorted(seen.items()):
        dest=attempt/'snapshots'/phase/source
        dest.parent.mkdir(parents=True,exist_ok=True)
        with dest.open('xb') as f: f.write(data)
        out=repo/'out'/source[4:]
        if source.endswith('.ts'): out=out.with_suffix('.js')
        entries.append({'source':source,'snapshot':str(dest),'out':str(out),'sha256':sha(data),'bytes':len(data),'kind':'ts' if source.endswith('.ts') else 'resource','role':role,'baselineBlob':trees[revision].get(source) if source not in active_frozen else None})
    phases[phase]=entries; graphs[phase]=edges; externals[phase]=external; omitted[phase]=types
assert not any('universeAgentExpectedOwner' in x['source'] for x in phases['old']), 'new owner runtime forbidden in old'

# The codicons generated CSS resource is not in Git; snapshot only this exact package artifact and its URL font.
for package_path,source in list(package_resources.items()):
    resource=repo/'node_modules'/package_path
    data=resource.read_bytes()
    extra=[(package_path,data,source)]
    for match in (css_url.finditer(clean(data.decode())) if package_path.endswith('.css') else []):
        spec=match[1] or match[2]
        if spec.startswith(('data:','http:','https:')): continue
        rel=os.path.normpath(str(PurePosixPath(package_path).parent/spec))
        extra.append((rel,(repo/'node_modules'/rel).read_bytes(),'src/vs/base/browser/ui/codicons/codicon/'+PurePosixPath(spec).name))
    for pkg,data,source in extra:
        for phase in (['old'] if args.baseline_only else ['old','new']):
            dest=attempt/'snapshots'/phase/source
            dest.parent.mkdir(parents=True,exist_ok=True)
            with dest.open('xb') as f: f.write(data)
            phases[phase].append({'source':source,'snapshot':str(dest),'out':str(repo/'out'/source[4:]),'sha256':sha(data),'bytes':len(data),'kind':'resource','role':'readonly-package-resource','packagePath':str((repo/'node_modules'/pkg).resolve())})

# Static control closure (official runner and tooling); relative imports outside src are not emitted.
control_roots=['test/unit/electron/index.js','test/unit/electron/renderer.js','test/unit/electron/preload.js','test/unit/electron/renderer.html','test/unit/assert.js','test/package.json','scripts/test.sh','build/next/transpile.ts','eslint.config.js','src/tsconfig.json','src/tsconfig.base.json','package.json','package-lock.json','product.json','remote/package.json','.npmrc','remote/.npmrc','node_modules/mocha/lib/reporters/json.js','node_modules/mocha/lib/stats-collector.js']
# Bind exactly the local rule globs dynamically loaded by the two lint plugin indexes.
for directory in ['.eslint-plugin-local','extensions/copilot/.eslintplugin']:
    control_roots.extend(str(p.relative_to(repo)) for p in sorted((repo/directory).glob('*.ts')) if p.name not in ['index.ts','utils.ts'])
controls={}; control_external=[]; queue=deque(control_roots)
while queue:
    source=queue.popleft()
    if source in controls: continue
    path=repo/source
    data=path.read_bytes()
    controls[source]={'source':source,'path':str(path),'bytes':len(data),'sha256':sha(data)}
    if source.endswith(('.js','.ts')):
        refs,_=imports(data,source)
        for kind,spec in refs:
            if spec.startswith('.'):
                rel=os.path.normpath(str(PurePosixPath(source).parent/spec))
                found=next((x for x in [rel,rel+'.js',rel+'.json',rel+'.ts',rel+'/index.js'] if (repo/x).is_file()),None)
                if found: queue.append(found)
                else: control_external.append({'source':source,'specifier':spec,'reason':'dynamic/optional path, not statically resolved'})
            else: control_external.append({'source':source,'specifier':spec})

# Bind package metadata and entry candidates without executing require or relying on require.resolve.
# renderer.html eagerly probes each declared dependency; platform optional misses are recorded, not installed.
pkg=json.loads((repo/'package.json').read_text()); remote=json.loads((repo/'remote/package.json').read_text())
specs=set(pkg.get('dependencies',{}))|set(pkg.get('optionalDependencies',{}))|set(remote.get('dependencies',{}))
for rows in externals.values(): specs.update(x['specifier'] for x in rows)
specs.update(x['specifier'] for x in control_external)
specs.update(['esbuild','eslint','typescript','mocha','mocha-junit-reporter','minimist','glob','sinon/pkg/sinon-esm.js','sinon-test/dist/sinon-test-es.js','mocha/mocha.js','mocha/mocha.css','mocha/lib/reporters/json.js','mocha/lib/stats-collector.js','@typescript/native/lib/tsc.js','@typescript/native/lib/getExePath.js','@typescript/typescript-linux-x64/lib/tsc','@typescript/old','@esbuild/linux-x64/bin/esbuild','eslint/bin/eslint.js'])
packages=[]
def strings(value):
    if isinstance(value,str): return [value]
    if isinstance(value,list): return [x for v in value for x in strings(v)]
    if isinstance(value,dict): return [x for v in value.values() for x in strings(v)]
    return []
builtins=set('assert async_hooks buffer child_process cluster console constants crypto dgram diagnostics_channel dns domain events fs http http2 https inspector module net os path perf_hooks process punycode querystring readline repl stream string_decoder sys timers tls trace_events tty url util v8 vm wasi worker_threads zlib test'.split())
for spec in sorted(specs):
    if spec.startswith(('node:','vs/','.','/','data:','http:','https:')) or spec.split('/')[0] in builtins or spec=='electron' or spec.endswith('.d.ts'): continue
    bits=spec.split('/'); name='/'.join(bits[:2]) if spec.startswith('@') else bits[0]
    root=repo/'node_modules'/name; metadata=root/'package.json'
    row={'specifier':spec,'package':name,'root':str(root.resolve()),'installed':metadata.is_file(),'entryCandidates':[]}
    if metadata.is_file():
        data=metadata.read_bytes(); value=json.loads(data)
        row.update(packageJsonSha256=sha(data),packageJsonBytes=len(data),version=value.get('version'))
        candidates=set([value.get('main','index.js')])|set(strings(value.get('exports',{})))
        if spec!=name: candidates.add(spec[len(name)+1:])
        # The ESM/module alternative is also bound for the renderer import map / direct source imports.
        candidates.update(strings(value.get('module')))
        candidates.update(strings(value.get('bin')))
        candidates.update(strings(value.get('imports')))
        for relative in sorted(candidates):
            if '*' in relative: continue
            path=next((p for p in [root/relative,root/(relative+'.js'),root/(relative+'.json'),root/relative/'index.js'] if p.is_file()),None)
            if path is None: continue
            data=path.read_bytes(); row['entryCandidates'].append({'path':str(path.resolve()),'relative':relative,'sha256':sha(data),'bytes':len(data)})
    packages.append(row)

# Readonly executable/resources identities. Hash the existing Electron distribution, no cache writes.
electron=repo/'.build/electron/code-oss'
electron_root=electron.resolve().parent
electron_files=[]
for path in sorted(electron_root.rglob('*')):
    if path.is_file():
        data=path.read_bytes(); electron_files.append({'path':str(path),'bytes':len(data),'sha256':sha(data)})
executables=[]
for name in ['node','npm']:
    path=Path(shutil.which(name)).resolve(); data=path.read_bytes()
    executables.append({'name':name,'path':str(path),'bytes':len(data),'sha256':sha(data)})

# Out is inspected read-only. This is topology only, not a claim of current usable S2 output.
topology={'root':str(repo/'out'),'files':0,'bytes':0,'symlinks':[],'hardlinks':[]}
for path in [repo/'out',*(repo/'out').rglob('*')]:
    stat=path.lstat()
    if path.is_symlink(): topology['symlinks'].append(str(path))
    elif path.is_file():
        topology['files']+=1; topology['bytes']+=stat.st_size
        if stat.st_nlink>1: topology['hardlinks'].append(str(path))
assert not topology['symlinks'] and not topology['hardlinks']
old={e['source']:e for e in phases['old']}
replacements=[e for e in phases.get('new',[]) if e['source'] not in old or e['sha256']!=old[e['source']]['sha256']]
assert all(sha((repo/p).read_bytes())==h for p,h in freeze.items())
if not args.baseline_only: assert git('diff','HEAD','--','src')==source_diff
assert git('rev-parse','HEAD').decode().strip()==config['head']
manifest={'frozen':False,'candidateOnly':True,'baselineReferenceOnly':args.baseline_only,'runtimeAuthorized':False,'reviewStatus':config['reviewStatus'],'repo':str(repo),'slot':repo.name,'scratch':str(attempt),'baseline':config['baseline'],'frozenHead':config['head'],'sourceSha256':freeze,'transpileDriverSha256':sha((Path(__file__).parent/'s2-transpile.mjs').read_bytes()),'sourceDiffSha256':sha(source_diff),'sourceWipPaths':config['production']+config['tests'],'sourceReadInputs':source_read_inputs,'testPlan':test_plan,'phases':{'old':phases['old'],'new':replacements},'completeNew':phases.get('new',[]),'oldTests':config['tests'],'newTests':config['tests'],'oldGrep':None,'lintPaths':config['production']+config['tests'],'controls':list(controls.values()),'packages':packages,'electron':{'entry':str(electron),'root':str(electron_root),'files':electron_files},'executables':executables,'notes':['Candidate snapshots retained; independent final data-owner review pending. Never execute this candidate manifest.','Old: exact raw baseline closure plus same frozen tests; explicit type-only owner import erased, no S1 helper added.','New: exact fixed HEAD closure plus frozen UI/tests, no moving source dependencies.','Conservative unmarked TS imports included; runtime emission graph must be checked after authorized transpilation.','Both phases run complete selected files, with expected expanded business/source-scan/official-meta counts. The Composer source scan reads explicitly bound current source in BOTH phases; it is excluded from raw-baseline business evidence.']}
def write(name,value):
    with (attempt/name).open('x') as f: json.dump(value,f,indent=2); f.write('\n')
write('candidate-manifest.json',manifest)
write('closure.json',{'graphs':graphs,'completePhases':phases,'externals':externals,'omittedTypeOnly':omitted,'controlExternal':control_external})
write('out-topology-before.json',topology)
report={'createdUtc':datetime.now(timezone.utc).isoformat(),'slot':repo.name,'candidateOnly':True,'baselineReferenceOnly':args.baseline_only,'runtimeAuthorized':False,'oldEntries':len(phases['old']),'newEntries':len(phases.get('new',[])),'newReplacements':len(replacements),'oldKinds':{k:sum(e['kind']==k for e in phases['old']) for k in ['ts','resource']},'newKinds':{k:sum(e['kind']==k for e in phases.get('new',[])) for k in ['ts','resource']},'snapshotBytes':sum(e['bytes'] for rows in phases.values() for e in rows),'controls':len(controls),'packages':len(packages),'electronFiles':len(electron_files),'manifestSha256':sha((attempt/'candidate-manifest.json').read_bytes()),'capacity':{str(p):os.statvfs(p).f_bavail*os.statvfs(p).f_frsize for p in [repo,attempt]},'outMutated':False,'locksAcquired':False,'NodeStarted':False,'refsChanged':False}
write('assembly-report.json',report)
print(json.dumps(report))
