from pathlib import Path
import json,subprocess,sys
base=Path(__file__).resolve().parent;sys.path.insert(0,str(base.parent/'common'))
from gates import verify,read
if __name__=='__main__':
    proof=verify('J',native=False,require_launch=True);plan=read(base/'actions.template.json');assert plan['runId']==proof['runId'] and len(plan['actions'])==67
    result=subprocess.run(['rtk','proxy','python3',str(base/'run-actions.py')],input=json.dumps(plan['actions']),text=True);raise SystemExit(result.returncode)
