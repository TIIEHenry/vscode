from pathlib import Path
import os,json,hashlib,datetime
E=Path(__file__).parent;P=Path(str(E.parent)[:-7]);now=lambda:datetime.datetime.now(datetime.timezone.utc).isoformat()
patterns=['compile-client','typecheck-client','transpile-client','gulp.js','build/next/index.ts transpile','build/next/index.ts watch','watch-client','tsc --project','tsgo --project','virtual-noemit','virtual-noEmit','test/unit/electron/index.js','test/unit/node/index.js','source-checker.mjs','linter.mjs','emitter.mjs','node_modules/eslint/bin/eslint.js','build/eslint.ts']
raw=(P/'validate.py').read_bytes();line=next(x.decode() for x in raw.splitlines() if b"        patterns=['compile-client'" in x)
assert line.strip()==('patterns='+repr(patterns).replace(', ',','))
ancestors=set();pid=os.getpid()
while pid>0 and pid not in ancestors:
 ancestors.add(pid)
 try:s=(Path('/proc')/str(pid)/'stat').read_text();pid=int(s[s.rfind(')')+2:].split()[1])
 except OSError:break
matches=[];denied=[];examined=0
for q in Path('/proc').iterdir():
 if not q.name.isdigit() or int(q.name) in ancestors:continue
 try:s=(q/'stat').read_text();f=s[s.rfind(')')+2:].split();argv=[x.decode(errors='replace') for x in (q/'cmdline').read_bytes().split(b'\0') if x]
 except (OSError,IndexError) as e:
  if isinstance(e,PermissionError):denied.append(dict(pid=int(q.name),error=str(e)))
  continue
 examined+=1;hits=[x for x in patterns if x in ' '.join(argv)]
 if hits:matches.append(dict(pid=int(q.name),startTime=f[19],ppid=int(f[1]),argv=argv,matchedPatterns=hits))
x=json.loads((E/'fresh-execution-preflight.json').read_bytes());derived={}
for label in ['freshBefore','freshAfter']:
 p=x[label]['processes'];assert p['activeBuildTestAutomationMatches']==[] and not p['unreadableProcessIdentityRows']
 derived[label]=dict(sampleCapturedAtUtc=p['capturedAtUtc'],exact18SelectorMatches=[v for v in p['activeBuildTestAutomationMatches'] if any(z in ' '.join(v['argv']) for z in patterns)],broaderObservedMatches=p['activeBuildTestAutomationMatches'],allNodeElectronFamiliesRetained=len(p['allNodeElectronEsbuildXvfbRows']),notAllNodeExitGate=True)
value=dict(capturedAtUtc=now(),scope='Independent fresh read-only exact candidate global_idle selector mirror, with own collector/proven ancestors excluded. Candidate is only read as fixed bytes, never executed/imported/parsed.',candidatePath=str(P/'validate.py'),candidateBytes=len(raw),candidateSha256=hashlib.sha256(raw).hexdigest(),exactLiteralSourceLine=line,patterns=patterns,selectorCount=18,excludedOwnAncestorPids=sorted(ancestors),visibleProcessesExamined=examined,currentMatches=matches,unreadableIdentityRows=denied,exactSelectorQuietAtCurrentSample=not matches and not denied,priorSame18SelectorDerivedFromStrictSupersetSnapshots=derived,allGlobalNodeStoppedIsNotProtocolGate=True,persistentOtherNodeElectronRowsRemainAt='fresh-execution-preflight.json freshBefore/freshAfter.processes.allNodeElectronEsbuildXvfbRows',noUnknownProcessSignaled=True,noLockAcquired=True,noNodeOrDriverInvoked=True)
b=(json.dumps(value,ensure_ascii=False,indent=2)+'\n').encode()
with (E/'exact-global-idle-selector.json').open('xb') as f:f.write(b);f.flush();os.fchmod(f.fileno(),0o444);os.fsync(f.fileno())
print(json.dumps(dict(selectorCount=18,actualMatches=len(matches),unreadable=len(denied),quiet=value['exactSelectorQuietAtCurrentSample'],reportSha256=hashlib.sha256(b).hexdigest())))
