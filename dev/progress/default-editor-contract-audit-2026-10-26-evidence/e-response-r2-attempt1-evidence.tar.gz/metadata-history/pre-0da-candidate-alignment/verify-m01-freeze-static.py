"""Read-only static rearm verification. Never imports launchers or reads/runs native out."""
from pathlib import Path
import ast, hashlib, json, os, re, subprocess
base=Path(__file__).resolve().parent
jbase=base.parent/'d1387-m01-after-20261027-r2'
oldj=base.parent/'d1387-after-sources-audit-20261026'
olde=base.parent/'e-response-after-preparation-20261027'
backup=olde/'m01-static-preparation-originals'
runid='sources-m01-after-20261027-r2'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
contract=json.loads((base/'final-freeze-contract.json').read_text())
legacy=json.loads((backup/'E-final-freeze-contract.json').read_text())
assert contract['schemaVersion']==2 and contract['runId']==runid and contract['minimumUnionAssets']==53
assert contract['fixedExternalBaselineCommit']==legacy['fixedExternalBaselineCommit']=='d91a7a8d361cff7c12e7717dfc7c5ab2e3d41f42'
for key in ['originalJ18','originalE16','hashEvidence','runtimeEvidence','fakeTransportScope','fakeRpcSurface']:
    assert contract[key]==legacy[key],key
assert len(contract['originalJ18'])==18 and len(contract['originalE16'])==16
assert contract['mandatoryAdditions'][:18]==legacy['mandatoryAdditions'] and len(contract['mandatoryAdditions'])==19
m01={'out/vs/workbench/contrib/sources/browser/'+n+'.js' for n in ['sourcesDiffRefHelpers','sourcesDiffActions','conversationDiffReviewPane']}
assert {x['path']for x in contract['mandatoryM01Production']}==m01
required=set(contract['originalJ18'])|set(contract['originalE16'])|{x['path']for x in contract['mandatoryAdditions']}|m01
old_union=set(legacy['originalJ18'])|set(legacy['originalE16'])|{x['path']for x in legacy['mandatoryAdditions']}
assert len(old_union)==52 and len(required)==53 and required-old_union=={'out/vs/workbench/contrib/sources/browser/sourcesDiffRefHelpers.js'}
templates=[jbase/'fresh-notice.template.json',base/'e-final-freeze.template.json']
for p in templates:
    n=json.loads(p.read_text());assert n['runId']==runid and n['outFrozen']is False and n['freezeSchemaVersion']==2 and n['minimumUnionAssets']==53
    assert len(n['outputs'])==53 and {x['path']for x in n['outputs']}==required
    assert set(n['mandatoryM01Production'])==m01
    assert n['fixedExternalBaselineCommit']==contract['fixedExternalBaselineCommit']
    for x in n['outputs']:
        native=x['path'];assert native.startswith('out/vs/') and '..'not in native and native.endswith(('.js','.css'))
        source='src/'+native[4:];source=source[:-3]+'.ts'if source.endswith('.js')else source
        assert x['sourcePath']==source and x['sha256']=='REQUIRED native SHA-256'and x['sourceSha256']=='REQUIRED source SHA-256'
# Pure-set negative schema controls: every M01 member and the legacy52 union is insufficient.
for absent in m01:assert not required.issubset(required-{absent})
assert not required.issubset(old_union)
for row in json.loads((backup/'inventory.json').read_text()):assert sha(Path(row['path']))==row['sha256'],row['path']
assert sha(oldj/'fresh-notice.json')=='44372cedc1f7ad94fc335cf0fa89c99961b39aa6fbcaed7a087a2179b410c114'
assert sha(olde/'e-final-freeze.json')=='54bddec4715d26d37dc13feaea58dc1b633d1aec8845142e99e584e68d7829ee'
partial=jbase.parents[1]/'dev/progress/default-editor-contract-audit-2026-10-26-evidence/d1387-j-partial-after-evidence.tar.gz'
assert sha(partial)=='17e6b62b91bd493d5c021924eb8c255d8585baba16c7c050134d6a6c656e75f4'
jm=json.loads((jbase/'matrix.json').read_text());em=json.loads((base/'matrix.json').read_text())
assert jm['runId']==em['runId']==runid and len(jm['cases'])==18 and all(x['status']=='NOT_RUN'for x in jm['cases'])
assert len(em['cases'])==9 and all(x['state']=='NOT_RUN'for x in em['cases'])and em['runState']=='NOT_RUN'and em['onlineBackend']is False
route=json.loads((base/'phase-route.json').read_text());home=Path(route['engineHome']);st=home.lstat()
assert route['runId']==runid and home.is_dir()and not home.is_symlink()and st.st_uid==os.getuid()and st.st_mode&0o777==0o700 and not list(home.iterdir())
for root,names in [(jbase,['fresh-notice.json','launch.json','lease.json','loaded-manifest.json','j-phase-complete.json','runtime-assets-J.json']),(base,['e-final-freeze.json','e-phase-authorization.json','j-phase-complete.json','server-started.json','fake-io.jsonl','frozen-asset-check.json','runtime-assets-J.json','runtime-assets-E.json'])]:
    assert all(not(root/name).exists()for name in names)
pyfiles=sorted(jbase.glob('*.py'))+sorted(base.glob('*.py'))
for p in pyfiles:ast.parse(p.read_text(),filename=str(p))
jsonfiles=sorted(jbase.rglob('*.json'))+sorted(base.glob('*.json'))+[jbase/'after.code-workspace']
for p in jsonfiles:json.loads(p.read_text())
server=(base/'fake-uds-engine.cjs').read_text();readiness=(jbase/'readiness.py').read_text();launch=(jbase/'launch.py').read_text();collector=(base/'collect-runtime-assets.cjs').read_text();loaded=(jbase/'collect-loaded.cjs').read_text();driver=(jbase/'driver.cjs').read_text();probe=(jbase/'probe.cjs').read_text()
methods=next(x for x in server.splitlines()if x.startswith('const methods = '));pairs=[list(x)for x in re.findall(r"(?:unary|add)\('([^']+)', '([^']+)'",server)]
assert methods==legacy['fakeRpcSurface']['methodsDeclaration']and pairs==legacy['fakeRpcSurface']['registrationPairs']and len(pairs)==13
old_server=(backup/'E-fake-uds-engine.cjs').read_text()
normalize=lambda text:text[text.index('const sessionId ='):].replace('{ runId: contract.runId, freezeNoticeSha256, frozenOutputsSha256, createdBy:', '{ createdBy:')
assert normalize(server)==normalize(old_server),'Fake transport/handler body changed beyond run metadata'
assert not any(x in methods or any(x in '.'.join(p)for p in pairs)for x in ['AgentService.*','GetQueue','SaveSkillContent'])
for gate in ["readJson('e-final-freeze.json')","readJson('e-phase-authorization.json')","readJson('j-phase-complete.json')","assert.equal(j.zeroEngineRpc, true)","assert.equal(j.m01ActualButtonPassed, true)","assert.equal(j.allRequiredCasesPassed, true)","assert.equal(j.freezeNoticeSha256, jFreezeNoticeSha256)","assert.equal(phase.frozenOutputsSha256, frozenOutputsSha256)"]:
    assert gate in server and server.index(gate)<server.index('const grpc =')<server.index('server.bindAsync(')
for text in [readiness,server,collector]:assert 'mandatoryM01Production'in text and '53'in text
assert "contract['mandatoryAdditions']"in readiness and 'contract.mandatoryAdditions'in server
assert "'sourceSha256'"in readiness and 'file.sourceSha256'in server
assert "runtimeEvidenceStatus': 'manifest-only'"in readiness and "runtimeEvidenceStatus: 'manifest-only'"in server
assert 'Debugger.getScriptSource'in collector and 'CSS.getStyleSheetText'in collector and 'Actual connected DOM stylesheet'in collector and 'No main-process inspector collection performed'in collector
assert 'm01Required'in collector and 'const requiredRenderer'in collector and 'const m01Core'in loaded and '...originalCore,...m01Core'in loaded
for n in ['sourcesDiffRefHelpers','sourcesDiffActions','conversationDiffReviewPane']:assert n in loaded
assert launch.index('proof = verify()')<launch.index('engine_route =')<launch.index('subprocess.Popen')and 'UNIVERSE_AGENT_HOME=str(engine_home)'in launch
for x in ['runId','freezeNoticeSha256','frozenOutputsSha256']:assert x in launch and x in driver and x in probe and x in server and x in collector
assert "action.type==='conversationPreviewButton'"in driver and "getByRole('button',{name:'Open Diff in Preview',exact:true}).click()"in driver
assert "keyboard target mismatch"in driver and "button.sources-tab"in driver and "aria-activedescendant"in driver
assert 'containsExactEditor'in driver and 'sameActivePane'in driver and 'serializationError'in driver
# Syntax only: Node --check parses our controllers without executing require/import or any out asset.
cjsfiles=[jbase/'probe.cjs',jbase/'driver.cjs',jbase/'collect-loaded.cjs',base/'fake-uds-engine.cjs',base/'collect-runtime-assets.cjs']
syntax=[]
for p in cjsfiles:
    r=subprocess.run(['rtk','proxy','node','--check',str(p)],capture_output=True,text=True);assert r.returncode==0,r.stderr;syntax.append({'path':str(p),'exitCode':r.returncode,'sha256':sha(p)})
paths=[*templates,base/'final-freeze-contract.json',jbase/'readiness.py',base/'fake-uds-engine.cjs',base/'collect-runtime-assets.cjs',jbase/'collect-loaded.cjs',jbase/'driver.cjs',jbase/'launch.py',base/'phase-route.json']
proof={'runId':runid,'state':'STATIC_REARM_ONLY_NOT_AUTHORIZED','schemaVersion':2,'originalJPreserved':18,'originalEPreserved':16,'originalAdditionsPreserved':18,'newHelper':sorted(required-old_union),'mandatoryM01Production':sorted(m01),'jRequiredAssets':53,'eRequiredAssets':53,'unionAssets':53,'pythonAst':'PASS','pythonAstFileCount':len(pyfiles),'jsonParse':'PASS','jsonInputCount':len(jsonfiles),'cjsSyntaxOnly':syntax,'negativeMandatorySetChecks':4,'oldPreparatoryFilesRestored':True,'oldNoticesAndPartialArchiveByteExact':True,'engineHome':str(home),'engineHomeMode':oct(st.st_mode&0o777),'engineHomeEmpty':True,'actualNewNoticesOrPhaseGatesPresent':False,'fakeAdvertisements':12,'fakeHandlerPairs':13,'fakeSurfaceUnchanged':True,'businessOrServerOrUiExecuted':False,'nativeOutputsRead':False,'productOrOutTouched':False,'staticFiles':[{'path':str(p.resolve()),'sha256':sha(p)}for p in paths]}
(base/'m01-static-verification.json').write_text(json.dumps(proof,indent=2)+'\n')
print(json.dumps({k:v for k,v in proof.items()if k not in ['staticFiles','cjsSyntaxOnly']}))
