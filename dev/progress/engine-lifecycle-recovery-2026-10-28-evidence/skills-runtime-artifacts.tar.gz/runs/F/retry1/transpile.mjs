import fs from 'node:fs';
import path from 'node:path';
import {pathToFileURL} from 'node:url';
const m=JSON.parse(fs.readFileSync(process.argv[2],'utf8'));
const {transpileFile,mapWithConcurrency}=await import(pathToFileURL(m.root+'/build/next/transpile.ts').href);
const mode=process.argv[3];
const entries=mode==='old'?m.entries:m.entries.filter(x=>x.source===m.production).map(x=>({...x,snapshot:m.scratch+'/new/'+x.source}));
await mapWithConcurrency(entries,16,async x=>{
 if(!x.out.startsWith(m.root+'/out/'))throw Error('nonprivate output');
 let st;try{st=fs.lstatSync(x.out);}catch(e){if(e.code!=='ENOENT')throw e;}
 if(st&&(st.isSymbolicLink()||st.nlink>1))throw Error('shared output inode');
 if(x.kind==='ts')await transpileFile(x.snapshot,x.out);
 else{fs.mkdirSync(path.dirname(x.out),{recursive:true});fs.copyFileSync(x.snapshot,x.out);}
});
console.log(JSON.stringify({mode,refreshed:entries.length}));
