/*---------------------------------------------------------------------------------------------
 *  Copyright (c) Microsoft Corporation. All rights reserved.
 *  Licensed under the MIT License. See License.txt in the project root for license information.
 *--------------------------------------------------------------------------------------------*/

import assert from 'assert';
import * as fs from 'fs';
import { fileURLToPath } from 'url';
import { Emitter, Event } from '../../../../base/common/event.js';
import { isCancellationError } from '../../../../base/common/errors.js';
import { DisposableStore } from '../../../../base/common/lifecycle.js';
import { MarshalledId } from '../../../../base/common/marshallingIds.js';
import * as path from '../../../../base/common/path.js';
import { ProxyChannel, type IChannel } from '../../../../base/parts/ipc/common/ipc.js';
import { ensureNoDisposablesAreLeakedInTestSuite } from '../../../../base/test/common/utils.js';
import { universeAgentHubChannelName } from '../../common/hub.js';
import { universeAgentConnectionChannelName } from '../../common/universeAgentConnection.js';
import { UniverseAgentConnectionChannelClient } from '../../common/universeAgentConnectionChannelClient.js';
import { UniverseAgentConnectionIpcChannel, UniverseAgentHubIpcChannel } from '../../common/universeAgentConnectionIpcChannel.js';
import {
	navigatorTeamInfoCommand,
	navigatorTeamMemberStatusCommand,
	navigatorTeamTaskListCommand,
} from '../../common/universeAgentNavigatorTeamIpc.js';

const thisDir = path.dirname(fileURLToPath(import.meta.url));
const REPO_ROOT = path.join(thisDir, '../../../../../../');

class FakeWindowService {
	readonly forwarded: string[] = [];
	readonly teamCalls: unknown[][] = [];
	onDidChangeConnection = Event.None;
	onDidChangeAuthStatus = Event.None;
	onRequestAgentTreeRefresh = Event.None;
	onDidFileMutation = Event.None;

	getConnectionSnapshot() {
		return { pairingPending: false };
	}

	readonly team = {
		memberStatus: (sessionId: string, agentId: string) => {
			this.teamCalls.push(['memberStatus', sessionId, agentId]);
			return Promise.resolve([{
				memberAgentId: 'm',
				memberName: 'M',
				status: 'IDLE',
				preset: '',
				dynamic: '',
				turnCount: 0,
			}]);
		},
		taskList: (sessionId: string, agentId: string) => {
			this.teamCalls.push(['taskList', sessionId, agentId]);
			return Promise.resolve([]);
		},
		teamInfo: (sessionId: string, agentId: string, teamId: number) => {
			this.teamCalls.push(['teamInfo', sessionId, agentId, teamId]);
			return Promise.resolve({ teamId, status: 'READY' });
		},
	};

	disconnect(): Promise<void> {
		this.forwarded.push('disconnect');
		return Promise.resolve();
	}

	isEngineConnected(): boolean {
		this.forwarded.push('isEngineConnected');
		return false;
	}

	probeEngine(): Promise<{ readonly ok: false; readonly reason: string }> {
		this.forwarded.push('probeEngine');
		return Promise.resolve({ ok: false, reason: 'x' });
	}

	connect(): Promise<void> {
		this.forwarded.push('connect');
		return Promise.resolve();
	}

	openChatStream(): { dispose(): void } {
		this.forwarded.push('openChatStream');
		return { dispose() { } };
	}

	openPtyStream(): { dispose(): void } {
		this.forwarded.push('openPtyStream');
		return { dispose() { } };
	}

	fetchAgentTree(): Promise<undefined> {
		this.forwarded.push('fetchAgentTree');
		return Promise.resolve(undefined);
	}

	notifyFileMutation(): void {
		this.forwarded.push('notifyFileMutation');
	}

	dispose(): void {
		this.forwarded.push('dispose');
	}

	login(): Promise<{ readonly ok: true }> {
		this.forwarded.push('login');
		return Promise.resolve({ ok: true });
	}

	_leakSecret(): string {
		this.forwarded.push('_leakSecret');
		return 'secret';
	}
}

function assertMethodNotFound(error: unknown, command: string): boolean {
	return error instanceof Error && error.message === `Method not found: ${command}`;
}

suite('UniverseAgentConnectionIpcChannel', () => {

	const store = ensureNoDisposablesAreLeakedInTestSuite();

	test('session tool profile and engine trigger requests cross the explicit IPC allowlist unchanged', async () => {
		const calls: unknown[] = [];
		const service = {
			team: new FakeWindowService().team,
			getConnectionSnapshot: () => ({ pairingPending: false }),
			isEngineConnected: () => false,
			setClientToolProfile: async (request: unknown) => { calls.push(request); return { ok: false, error: 'missing' }; },
			registerSessionEngineTrigger: async (request: unknown) => { calls.push(request); return { trigger: { triggerId: 't' } }; },
		};
		const inner = ProxyChannel.fromService<string>(service, store.add(new DisposableStore()));
		const channel = new UniverseAgentConnectionIpcChannel(service, inner);
		const profile = { sessionId: 's', profile: 'CLIENT_TOOL_PROFILE_NONE' };
		const trigger = { sessionId: 's', name: 'Watch', type: 'file_changed', promptTemplate: 'Changed', watchPaths: ['src'], dedupeKeyField: '' };
		assert.deepStrictEqual(await channel.call('ctx', 'setClientToolProfile', [profile]), { ok: false, error: 'missing' });
		assert.deepStrictEqual(await channel.call('ctx', 'registerSessionEngineTrigger', [trigger]), { trigger: { triggerId: 't' } });
		assert.deepStrictEqual(calls, [profile, trigger]);
	});

	test('GetQueue crosses desktop client and host allowlist without losing version precision', async () => {
		const calls: string[] = [];
		const state = { items: [], isPaused: false, isProcessing: false, pauseReason: 'NONE', version: '9007199254740993' };
		const service = { team: new FakeWindowService().team, getConnectionSnapshot: () => ({ pairingPending: false }), isEngineConnected: () => false, getQueue: async (request: { sessionId: string }) => { calls.push(request.sessionId); return state; } };
		const inner = ProxyChannel.fromService<string>(service, store.add(new DisposableStore()));
		const channel = new UniverseAgentConnectionIpcChannel(service, inner);
		const client = store.add(new UniverseAgentConnectionChannelClient({ call: (command, arg) => channel.call('ctx', command, arg), listen: () => Event.None }));
		assert.deepStrictEqual(await client.getQueue?.({ sessionId: 'actual' }), state);
		assert.deepStrictEqual(calls, ['actual']);
	});

	function open() {
		const disposables = store.add(new DisposableStore());
		const service = new FakeWindowService();
		const connectionEmitter = disposables.add(new Emitter<string>());
		const authEmitter = disposables.add(new Emitter<string>());
		service.onDidChangeConnection = connectionEmitter.event;
		service.onDidChangeAuthStatus = authEmitter.event;
		const inner = ProxyChannel.fromService<string>(service, disposables);
		const connection = new UniverseAgentConnectionIpcChannel(service, inner);
		const hub = new UniverseAgentHubIpcChannel(inner);
		return { service, connection, hub, connectionEmitter, authEmitter };
	}

	const strictMethods = [
		['upsertProviderCredentials', 1], ['clearProviderCredentials', 1],
		['upsertModel', 1], ['deleteModel', 1], ['setModelEnabled', 1],
		['testModelProfile', 1], ['importHarnessProviders', 1],
		['listProviderStatus', 0], ['listModels', 0],
		['setSkillEnabled', 1], ['saveSkillContent', 1], ['listSkills', 0], ['getSkillInfo', 1],
	] as const;
	const currentOwner = { engineIdentityId: 'engine-b', linkId: 2 };

	for (const [command, ownerIndex] of strictMethods) {
		test(`expected owner IPC gate: ${command} rejects missing malformed and stale owners before inner dispatch`, async () => {
			const forwarded: unknown[] = [];
			let connected = true;
			let pairingPending = false;
			const channel = new UniverseAgentConnectionIpcChannel({
				team: new FakeWindowService().team,
				getConnectionSnapshot: () => ({ ...currentOwner, pairingPending }),
				isEngineConnected: () => connected,
			}, {
				call: async <T>(_ctx: string, _command: string, args?: unknown): Promise<T> => { forwarded.push(args); return undefined as T; },
				listen: () => Event.None,
			});
			const invalidOwners: unknown[] = [
				undefined, null, {}, [],
				{ engineIdentityId: '', linkId: 2 }, { engineIdentityId: 'engine-b', linkId: 0 },
				{ engineIdentityId: 'engine-b', linkId: 1.5 }, { engineIdentityId: 'engine-b', linkId: Number.MAX_SAFE_INTEGER + 1 },
				{ engineIdentityId: 'engine-a', linkId: 1 }, { engineIdentityId: 'engine-b', linkId: 1 },
				{ $mid: MarshalledId.Regexp, source: '[', flags: '' },
				{ ...currentOwner, $mid: MarshalledId.Regexp, source: '[', flags: '' },
			];
			const cancelled: boolean[] = [];
			for (const owner of invalidOwners) {
				const args = ownerIndex === 0 ? [owner] : [{ business: 'unchanged' }, owner];
				const error = await Promise.resolve().then(() => channel.call('ctx', command, args)).then(() => undefined, error => error);
				cancelled.push(isCancellationError(error));
			}
			for (const state of ['disconnected', 'pairing'] as const) {
				connected = state !== 'disconnected';
				pairingPending = state === 'pairing';
				const args = ownerIndex === 0 ? [currentOwner] : [{ business: 'unchanged' }, currentOwner];
				const error = await Promise.resolve().then(() => channel.call('ctx', command, args)).then(() => undefined, error => error);
				cancelled.push(isCancellationError(error));
			}
			assert.deepStrictEqual({ forwarded, cancelled }, { forwarded: [], cancelled: Array(invalidOwners.length + 2).fill(true) });
			connected = true;
			pairingPending = false;
			const validArgs = ownerIndex === 0 ? [currentOwner] : [{ business: 'unchanged' }, currentOwner];
			await channel.call('ctx', command, validArgs);
			assert.deepStrictEqual(forwarded, [validArgs]);
		});
	}

	test('expected owner IPC gate: missing owner wins over malformed business marshalling', async () => {
		let dispatches = 0;
		const service = {
			team: new FakeWindowService().team,
			getConnectionSnapshot: () => ({ ...currentOwner, pairingPending: false }),
			isEngineConnected: () => true,
			saveSkillContent: async () => { dispatches++; return { ok: true }; },
		};
		const inner = ProxyChannel.fromService<string>(service, store.add(new DisposableStore()));
		const channel = new UniverseAgentConnectionIpcChannel(service, inner);
		const malformedRequest = { $mid: MarshalledId.Regexp, source: '[', flags: '' };
		const error = await Promise.resolve().then(() => channel.call('ctx', 'saveSkillContent', [malformedRequest])).then(() => undefined, error => error);
		assert.deepStrictEqual({ cancelled: isCancellationError(error), dispatches }, { cancelled: true, dispatches: 0 });
	});

	test('allowlist forwards unary calls and blocks host, connect, streams, and extras', async () => {
		const { service, connection } = open();
		await connection.call('ctx', 'disconnect');
		assert.strictEqual(await connection.call('ctx', 'isEngineConnected'), false);
		assert.deepStrictEqual(await connection.call('ctx', 'probeEngine'), { ok: false, reason: 'x' });
		for (const command of ['notifyFileMutation', 'fetchAgentTree', 'connect', 'openChatStream', 'openPtyStream', 'dispose', '_leakSecret', 'login']) {
			assert.throws(
				() => connection.call('ctx', command, [{}]),
				(error: unknown) => assertMethodNotFound(error, command),
			);
		}
		assert.deepStrictEqual(service.forwarded, ['disconnect', 'isEngineConnected', 'probeEngine']);
	});

	test('connection events pass and the host refresh event does not', async () => {
		const { connection, connectionEmitter } = open();
		const heard: string[] = [];
		store.add(connection.listen<string>('ctx', 'onDidChangeConnection')(value => heard.push(value)));
		connectionEmitter.fire('snap');
		// ProxyChannel buffers events and flushes on a timeout after the first listener.
		await new Promise<void>(resolve => setTimeout(resolve, 0));
		assert.deepStrictEqual(heard, ['snap']);
		assert.throws(
			() => connection.listen('ctx', 'onRequestAgentTreeRefresh'),
			(error: unknown) => error instanceof Error && error.message === 'Event not found: onRequestAgentTreeRefresh',
		);
	});

	test('team commands hit the nested object and reject a bad team id', async () => {
		const { service, connection } = open();
		const members = await connection.call('ctx', navigatorTeamMemberStatusCommand, ['sess', 'agent']);
		assert.strictEqual((members as { memberAgentId: string }[])[0].memberAgentId, 'm');
		await connection.call('ctx', navigatorTeamTaskListCommand, ['sess', 'agent']);
		const info = await connection.call<{ teamId: number }>('ctx', navigatorTeamInfoCommand, ['sess', 'agent', 4]);
		assert.strictEqual(info.teamId, 4);
		await connection.call('ctx', navigatorTeamMemberStatusCommand, undefined);
		assert.throws(
			() => connection.call('ctx', navigatorTeamInfoCommand, ['sess', 'agent', 'nope']),
			(error: unknown) => error instanceof Error && error.message === 'Invalid team id',
		);
		assert.deepStrictEqual(service.teamCalls, [
			['memberStatus', 'sess', 'agent'],
			['taskList', 'sess', 'agent'],
			['teamInfo', 'sess', 'agent', 4],
			['memberStatus', '', ''],
		]);
	});

	test('hub channel forwards hub calls only', async () => {
		const { service, hub, authEmitter } = open();
		assert.deepStrictEqual(await hub.call('ctx', 'login', ['https://hub.example', 'a@b.c', 'pw']), { ok: true });
		assert.throws(
			() => hub.call('ctx', 'notifyFileMutation', [{}]),
			(error: unknown) => assertMethodNotFound(error, 'notifyFileMutation'),
		);
		assert.throws(
			() => hub.listen('ctx', 'onDidFileMutation'),
			(error: unknown) => error instanceof Error && error.message === 'Event not found: onDidFileMutation',
		);
		const heard: string[] = [];
		store.add(hub.listen<string>('ctx', 'onDidChangeAuthStatus')(value => heard.push(value)));
		authEmitter.fire('signed-in');
		await new Promise<void>(resolve => setTimeout(resolve, 0));
		assert.deepStrictEqual(heard, ['signed-in']);
		assert.deepStrictEqual(service.forwarded, ['login']);
	});

	test('desktop client team is an object of unary IPC calls', async () => {
		const calls: Array<{ command: string; arg: unknown }> = [];
		const ipc: IChannel = {
			call: <T>(command: string, arg?: unknown) => {
				calls.push({ command, arg });
				if (command === navigatorTeamMemberStatusCommand) {
					return Promise.resolve([] as T);
				}
				if (command === navigatorTeamTaskListCommand) {
					return Promise.resolve([] as T);
				}
				if (command === navigatorTeamInfoCommand) {
					return Promise.resolve({ teamId: 3, status: 'READY' } as T);
				}
				return Promise.reject(new Error(`unexpected ${command}`));
			},
			listen: () => Event.None,
		};
		const client = store.add(new UniverseAgentConnectionChannelClient(ipc));
		assert.strictEqual(typeof client.team, 'object');
		assert.strictEqual(typeof client.team.memberStatus, 'function');
		assert.deepStrictEqual(await client.team.memberStatus('sess', 'mgr'), []);
		assert.deepStrictEqual(await client.team.taskList('sess', 'mgr'), []);
		assert.deepStrictEqual(await client.team.teamInfo('sess', 'mgr', 3), { teamId: 3, status: 'READY' });
		assert.deepStrictEqual(calls.filter(call => call.command.startsWith('navigatorTeam')), [
			{ command: navigatorTeamMemberStatusCommand, arg: ['sess', 'mgr'] },
			{ command: navigatorTeamTaskListCommand, arg: ['sess', 'mgr'] },
			{ command: navigatorTeamInfoCommand, arg: ['sess', 'mgr', 3] },
		]);
	});

	test('registration source keeps the allowlist, hub name, and host token', () => {
		const app = fs.readFileSync(path.join(REPO_ROOT, 'src/vs/code/electron-main/app.ts'), 'utf8');
		const hub = fs.readFileSync(path.join(REPO_ROOT, 'src/vs/platform/universeAgent/common/hub.ts'), 'utf8');
		const sessionView = fs.readFileSync(path.join(REPO_ROOT, 'src/vs/platform/universeAgent/electron-main/universeAgentSessionViewService.ts'), 'utf8');
		assert.strictEqual(universeAgentHubChannelName, 'universeAgentHub');
		assert.notStrictEqual(universeAgentHubChannelName, universeAgentConnectionChannelName);
		assert.ok(app.includes('new UniverseAgentConnectionIpcChannel(universeAgentConnection, universeAgentInnerChannel)'));
		assert.ok(app.includes('registerChannel(universeAgentConnectionChannelName, universeAgentConnectionChannel)'));
		assert.ok(app.includes('new UniverseAgentHubIpcChannel(universeAgentInnerChannel)'));
		assert.ok(app.includes('registerChannel(universeAgentHubChannelName, universeAgentHubChannel)'));
		assert.ok(app.includes('services.set(IUniverseAgentHostConnection, new SyncDescriptor(UniverseAgentHostConnectionAdapter, undefined, false /* main-only host token */));'));
		assert.ok(!app.includes('registerChannel(universeAgentConnectionChannelName, ProxyChannel'));
		assert.ok(hub.includes("export const universeAgentHubChannelName = 'universeAgentHub';"));
		assert.ok(sessionView.includes('@IUniverseAgentHostConnection hostConnection: IUniverseAgentHostConnection'));
		assert.ok(!sessionView.includes('as unknown as'));
	});
});
