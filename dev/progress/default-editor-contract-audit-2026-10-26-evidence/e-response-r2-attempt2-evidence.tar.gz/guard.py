from pathlib import Path
import json, hashlib, subprocess, datetime, sys
base = Path(__file__).resolve().parent
repo = Path('/home/clarence/Projects/Agents/vscode-WorkTrees/merge')
sha = lambda value: hashlib.sha256(value).hexdigest()
freeze = json.loads((base/'full163-freeze.json').read_text())
auth = json.loads((base/'e-attempt2-authorization.json').read_text())
assert sha((base/'full163-freeze.json').read_bytes()) == auth['full163FreezeSha256']
def git(*args):
    return subprocess.run(['rtk','proxy','git',*args],cwd=repo,capture_output=True,check=True).stdout
assert git('rev-parse','HEAD:src').decode().strip() == auth['sourceTree']
assert not git('status','--porcelain','--','src').strip()
files = []
for item in freeze['outputs']:
    native = sha((repo/item['path']).read_bytes())
    source = sha((repo/item['sourcePath']).read_bytes())
    frozen = sha(git('show',auth['sourceHead']+':'+item['sourcePath']))
    assert native == item['sha256'] and source == frozen == item['sourceSha256'], item['path']
    files.append({'path':item['path'],'nativeSha256':native,'sourcePath':item['sourcePath'],'filesystemSourceSha256':source,'frozenGitSourceSha256':frozen,'matches':True})
jbase = base.parent/'d1387-m01-after-20261027-r2'
assert sha((jbase/'j-phase-complete.json').read_bytes()) == auth['jPhaseCompleteSha256']
assert sha((jbase/'J-evidence-sealed.tar.gz').read_bytes()) == '19a06c98431ae7a1c8aa04ce556a7695d40ca32ed17c5f445b7aa5115665cd80'
record = {'attempt':2,'runId':auth['runId'],'at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'sourceHead':auth['sourceHead'],'sourceTree':auth['sourceTree'],'currentDocsHead':git('rev-parse','HEAD').decode().strip(),'full163FreezeRawSha256':sha((base/'full163-freeze.json').read_bytes()),'all163SourceAndNativeAndFrozenGitSourceMatch':True,'jCompletionAndArchivePreserved':True,'files':files}
(base/('full163-guard-'+(sys.argv[1] if len(sys.argv)>1 else 'before')+'.json')).write_text(json.dumps(record,indent=2)+'\n')
print(json.dumps({'full163':len(files),'allMatch':True,'currentDocsHead':record['currentDocsHead']}))
