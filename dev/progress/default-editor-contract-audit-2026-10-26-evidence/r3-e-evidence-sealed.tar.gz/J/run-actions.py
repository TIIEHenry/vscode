from pathlib import Path
import json,subprocess,sys,time
base=Path(__file__).resolve().parent;sys.path.insert(0,str(base.parent/'common'))
from gates import verify,read
proof=verify('J',native=False,require_launch=True);fixture=Path(read(base/'fixture.json')['fixture']);last=None
for template in json.load(sys.stdin):
    action=dict(template);label=action['label'];assert not (base/'steps'/(label+'.json')).exists(),'Never overwrite actual evidence'
    if 'target' in action:action['target']=action['target'].replace('@FIXTURE_URI',fixture.as_uri())
    role=action.pop('groupRole',None)
    if role:
        assert last is not None
        if role=='alphaComparison':
            part=next(p for p in last['conversationParts'] if p['sessionKey']=='untitled');action['group']=next(g['id'] for g in part['groups'] if any(e.get('modified')==(fixture/'alpha/shared.txt').as_uri() for e in g['editors']))
        elif role=='previewComparison':action['group']=next(g['id'] for g in last['mainGroups'] if any(e.get('modified','').startswith(fixture.as_uri()+'/') for e in g['editors']))
        else:raise RuntimeError('Unknown runtime group role')
    started=time.time();r=subprocess.run(['rtk','proxy','node',str(base/'driver.cjs'),json.dumps(action)],capture_output=True,text=True)
    (base/'steps').mkdir(exist_ok=True);(base/'steps'/(label+'.driver.log')).write_text(r.stdout+'\n'+r.stderr)
    with (base/'action-execution.jsonl').open('a') as f:f.write(json.dumps({'template':template,'action':action,'exitCode':r.returncode,'elapsed':time.time()-started})+'\n')
    if r.returncode:print(json.dumps({'FAILED':label,'stdout':r.stdout,'stderr':r.stderr}));raise SystemExit(r.returncode)
    last=read(base/'steps'/(label+'.json'))['state'];assert not last['connected'] and last['connection']['phase']['kind']=='disconnected' and last['connection']['transport']=='idle' and last['connection']['channelAlive'] is False and not last['connectionEvents'],'J zero-engine isolation failed'
    print(json.dumps({'label':label,'runId':last['runId'],'engineConnected':last['connected'],'uiErrors':last['uiErrors']}),flush=True)
