'use strict';

// Temporary, explicitly fake transport I/O. This file never replaces product
// services. The actual editor/roster/lease/IPC/main SessionViewHost stay real.
// Prepared 2026-10-27; NOT_RUN until all three gate files are supplied.
const fs = require('node:fs');
const path = require('node:path');
const crypto = require('node:crypto');
const { createRequire } = require('node:module');
const { spawnSync } = require('node:child_process');
const assert = require('node:assert/strict');
const base = __dirname;
const repo = '/home/clarence/Projects/Agents/vscode-WorkTrees/merge';
const owner = '/root/sources_audit';
const readJson = name => JSON.parse(fs.readFileSync(path.join(base, name), 'utf8'));
const route = readJson('phase-route.json');
const freeze = readJson('e-final-freeze.json');
const phase = readJson('e-attempt2-authorization.json');
assert.equal(phase.attempt, 2);
assert.equal(phase.originalEAuthorizationSha256, crypto.createHash('sha256').update(fs.readFileSync(path.join(base, 'e-phase-authorization.json'))).digest('hex'));
const j = readJson('j-phase-complete.json');
assert.equal(route.createdBy, owner);
assert.equal(freeze.phase, 'E-after-production-frozen');
assert.equal(freeze.reportedBy, '/root/baseline_executor');
assert.equal(freeze.consumer, owner);
assert.equal(freeze.outFrozen, true);
assert.match(freeze.sourceHead, /^[0-9a-f]{40}$/);
assert.equal(phase.authorizedBy, '/root');
assert.equal(phase.phase, 'E-after');
assert.equal(phase.allowControlledFakeUds, true);
assert.equal(phase.sourceHead, freeze.sourceHead);
assert.equal(j.createdBy, owner);
assert.equal(j.phase, 'D1387-real-after-complete');
assert.equal(j.completed, true);
assert.equal(j.zeroEngineRpc, true);
assert.equal(j.sourceHead, freeze.sourceHead);
const git = args => {
  const r = spawnSync('rtk', ['proxy', 'git', ...args], { cwd: repo, encoding: 'utf8' });
  assert.equal(r.status, 0, r.stderr);
  return r.stdout.trim();
};
assert.equal(git(['rev-parse', freeze.sourceHead + ':src']), freeze.sourceTree);
assert.equal(git(['rev-parse', 'HEAD:src']), freeze.sourceTree);
assert.equal(git(['status', '--porcelain', '--', 'src']), '');
git(['merge-base', '--is-ancestor', freeze.sourceHead, 'HEAD']);
const contract = readJson('final-freeze-contract.json');
const stable = value => Array.isArray(value) ? value.map(stable) : value && typeof value === 'object' ? Object.fromEntries(Object.keys(value).sort().map(key => [key, stable(value[key])])) : value;
const digest = value => crypto.createHash('sha256').update(value).digest('hex');
const manifestDigest = notice => digest(JSON.stringify(stable([...notice.outputs].sort((a, b) => a.path < b.path ? -1 : a.path > b.path ? 1 : 0))));
const jNoticePath = path.join(base, '..', 'd1387-m01-after-20261027-r2', 'fresh-notice.json');
const jFreeze = JSON.parse(fs.readFileSync(jNoticePath, 'utf8'));
const freezeNoticeSha256 = digest(fs.readFileSync(path.join(base, 'e-final-freeze.json')));
const jFreezeNoticeSha256 = digest(fs.readFileSync(jNoticePath));
const frozenOutputsSha256 = manifestDigest(freeze);
assert.equal(contract.runId, 'sources-m01-after-20261027-r2');
for (const material of [route, freeze, jFreeze, phase, j]) assert.equal(material.runId, contract.runId);
for (const notice of [freeze, jFreeze]) { assert.equal(notice.freezeSchemaVersion, contract.schemaVersion); assert.equal(notice.minimumUnionAssets, contract.minimumUnionAssets); }
assert.equal(contract.schemaVersion, 2);
assert.equal(jFreeze.sourceHead, freeze.sourceHead);
assert.equal(jFreeze.sourceTree, freeze.sourceTree);
assert.equal(manifestDigest(jFreeze), frozenOutputsSha256);
assert.equal(phase.sourceTree, freeze.sourceTree);
assert.equal(j.sourceTree, freeze.sourceTree);
assert.equal(phase.freezeNoticeSha256, freezeNoticeSha256);
assert.equal(phase.jFreezeNoticeSha256, jFreezeNoticeSha256);
assert.equal(j.freezeNoticeSha256, jFreezeNoticeSha256);
assert.equal(phase.frozenOutputsSha256, frozenOutputsSha256);
assert.equal(j.frozenOutputsSha256, frozenOutputsSha256);
assert.equal(phase.jPhaseCompleteSha256, digest(fs.readFileSync(path.join(base, 'j-phase-complete.json'))));
assert.equal(j.allRequiredCasesPassed, true);
assert.equal(j.m01ActualButtonPassed, true);
assert.equal(freeze.fixedExternalBaselineCommit, contract.fixedExternalBaselineCommit);
git(['merge-base', '--is-ancestor', contract.fixedExternalBaselineCommit, freeze.sourceHead]);
const m01Required = contract.mandatoryM01Production.map(file => file.path);
assert.deepEqual(new Set(m01Required), new Set(['sourcesDiffRefHelpers', 'sourcesDiffActions', 'conversationDiffReviewPane'].map(name => 'out/vs/workbench/contrib/sources/browser/' + name + '.js')));
const expectedOutputs = [...new Set([...contract.originalJ18, ...contract.originalE16, ...contract.mandatoryAdditions.map(file => file.path), ...m01Required])];
assert.equal(expectedOutputs.length, contract.minimumUnionAssets);
assert.equal(contract.minimumUnionAssets, 53);
assert.equal(contract.originalE16.length, 16);
assert.ok(Array.isArray(freeze.outputs));
assert.equal(new Set(freeze.outputs.map(file => file.path)).size, freeze.outputs.length, 'Duplicate frozen native paths');
for (const expected of expectedOutputs) assert.ok(freeze.outputs.some(file => file.path === expected), 'Missing frozen E output: ' + expected);
const frozenAssets = [];
for (const file of freeze.outputs) {
  assert.ok(file.path.startsWith('out/vs/') && !file.path.includes('..') && /\.(js|css)$/.test(file.path));
  assert.match(file.sha256, /^[0-9a-f]{64}$/);
  const actual = crypto.createHash('sha256').update(fs.readFileSync(path.join(repo, file.path))).digest('hex');
  assert.equal(actual, file.sha256, file.path);
  const sourcePath = file.path.replace(/^out\//, 'src/').replace(/\.js$/, '.ts');
  assert.equal(file.sourcePath, sourcePath);
  assert.match(file.sourceSha256, /^[0-9a-f]{64}$/);
  const sourceActual = crypto.createHash('sha256').update(fs.readFileSync(path.join(repo, sourcePath))).digest('hex');
  assert.equal(sourceActual, file.sourceSha256, sourcePath);
  frozenAssets.push({ path: file.path, sha256: actual, sourcePath, sourceSha256: sourceActual, runtimeEvidenceStatus: 'manifest-only' });
}
fs.writeFileSync(path.join(base, 'frozen-asset-check.json'), JSON.stringify({ runId: contract.runId, freezeNoticeSha256, jFreezeNoticeSha256, frozenOutputsSha256, sourceHead: freeze.sourceHead, sourceTree: freeze.sourceTree, evidenceScope: 'source/native hashes only; no runtime loaded claim', files: frozenAssets }, null, 2) + '\n');
const engineHome = route.engineHome;
assert.match(engineHome, /^\/tmp\/vscode-e-after-home-[a-z0-9]+$/);
const homeStat = fs.lstatSync(engineHome);
assert.ok(homeStat.isDirectory() && !homeStat.isSymbolicLink());
assert.equal(homeStat.uid, process.getuid());
assert.equal(homeStat.mode & 0o077, 0);
const socket = path.join(engineHome, 'server.sock');
assert.ok(!fs.existsSync(socket), 'Never unlink another live or stale socket automatically');
assert.ok(!fs.existsSync(path.join(engineHome, 'server.lock')));
assert.ok(!fs.existsSync(path.join(base, 'server-started.json')), 'Inspect and clean the previous owned run first');
const grpc = createRequire(path.join(repo, 'package.json'))('@grpc/grpc-js');
const sessionId = 'D-E-attempt2-controlled-session';
const rootAgent = 'root';
const sessionTitle = 'D E controlled transport after';
const callsLog = path.join(base, 'fake-io.jsonl');
const commandsPath = path.join(base, 'fake-control.jsonl');
assert.ok(!fs.existsSync(callsLog), 'Inspect the previous fake I/O transcript before a new run');
assert.ok(!fs.existsSync(commandsPath) || fs.statSync(commandsPath).size === 0, 'Do not replay old fixture control commands');
const log = data => fs.appendFileSync(callsLog, JSON.stringify({ at: Date.now(), fakeIo: true, ...data }) + '\n');
const vint = value => {
  let n = BigInt(value); const out = [];
  assert.ok(n >= 0n);
  do { let b = Number(n & 127n); n >>= 7n; if (n) b |= 128; out.push(b); } while (n);
  return Buffer.from(out);
};
const int = (field, value) => Buffer.concat([vint(field * 8), vint(value)]);
const msg = (field, value) => Buffer.concat([vint(field * 8 + 2), vint(value.length), value]);
const str = (field, value) => msg(field, Buffer.from(value, 'utf8'));
const cat = (...parts) => Buffer.concat(parts.flat());
const parse = bytes => {
  const out = []; let p = 0;
  const read = () => { let n = 0n, shift = 0n; for (;;) { assert.ok(p < bytes.length); const b = bytes[p++]; n |= BigInt(b & 127) << shift; if (!(b & 128)) return n; shift += 7n; assert.ok(shift < 70n); } };
  while (p < bytes.length) {
    const key = Number(read()), field = key >> 3, wire = key & 7;
    if (wire === 0) out.push({ field, wire, value: read().toString() });
    else if (wire === 2) { const size = Number(read()); assert.ok(size <= bytes.length - p); out.push({ field, wire, bytes: bytes.subarray(p, p + size) }); p += size; }
    else throw new Error('Temporary fixture only supports existing varint/length-delimited fields');
  }
  return out;
};
const fieldBytes = (bytes, field) => parse(bytes).findLast(x => x.field === field && x.wire === 2)?.bytes;
const fieldText = (bytes, field) => fieldBytes(bytes, field)?.toString('utf8') ?? '';
const methods = ['SystemService.HealthCheck', 'SessionService.List', 'SessionService.Info', 'SessionService.Resume', 'SessionService.Create', 'SessionService.GetHistory', 'SessionService.SessionEventStream', 'AgentService.Chat', 'AgentService.Tree', 'PermissionService.Respond', 'AgentService.RespondQuestion', 'AgentService.SendClientToolResponse'];
const agent = cat(str(1, rootAgent), str(2, 'D E fixture root'), int(4, 2));
const summary = cat(str(1, sessionId), int(2, 2), str(7, sessionTitle));
const streams = new Set();
const pending = new Map();
const held = new Map();
let commandLinesRead = 0;
const event = (field, body) => cat(str(1, sessionId), msg(field, body));
const questionItem = request => cat(str(1, request.itemId ?? 'choose'), str(2, 'D E retained answers'), str(3, 'Choose a label and preserve custom text'), msg(4, str(2, 'Alpha')), msg(4, str(2, 'Beta')), int(5, 1), int(6, 1));
const pendingBody = request => cat(str(1, request.id), int(2, { permission: 1, question: 2, clientTool: 3 }[request.kind]), str(3, request.toolName ?? 'D_E_fixture_no_execution'), str(4, 'D E controlled ' + request.kind), str(5, rootAgent), request.kind === 'question' ? msg(7, questionItem(request)) : Buffer.alloc(0), request.kind === 'clientTool' ? str(8, '{"fixture":true,"execute":false}') : Buffer.alloc(0));
const overlay = () => event(44, cat(int(1, 1), [...pending.values()].map(p => msg(6, pendingBody(p)))));
const broadcast = bytes => { for (const call of streams) call.write(bytes); log({ type: 'stream-emitted', bytes: bytes.toString('hex'), streams: streams.size }); };
const server = new grpc.Server();
function add(service, method, requestStream, responseStream, handler) {
  const key = service + '_' + method;
  server.addService({ [key]: { path: '/agentservice.' + service + '/' + method, requestStream, responseStream, requestDeserialize: Buffer.from, requestSerialize: Buffer.from, responseDeserialize: Buffer.from, responseSerialize: Buffer.from } }, { [key]: handler });
}
function unary(service, method, handler) {
  add(service, method, false, false, (call, callback) => {
    log({ type: 'unary', service, method, requestHex: call.request.toString('hex') });
    try { handler(call.request, callback); } catch (error) { callback({ code: grpc.status.INTERNAL, details: error.message }); }
  });
}
unary('SystemService', 'HealthCheck', (_, cb) => cb(null, Buffer.alloc(0)));
unary('SystemService', 'Connect', (_, cb) => cb(null, msg(3, cat(methods.map(m => str(1, m))))));
unary('SessionService', 'List', (_, cb) => cb(null, cat(msg(1, summary), int(2, 1))));
unary('SessionService', 'Info', (_, cb) => cb(null, cat(str(1, sessionId), msg(2, agent))));
unary('SessionService', 'Create', (request, cb) => {
  // Only the single advertised catalog fixture is allowed. Never create user sessions.
  const requested = fieldText(request, 4);
  if (requested && requested !== sessionId) return cb({ code: grpc.status.INVALID_ARGUMENT, details: 'Only the D E catalog fixture exists' });
  cb(null, str(1, sessionId));
});
unary('SessionService', 'Resume', (request, cb) => cb(null, fieldText(request, 1) === sessionId ? cat(int(1, 1), msg(3, agent)) : str(2, 'Unknown controlled session')));
unary('SessionService', 'GetHistory', (_, cb) => cb(null, Buffer.alloc(0)));
unary('AgentService', 'Tree', (_, cb) => cb(null, msg(1, agent)));
function response(kind, request, cb) {
  assert.equal(fieldText(request, 1), sessionId);
  const inner = kind === 'permission' ? request : fieldBytes(request, 2);
  assert.ok(inner);
  const id = fieldText(inner, kind === 'permission' ? 2 : 1);
  assert.ok(pending.has(id), 'Response must refer to a real emitted fixture request');
  const token = crypto.randomUUID();
  held.set(token, { kind, id, cb });
  log({ type: 'response-held', token, kind, id, requestHex: request.toString('hex'), answersHex: kind === 'question' ? inner.toString('hex') : undefined, customText: kind === 'question' ? fieldText(inner, 3) : undefined });
}
unary('PermissionService', 'Respond', (request, cb) => response('permission', request, cb));
unary('AgentService', 'RespondQuestion', (request, cb) => response('question', request, cb));
unary('AgentService', 'SendClientToolResponse', (request, cb) => response('clientTool', request, cb));
add('SessionService', 'SessionEventStream', true, true, call => {
  call.once('data', request => {
  assert.equal(fieldText(request, 1), sessionId);
  log({ type: 'session-stream-handshake', requestHex: request.toString('hex') });
  streams.add(call);
  call.on('cancelled', () => streams.delete(call));
  call.on('error', error => { streams.delete(call); log({ type: 'stream-error', message: error.message }); });
  call.write(event(10, cat(int(1, 1), int(2, 0), int(3, 1), int(4, 0))));
  call.write(overlay());
  log({ type: 'real-session-stream-subscribed', sessionId, streams: streams.size });
  });
});
add('AgentService', 'Chat', true, true, call => {
  call.on('data', request => {
    log({ type: 'chat-write', requestHex: request.toString('hex') });
    // This fixture tests unary recovery only, never performs workspace tools/chat.
    call.write(cat(str(1, sessionId), str(2, rootAgent)));
  });
  call.on('error', error => log({ type: 'chat-error', message: error.message }));
  call.on('end', () => call.end());
});
function control(command) {
  if (command.op === 'emit') {
    assert.ok(['permission', 'question', 'clientTool'].includes(command.kind));
    assert.match(command.id, /^D-E-[A-Za-z0-9-]+$/);
    assert.ok(!pending.has(command.id));
    pending.set(command.id, { kind: command.kind, id: command.id, itemId: command.itemId });
    broadcast(overlay());
  } else if (command.op === 'settle') {
    assert.ok(['false', 'reject', 'success'].includes(command.outcome));
    const item = held.get(command.token); assert.ok(item, 'Unknown held unary token');
    held.delete(command.token);
    if (command.outcome === 'reject') item.cb({ code: grpc.status.INVALID_ARGUMENT, details: 'D E controlled rejected unary' });
    else item.cb(null, command.outcome === 'success' ? int(1, 1) : str(2, 'D E controlled ok:false unary'));
    if (command.outcome === 'success') pending.delete(item.id);
    log({ type: 'response-settled', ...command, kind: item.kind, id: item.id });
    // Wait for the real UI's immediate local success cleanup to be observed
    // before an explicit publish command sends the fake authoritative snapshot.
  } else if (command.op === 'publish') broadcast(overlay());
  else throw new Error('Unknown temporary control operation');
}
const timer = setInterval(() => {
  if (!fs.existsSync(commandsPath)) return;
  const content = fs.readFileSync(commandsPath, 'utf8');
  const lines = content.split('\n'); lines.pop(); // Only complete appended lines.
  while (commandLinesRead < lines.length) {
    const line = lines[commandLinesRead++];
    if (!line.trim()) continue;
    try { const command = JSON.parse(line); log({ type: 'control', command }); control(command); }
    catch (error) { log({ type: 'control-error', line, message: error.message }); }
  }
}, 100);
let socketInode;
const startedPath = path.join(base, 'server-started.json');
server.bindAsync('unix:' + socket, grpc.ServerCredentials.createInsecure(), error => {
  if (error) throw error;
  fs.chmodSync(socket, 0o600); socketInode = fs.lstatSync(socket).ino;
  fs.writeFileSync(startedPath, JSON.stringify({ runId: contract.runId, freezeNoticeSha256, frozenOutputsSha256, createdBy: owner, pid: process.pid, socket, socketInode, sessionId, processStartTimeTicks: fs.readFileSync('/proc/self/stat', 'utf8').split(') ').at(-1).split(' ')[19], sourceHead: freeze.sourceHead, transport: 'FAKE UDS unary/stream I/O', startedAt: new Date().toISOString() }, null, 2) + '\n');
  log({ type: 'fake-server-started', pid: process.pid, socket, sourceHead: freeze.sourceHead });
});
function stop(signal) {
  clearInterval(timer);
  server.forceShutdown();
  try { if (fs.lstatSync(socket).ino === socketInode) fs.unlinkSync(socket); } catch (error) { if (error.code !== 'ENOENT') throw error; }
  log({ type: 'fake-server-stopped', signal, pid: process.pid });
  process.exit(0);
}
process.on('SIGINT', () => stop('SIGINT'));
process.on('SIGTERM', () => stop('SIGTERM'));
