'use strict';

// Preparation only. Execute on the already-owned default-editor window after
// the final freeze, never as proof that a frozen file was actually loaded.
const fs = require('node:fs');
const path = require('node:path');
const crypto = require('node:crypto');
const assert = require('node:assert/strict');
const { chromium } = require('/home/clarence/Projects/Agents/vscode-WorkTrees/merge/node_modules/playwright-core');
const base = __dirname;
const jbase = path.join(base, '..', 'd1387-m01-after-20261027-r2');
const repo = '/home/clarence/Projects/Agents/vscode-WorkTrees/merge';
const owner = '/root/sources_audit';
const phase = process.argv.includes('--phase=E') ? 'E' : 'J';
const json = file => JSON.parse(fs.readFileSync(file, 'utf8'));
const sha = bytes => crypto.createHash('sha256').update(bytes).digest('hex');
const mainAsset = file => file.includes('/node/') || file.includes('/electron-main/');
const ownPrefix = 'vscode-file://vscode-app' + repo + '/out/';
const normalizedUrl = url => url.split(/[?#]/)[0];
const contract = json(path.join(base, 'final-freeze-contract.json'));
const info = json(path.join(jbase, 'launch.json'));
assert.equal(info.createdBy, owner);
assert.equal(info.repo, repo);
assert.equal(info.agents, false);
const jnotice = json(path.join(jbase, 'fresh-notice.json'));
assert.equal(jnotice.outFrozen, true);
assert.equal(jnotice.reportedBy, '/root/baseline_executor');
assert.equal(jnotice.sourceHead, info.explicitReadySource);
assert.equal(info.runId, contract.runId);
assert.equal(jnotice.runId, contract.runId);
assert.equal(contract.runId, 'sources-m01-after-20261027-r2');
assert.equal(jnotice.sourceTree, info.explicitReadySourceTree);
assert.equal(sha(fs.readFileSync(path.join(jbase, 'fresh-notice.json'))), info.freezeNoticeSha256);
const notices = [jnotice];
if (phase === 'E') {
  const enotice = json(path.join(base, 'e-final-freeze.json'));
  const scheduling = json(path.join(base, 'e-phase-authorization.json'));
  const completed = json(path.join(base, 'j-phase-complete.json'));
  assert.equal(enotice.sourceHead, jnotice.sourceHead);
  assert.equal(enotice.sourceTree, jnotice.sourceTree);
  assert.equal(enotice.outFrozen, true);
  assert.equal(scheduling.authorizedBy, '/root');
  assert.equal(scheduling.phase, 'E-after');
  assert.equal(scheduling.sourceHead, jnotice.sourceHead);
  assert.equal(completed.completed, true);
  assert.equal(completed.zeroEngineRpc, true);
  assert.equal(completed.sourceHead, jnotice.sourceHead);
  for (const material of [enotice, scheduling, completed]) assert.equal(material.runId, contract.runId);
  assert.equal(scheduling.sourceTree, jnotice.sourceTree);
  assert.equal(completed.sourceTree, jnotice.sourceTree);
  assert.equal(scheduling.freezeNoticeSha256, sha(fs.readFileSync(path.join(base, 'e-final-freeze.json'))));
  assert.equal(scheduling.jFreezeNoticeSha256, info.freezeNoticeSha256);
  assert.equal(completed.freezeNoticeSha256, info.freezeNoticeSha256);
  assert.equal(scheduling.frozenOutputsSha256, info.frozenOutputsSha256);
  assert.equal(completed.frozenOutputsSha256, info.frozenOutputsSha256);
  assert.equal(scheduling.jPhaseCompleteSha256, sha(fs.readFileSync(path.join(base, 'j-phase-complete.json'))));
  assert.equal(completed.allRequiredCasesPassed, true);
  assert.equal(completed.m01ActualButtonPassed, true);
  notices.push(enotice);
}
const m01Required = contract.mandatoryM01Production.map(file => file.path);
const mandatoryUnion = [...new Set([...contract.originalJ18, ...contract.originalE16, ...contract.mandatoryAdditions.map(file => file.path), ...m01Required])];
assert.equal(mandatoryUnion.length, contract.minimumUnionAssets);
assert.equal(contract.minimumUnionAssets, 53);
for (const notice of notices) { assert.equal(notice.freezeSchemaVersion, contract.schemaVersion); assert.equal(notice.minimumUnionAssets, contract.minimumUnionAssets); }
for (const notice of notices) for (const required of mandatoryUnion) assert.ok(notice.outputs.some(file => file.path === required), 'Missing mandatory frozen source/native asset: ' + required);
const frozen = new Map();
for (const notice of notices) {
  assert.equal(notice.fixedExternalBaselineCommit, contract.fixedExternalBaselineCommit);
  for (const file of notice.outputs) {
    if (frozen.has(file.path)) assert.deepEqual(frozen.get(file.path), file, 'Conflicting freeze notices');
    frozen.set(file.path, file);
  }
}
const assets = [];
for (const file of frozen.values()) {
  assert.ok(file.path.startsWith('out/vs/') && !file.path.includes('..') && /\.(js|css)$/.test(file.path));
  const sourcePath = file.path.replace(/^out\//, 'src/').replace(/\.js$/, '.ts');
  assert.equal(file.sourcePath, sourcePath);
  assert.equal(sha(fs.readFileSync(path.join(repo, file.path))), file.sha256);
  assert.equal(sha(fs.readFileSync(path.join(repo, sourcePath))), file.sourceSha256);
  assets.push({ ...file, runtimeEvidenceStatus: 'manifest-only', runtimeEvidence: [], reason: mainAsset(file.path) ? 'No main-process inspector collection performed; renderer CDP cannot prove node-main loading' : 'Not yet observed in the actual renderer' });
}
const jsAssets = assets.filter(file => file.path.endsWith('.js') && !mainAsset(file.path));
const cssAssets = assets.filter(file => file.path.endsWith('.css'));
const evidenceDir = path.join(base, 'runtime-' + phase);
fs.mkdirSync(evidenceDir, { recursive: true });

(async () => {
  const browser = await chromium.connectOverCDP('http://127.0.0.1:' + info.cdpPort);
  try {
    const page = browser.contexts().flatMap(c => c.pages()).find(p => p.url().startsWith(ownPrefix) && p.url().includes('/workbench-dev.html'));
    assert.ok(page, 'Own real default editor is absent');
    await page.waitForFunction(() => !!window.driver);
    await page.evaluate(() => window.driver.whenWorkbenchRestored());
    const cdp = await page.context().newCDPSession(page);
    const scripts = new Map();
    const styles = new Map();
    const cssErrors = [];
    cdp.on('Debugger.scriptParsed', script => {
      const url = normalizedUrl(script.url ?? '');
      if (url.startsWith(ownPrefix) && jsAssets.some(file => url === ownPrefix + file.path.slice(4))) scripts.set(script.scriptId, script);
    });
    cdp.on('CSS.styleSheetAdded', ({ header }) => styles.set(header.styleSheetId, header));
    await cdp.send('Debugger.enable');
    try { await cdp.send('DOM.enable'); await cdp.send('CSS.enable'); } catch (error) { cssErrors.push(String(error)); }
    await new Promise(resolve => setTimeout(resolve, 150));
    for (const script of scripts.values()) {
      const url = normalizedUrl(script.url);
      const asset = jsAssets.find(file => url === ownPrefix + file.path.slice(4));
      const { scriptSource } = await cdp.send('Debugger.getScriptSource', { scriptId: script.scriptId });
      const bytes = Buffer.from(scriptSource);
      const copy = path.join(evidenceDir, asset.path.replaceAll('/', '__') + '.loaded.txt');
      fs.writeFileSync(copy, bytes);
      asset.runtimeEvidenceStatus = 'renderer-js-loaded';
      asset.reason = 'Actual Debugger.scriptParsed URL and Debugger.getScriptSource';
      asset.runtimeEvidence.push({ surface: 'renderer', url: script.url, scriptId: script.scriptId, sha256: sha(bytes), bytes: bytes.length, copy, matchesFrozenNativeBytes: sha(bytes) === asset.sha256 });
    }
    for (const header of styles.values()) {
      const url = normalizedUrl(header.sourceURL ?? '');
      const asset = cssAssets.find(file => url === ownPrefix + file.path.slice(4));
      if (!asset) continue;
      try {
        const { text } = await cdp.send('CSS.getStyleSheetText', { styleSheetId: header.styleSheetId });
        const copy = path.join(evidenceDir, asset.path.replaceAll('/', '__') + '.' + header.styleSheetId + '.css.loaded.txt');
        fs.writeFileSync(copy, text);
        asset.runtimeEvidenceStatus = 'renderer-css-loaded';
        asset.reason = 'Actual CSS.styleSheetAdded sourceURL and CSS.getStyleSheetText';
        asset.runtimeEvidence.push({ surface: 'renderer', source: 'CDP CSS', url: header.sourceURL, styleSheetId: header.styleSheetId, sha256: sha(Buffer.from(text)), copy, matchesFrozenNativeBytes: sha(Buffer.from(text)) === asset.sha256 });
      } catch (error) { cssErrors.push(String(error)); }
    }
    // Dev CSS loaders can insert connected <style> nodes without a CSS URL.
    // Only an actual stylesheet node whose whole body equals the frozen CSS
    // bytes can identify the asset; disk existence alone never counts.
    const inline = await page.evaluate(() => [...document.querySelectorAll('style')].filter(node => node.sheet).map((node, index) => ({ index, text: node.textContent ?? '', disabled: node.sheet.disabled, attributes: [...node.attributes].map(a => [a.name, a.value]) })));
    for (const node of inline) {
      const hash = sha(Buffer.from(node.text));
      const asset = cssAssets.find(file => file.sha256 === hash);
      if (!asset) continue;
      const copy = path.join(evidenceDir, asset.path.replaceAll('/', '__') + '.style-' + node.index + '.loaded.txt');
      fs.writeFileSync(copy, node.text);
      asset.runtimeEvidenceStatus = 'renderer-css-loaded';
      asset.reason = 'Actual connected DOM stylesheet whose complete text equals frozen native CSS';
      asset.runtimeEvidence.push({ surface: 'renderer', source: 'DOM stylesheet text', styleIndex: node.index, disabled: node.disabled, attributes: node.attributes, sha256: hash, copy, matchesFrozenNativeBytes: true });
    }
    const eCore = ['out/vs/workbench/contrib/conversation/browser/conversationEditorPane.js', 'out/vs/workbench/contrib/conversation/browser/conversationEngineRosterService.js', 'out/vs/workbench/contrib/conversation/browser/conversationEngineQueueReader.js', 'out/vs/platform/universeAgent/common/conversationResponseState.js'];
    const requiredRenderer = [...new Set([...m01Required, ...cssAssets.map(file => file.path), ...(phase === 'E' ? eCore : [])])];
    const missing = requiredRenderer.filter(file => !assets.find(a => a.path === file)?.runtimeEvidence.length);
    const record = { runId: contract.runId, freezeNoticeSha256: info.freezeNoticeSha256, frozenOutputsSha256: info.frozenOutputsSha256, at: new Date().toISOString(), createdBy: owner, phase, sourceHead: jnotice.sourceHead, sourceTree: jnotice.sourceTree, windowUrl: page.url(), loadedEvidenceScope: 'Only actual renderer Debugger/CSS/DOM observations; node-main stays manifest-only', fakeIoScope: 'E response recovery with queue unsupported; no queue/skills acceptance credit', assets, missingRequiredRendererEvidence: missing, cssErrors };
    fs.writeFileSync(path.join(base, 'runtime-assets-' + phase + '.json'), JSON.stringify(record, null, 2) + '\n');
    console.log(JSON.stringify({ phase, frozenAssets: assets.length, observedJs: assets.filter(a => a.runtimeEvidenceStatus === 'renderer-js-loaded').length, observedCss: assets.filter(a => a.runtimeEvidenceStatus === 'renderer-css-loaded').length, manifestOnly: assets.filter(a => a.runtimeEvidenceStatus === 'manifest-only').length, missingRequiredRendererEvidence: missing }));
    assert.equal(missing.length, 0, 'Missing actual required renderer evidence; retain the boundary, do not relabel manifest-only assets');
  } finally { await browser.close(); }
})().catch(error => { console.error(error); process.exitCode = 1; });
