// Prepared only. Execute after source freeze and the parent's exclusive-lane authorization.
import fs from 'node:fs';
import path from 'node:path';
import crypto from 'node:crypto';
import { pathToFileURL } from 'node:url';
const [manifestPath, phase] = process.argv.slice(2);
const manifest = JSON.parse(fs.readFileSync(manifestPath, 'utf8'));
if (!manifest.frozen || manifest.candidateOnly !== false || !manifest.runtimeAuthorized || !['old', 'new'].includes(phase)) { throw Error('unfrozen or invalid phase'); }
const digest = data => crypto.createHash('sha256').update(data).digest('hex');
const root = fs.realpathSync(manifest.repo);
const outRoot = path.join(root, 'out');
if (manifest.repo !== root || !['C', 'F'].includes(path.basename(root))) { throw Error('requires a private C/F repository'); }
const scan = dir => {
 if (!fs.existsSync(dir)) { return; }
 const stat = fs.lstatSync(dir);
 if (stat.isSymbolicLink() || (stat.isFile() && stat.nlink > 1)) { throw Error('shared output: ' + dir); }
 if (stat.isDirectory()) { for (const name of fs.readdirSync(dir)) { scan(path.join(dir, name)); } }
};
scan(outRoot);
const helper = path.join(root, 'build/next/transpile.ts');
if (digest(fs.readFileSync(helper)) !== manifest.controls.find(entry => entry.source === 'build/next/transpile.ts').sha256) { throw Error('transpile helper changed'); }
const { transpileFile, copyFile, mapWithConcurrency } = await import(pathToFileURL(helper).href);
const entries = manifest.phases[phase];
if (!entries?.length) { throw Error('empty phase'); }
await mapWithConcurrency(entries, 16, async entry => {
 const target = path.resolve(entry.out);
 if (!target.startsWith(outRoot + path.sep)) { throw Error('outside private output'); }
 for (let dir = path.dirname(target); dir !== root; dir = path.dirname(dir)) {
  if (fs.existsSync(dir) && fs.lstatSync(dir).isSymbolicLink()) { throw Error('shared ancestor'); }
 }
 const bytes = fs.readFileSync(entry.snapshot);
 if (digest(bytes) !== entry.sha256) { throw Error('snapshot changed: ' + entry.source); }
 if (entry.kind === 'ts') { await transpileFile(entry.snapshot, target); }
 else if (entry.kind === 'resource') { await copyFile(entry.snapshot, target); }
 else { throw Error('unknown input kind'); }
});
console.log(JSON.stringify({ phase, refreshed: entries.length }));
