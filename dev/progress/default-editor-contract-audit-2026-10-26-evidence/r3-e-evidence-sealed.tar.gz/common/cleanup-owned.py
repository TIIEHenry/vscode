from pathlib import Path
import json,os,signal,sys,time,shutil,hashlib
sys.path.insert(0,str(Path(__file__).resolve().parent))
from gates import ROOT,read,verify
phase=sys.argv[1];proof=verify(phase,native=False,require_launch=True);base=ROOT/phase;launch=proof['launch'];lease=read(base/'lease.json')
def process(pid):
    p=Path('/proc',str(pid))
    try:
        s=(p/'stat').read_text().split(') ')[-1].split();return {'pid':pid,'ppid':int(s[1]),'state':s[0],'startTicks':s[19],'cmdline':(p/'cmdline').read_bytes().replace(b'\0',b' ').decode(errors='replace')}
    except FileNotFoundError:return None
roots=[(lease['electronPid'],lease['electronStartTimeTicks']),(lease['xvfbPid'],lease['xvfbStartTimeTicks'])]
servers=[]
if phase=='E':
    for directory in [base]+sorted(p for p in base.glob('transport-episode-*') if p.is_dir()):
        if not (directory/'server-started.json').exists():continue
        server=read(directory/'server-started.json');current=process(server['pid'])
        if current and current['state']!='Z':assert current['startTicks']==server['processStartTimeTicks'] and str(directory/'fake-uds-engine.cjs') in current['cmdline'];roots.append((server['pid'],server['processStartTimeTicks']));servers.append(server)
for pid,ticks in roots:
    row=process(pid);assert row and row['startTicks']==ticks,'Refuse changed/missing root process'
assert launch['runDir'] in process(lease['electronPid'])['cmdline'];assert 'Xvfb' in process(lease['xvfbPid'])['cmdline']
allp=[r for p in Path('/proc').iterdir() if p.name.isdigit() for r in [process(int(p.name))] if r];owned={pid for pid,_ in roots}
while True:
    new=owned|{r['pid'] for r in allp if r['ppid'] in owned}
    if new==owned:break
    owned=new
rows=[r for r in allp if r['pid'] in owned];before=base/'final-live-owned-processes.json';assert not before.exists();before.write_text(json.dumps({'runId':proof['runId'],'phase':phase,'at':time.time(),'roots':roots,'processes':rows,'launch':launch,'lease':lease},indent=2)+'\n')
run=Path(launch['runDir']);home=Path(launch['engineHome']);assert str(run).startswith('/tmp/code-oss-dev-') and not run.is_symlink();assert home.parent==Path('/tmp') and home.name.startswith('vscode-r3-') and not home.is_symlink();logs=base/'profile-logs';logs.mkdir()
if (run/'code.log').exists():shutil.copyfile(run/'code.log',logs/'code.before-stop.log')
actions=[]
def stop(row,sig):
    current=process(row['pid'])
    if current and current['state']!='Z':
        assert current['startTicks']==row['startTicks'],'PID reuse; refuse signal'
        os.kill(row['pid'],sig);actions.append({'pid':row['pid'],'startTicks':row['startTicks'],'signal':signal.Signals(sig).name,'at':time.time()})
lookup={r['pid']:r for r in rows}
for server in servers:stop(lookup[server['pid']],signal.SIGTERM)
time.sleep(.25);stop(lookup[lease['electronPid']],signal.SIGTERM);time.sleep(2);stop(lookup[lease['xvfbPid']],signal.SIGTERM);time.sleep(.5)
for row in rows:stop(row,signal.SIGTERM)
time.sleep(.5)
for row in rows:stop(row,signal.SIGKILL)
time.sleep(.25);remaining=[p for row in rows for p in [process(row['pid'])] if p and p['state']!='Z'];assert not remaining
if (run/'code.log').exists():shutil.copyfile(run/'code.log',logs/'code.after-stop.log')
if (Path(launch['userDataDir'])/'logs').exists():shutil.copytree(Path(launch['userDataDir'])/'logs',logs/'user-data-logs')
assert not list(home.iterdir()),'Unexpected home contents; do not remove';shutil.rmtree(run);home.rmdir()
result={'runId':proof['runId'],'phase':phase,'actions':actions,'remainingOwnedLiveProcesses':0,'profileRemoved':not run.exists(),'homeRemoved':not home.exists(),'profileLogs':[{'path':str(p.relative_to(logs)),'bytes':p.stat().st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()} for p in sorted(logs.rglob('*')) if p.is_file()],'noOldStageArtifactsOrFixturesTouched':True};target=base/'cleanup.json';assert not target.exists();target.write_text(json.dumps(result,indent=2)+'\n');lease.update(released=True,releasedAt=time.time());(base/'lease.json').write_text(json.dumps(lease,indent=2)+'\n');print(json.dumps({'phase':phase,'runId':proof['runId'],'liveOwned':0,'profileRemoved':True,'homeRemoved':True}))
