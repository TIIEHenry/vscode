import json,pathlib,sys
from prepare import snapshot
base=pathlib.Path(__file__).resolve().parent
info=json.loads((base/'fixture.json').read_text());root=pathlib.Path(info['fixture'])
current=[snapshot(root/k) for k in ['alpha','beta']]
before=json.loads((base/'fixture-baseline.json').read_text());same=current==before
name=sys.argv[1] if len(sys.argv)>1 else 'fixture-verification.json'
assert '/' not in name and name.endswith('.json')
(base/name).write_text(json.dumps({'matchesBaseline':same,'current':current,'runtimeCheck':(base/'launch.json').exists()},indent=2)+'\n')
print(json.dumps({'matchesBaseline':same,'HEADs':{x['root']:x['HEAD'] for x in current},'indexEmpty':all(not x['cachedDiffHex'] for x in current)}))
raise SystemExit(0 if same else 1)
