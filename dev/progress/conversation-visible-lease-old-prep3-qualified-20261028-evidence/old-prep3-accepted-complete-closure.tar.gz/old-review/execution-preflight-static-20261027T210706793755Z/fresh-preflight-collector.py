from pathlib import Path
import os,json,hashlib,stat,subprocess,datetime,time,resource,traceback,sys
E=Path(__file__).parent;D=E.parent;P=Path(str(D)[:-7]);R=Path('/home/clarence/Projects/Agents/vscode-WorkTrees/merge')
sha=lambda b:hashlib.sha256(b).hexdigest()
now=lambda:datetime.datetime.now(datetime.timezone.utc).isoformat()
def readj(p):return json.loads(Path(p).read_bytes())
def meta(p):
 p=Path(p);s=p.lstat();return dict(type=stat.S_IFMT(s.st_mode),fullMode=s.st_mode,size=s.st_size,mtimeNs=s.st_mtime_ns,ctimeNs=s.st_ctime_ns,symlinkTarget=os.readlink(p) if stat.S_ISLNK(s.st_mode) else None)
def ref(p):
 p=Path(p);b=p.read_bytes();return dict(path=str(p),bytes=len(b),sha256=sha(b),metadata=meta(p))
def save(n,v):
 b=(json.dumps(v,ensure_ascii=False,indent=2)+'\n').encode()
 with (E/n).open('xb') as f:f.write(b);f.flush();os.fchmod(f.fileno(),0o444);os.fsync(f.fileno())
 return ref(E/n)
def git(*a):return subprocess.check_output(['rtk','proxy','git',*a],cwd=R)
def workspace():
 h=git('rev-parse','HEAD').decode().strip();t=git('rev-parse','HEAD:src').decode().strip();status=git('status','--porcelain=v1','-z')
 assert h=='64934a7772b667c6a3aba9739fc4f935b5aeb115' and t=='3dc1205763451e60e70c1a8a84465613990aa526' and status==b''
 return dict(head=h,sourceTree=t,gitStatusPorcelainZHex=status.hex(),clean=True)
def memory():
 captured=now();host={}
 for line in Path('/proc/meminfo').read_text().splitlines():
  key,value=line.split(':',1)
  if key in ['MemTotal','MemAvailable','SwapTotal','SwapFree','Shmem']:
   host[key]=int(value.strip().split()[0])*1024
 raw=Path('/proc/self/cgroup').read_text();relative=next(line.split('::',1)[1] for line in raw.splitlines() if line.startswith('0::'))
 current=Path('/sys/fs/cgroup')/relative.lstrip('/');ancestors=[];headrooms=[]
 for candidate in [current,*[p for p in current.parents if p.is_relative_to(Path('/sys/fs/cgroup'))]]:
  values={};errors={}
  for name in ['memory.max','memory.current','memory.high','memory.events','memory.swap.max','memory.swap.current','memory.swap.high']:
   q=candidate/name
   try:values[name]=q.read_text().strip()
   except OSError as error:values[name]=None;errors[name]=str(error)
  is_root=candidate==Path('/sys/fs/cgroup')
  if not is_root:assert values['memory.max'] is not None and values['memory.current'] is not None and values['memory.high'] is not None,dict(path=str(candidate),errors=errors)
  used=int(values['memory.current']) if values['memory.current'] is not None else None
  per={}
  for name in ['memory.max','memory.high']:
   limit=values[name]
   if limit is not None and limit!='max':
    available=max(0,int(limit)-used);per[name]=available;headrooms.append(available)
   else:per[name]=None
  swap_current=int(values['memory.swap.current']) if values['memory.swap.current'] is not None else None
  swap_limit=values['memory.swap.max']
  swap_headroom=max(0,int(swap_limit)-swap_current) if swap_limit is not None and swap_limit!='max' else None
  ancestors.append(dict(path=str(candidate),capturedAtUtc=now(),values=values,readErrors=errors,finiteMemoryHeadroomBytes=per,finiteSwapMaxHeadroomBytes=swap_headroom,rootControllerFilesAbsentNotClaimedAsMeasuredInfinite=is_root and values['memory.max'] is None))
 effective=min([host['MemAvailable'],*headrooms])
 return dict(capturedAtUtc=captured,completedAtUtc=now(),pid=os.getpid(),selfCgroupRaw=raw,hostBytes=host,actualProcessCgroup=str(current),visibleAncestors=ancestors,effectiveAvailableWorkingMemoryHeadroomBytes=effective,minimumRequiredWorkingHeadroomBytes=8589934592,gatePass=effective>=8589934592,swapNotCountedAsAvailableWorkingHeadroom=True,qualification='Fresh timestamped host and actual helper process cgroup/visible ancestor limits/current/high/headroom. No future runtime child observed; no memory reservation.')

def pid_resources():
 raw=Path('/proc/self/cgroup').read_text();relative=next(x.split('::',1)[1] for x in raw.splitlines() if x.startswith('0::'));q=Path('/sys/fs/cgroup')/relative.lstrip('/');levels=[];headrooms=[]
 for root in [q,*[p for p in q.parents if p.is_relative_to('/sys/fs/cgroup')]]:
  values={};errors={}
  for name in ['pids.max','pids.current','pids.events']:
   try:values[name]=(root/name).read_text().strip()
   except OSError as e:values[name]=None;errors[name]=str(e)
  limit=values['pids.max'];cur=values['pids.current'];head=max(0,int(limit)-int(cur)) if limit not in [None,'max'] and cur is not None else None
  if head is not None:headrooms.append(head)
  levels.append(dict(path=str(root),values=values,errors=errors,finiteAvailablePids=head))
 procpaths=[p for p in Path('/proc').iterdir() if p.name.isdigit()];tasks=0;unreadable=[]
 for p in procpaths:
  try:tasks+=len(list((p/'task').iterdir()))
  except OSError as e:unreadable.append(dict(pid=int(p.name),error=str(e)))
 limits={name:list(resource.getrlimit(getattr(resource,name))) for name in ['RLIMIT_NPROC','RLIMIT_NOFILE','RLIMIT_AS']}
 kernel={name:int((Path('/proc/sys/kernel')/name).read_text().strip()) for name in ['pid_max','threads-max']}
 finite=min(headrooms) if headrooms else None
 return dict(capturedAtUtc=now(),pid=os.getpid(),actualCgroupLevels=levels,finiteEffectivePidsHeadroom=finite,minimumExpectedRuntimePidHeadroom=512,finitePidGatePass=finite is None or finite>=512,hostKernelLimits=kernel,hostVisibleProcesses=len(procpaths),hostVisibleTasksSample=tasks,hostTaskReadErrors=unreadable,hostThreadsCapacityApproximate=max(0,kernel['threads-max']-tasks),rlimits=limits,loadavg=Path('/proc/loadavg').read_text().strip(),pidHeadroomIsSampleNotReservation=True,unlimitedCgroupValueIsMeasuredMaxButMissingRootFilesAreNotInfinity=True)
patterns=['compile-client','typecheck-client','transpile-client','gulp.js','build/next/index.ts transpile','build/next/index.ts watch','watch-client','tsc --project','tsgo --project','virtual-noemit','virtual-noEmit','test/unit/electron/index.js','test/unit/node/index.js','source-checker.mjs','linter.mjs','emitter.mjs','node_modules/eslint/bin/eslint.js','build/eslint.ts','--extensionTestsPath','--extension-tests-path','playwright','test/scenario','smokeTestDriver']
def process_scan():
 ancestors=set();pid=os.getpid()
 while pid>0 and pid not in ancestors:
  ancestors.add(pid)
  try:s=(Path('/proc')/str(pid)/'stat').read_text();pid=int(s[s.rfind(')')+2:].split()[1])
  except (OSError,ValueError,IndexError):break
 nodes=[];runners=[];unreadable=[];allids={}
 for q in Path('/proc').iterdir():
  if not q.name.isdigit():continue
  try:
   s=(q/'stat').read_text();f=s[s.rfind(')')+2:].split();argv=[b.decode(errors='replace') for b in (q/'cmdline').read_bytes().split(b'\0') if b];allids[int(q.name)]=f[19]
  except (OSError,IndexError) as e:
   if isinstance(e,PermissionError):unreadable.append(dict(pid=int(q.name),error=str(e)))
   continue
  if int(q.name) in ancestors:continue
  joined=' '.join(argv);matched=[p for p in patterns if p in joined]
  try:exe=os.readlink(q/'exe')
  except OSError:exe=''
  base=Path(exe).name.lower();isnode=any(x in base for x in ['node','electron','code-oss','esbuild','xvfb'])
  if not isnode and not matched:continue
  try:cwd=os.readlink(q/'cwd')
  except OSError as e:cwd={'error':str(e)}
  if matched:category='active-build-test-or-automation-runner'
  elif 'codex' in joined or '/usr/lib/chatgpt/resources/cua_node/' in joined:category='agent-or-chatgpt-control-infrastructure'
  elif '/Projects/Android/ClientMessageSync/' in joined or '/Projects/Android/ClientMessageSync/' in str(cwd):category='unrelated-Android-vite-development-service'
  elif any(x in joined for x in ['mcporter','chrome-devtools-mcp']):category='persistent-MCP-service'
  elif 'code-oss' in base:category='existing-CodeOSS-desktop-process-no-test-runner-flag'
  elif 'xvfb' in base:category='existing-Xvfb-not-owned-by-this-package'
  else:category='other-or-unknown-Node-service'
  x=dict(pid=int(q.name),startTime=f[19],state=f[0],ppid=int(f[1]),pgrp=int(f[2]),session=int(f[3]),uid=q.stat().st_uid,rssBytes=int(f[21])*os.sysconf('SC_PAGE_SIZE'),executable=exe,cwd=cwd,argv=argv,matchedPatterns=matched,classification=category)
  if isnode:nodes.append(x)
  if matched:runners.append(x)
 return dict(capturedAtUtc=now(),allNodeElectronEsbuildXvfbRows=nodes,activeBuildTestAutomationMatches=runners,unreadableProcessIdentityRows=unreadable,excludedOwnAncestorPids=sorted(ancestors),noProcessEnvironmentRead=True,allVisibleNodeElectronStopped=False,quietRelevantBuildTestPatternDomain=not runners and not unreadable,qualification='All matching runtime-family processes are listed, including unrelated services/desktop/agent infrastructure. Relevant build/test quiet is distinct from a claim that every Node/Electron process has exited.'),allids
lockpaths=[Path('/tmp/vscode-compile.lock'),Path('/tmp/vscode-loop-compile.lock')]
def locks():
 raw=Path('/proc/locks').read_text();rows=[]
 for q in lockpaths:
  s=q.lstat();assert stat.S_ISREG(s.st_mode) and q.resolve()==q and not q.is_symlink();key=f'{os.major(s.st_dev):02x}:{os.minor(s.st_dev):02x}:{s.st_ino}'
  matches=[line for line in raw.splitlines() if key in line.split()];openers=[];errors=[]
  for p in Path('/proc').iterdir():
   if not p.name.isdigit():continue
   try:fds=list((p/'fd').iterdir())
   except (PermissionError,FileNotFoundError):continue
   for fd in fds:
    try:target=os.readlink(fd)
    except OSError:continue
    if target==str(q):
     try:info=(p/'fdinfo'/fd.name).read_text()
     except OSError as e:info=str(e)
     openers.append(dict(pid=int(p.name),fd=fd.name,fdinfo=info))
  rows.append(dict(path=str(q),metadata=meta(q),device=s.st_dev,inode=s.st_ino,kernelDeviceInodeKey=key,matchingKernelLockRows=matches,openDescriptors=openers,heldAtKernelTableSample=bool(matches)))
 return dict(capturedAtUtc=now(),procLocksRaw=raw,rows=rows,bothNoMatchingKernelLockAtSample=all(not x['heldAtKernelTableSample'] for x in rows),method='Read-only /proc/locks plus stat identity and matching /proc/PID/fd/fdinfo; no lock files opened/acquired/created or runtime lock retained.',qualification='Kernel-table sample only, not a nonblocking acquisition test or future exclusivity guarantee.')
def telemetry(label):
 caps={}
 for k,p in [('sdd',P),('home',Path('/home/clarence/.codex/tmp')),('tmp',Path('/tmp'))]:
  v=os.statvfs(p);caps[k]=dict(path=str(p),device=p.stat().st_dev,availableBytes=v.f_bavail*v.f_frsize,availableInodes=v.f_favail,blockSize=v.f_frsize)
 mem=memory();pids=pid_resources();proc,allids=process_scan();lock=locks();mounts={}
 for k,p in [('sdd',P),('home',Path('/home/clarence/.codex/tmp')),('tmp',Path('/tmp'))]:
  a=['rtk','proxy','findmnt','--json','--target',str(p),'--output','TARGET,SOURCE,FSTYPE,OPTIONS,MAJ:MIN'];r=subprocess.run(a,capture_output=True);mounts[k]=dict(argv=a,actualExitCode=r.returncode,stdout=r.stdout.decode(),stderr=r.stderr.decode());assert r.returncode==0
 budgets=dict(sdd=10200547328,home=67108864,tmp=134217728);inode=dict(sdd=200000,home=10000,tmp=10000)
 value=dict(label=label,capturedAtUtc=now(),collectorPid=os.getpid(),capacities=caps,mounts=mounts,memory=mem,pids=pids,processes=proc,locks=lock,requiredBytes=budgets,requiredInodes=inode,budgetComponents=dict(sddOldStaticAndReviewAllowance=536870912,sddFutureOldRuntimeReportsWALTmpCachesUserData=4294967296,sddFutureAfterAllowanceOnlyNoReservation=4294967296,sddMargin=1073741824,homeFuturePublication=67108864,tmpFutureXvfbLocks=134217728),retainedOriginalsAndCurrentPackageAlreadyIncludedInFreshAvailable=True,currentPackageNotChargedAgain=True,expectedRuntimeWorkingMemoryMinimumBytes=8589934592,memoryBudgetQualification='Same accepted preflight working-headroom floor. Checker alone permits8GiB heap; this is a measured admission floor, not a memory reservation or guaranteed future peak.',capacityGatePass=all(caps[k]['availableBytes']>=budgets[k] and caps[k]['availableInodes']>=inode[k] for k in caps),memoryGatePass=mem['gatePass'],pidGatePass=pids['finitePidGatePass'],noLockAcquisitionOrProbe=True,currentMountNamespace=os.readlink('/proc/self/ns/mnt'))
 save(label+'.json',value);return value,allids
def fixed_package():
 anchor=readj(D/'package-final-audit.anchor.json');inv=readj(D/'frozen-package-inventory.json');audit=ref(P/'package-final-audit.json');release=readj(P/'execution-release.json');b=(P/'execution-release.json').read_bytes()
 assert audit['sha256']=='c23d7660b411ddc22539e805be1e5851a3112e134f314bb307b7f5971b374620' and ref(D/'frozen-package-inventory.json')['sha256']=='66cc893cace9297ecf3460108a2697f04eccdfdfca1da7d184d88e4bf520d9ae'
 assert sha(b)=='f0feff5f54f9c4fe796135167e9e7aa3f274d95f4ab0f1deb8452f53eb53b4af' and b==(D/'execution-release.prepared0.original.json').read_bytes()
 assert release['executionAuthorized'] is False and release['activationAuthorized'] is False and release['invocations']==0 and release['state']=='PREPARED0_NOT_AUTHORIZED'
 assert {q.relative_to(P).as_posix() for q in [P,*P.rglob('*')]}=={x['path'] for x in inv['rows']} and len(inv['rows'])==555
 for x in inv['rows']:
  q=P/x['path'];assert {'path':x['path'],**meta(q)}=={k:v for k,v in x.items() if k!='sha256'},x['path']
  if 'sha256' in x:assert sha(q.read_bytes())==x['sha256'],x['path']
 assert len(release['pinnedFilesSha256'])==436
 for name,h in release['pinnedFilesSha256'].items():assert sha((P/name).read_bytes())==h
 seals=readj(P/'sealed-originals.json')
 for x in seals:
  q=R/x['path'];s=q.stat();assert q.read_bytes()==Path(x['sealedBytesPath']).read_bytes() and sha(q.read_bytes())==x['sha256'] and (stat.S_IMODE(s.st_mode),s.st_mtime_ns,s.st_ctime_ns)==(x['mode'],x['mtimeNs'],x['ctimeNs'])
 return dict(audit=audit,release=ref(P/'execution-release.json'),inventory=ref(D/'frozen-package-inventory.json'),full555EntriesAnd438HashesExact=True,all436PinsExact=True,exactTwoSealedLiveBytesModeMtimeCtime=True,prepared0Unactivated=True,noPackageMutation=True)
def context_shared():
 ctx=readj(P/'context-content-inventory.json');names=set()
 for scope in ['src','.build','node_modules','out','build']:
  names.update(q.relative_to(R).as_posix() for q in [R/scope,*(R/scope).rglob('*')])
 assert names=={x['path'] for x in ctx['rows']} and len(names)==119095
 for x in ctx['rows']:assert {'path':x['path'],**meta(R/x['path'])}=={k:v for k,v in x.items() if k!='sha256'},x['path']
 ext=readj(P/'external-reference-closure.json');extcount=0
 for g in ext['externalSymlinkTargets']:
  root=Path(g['target']);actual=[root,*root.rglob('*')] if root.is_dir() else [root] if root.exists() or root.is_symlink() else []
  assert {str(q) for q in actual}=={x['path'] for x in g['rows']};extcount+=len(actual)
  for x in g['rows']:assert {'path':x['path'],**meta(x['path'])}=={k:v for k,v in x.items() if k!='sha256'},x['path']
 assert extcount==27318
 authority=Path('/sdd/tmp/vscode-conversation-visible-lease-after-I-20261028-reservation1/preservation/shared-seven-content-and-identity-manifest.json');shared=readj(authority);sharednames=set()
 for wanted in shared['targets']:
  q=Path(wanted['path']);s=q.lstat();assert meta(q)=={k:wanted[k] for k in ['type','fullMode','size','mtimeNs','ctimeNs','symlinkTarget']} and s.st_dev==wanted['device'] and s.st_ino==wanted['inode'] and str(q.resolve())==wanted['resolved']
  sharednames.update(str(p) for p in [q,*q.rglob('*')])
 assert sharednames=={x['path'] for x in shared['rows']}
 for x in shared['rows']:
  wanted=x['acceptedFrozenContentAndMetadata'];assert meta(x['path'])=={k:v for k,v in wanted.items() if k not in ['path','sha256']},x['path']
 return dict(capturedAtUtc=now(),context119095PathsetAndMetadataExact=True,external27318PathsetAndMetadataExact=True,sevenSharedAuthority=ref(authority),allSevenTargetDeviceInodeCanonicalMetadataExact=True,sevenSharedObservedUnionRows=len(sharednames),sevenSharedAllPathsetsAndMetadataExact=True,sharedFreezeProvenance='Root-forwarded original seven-target C/F/J read-only commitment from accepted frozen authority. Fresh metadata checked now; not a new independent ACL/freeze promise.',wholeContextOrExternalOrSharedContentRehashCount=0,acceptedFrozenContentHashesRetainOriginalProvenance=True)
def known_owned(allids):
 sources=[Path('/sdd/tmp/vscode-conversation-visible-lease-old-business-20261028-prep2/business-report.json'),Path('/tmp/vscode-conversation-visible-lease-work-root-mount-isolated-diagnostics-20261027-prep2/diagnostic-report.json'),Path('/sdd/tmp/vscode-conversation-visible-lease-old-business-20261028-prep2-review/authorized-old-once-20261027T184023447555Z/driver-invocation.process.json')];owned={};counts={}
 for q in sources:
  data=readj(q);rows=[]
  if 'stages' in data:
   for stage in data['stages']:rows+=stage.get('ownedProcesses',[])
  else:rows=[data]
  pairs={(int(x['pid']),str(x['startTime'])) for x in rows};counts[str(q)]=len(pairs)
  for pid,start in pairs:owned[(pid,start)]=dict(pid=pid,startTime=start,currentSameIdentity=allids.get(pid)==start)
 alive=[v for v in owned.values() if v['currentSameIdentity']]
 return dict(capturedAtUtc=now(),exactHistoricalIdentityCounts=counts,distinctKnownPidStartCount=len(owned),alive=alive,allKnownHistoricalOwnedQuiet=not alive,cfOwnedQuietProvenance='Root-forwarded actual C/F owned groups quiet/both locks released/S2 authority closed and window through21:25; own global process/locks scan is separate.',historicalProcessesNeverSignaled=True)
started=now();report=dict(startedAtUtc=started,scope='Fresh trusted Python preflight only; no candidate guard/validate, Node, activation, driver, Program/lint/syntax/dry/emit/official or runtime lock acquisition.',reportRoot=str(E),executionAuthorized=False,activationAuthorized=False,candidateInvocations=0)
try:
 report['workspaceBefore']=workspace();before,ids=telemetry('fresh-before');report['freshBefore']=before
 report['fixedPackage']=fixed_package();save('fixed-package-and-pins.json',report['fixedPackage'])
 a=['rtk','proxy','python3','-B',str(E/'trusted-targeted-protection.py'),'fresh-execution-preflight'];start=now()
 with (E/'targeted.stdout.raw').open('xb') as o,(E/'targeted.stderr.raw').open('xb') as e:
  result=subprocess.run(a,stdout=o,stderr=e,cwd=R)
  for f in [o,e]:f.flush();os.fchmod(f.fileno(),0o444);os.fsync(f.fileno())
 command=dict(startedAtUtc=start,endedAtUtc=now(),actualArgv=a,actualExitCode=result.returncode,stdout=ref(E/'targeted.stdout.raw'),stderr=ref(E/'targeted.stderr.raw'))
 save('targeted.actual-result.json',command);report['targetedActualResult']=command;assert result.returncode==0
 report['targetedProtection']=readj(E/'targeted-original-protection.json');report['contextAndSevenShared']=context_shared();save('context-external-seven-shared.json',report['contextAndSevenShared'])
 after,ids=telemetry('fresh-after');report['freshAfter']=after;report['knownOwned']=known_owned(ids);save('known-owned-process-identities.json',report['knownOwned']);report['workspaceAfter']=workspace()
 # Final P metadata/release remain exact after every collector has finished its P reads.
 inv=readj(D/'frozen-package-inventory.json')
 for x in inv['rows']:assert meta(P/x['path'])=={k:v for k,v in x.items() if k not in ['path','sha256']}
 assert sha((P/'execution-release.json').read_bytes())=='f0feff5f54f9c4fe796135167e9e7aa3f274d95f4ab0f1deb8452f53eb53b4af'
 report['resourceGatePass']=all(x['capacityGatePass'] and x['memoryGatePass'] and x['pidGatePass'] for x in [before,after])
 report['relevantBuildTestQuietAtBothSamples']=all(x['processes']['quietRelevantBuildTestPatternDomain'] for x in [before,after]) and report['knownOwned']['allKnownHistoricalOwnedQuiet']
 report['bothLocksNoKernelHolderAtBothSamples']=all(x['locks']['bothNoMatchingKernelLockAtSample'] for x in [before,after])
 report['allGlobalNodeElectronStopped']=False
 report.update(completedAtUtc=now(),status='STATIC_PROTECTION_COMPLETE_RESOURCE_AND_QUIET_SAMPLES_RECORDED',gatePass=report['resourceGatePass'] and report['relevantBuildTestQuietAtBothSamples'] and report['bothLocksNoKernelHolderAtBothSamples'],noActivationDriverOrNode=True,noLockAcquiredOrHeld=True,noFullFiveGigabyteContentRehash=True,noPackageMutation=True,noRuntimeAuthorityOrResourceReservation=True,stop='Root independent acceptance and separate five-field activation/unique-driver authority required.')
except BaseException as e:
 report.update(completedAtUtc=now(),status='STOPPED_OWN_COLLECTOR_OR_PROTECTION_FAILURE',errorType=type(e).__name__,error=str(e),traceback=traceback.format_exc(),gatePass=False,noActivationDriverOrNode=True,noLockAcquiredOrHeld=True)
 save('fresh-execution-preflight.json',report);print(report['traceback'],file=sys.stderr);sys.exit(1)
summary=save('fresh-execution-preflight.json',report)
print(json.dumps(dict(report=summary,gatePass=report['gatePass'],resources=report['resourceGatePass'],relevantBuildTestQuiet=report['relevantBuildTestQuietAtBothSamples'],bothLocksNoKernelHolder=report['bothLocksNoKernelHolderAtBothSamples'],allGlobalNodeElectronStopped=False,hostMemAvailableBytes=after['memory']['hostBytes']['MemAvailable'],effectiveMemoryHeadroomBytes=after['memory']['effectiveAvailableWorkingMemoryHeadroomBytes'],knownOwnedAlive=report['knownOwned']['alive'],noRuntimeAuthority=True)))
