// Prepared only. Gate precedes compiler imports and all output access.
import fs from 'node:fs';
import path from 'node:path';
import { createRequire } from 'node:module';
import { installIsolation } from './fs-isolation.mjs';
import { pathToFileURL } from 'node:url';
import { authorize, repo, scratch, sha, check, json, immutableInputs } from './binding.mjs';
const mode = process.argv[2];
const { manifest, policy, profile } = authorize(mode);
const allInputs = immutableInputs(manifest);
check(['dry', 'emit-pane', 'emit-reveal'].includes(mode) && process.argv.length === 3, 'Expected exact dry/emit-pane/emit-reveal mode');
check(process.env.VSCODE_LEASE_DIAGNOSTIC_EMITTER_MODE === mode, 'Wrong owned emitter mode');
const sourceRows = mode === 'dry' ? manifest.sourceFiles : manifest.sourceFiles.filter(row => row.outputPath === profile.emissionPhases[mode]);
check(allInputs.length === 2 && sourceRows.length === (mode === 'dry' ? 2 : 1) && policy.temporaryProductionJs === 1, 'Wrong dual dry or single-path emit selection');
const sourcePaths = sourceRows.map(r => r.sourcePath), outputPaths = sourceRows.map(r => r.outputPath);
const isolation = installIsolation({ repo, scratch, stage: mode, manifest });
const require = createRequire(path.join(repo, 'package.json'));
const ts = require('typescript'), gulp = require('gulp'), es = require('event-stream');
const compilationPath = path.join(repo, 'build/lib/compilation.ts');
const { createCompile } = await import(pathToFileURL(compilationPath).href);
const util = await import(pathToFileURL(path.join(repo, 'build/lib/util.ts')).href);
const { ESBuildTranspiler } = await import(pathToFileURL(path.join(repo, 'build/lib/tsb/transpiler.ts')).href);
const rootDir = path.join(repo, 'src'), projectPath = path.join(rootDir, 'tsconfig.json');
const read = ts.readConfigFile(projectPath, ts.sys.readFile);
if (read.error) throw Error(ts.flattenDiagnosticMessageText(read.error.messageText, '\n'));
const override = { verbose: false, sourceMap: !process.env.VSCODE_NO_SOURCEMAP, rootDir, baseUrl: rootDir, sourceRoot: util.toFileUri(rootDir), newLine: /\r\n/.test(fs.readFileSync(compilationPath, 'utf8')) ? 0 : 1, inlineSources: false, inlineSourceMap: true };
const parsed = ts.parseJsonConfigFileContent(read.config, ts.sys, rootDir, override);
check(parsed.errors.length === 0, 'Invalid actual src configuration');
const transpiler = new ESBuildTranspiler(() => {}, error => { throw Error(String(error)); }, projectPath, parsed);
const toolPackages = {};
for (const name of ['typescript', 'esbuild', 'gulp', 'vinyl']) {
 const file = require.resolve(name + '/package.json'), bytes = fs.readFileSync(file);
 toolPackages[name] = { packagePath: file, packageSha256: sha(bytes), packageVersion: JSON.parse(bytes).version, modulePath: require.resolve(name), runtimeVersion: require(name).version ?? null };
}
check(toolPackages.esbuild.packageVersion === manifest.esbuildPolicy.version && manifest.esbuildPolicy.version === '0.27.2' && process.platform === manifest.esbuildPolicy.platform && process.arch === manifest.esbuildPolicy.arch && !manifest.esbuildPolicy.binaryPath.includes('.zip/') && fs.realpathSync(manifest.esbuildPolicy.binaryPath) === manifest.esbuildPolicy.binaryResolvedPath && sha(fs.readFileSync(manifest.esbuildPolicy.binaryPath)) === manifest.esbuildPolicy.binarySha256, 'Unpinned native esbuild resolution');
const options = { repositoryAPI: 'build/lib/compilation.ts:createCompile', call: { src: 'src', build: false, emitError: true, transpileOnly: { esbuild: true }, preserveEnglish: false }, effectiveCompilerOptions: parsed.options, actualESBuildTranspilerOptions: transpiler._transformOpts, projectPath, overrides: override, sourceRule: 'Canonical repository Vinyl path/base; exact root-bound immutable Git blobs replace input contents before createCompile; no source writes', sourceInputs: sourceRows, expectedOutputPaths: outputPaths, actualInputCount: sourceRows.length, productionWriteCountAllowed: mode === 'emit-pane' ? 1 : 0, inlineSourceMap: true, standaloneMapAllowed: false, nodeVersion: process.version, nodeExecutable: process.execPath, toolPackages, repositoryBuildInputs: ['build/lib/compilation.ts', 'build/lib/util.ts', 'build/lib/tsb/index.ts', 'build/lib/tsb/transpiler.ts', 'build/lib/tsconfigUtils.ts', 'src/tsconfig.json', 'src/tsconfig.base.json'].map(p => ({ path: p, sha256: sha(fs.readFileSync(path.join(repo, p))) })) };
const optionsPath = path.join(scratch, mode + '-emitter-options.json');
check(!fs.existsSync(optionsPath), 'Refuse options overwrite');
fs.writeFileSync(optionsPath, JSON.stringify(options, null, 2) + '\n', { flag: 'wx' });
const expected = new Map(sourceRows.map(row => [path.resolve(repo, row.sourcePath), row]));
const generated = [], seen = new Set(), destination = path.join(isolation.stageRoot, 'generated');
check(!fs.existsSync(destination), 'Refuse generated artifact overwrite');
const inputs = sourceRows.map(row => row.sourcePath);
const replace = es.mapSync(file => {
 const row = expected.get(file.path);
 check(row !== undefined, 'Unexpected source input ' + file.path);
 file.contents = fs.readFileSync(row.inputCopyPath);
 const input = allInputs.find(input => input.row.sourcePath === row.sourcePath);
 check(input && file.contents.equals(input.bytes) && sha(file.contents) === row.sourceSha256 && file.contents.length === row.sourceBytes, 'Immutable input content/UTF8 changed');
 return file;
});
const enumerate = es.mapSync(file => {
 const output = path.relative(repo, path.resolve(repo, 'out', file.relative)).split(path.sep).join('/');
 check(outputPaths.includes(output) && !seen.has(output) && output.endsWith('.js'), 'Extra/duplicate/non-JS output ' + output);
 seen.add(output);
 const source = sourceRows.find(row => row.outputPath === output);
 generated.push({ outputPath: output, vinylPath: file.path, vinylBase: file.base, relativePath: file.relative, bytes: file.contents.length, sha256: sha(file.contents), sourceRef: source.sourceRef, sourceBlob: source.sourceBlob, sourceSha256: source.sourceSha256, role: source.role });
 return file;
});
const compile = createCompile('src', { build: false, emitError: true, transpileOnly: { esbuild: true }, preserveEnglish: false });
await util.streamToPromise(gulp.src(inputs, { base: 'src' }).pipe(replace).pipe(compile()).pipe(enumerate).pipe(gulp.dest(destination)));
generated.sort((a, b) => a.outputPath.localeCompare(b.outputPath));
check(JSON.stringify([...seen].sort()) === JSON.stringify(outputPaths), 'Pipeline did not emit exactly the selected authorized JS outputs');
const actualFiles = [];
function walk(dir) {
 for (const entry of fs.readdirSync(dir, { withFileTypes: true })) {
  const file = path.join(dir, entry.name);
  if (entry.isDirectory()) walk(file);
  else { check(entry.isFile() && !entry.isSymbolicLink(), 'Non-regular generated artifact'); actualFiles.push(path.relative(destination, file).split(path.sep).join('/')); }
 }
}
walk(destination);
actualFiles.sort();
check(JSON.stringify(actualFiles) === JSON.stringify(outputPaths.map(p => p.slice(4))), 'Unexpected generated artifact; no out writes allowed');
const report = { mode, atUtc: new Date().toISOString(), actualInputCount: sourceRows.length, repositoryCreateCompilePipeline: true, actualESBuildTranspiler: true, repositoryStreamToPromise: true, standaloneMapCount: actualFiles.filter(p => p.endsWith('.map')).length, generatedArtifactPaths: actualFiles.map(p => path.join(destination, p)), outputs: generated, outWriteFileCalls: [], noRepositorySourceWritten: true, productionOutWriteFileCalls: 0, fullCompileOfFinalSourceTree: false };
const reportPath = path.join(scratch, mode + '-emitter-report.json');
check(!fs.existsSync(reportPath), 'Refuse report overwrite');
if (mode !== 'dry') {
 const dry = json(path.join(scratch, 'dry-emitter-report.json'));
 check(dry.actualInputCount === 2 && dry.standaloneMapCount === 0 && dry.outWriteFileCalls.length === 0 && JSON.stringify(generated) === JSON.stringify(dry.outputs.filter(r => outputPaths.includes(r.outputPath))), 'Dry/emit exact output/byte enumeration differs; no out write performed');
 const seals = json(path.join(scratch, 'sealed-originals.json'));
 check(seals.length === 2 && seals.every(row => row.potentialWriteEligibility === true && row.restoreAuthority === false) && seals.some(row => row.path === outputPaths[0] && row.emissionPhase === mode), 'Each output needs a separate phase-bound potential seal; no standing restore authority');
 const drySeals = json(path.join(scratch, 'dry-output-seals.json'));
 check(drySeals.length === 2 && JSON.stringify(drySeals.map(row => row.outputPath).sort()) === JSON.stringify(profile.outputPaths), 'Dry must seal exactly two outputs');
 // Validate ALL originals and generated bytes before the FIRST out write.
 const preparedWrites = generated.map(row => {
  const target = path.resolve(repo, row.outputPath), seal = seals.find(item => item.path === row.outputPath);
  const metadata = fs.lstatSync(target, { bigint: true });
  check(seal && metadata.isFile() && !metadata.isSymbolicLink() && sha(fs.readFileSync(target)) === seal.sha256 && Number(metadata.mode & 0o7777n) === seal.mode && metadata.mtimeNs.toString() === seal.mtimeNsString && metadata.ctimeNs.toString() === seal.ctimeNsString, 'Out original changed before write');
  const drySeal = drySeals.find(item => item.outputPath === row.outputPath);
  check(drySeal && drySeal.sourceRef === sourceRows[0].sourceRef && drySeal.sourceBlob === sourceRows[0].sourceBlob && drySeal.sourceSha256 === sourceRows[0].sourceSha256 && drySeal.sealedArtifactPath === path.join(scratch, 'stage-dry', 'generated', row.outputPath.slice(4)), 'Wrong dry seal lineage/path');
  const bytes = fs.readFileSync(drySeal.sealedArtifactPath), regenerated = fs.readFileSync(path.join(destination, row.outputPath.slice(4)));
  check(bytes.equals(regenerated) && bytes.length === row.bytes && bytes.length === drySeal.bytes && sha(bytes) === row.sha256 && row.sha256 === drySeal.sha256, 'Sealed dry/regenerated exact bytes changed');
  return { row, target, bytes };
 });
 for (const { row, target, bytes } of preparedWrites) {
  // Compiler stream, scratch destination and all enumeration/seal audits completed.
  const authority = await isolation.requestWrite(row, bytes);
  isolation.writeOutputOnce(target, bytes);
  const call = { path: row.outputPath, absolutePath: target, bytes: bytes.length, sha256: sha(bytes), completedAtUtc: new Date().toISOString(), ...authority };
  report.outWriteFileCalls.push(call);
  report.productionOutWriteFileCalls += mode === 'emit-pane' ? 1 : 0;
  isolation.completeWrite(call);
 }
 report.isolation = isolation.summary();
 isolation.assertHealthy();
 fs.writeFileSync(reportPath, JSON.stringify(report, null, 2) + '\n', { flag: 'wx' });
} else fs.writeFileSync(reportPath, JSON.stringify(report, null, 2) + '\n', { flag: 'wx' });
isolation.assertHealthy();
console.log(JSON.stringify({ mode, actualInputs: sourceRows.length, exactEnumeratedOutputs: generated.map(row => row.outputPath), standaloneMapCount: report.standaloneMapCount, outWriteFileCallCount: report.outWriteFileCalls.length, productionOutWriteFileCalls: report.productionOutWriteFileCalls, repositoryCreateCompilePipeline: true }));
