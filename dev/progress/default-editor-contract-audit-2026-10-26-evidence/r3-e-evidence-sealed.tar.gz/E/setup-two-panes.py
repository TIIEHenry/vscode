from pathlib import Path
import json,subprocess,sys
base=Path(__file__).resolve().parent;sys.path.insert(0,str(base.parent/'common'))
from gates import verify,read
proof=verify('E',native=False,require_launch=True);session=read(base.parent/'run-config.json')['fixtureSession']
def step(action):
    path=base/'steps'/(action['label']+'.json');assert not path.exists()
    r=subprocess.run(['rtk','proxy','node',str(base/'driver.cjs'),json.dumps(action)],capture_output=True,text=True)
    with (base/'driver-stdout.jsonl').open('a') as f:f.write(json.dumps({'action':action,'exit':r.returncode,'stdout':r.stdout,'stderr':r.stderr})+'\n')
    assert r.returncode==0,r.stdout+r.stderr
    return read(path)
a=step({'type':'revealSession','id':session,'options':{'replace':'untitled'},'label':'02-r3-public-reveal-fresh-session','waitMs':1000})
part=next(p for p in a['state']['parts'] if p['sessionKey']==session);assert len(part['groups'])==1;group=part['groups'][0];index=next(i for i,e in enumerate(group['editors']) if e['resource']=='conversation-chat:/session/'+session+'/chat/default')
step({'type':'command','id':'workbench.action.splitEditorRight','args':[{'groupId':group['id'],'editorIndex':index}],'label':'03-r3-public-split-real-pane','waitMs':800})
step({'type':'layoutHide','label':'04-r3-hide-other-parts'})
final=step({'type':'evenGroups','session':session,'label':'05-r3-even-two-panes'})
panes=final['state']['actualPaneDiagnostics'];assert len(panes)==2 and len({p['groupId'] for p in panes})==2 and all(p['leaseSessionId']==session for p in panes);assert all(not p['snapshot']['timeline'] and not p['snapshot']['pendingActions'] for p in panes)
print(json.dumps({'phase':'E','runId':proof['runId'],'actualGroupIds':[p['groupId'] for p in panes],'distinctActualPanes':True,'freshEmptyTargetTimelineAndPending':True}))
