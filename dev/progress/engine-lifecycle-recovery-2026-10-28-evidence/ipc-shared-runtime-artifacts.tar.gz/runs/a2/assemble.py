#!/usr/bin/env python3
"""Static snapshot/closure assembly only. Does not start Node or update out."""
import ast
from collections import deque
from datetime import datetime, timezone
import hashlib
import json
import os
from pathlib import Path, PurePosixPath
import re
import subprocess

repo = Path('/home/clarence/Projects/Agents/vscode-WorkTrees/C')
scratch = Path(__file__).resolve().parent
prep = repo / '.build/engine-lifecycle-validation-20261028/ipc-s1-preparation'
baseline = '2f35686b611c60355c42d58a11c2e6d8638ba7cb'
head = '0e3310ee67482b9502503747826f0ef3aa78c863'
prefix = 'src/vs/platform/universeAgent/'
freeze = dict((prefix + name, digest) for name, digest in [
    ('common/universeAgentExpectedOwner.ts', 'e0e1b5357d81c0d77fdb3f106594c6c428576e271b5488f2cf0684952edc2616'),
    ('common/universeAgentConnection.ts', 'b856d8d936edbf455319856fbf2da709b3cc79f4a46f962e5589b0c25b711735'),
    ('common/universeAgentConnectionIpcChannel.ts', '98eff55a5525169cc25c7b82aa9b5a5139c2ecb7d031222a9cc5b5825bcba476'),
    ('node/universeAgentConnectionService.ts', '75bbdec55e3298a6462c4a9ed6cbf31acfc2366f28ddeeb7d5415a0c31c53516'),
    ('test/common/universeAgentExpectedOwner.test.ts', 'ebf7d6897970db0929e05a479a7e1ae9ad407868daf1ce7aba3336b713b25dd8'),
    ('test/node/universeAgentConnection.test.ts', '1cebeede10f2b09583809064697eb8a70101d80bcccb321a2c43deda636ba62b'),
    ('test/node/universeAgentConnectionIpcChannel.test.ts', 'd673a925a9a9c6e392c3849dc9c8dee06135d3d134ff52f7231718feb3d80b94'),
])
sha = lambda data: hashlib.sha256(data).hexdigest()
git = lambda *args: subprocess.check_output(['git', *args], cwd=repo)
assert git('rev-parse', 'HEAD').decode().strip() == head
frozen = {path: (repo / path).read_bytes() for path in freeze}
assert all(sha(frozen[path]) == digest for path, digest in freeze.items())
tree = {}
for row in git('ls-tree', '-r', '-z', baseline).split(b'\0'):
    if row:
        meta, name = row.split(b'\t', 1)
        mode, kind, blob = meta.decode().split()
        tree[name.decode()] = blob
cache = {}
def raw(path):
    if path not in cache:
        cache[path] = git('cat-file', 'blob', tree[path])
    return cache[path]

# Strip comments while preserving quoted strings/newlines. Import statements are
# selected at line boundaries; inline import()/require() literals are also walked.
lex = re.compile(r"(?P<string>'(?:\\.|[^'\\])*'|\"(?:\\.|[^\"\\])*\"|`(?:\\.|[^`\\])*`)|(?P<line>//[^\n]*)|(?P<block>/\*[\s\S]*?\*/)")
def clean(text):
    return lex.sub(lambda m: m.group() if m.lastgroup == 'string' else ''.join('\n' if c == '\n' else ' ' for c in m.group()), text)

statement = re.compile(r"(?m)^\s*(?P<kind>import|export)\s+(?P<body>(?:(?!;)[\s\S])*?);", re.M)
spec_re = re.compile(r"\bfrom\s*['\"]([^'\"]+)['\"]")
literal = re.compile(r"\b(?P<kind>import|require)\s*\(\s*['\"](?P<spec>[^'\"]+)['\"]\s*\)")

def imports(data):
    text = clean(data.decode(errors='strict'))
    refs, types = [], []
    for m in statement.finditer(text):
        body = m['body'].strip()
        sm = spec_re.search(body)
        if sm:
            spec = sm[1]
        elif m['kind'] == 'import' and body[:1] in ["'", '"']:
            spec = body[1:].split(body[0], 1)[0]
        else:
            continue
        if body.startswith('type ') or re.fullmatch(r"\{\s*(?:type\s+[^,}]+\s*,?\s*)+\}\s+from[\s\S]*", body):
            types.append(spec)
        else:
            refs.append((m['kind'], spec))
    for m in literal.finditer(text):
        refs.append((m['kind'] + '-literal', m['spec']))
    return refs, types

def resolve(source, spec, available):
    spec = spec.split('?', 1)[0]
    if spec.startswith('.'):
        rel = os.path.normpath(str(PurePosixPath(source).parent / spec))
    elif spec.startswith('vs/'):
        rel = 'src/' + spec
    else:
        return None
    candidates = [rel]
    if rel.endswith('.js'):
        candidates = [rel[:-3] + '.ts', rel]
    elif not PurePosixPath(rel).suffix:
        candidates += [rel + '.ts', rel + '.js', rel + '/index.ts', rel + '/index.js']
    found = next((x for x in candidates if x in available and not x.endswith('.d.ts')), None)
    if found is None and any(x[:-3] + '.d.ts' in available for x in candidates if x.endswith('.js')):
        return '@declaration-only:' + rel
    if found is None:
        raise RuntimeError(('unresolved internal import', source, spec, candidates))
    return found

business = [prefix + 'test/node/universeAgentConnection.test.ts', prefix + 'test/node/universeAgentConnectionIpcChannel.test.ts']
green = business + [prefix + 'test/common/universeAgentExpectedOwner.test.ts', prefix + 'test/node/universeAgentConnectionChannelClientScan.test.ts']
productions = [path for path in freeze if '/test/' not in path]
graphs, snapshots, externals, type_edges = {}, {}, {}, {}
for phase, roots in [('old', business), ('new', green + productions)]:
    queue = deque(roots)
    seen, edges, external, omitted = {}, [], [], []
    available = set(tree) | (set(freeze) if phase == 'new' else set(business))
    while queue:
        source = queue.popleft()
        if source in seen:
            continue
        use_frozen = source in (freeze if phase == 'new' else business)
        data = frozen[source] if use_frozen else raw(source)
        role = 'frozen-test' if source in green and use_frozen else 'frozen-production' if use_frozen else 'raw-2f'
        seen[source] = (data, role)
        if not source.endswith(('.ts', '.js')):
            continue
        refs, types = imports(data)
        omitted.extend({'source': source, 'specifier': spec} for spec in types)
        for kind, spec in refs:
            target = resolve(source, spec, available)
            if target and target.startswith('@declaration-only:'):
                omitted.append({'source': source, 'specifier': spec, 'reason': 'declaration-only module, erased by TypeScript emission'})
            elif target:
                edges.append({'source': source, 'target': target, 'kind': kind, 'specifier': spec})
                queue.append(target)
            else:
                external.append({'source': source, 'kind': kind, 'specifier': spec})
    entries = []
    for source, (data, role) in sorted(seen.items()):
        path = scratch / 'snapshots' / phase / source
        path.parent.mkdir(parents=True, exist_ok=True)
        with path.open('xb') as stream:
            stream.write(data)
        out = repo / 'out' / source[4:]
        if source.endswith('.ts'):
            out = out.with_suffix('.js')
        entries.append({'source': source, 'snapshot': str(path), 'out': str(out), 'sha256': sha(data), 'bytes': len(data), 'kind': 'ts' if source.endswith('.ts') else 'resource', 'role': role, 'baselineBlob': tree.get(source) if role == 'raw-2f' else None})
    graphs[phase], snapshots[phase], externals[phase], type_edges[phase] = edges, entries, external, omitted

assert not any('universeAgentExpectedOwner' in x['source'] for x in snapshots['old'])
# Refresh only changed/new new-phase entries; reused outputs stay tied to old identity.
old_map = {x['source']: x for x in snapshots['old']}
new_entries = [x for x in snapshots['new'] if x['source'] not in old_map or x['sha256'] != old_map[x['source']]['sha256']]

def write(name, value):
    with (scratch / name).open('x') as stream:
        json.dump(value, stream, indent=2)
        stream.write('\n')

manifest = {'frozen': True, 'baseline': baseline, 'repo': str(repo), 'scratch': str(scratch), 'frozenHead': head,
            'sourceSha256': freeze, 'transpileHelperSha256': sha((repo / 'build/next/transpile.ts').read_bytes()),
            'phases': {'old': snapshots['old'], 'new': new_entries}, 'oldTests': business, 'newTests': green,
            'lintPaths': sorted(freeze), 'notes': ['Python static closure freshly resolved for S1; type-only declarations omitted, unmarked type imports conservatively included.', 'Author freeze and independent Astra C0/I0/M0 received; parent runtime authorization is separate from manifest frozen status.', 'All raw old bytes are exact Git 2f blobs; no adaptation to business control flow.', 'New phase refreshes only changed/new entries. Full new graph and snapshots retained in closure.json.']}
write('manifest.json', manifest)
write('closure.json', {'graphs': graphs, 'completePhases': snapshots, 'externalImports': externals, 'explicitTypeOnlyOmitted': type_edges})

# Capture private output topology without changing it; reject links/shared file inodes.
out = repo / 'out'
topology = {'root': str(out), 'files': 0, 'bytes': 0, 'symlinks': [], 'hardlinks': []}
for path in [out, *out.rglob('*')]:
    stat = path.lstat()
    if path.is_symlink():
        topology['symlinks'].append(str(path))
    elif path.is_file():
        topology['files'] += 1
        topology['bytes'] += stat.st_size
        if stat.st_nlink > 1:
            topology['hardlinks'].append(str(path))
assert not topology['symlinks'] and not topology['hardlinks'], topology
write('out-topology-before.json', topology)

controls = ['build/next/transpile.ts', 'test/unit/node/index.js', 'test/unit/node/nodeUnitTestExitCode.js', 'package.json', 'package-lock.json', 'product.json', 'remote/.npmrc', 'src/vs/platform/universeAgent/common/universeAgentConnectionChannelClient.ts']
identities = [{'source': path, 'bytes': len((repo/path).read_bytes()), 'sha256': sha((repo/path).read_bytes())} for path in controls]
processes = []
for path in Path('/proc').iterdir():
    if path.name.isdigit():
        try:
            command = (path/'cmdline').read_bytes().replace(b'\0', b' ').decode(errors='replace')
            if re.search(r'(?:/|\s)(?:gulp\.js|tsc(?:\.js)?|tsgo)(?:\s|$)|npm run (?:compile|typecheck|transpile)|test/unit/(?:node|electron)/index\.js|scripts/test\.sh|node[^\n]*transpile[^\n]*\.mjs', command) and int(path.name) != os.getpid():
                processes.append({'pid': path.name, 'command': command[:700]})
        except OSError:
            pass
capacity = {str(path): {'availableBytes': os.statvfs(path).f_bavail * os.statvfs(path).f_frsize} for path in [scratch, repo]}
assert git('rev-parse', 'HEAD').decode().strip() == head
assert all(sha((repo/path).read_bytes()) == digest for path, digest in freeze.items())
ast.parse((prep/'s1-runner.py').read_text())
report = {'createdUtc': datetime.now(timezone.utc).isoformat(), 'head': head, 'frozen7Match': True, 'manifestSha256': sha((scratch/'manifest.json').read_bytes()), 'oldClosureEntries': len(snapshots['old']), 'completeNewClosureEntries': len(snapshots['new']), 'newReplacementEntries': len(new_entries), 'snapshotBytes': sum(x['bytes'] for rows in snapshots.values() for x in rows), 'controlInputs': identities, 'outTopology': topology, 'capacity': capacity, 'processesBeforeAssemblyOnly': processes, 'runtimeStarted': False, 'locksAcquired': False, 'outMutated': False}
write('assembly-report.json', report)
print(json.dumps({k: v for k, v in report.items() if k not in ['controlInputs', 'outTopology']}))
