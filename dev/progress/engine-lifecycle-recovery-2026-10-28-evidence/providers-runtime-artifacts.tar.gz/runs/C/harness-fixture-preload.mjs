import {registerHooks} from 'node:module';
import {readFileSync,appendFileSync} from 'node:fs';
import {fileURLToPath,pathToFileURL} from 'node:url';
import assert from 'node:assert/strict';
const root="/home/clarence/Projects/Agents/vscode-WorkTrees/C";
const scratch="/home/clarence/Projects/Agents/vscode-WorkTrees/C/.build/engine-lifecycle-validation-20261028/C";
const target=root+'/out/vs/platform/universeAgent/node/harnessProviderImport.js';
const fixture=JSON.parse(readFileSync(scratch+'/harness-fixture.json','utf8'));
const trace=scratch+'/'+process.env.HARNESS_TRACE_PHASE+'-harness-isolation.jsonl';
const record=x=>appendFileSync(trace,JSON.stringify(x)+'\n');
let phase='preflight';let reads=0;
globalThis.__engineImportFixtureRead=()=>{record({event:'fixture-read',phase,n:++reads});return structuredClone(fixture);};
registerHooks({load(url,context,nextLoad){
 const pathname=url.startsWith('file:')?fileURLToPath(url):'';
 if(pathname===target){record({event:'intercept',path:pathname});return {format:'module',shortCircuit:true,source:'export const __fixtureIsolation=true; export function readLocalHarnessProviderDrafts(){return globalThis.__engineImportFixtureRead();}'};}
 if(pathname.endsWith('/node/harnessProviderImport.js'))throw new Error('harness fixture escaped exact private output');
 return nextLoad(url,context);
}});
const isolated=await import(pathToFileURL(target).href);
assert.equal(isolated.__fixtureIsolation,true);
assert.deepEqual(isolated.readLocalHarnessProviderDrafts(),fixture);
record({event:'preflight-ok',fixtureCount:fixture.length});phase='runner';
process.on('exit',()=>record({event:'exit',reads,runnerReads:reads-1}));
