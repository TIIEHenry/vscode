from pathlib import Path
D=Path('/sdd/tmp/vscode-conversation-visible-lease-old-business-20261028-prep3-review')
ns={'__name__':'own_support'}
exec(compile((D/'static-support-and-protection.py').read_bytes(),str(D/'static-support-and-protection.py'),'exec'),ns)
globals().update({k:v for k,v in ns.items() if not k.startswith('__')})
workspace();assert readj(D/'phase1.actual-result.json')['actualExitCode']==0
old_context_raw=(OLD/'context-content-inventory.json').read_bytes();old_context=json.loads(old_context_raw)
old_external_raw=(OLD/'external-reference-closure.json').read_bytes();old_external=json.loads(old_external_raw)
oldmap={x['path']:x for x in old_context['rows']};rows=[];counts={};external_aliases={}
for scope in ['src','.build','node_modules','out','build']:
 entries=sorted([R/scope,*(R/scope).rglob('*')],key=lambda p:p.relative_to(R).as_posix());regular=total=0
 for p in entries:
  name=p.relative_to(R).as_posix();wanted=oldmap[name];current={'path':name,**meta(p)};assert current=={k:v for k,v in wanted.items() if k!='sha256'},name
  if current['type']==stat.S_IFREG:current['sha256']=wanted['sha256'];regular+=1;total+=current['size']
  rows.append(current)
  if p.is_symlink():
   target=p.resolve()
   if not target.is_relative_to(R):external_aliases.setdefault(str(target),[]).append(dict(path=str(p),metadata=meta(p)))
 counts[scope]=dict(entriesIncludingRoot=len(entries),regularFilesWithAcceptedHashes=regular,regularLogicalBytes=total,newWholeContentHashes=0)
assert len(rows)==119095 and {x['path'] for x in rows}==set(oldmap)
xjson(P/'context-content-inventory.json',dict(scope='Fresh complete metadata/pathset capture of five repository roots. Every regular SHA is reused from exact accepted frozen prep2 context after full mode/type/size/mtime/ctime/symlink metadata equality; no fresh5GB content hash or new full-content freshness claim.',capturedAtUtc=now(),expectedHead=H,sourceTree=T,counts=counts,rows=rows,acceptedContentHashAuthority=dict(originalPath=str(OLD/'context-content-inventory.json'),bytes=len(old_context_raw),sha256=sha(old_context_raw)),freshPathsetsAndMetadataExact=True,reusedAcceptedRegularHashes=sum('sha256' in x for x in rows),newWholeContextRegularHashes=0,atimeExcluded=True,fullCompileOfFinalSourceTree=False,originalWholeBuildProtectionPassed=False))
assert sum('sha256' in x for x in rows)==102720
newmap={x['path']:x for x in rows}
groups=[]
for old in old_external['externalSymlinkTargets']:
 root=Path(old['target']);entries=sorted([root,*root.rglob('*')],key=str) if root.exists() and root.is_dir() else [root] if root.exists() or root.is_symlink() else []
 assert {str(p) for p in entries}=={x['path'] for x in old['rows']},str(root)
 actual=[];wantmap={x['path']:x for x in old['rows']}
 for q in entries:
  wanted=wantmap[str(q)];x={'path':str(q),**meta(q)};assert x=={k:v for k,v in wanted.items() if k!='sha256'},str(q)
  if 'sha256' in wanted:x['sha256']=wanted['sha256']
  actual.append(x)
 for alias in old['aliases']:
  q=Path(alias['path']);assert meta(q)==alias['metadata'] and str(q.resolve())==old['target']
 group={**old,'rows':actual};groups.append(group)
# The five accepted target groups include one finite file also nested in esbuild.
# It is a separately bound finite target, not another original-protection child root.
assert len(groups)==5 and sum(len(g['rows']) for g in groups)==27318
for target,aliases in external_aliases.items():
 found=next((g for g in groups if g['target']==target),None);assert found is not None,target
 assert all(alias in found['aliases'] for alias in aliases),target
assets=readj(P/'native-asset-manifest.json');assert len(assets['files'])==11168
for x in assets['files']:
 current=newmap[x['path']];assert current['size']==x['bytes'] and current['sha256']==x['sha256'] and stat.S_IMODE(current['fullMode'])==x['mode'],x['path']
for x in readj(P/'current-workspace-source-descriptions.json')['rows']:
 current=newmap[x['sourcePath']];assert current['size']==x['currentSourceBytes'] and current['sha256']==x['currentSourceSha256'],x['sourcePath']
xjson(P/'accepted-content-hash-provenance.json',dict(capturedAtUtc=now(),workspaceHead=H,sourceTree=T,contextAuthority=dict(path=str(OLD/'context-content-inventory.json'),bytes=len(old_context_raw),sha256=sha(old_context_raw)),externalAuthority=dict(path=str(OLD/'external-reference-closure.json'),bytes=len(old_external_raw),sha256=sha(old_external_raw)),freshMetadataAndFullPathsetsChecked=True,contextEntries=119095,acceptedContextRegularHashes=102720,externalEntries=27318,acceptedExternalRegularHashes=sum('sha256' in x for g in groups for x in g['rows']),freshFullContextAndExternalContentHashCount=0,contentHashesRetainOriginalFrozenProvenance=True,sourceTreeUnchangedFromAcceptedOriginal=True,native11168AcceptedHashesAndCurrentMetadataQualified=True,currentWorkspaceDescriptionsAcceptedSourceHashesAndMetadataQualified=True,noCurrentBlanketFiveGigabyteHashClaim=True,noDynamicLoadOrProducerCredit=True))
preserve=[(OLD/'immutable-protection-inventory.json','prior3238-immutable-inventory.original.json'),(OD/'authorized-old-once-20261027T184023447555Z/postrun-package-inventory.json','consumed-old-prep2-postrun.original.json'),(OD/'package-final-audit.anchor.json','consumed-old-prep2-prepared0-audit-anchor.original.json'),(VR/'final-source-only-directory-inventory.json','source-v3-all75-frozen.original.json')]
for src,dest in preserve:write(P/'preservation'/dest,src.read_bytes())
xjson(P/'preservation/complete-original-root-contract.json',dict(legacyDescendantOnlyRoots=readj(P/'immutable-protection-inventory.json')['roots'],rootInclusiveRoots=readj(P/'immutable-protection-inventory.json')['additionalRootInclusiveRoots'],legacyRows=2018,rootInclusiveRows=len(readj(P/'immutable-protection-inventory.json')['additionalRootInclusiveRows']),combinedRows=readj(D/'targeted-protection-before-assembly.json')['combinedImmutableRows'],nineFreshCounts=readj(D/'targeted-protection-before-assembly.json')['nineFreshRootInclusiveCounts'],original3238RowsPreservedExactly=True,rootInclusiveFreshEnumeration=True,noOriginalMovedChangedOrReclassified=True,noV1ReviewOrDiagnosticPrep1ReviewInvented=True,noCurrentPackageReviewOrOngoingIIncluded=True))
provenance=[]
for name in ['AGENTS.md','docs/DOCUMENTATION.md','docs/DOCS-SPEC.md','docs/INDEX.md','.github/copilot-instructions.md','dev/progress/status.md','dev/plans/conversation-visible-lease-recovery.md','dev/parallel/active/sources-accept-post-read-authorization.md']:
 src=R/name;data=src.read_bytes();assert data==git('show',H+':'+name);dest='current-workspace-provenance/'+name;write(P/dest,data)
 provenance.append(dict(path=str(src),sourceRef=H,bytes=len(data),sha256=sha(data),metadata=meta(src),copyPath=dest))
direct={}
def ref(path,role):
 q=Path(path);key=str(q);b=q.read_bytes();m=meta(q)
 if key in direct:
  assert direct[key]['originalMetadata']==m and direct[key]['sha256']==sha(b)
  if role not in direct[key]['roles']:direct[key]['roles'].append(role)
 else:direct[key]=dict(originalPath=key,roles=[role],originalMetadata=m,bytes=len(b),sha256=sha(b),operationalPathUnchanged=True,originalBytesCopiedIntoPackage=False)
for x in old_external['directFileReferences']:
 q=Path(x['originalPath']);assert meta(q)==x['originalMetadata'] and q.stat().st_size==x['bytes'] and digest(q)==x['sha256'];ref(q,'historical-prep2-direct-reference')
manifest=readj(P/'input-manifest.json')
for k in ['baselineFile','oldD8ePreservationInventory','oldF33PreservationInventory','oldOwnedReport']:ref(manifest[k],'runtime-direct-'+k)
for q,role in [(N/'guard-after-restore.json','runtime-only-715-predecessor'),(OLD/'guard-after-restore.json','consumed-failure-e182-not-runtime-predecessor'),(V/'source-freeze.json','original-v3-freeze-pending-label-preserved'),(VR/'authorized-single-mjs-syntax-20261027T190551935133Z/syntax-receipt.json','accepted-prior-single-syntax-receipt'),(OLD/'context-content-inventory.json','accepted-context-content-hash-authority'),(OLD/'external-reference-closure.json','accepted-external-content-hash-authority')]:ref(q,role)
for src,dest in preserve:ref(src,'closed-original-preservation-anchor')
for source in readj(P/'source-provenance.json')['runtimeSourceFiles']:ref(V/'candidate'/source['name'],'fixed-v3-source-original')
for x in manifest['boundToolAndConfigFiles']:ref(x['path'],'runtime-bound-tool-or-config')
for source in readj(P/'source-provenance.json')['reviewedV3PublicationCopies']:ref(R/source['path'],'fixed5f-publication-original-live-equals-git')
for n in sorted(p.name for p in D.iterdir() if p.is_file()):
 q=D/n;ref(q,'current-executor-static-preparation-evidence');write(P/'preparation-evidence'/n,q.read_bytes())
executables=[]
for q in [Path('/usr/bin/python3'),Path('/usr/bin/python3.10'),Path('/usr/bin/xvfb-run'),Path('/home/clarence/.hermes/node/bin/node')]:
 b=q.read_bytes();executables.append(dict(path=str(q),metadata=meta(q),resolvedPath=str(q.resolve()),resolvedMetadata=meta(q.resolve()),bytes=len(b),sha256=sha(b),executedNow=False))
 if q.resolve()!=q:ref(q.resolve(),'resolved-executable-static-identity')
xjson(P/'external-reference-closure.json',dict(capturedAtUtc=now(),scope='Fresh metadata/pathset closure with accepted frozen hashes for full external targets. Direct file references freshly content/metadata checked. Static filesystem evidence only; no universal OS/ELF closure or dynamically observed loads.',directFileReferences=sorted(direct.values(),key=lambda x:x['originalPath']),currentProvenance=provenance,externalSymlinkTargets=groups,executableResolutions=executables,acceptedExternalHashAuthority=dict(path=str(OLD/'external-reference-closure.json'),bytes=len(old_external_raw),sha256=sha(old_external_raw)),fullExternalRegularContentRehashed=False,allExternalMetadataAndPathsetsFreshlyExact=True,originalInventoryReferences=[dict(path='immutable-protection-inventory.json',legacyRows=2018,additionalRootInclusiveRows=len(readj(P/'immutable-protection-inventory.json')['additionalRootInclusiveRows']),combinedRows=readj(D/'targeted-protection-before-assembly.json')['combinedImmutableRows'])],runtimeMutablePathsNotInputs=['/tmp/vscode-compile.lock','/tmp/.X11-unix/automatic-display','/tmp/automatic-display-lock'],platformBoundary='System shared ELF/OS packages, X server binaries, kernel and environment remain platform dependencies. Child mount namespace inheritance remains source inference; no future runtime child observed.',executionAuthorized=False,activationAuthorized=False))
xjson(P/'static-versus-runtime-protection-scope.json',dict(capturedAtUtc=now(),freshFullMetadataContextCounts=counts,acceptedFullContentHashesRetainFrozenProvenance=True,fullContextAndExternalHashRepeatCount=0,runtimeGuardMetadataRoots=['src','.build','node_modules','out'],runtimeGuardContentBound='Listed source/native256 pairs,149 tool/config bindings, freeze4/cache3, listed legacy2018 and root-inclusive2151 original regular files, historical reports/pins and original output backups; independent metadata pre/post/poststream scope.',prePostSamplingNotEverySyscall=True,atimeExcluded=True,noRuntimeBlanketFiveGigabyteHashClaim=True,wholeBuildProtectionPassed=False,goEsbuildWritesOutsideNodeHooksRemainPossible=True,metadataAndIndependentPoststreamProtectionRequired=True))
xjson(P/'ambient-dependency-closure.json',dict(capturedAtUtc=now(),fullRepositoryContext='context-content-inventory.json',fullExternalTargets='external-reference-closure.json',contentHashProvenance='accepted-content-hash-provenance.json',protectionScope='static-versus-runtime-protection-scope.json',boundToolAndConfigFileCount=149,boundFileList='bound-tool-and-config-files.json',ambientRoots=list(counts),counts=counts,futureNodeCompileCacheDisabled=True,goEsbuildWritesOutsideNodeHooksRemainPossible=True,completeMetadataGuardAndIndependentPoststreamGuardRequired=True,originalWholeBuildProtectionPassed=False,noRuntimeCredit=True))
xjson(P/'preparation-invocations.json',dict(preparedInvocations=0,candidateImports=0,candidateExecutions=0,syntaxCalls=0,programOrCheckerInvocations=0,eslintInvocations=0,dryInvocations=0,emitInvocations=0,officialInvocations=0,engineInvocations=0,uiInvocations=0,lockProbeInvocations=0,recordersExecuted='Executor-owned Python static recorders/builders only',sourceEdits=0))
summary=dict(capturedAtUtc=now(),workspaceHead=H,sourceTree=T,contextEntryCount=len(rows),acceptedContextRegularHashes=sum('sha256' in x for x in rows),acceptedContextRegularBytes=sum(x['size'] for x in rows if 'sha256' in x),contextCounts=counts,externalTargetGroups=len(groups),externalTargetEntries=sum(len(g['rows']) for g in groups),acceptedExternalRegularHashes=sum('sha256' in x for g in groups for x in g['rows']),acceptedExternalRegularBytes=sum(x['size'] for g in groups for x in g['rows'] if 'sha256' in x),wholeContextOrExternalContentHashesRepeated=0,directExternalFileReferences=len(direct),combinedImmutableRows=readj(D/'targeted-protection-before-assembly.json')['combinedImmutableRows'],candidateInvocations=0,packageNotFinalYet=True)
xjson(D/'phase2-static-closure.json',summary);workspace();print(json.dumps(summary))
