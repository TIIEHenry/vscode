from pathlib import Path
import hashlib,json,sys
root=Path(__file__).resolve().parent.parent;phase=sys.argv[1];assert phase in ['J','E'];sys.path.insert(0,str(root/'common'));from gates import verify
verify(phase,native=False,require_launch=True)
base=root/phase;notice=json.loads((root/'common'/('freeze-'+phase+'.json')).read_text());assets=json.loads((base/('runtime-assets-final-'+phase+'.json')).read_text());asset=next(a for a in assets['assets'] if a['path'].endswith('/conversationLens.css'));evidence=asset['runtimeEvidence'][0];data=Path(evidence['copy']).read_bytes();text=data.decode('utf8');inverse={}
for i in range(256):
    try:c=bytes([i]).decode('cp1252')
    except UnicodeDecodeError:c=chr(i)
    inverse[c]=i
sha=lambda b:hashlib.sha256(b).hexdigest();rawMatch=sha(data)==asset['sha256'];recovered=data if rawMatch else bytes(inverse[c] for c in text);assert sha(recovered)==asset['sha256'];cssom=json.loads((base/'cssom-native-final-reference-comparison.json').read_text());assert cssom['allRulesExact'] and cssom['actualRules']==cssom['referenceRules']
result={'runId':notice['runId'],'rawCdpCopy':evidence['copy'],'rawBytesMatch':rawMatch,'nativeBytesIdentified':True,'recovery':'raw byte equality' if rawMatch else 'complete windows1252 inverse mapping of observed text','recoveredNativeSha256':sha(recovered),'recoveredByteCount':len(recovered),'actualCssomAllRulesExact':True,'actualCssomRuleCount':len(cssom['actualRules']),'rawCdpUtf8Sha256':sha(data),'frozenNativeSha256':asset['sha256'],'noProductGlyphDefectInferredFromRawEncodingDifference':True};out=base/'css-typed-final-identity.json';assert not out.exists();out.write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result))
