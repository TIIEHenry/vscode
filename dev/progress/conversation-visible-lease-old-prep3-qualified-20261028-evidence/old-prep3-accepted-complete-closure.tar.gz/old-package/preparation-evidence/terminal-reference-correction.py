from pathlib import Path
D=Path('/sdd/tmp/vscode-conversation-visible-lease-old-business-20261028-prep3-review')
ns={'__name__':'own_support'}
exec(compile((D/'static-support-and-protection.py').read_bytes(),str(D/'static-support-and-protection.py'),'exec'),ns)
globals().update({k:v for k,v in ns.items() if not k.startswith('__')})
workspace()
xjson(D/'root-forwarded-narrow-disposition-and-continuation-authority.json',dict(capturedAtUtc=now(),provenance='Executor-attributed root-forwarded Original Astra narrow disposition and root authorization; not raw/verbatim/original reviewer message bytes.',sevenHistoricalC6VsCurrent649DocumentationReferencesAccepted=True,noNormativeAmendmentOrRuntimeSourceReReviewRequired=True,ownPhase2ActualExit1Preserved=True,ownContinuationActualExit0Preserved=True,importantFinding='Continuation self stdout/stderr were sampled while in flight; retain those snapshots and original rows; separately capture terminal raw/receipt/source bytes and fullmetadata; only exact two rows may change. All other old288 refs remain strict.',authorizedScope='Own prep3/review static data correction, independent terminal capture, inactive prepared0 release/pins/audit/closed inventory and handoff, then stop for whole peer.',executionAuthorized=False,activationAuthorized=False,noSourceBaselineOrOriginalMutation=True,noWholeContextContentHashRepeat=True))
path=P/'external-reference-closure.json';original=path.read_bytes();original_meta=meta(path);closure=json.loads(original)
expected_paths={str(D/'phase2-continuation.stdout.raw'),str(D/'phase2-continuation.stderr.raw')}
corrections=[]
for index,old in enumerate(closure['directFileReferences']):
 q=Path(old['originalPath'])
 if str(q) not in expected_paths:
  assert meta(q)==old['originalMetadata'] and q.stat().st_size==old['bytes'] and digest(q)==old['sha256'],str(q)
  continue
 b=q.read_bytes();assert old['bytes']==0 and old['sha256']==sha(b'')
 assert (P/'preparation-evidence'/q.name).read_bytes()==b''
 dest='preparation-evidence/terminal-phase2-continuation/'+q.name;write(P/dest,b)
 new={**old,'originalMetadata':meta(q),'bytes':len(b),'sha256':sha(b),'roles':['completed-own-phase2-continuation-terminal-output'],'terminalCopyPath':dest,'sampleState':'POST_EXIT_COMPLETE'}
 corrections.append(dict(originalPath=str(q),oldInFlightRow=old,newTerminalRow=new,originalInFlightCopyPath='preparation-evidence/'+q.name,originalInFlightCopyMetadata=meta(P/'preparation-evidence'/q.name),terminalCopyPath=dest,terminalCopyMetadata=meta(P/dest),exceptionScope='Only these two continuation outputs; not one of the seven historical-document cases.'))
 closure['directFileReferences'][index]=new
assert {x['originalPath'] for x in corrections}==expected_paths
receipt=D/'phase2-continuation.actual-result.json';receipt_raw=receipt.read_bytes();r=json.loads(receipt_raw);assert r['actualExitCode']==0
for stream in ['stdout','stderr']:
 q=Path(r[stream]['path']);b=q.read_bytes();assert len(b)==r[stream]['bytes'] and sha(b)==r[stream]['sha256']
assert r['stdout']['bytes']==1349 and r['stdout']['sha256']=='ea6c4d48487c9a6707533a24fc76ab88f29183b2965c6ba37e570f2a0206e604'
terminal=[]
for q in [receipt,D/'static-assembly-phase2-continuation.py']:
 b=q.read_bytes();dest='preparation-evidence/terminal-phase2-continuation/'+q.name;write(P/dest,b)
 record=dict(originalPath=str(q),roles=['completed-own-phase2-continuation-terminal-receipt-or-source'],originalMetadata=meta(q),bytes=len(b),sha256=sha(b),operationalPathUnchanged=True,originalBytesCopiedIntoPackage=True,terminalCopyPath=dest,sampleState='POST_EXIT_COMPLETE')
 existing=next((x for x in closure['directFileReferences'] if x['originalPath']==str(q)),None)
 if existing:
  assert existing['originalMetadata']==record['originalMetadata'] and existing['bytes']==record['bytes'] and existing['sha256']==record['sha256'];existing.update(terminalCopyPath=dest,sampleState='POST_EXIT_COMPLETE')
 else:closure['directFileReferences'].append(record)
 terminal.append(record)
# Independently establish every one of the seven current live bindings.
seven=readj(D/'own-phase2-historical-reference-clarification.json')['records']
old_external=readj(OLD/'external-reference-closure.json');oldrows={x['originalPath']:x for x in old_external['directFileReferences']}
assert len(oldrows)==295
sevenpaths={x['currentPath'] for x in seven};assert len(sevenpaths)==7
for x in old_external['directFileReferences']:
 q=Path(x['originalPath'])
 if str(q) in sevenpaths:
  note=next(v for v in seven if v['currentPath']==str(q));name=q.relative_to(R).as_posix();b=q.read_bytes()
  assert b==git('show',H+':'+name) and len(b)==note['currentBytes'] and sha(b)==note['currentSha256'] and meta(q)==note['currentMetadata']
  oldcopy=P/note['historicalExactCopyPath'];historical=git('show','c6ded6c918c4f69b0e89037e85b8f49ddc5512b4:'+name);assert historical==oldcopy.read_bytes() and len(historical)==x['bytes'] and sha(historical)==x['sha256']
  current=next(v for v in closure['directFileReferences'] if v['originalPath']==str(q));assert current['sha256']==sha(b) and current['originalMetadata']==meta(q)
 else:assert meta(q)==x['originalMetadata'] and q.stat().st_size==x['bytes'] and digest(q)==x['sha256'],str(q)
# No old bytes are overwritten. Preserve the exact in-flight closure version and
# its original lstat before moving that own, not-yet-frozen data file aside.
backup=P/'pre-freeze-corrections/external-reference-closure.in-flight-original.json';backup.parent.mkdir(mode=0o700)
assert not backup.exists();xjson(P/'pre-freeze-corrections/external-reference-closure.original-identity.json',dict(originalPath=str(path),originalMetadata=original_meta,bytes=len(original),sha256=sha(original),archivePath=str(backup),archiveIsHistoricalInFlightDescriptorOnly=True,notCurrentStableReferenceContract=True))
os.rename(path,backup);assert backup.read_bytes()==original
context=readj(P/'context-content-inventory.json');phase2=readj(D/'phase2.actual-result.json')
closure.update(capturedAtUtc=now(),fullContextMetadataSampleCapturedAtUtc=context['capturedAtUtc'],externalTargetMetadataSampleTimeWindow=dict(startedAtUtc=phase2['startedAtUtc'],endedAtUtc=phase2['endedAtUtc'],source='Original phase2, before its later historical-doc assertion failure; not recaptured by continuation.'),continuationDidNotResampleFull119095Or27318=True,terminalContinuationReferenceCorrections=corrections,terminalContinuationSourceAndReceipt=terminal,originalInFlightClosureArchive=backup.relative_to(P).as_posix(),originalInFlightClosureSha256=sha(original),other288PriorDirectReferencesRemainStrict=True,sevenCurrent649DocumentBindingsIndependentlyVerified=True)
closure['directFileReferences'].sort(key=lambda x:x['originalPath']);write(path,rawjson(closure))
report=dict(capturedAtUtc=now(),exactCorrectedOutputReferenceCount=2,originalInFlightClosure=dict(path=str(backup),bytes=len(original),sha256=sha(original),metadataBeforeArchive=original_meta,metadataAfterArchive=meta(backup)),newStableClosure=dict(path=str(path),bytes=path.stat().st_size,sha256=sha(path.read_bytes()),metadata=meta(path)),corrections=corrections,terminalReceiptAndSource=terminal,sevenCurrentBindingsAllExact=True,oldOther288ReferencesAllExact=True,originalPhase2Actual1Preserved=True,continuationActual0Preserved=True,noExistingRawOverwritten=True,noSourceOrBaselineMutation=True,noWholeContextOrExternalTargetContentRehash=True,phase2SamplingTimesPreserved=True,candidateInvocations=0,syntaxCalls=0)
xjson(D/'terminal-reference-correction.json',report);xjson(P/'terminal-reference-correction.json',report)
for x in closure['directFileReferences']:
 q=Path(x['originalPath']);assert meta(q)==x['originalMetadata'] and q.stat().st_size==x['bytes'] and digest(q)==x['sha256'],str(q)
workspace();print(json.dumps({'exactCorrectedOutputs':2,'oldOther288Exact':True,'all7CurrentBindings':True,'currentClosureBytes':path.stat().st_size,'currentClosureSha256':sha(path.read_bytes())}))
