from pathlib import Path
import json,os,signal,subprocess,sys,time,shutil
base=Path(__file__).resolve().parent;sys.path.insert(0,str(base.parent/'common'))
from gates import verify,guard,read

def proc(pid):
    p=Path('/proc',str(pid))
    try:
        st=(p/'stat').read_text().split(') ')[-1].split();return {'pid':pid,'state':st[0],'startTicks':st[19],'cmdline':(p/'cmdline').read_bytes().replace(b'\0',b' ').decode()}
    except FileNotFoundError:return None
if __name__=='__main__':
    op,number=sys.argv[1:];n=int(number);assert n>=1;proof=verify('E',native=False,require_launch=True);config=read(base.parent/'run-config.json');episode=base if n==1 else base/('transport-episode-'+str(n));home=Path(config['engineHomes']['E']);socket=home/'server.sock'
    if op=='start':
        guard('E','before-fake-episode-'+str(n));main=read(base/'main-runtime-before-fake.json');assert main['pid']==proof['launch']['pid'] and main['engineHome']==str(home)
        if n>1:
            prior=base if n==2 else base/('transport-episode-'+str(n-1));stop=read(prior/'transport-stop.json');assert stop['socketAbsentAfter'] and stop['processStopped'];episode.mkdir();shutil.copyfile(base/'fake-uds-engine.cjs',episode/'fake-uds-engine.cjs')
        assert not socket.exists() and not (home/'server.lock').exists()
        assert not any((episode/p).exists() for p in ['server-started.json','fake-io.jsonl','fake-grpc-trace.log'])
        assert not (episode/'fake-control.jsonl').exists() or (episode/'fake-control.jsonl').stat().st_size==0
        env=os.environ.copy();env.update(GRPC_TRACE='server_call',GRPC_VERBOSITY='DEBUG')
        with (episode/'fake-grpc-trace.log').open('x') as log:p=subprocess.Popen(['rtk','proxy','node',str(episode/'fake-uds-engine.cjs')],env=env,stdin=subprocess.DEVNULL,stdout=log,stderr=subprocess.STDOUT,start_new_session=True)
        (episode/'spawn.json').write_text(json.dumps({'wrapperPid':p.pid,'traceEnvBeforeRequire':{'GRPC_TRACE':'server_call','GRPC_VERBOSITY':'DEBUG'},'at':time.time(),'sameEWindow':proof['launch']['pid']},indent=2)+'\n')
        for i in range(100):
            if (episode/'server-started.json').exists():break
            if p.poll() is not None:raise RuntimeError((episode/'fake-grpc-trace.log').read_text())
            time.sleep(.1)
        server=read(episode/'server-started.json');stat=socket.stat();record={'episode':n,'server':server,'socketCtimeNs':stat.st_ctime_ns,'socketMtimeNs':stat.st_mtime_ns,'numericInodeMayBeReused':True,'newLifetimeProof':'prior process stopped + socket absent before bind + current PID/startticks/bind timestamps','actualMainUnchanged':proof['launch']['pid']}
        (episode/'transport-start-provenance.json').write_text(json.dumps(record,indent=2)+'\n');print(json.dumps(record))
    elif op=='stop':
        server=read(episode/'server-started.json');current=proc(server['pid']);assert current and current['startTicks']==server['processStartTimeTicks'];assert str(episode/'fake-uds-engine.cjs') in current['cmdline'];assert socket.lstat().st_ino==server['socketInode']
        record={'at':time.time(),'server':server,'actualProcess':current,'signal':'SIGTERM','socketMatched':True};target=episode/'transport-stop.json';assert not target.exists();target.write_text(json.dumps(record,indent=2)+'\n');os.kill(server['pid'],signal.SIGTERM)
        for i in range(50):
            p=proc(server['pid'])
            if p is None or p['state']=='Z':break
            time.sleep(.1)
        record.update(socketAbsentAfter=not socket.exists(),processStopped=proc(server['pid']) is None or proc(server['pid'])['state']=='Z');assert record['socketAbsentAfter'] and record['processStopped'];target.write_text(json.dumps(record,indent=2)+'\n');print(json.dumps(record))
    else:raise RuntimeError('Only start/stop of exactly owned controlled fake is supported')
