# VS Code Agents Instructions

> 本文件是本仓库的 **Agent 开发向导**。编码风格与校验命令以 [Copilot Instructions](.github/copilot-instructions.md) 为准。

本项目只使用**默认编辑器窗口**。Agents Window（`src/vs/sessions/`）仅作上游界面与实现对照，不属于本项目的产品使用、UI 审查或交付验收范围；相关文档保留供参考。范围正文见 [产品愿景](docs/product/vision.md)。

## 新会话必读

1. 本文件 — 项目全貌与文档入口
2. [docs/DOCUMENTATION.md](docs/DOCUMENTATION.md) — 文档维护规则
3. [dev/progress/status.md](dev/progress/status.md) — 当前迭代状态

## 文档导航

| 文档 | 说明 |
|:-----|:-----|
| [产品需求](docs/product/INDEX.md) | Agent IDE 愿景、需求与追踪 SSOT |
| [文档索引](docs/INDEX.md) | 全局导航 |
| [文档规范](docs/DOCS-SPEC.md) | 目录结构与模板 |
| [维护规则](docs/DOCUMENTATION.md) | frontmatter、commit 门禁；**方案写完须只读审查**（规则 16） |
| [架构概览](docs/architecture/overview.md) | 分层全景 |
| [术语表](docs/glossary.md) | 核心术语 SSOT |
| [B2 壳 / Agent UI 分析](docs/reference/code-oss-b2/INDEX.md) | 对照 Desktop 文档壳的本仓实现真相 |
| [编码/校验](.github/copilot-instructions.md) | TypeScript、测试、分层 |
| [源码组织](.github/instructions/source-code-organization.instructions.md) | 层、目标环境、DI |
| [钉死引擎调试](docs/guides/debug-engine.md) | 仓外隔离 HeadlessServer，Direct Address 连本仓 |
| [Agents 测试配置](docs/guides/test-profile.md) | 「启动 / 启动一下」用 `~/.universe-agent-studio-test`，不用 `launch.sh` |
| [开发自动化 Loop](dev/loop/INDEX.md) | `/loop @dev/loop/loop-prompt.txt`（AgenticLoopDev submodule） |
| [dev/loop/worktrees.md](dev/loop/worktrees.md) | 仓外并行 worktree 工位（`$REPO-WorkTrees`） |

## 启动

用户要看窗口（「启动」「启动一下」）时，只按 [Agents 测试配置](docs/guides/test-profile.md) 启动默认编辑器窗口：`~/.universe-agent-studio-test` 的 user-data、extensions、shared-data，命令里带 `--new-window`，不要加 `--agents`。不带 `--new-window` 时，这份配置会把上次的 Agents 窗口恢复出来。只有用户明确要求查看 Agents 对照界面时，才去掉 `--new-window` 并追加 `--agents`；这不属于本项目产品联调。同时拉起 [钉死引擎](docs/guides/debug-engine.md)（`vscode-debug-engine/start-engine.sh`，`127.0.0.1:50061`）。`50061` 已经在听就不要再起一份。不要用 `.agents/skills/launch/scripts/launch.sh`，也不要拷 `~/.vscode-oss-dev` 或日常目录 `~/.universe-agent-studio`。`launch.sh` 只用于 [壳冒烟](docs/guides/shell-smoke-verification.md) 这种必须隔离、登录不写回的自动化。壳冒烟不启动这份引擎。

## 架构摘要

`src/vs/` 分层（低 → 高）：`base` → `platform` → `editor` → `workbench`。`code`（桌面）、`server`（远程）与 `sessions` 都在 `workbench` 之上，彼此是产品入口层。`sessions` 可依赖 `workbench`，反向禁止。

目标环境子目录：`common` / `browser` / `node` / `electron-browser` / `electron-utility` / `electron-main`。

工作台：`workbench/{common,browser,electron-browser}` 核心 · `services/` 核心服务 · `contrib/` 功能 · `api/` Extension API。

就近 SSOT：`src/vs/sessions/` 下既有规格（`LAYERS.md`、`SESSIONS.md` 等）不迁走。

## 文档系统要点

- 知识库在 `docs/`，行动层在 `dev/`
- **不要**在 `src/vs/` 新建 `docs/` 树
- 结构变更后运行 `python3 scripts/check-docs-health.py`
- commit 前门禁见 [DOCUMENTATION.md 规则 3a](docs/DOCUMENTATION.md)

## 校验（按影响面选用，勿当作收尾仪式）

详见 [.github/copilot-instructions.md](.github/copilot-instructions.md)：优先最小针对性测试；`scripts/test.sh`。产品壳只适配默认编辑器窗口；自动剧本是 [壳冒烟](docs/guides/shell-smoke-verification.md) 的 `test/scenario/scenarios/editor-shell.cjs`。`src/vs/sessions/test/e2e` 的 `npm test` 打开 Sessions 网页工作台，不是这条联调。选用见 [测试与校验](docs/architecture/cross-cutting/testing.md)。`npm run valid-layers-check` 在 [D8](dev/progress/deferred-gaps.md) 修好前不作合入门禁，见 [health-gates](dev/progress/health-gates.md)。托管 CI 已关（[.github/workflows/DISABLED.md](.github/workflows/DISABLED.md)）是既定选择：**不得**写成验证缺口、缺自动化的原因，也**不得**建议重开。
