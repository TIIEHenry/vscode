from pathlib import Path
import os,json,hashlib,stat,subprocess,datetime,sys,time,traceback
A=Path(__file__).parent;D=A.parent;P=Path(str(D)[:-7]);R=Path('/home/clarence/Projects/Agents/vscode-WorkTrees/merge')
now=lambda:datetime.datetime.now(datetime.timezone.utc).isoformat()
sha=lambda b:hashlib.sha256(b).hexdigest()
def meta(q):
 s=q.lstat();return dict(type=stat.S_IFMT(s.st_mode),fullMode=s.st_mode,size=s.st_size,mtimeNs=s.st_mtime_ns,ctimeNs=s.st_ctime_ns,symlinkTarget=os.readlink(q) if stat.S_ISLNK(s.st_mode) else None)
def write(n,b):
 with (A/n).open('xb') as f:f.write(b);f.flush();os.fchmod(f.fileno(),0o444);os.fsync(f.fileno())
 return dict(path=str(A/n),bytes=len(b),sha256=sha(b),metadata=meta(A/n))
def save(n,v):return write(n,(json.dumps(v,ensure_ascii=False,indent=2)+'\n').encode())
def readj(q):return json.loads(q.read_bytes())
def ref(q):
 b=q.read_bytes();return dict(path=str(q),bytes=len(b),sha256=sha(b),metadata=meta(q))
assert readj(A/'immediate-light.actual-result.json')['actualExitCode']==0 and readj(A/'immediate-light-recheck.json')['gatePass']
assert subprocess.check_output(['rtk','proxy','git','rev-parse','HEAD'],cwd=R).decode().strip()=='64934a7772b667c6a3aba9739fc4f935b5aeb115'
assert subprocess.check_output(['rtk','proxy','git','status','--porcelain=v1','-z'],cwd=R)==b''
assert datetime.datetime.now(datetime.timezone.utc)<datetime.datetime.fromisoformat('2026-10-27T21:23:00+00:00')
release=P/'execution-release.json';before=release.read_bytes();before_meta=meta(release);old=json.loads(before)
assert sha(before)=='f0feff5f54f9c4fe796135167e9e7aa3f274d95f4ab0f1deb8452f53eb53b4af' and before==(D/'execution-release.prepared0.original.json').read_bytes()
assert before==(json.dumps(old,ensure_ascii=False,indent=2)+'\n').encode()
contract=readj(P/'activation-contract.json');fields=contract['futureActivationFieldsOnly'];assert fields==['state','executionAuthorized','activationAuthorized','authorizedBy','authorizationMessage']
message=(A/'root-single-invocation-authority.message.txt').read_text();new={**old,'state':'AUTHORIZED_BUSINESS_ONCE','executionAuthorized':True,'activationAuthorized':True,'authorizedBy':'/root','authorizationMessage':message}
assert {k:v for k,v in old.items() if k not in fields}=={k:v for k,v in new.items() if k not in fields} and new['invocations']==new['preparedInvocations']==0
changes={k:{'before':old[k],'after':new[k]} for k in old if old[k]!=new[k]};assert set(changes)==set(fields)
write('execution-release.before.original.json',before);save('execution-release.before.metadata.json',dict(path=str(release),metadata=before_meta,bytes=len(before),sha256=sha(before)))
after=(json.dumps(new,ensure_ascii=False,indent=2)+'\n').encode();write('execution-release.after.authorized.json',after)
with release.open('wb') as f:f.write(after);f.flush();os.fsync(f.fileno())
assert release.read_bytes()==after and stat.S_IMODE(release.stat().st_mode)==0o644
save('five-field-activation-diff.json',dict(capturedAtUtc=now(),beforeSha256=sha(before),afterSha256=sha(after),changes=changes,changedFieldsOnly=fields,allOtherFieldsAndPinsExact=True,invocations=0,preparedInvocations=0,metadataBefore=before_meta,metadataAfter=meta(release),originalPreparedReleaseBackupUnchanged=True))
inv=readj(D/'frozen-package-inventory.json')
for x in inv['rows']:
 if x['path']=='execution-release.json':continue
 assert meta(P/x['path'])=={k:v for k,v in x.items() if k not in ['path','sha256']},x['path']
assert sha((P/'package-final-audit.json').read_bytes())=='c23d7660b411ddc22539e805be1e5851a3112e134f314bb307b7f5971b374620'
python=readj(P/'input-manifest.json')['pythonExecutable'];assert python=='/usr/bin/python3.10'
argv=['rtk','proxy',python,str(P/'validate.py')]
started=now();save('driver-invocation.started.json',dict(startedAtUtc=started,actualArgv=argv,cwd=str(R),activatedReleaseSha256=sha(after),maximumDriverInvocations=1,thisInvocationOrdinal=1,noRetryEvenIfLaunchOrBeforeMarkerFails=True,noOuterTimeout=True,environment='Inherited unchanged by outer launcher; fixed driver controls its own child environment.'))
print(json.dumps({'event':'launching-single-authorized-driver','atUtc':started,'argv':argv}),flush=True)
process=None;launch_error=None;returncode=None
with (A/'driver.stdout.raw').open('xb') as out,(A/'driver.stderr.raw').open('xb') as err:
 try:
  process=subprocess.Popen(argv,stdout=out,stderr=err,cwd=R)
  info=dict(pid=process.pid,startedAtUtc=started,argv=argv,cwd=str(R),activatedReleaseSha256=sha(after))
  try:
   raw=(Path('/proc')/str(process.pid)/'stat').read_text();f=raw[raw.rfind(')')+2:].split();info.update(startTime=f[19],ppid=int(f[1]),pgrp=int(f[2]),session=int(f[3]),state=f[0])
  except OSError as e:info['immediatePidIdentityReadError']=str(e)
  save('driver-invocation.process.json',info);print(json.dumps({'event':'single-driver-started','process':info}),flush=True)
  returncode=process.wait()
 except BaseException as e:launch_error=dict(type=type(e).__name__,error=str(e),traceback=traceback.format_exc())
 finally:
  for f in [out,err]:f.flush();os.fchmod(f.fileno(),0o444);os.fsync(f.fileno())
# No raw stream is referenced before the producer has actually exited.
value=dict(startedAtUtc=started,endedAtUtc=now(),actualArgv=argv,cwd=str(R),actualExitCode=returncode,pid=process.pid if process else None,launchError=launch_error,driverInvocationAttempts=1,driverPopenCount=1 if process else 0,retries=0,stdout=ref(A/'driver.stdout.raw'),stderr=ref(A/'driver.stderr.raw'),activatedReleaseSha256=sha(after),noOuterTimeout=True,noAutomaticNewDispatch=True)
receipt=save('driver-invocation.actual-result.json',value);fd=os.open(A,os.O_RDONLY|os.O_DIRECTORY);os.fsync(fd);os.close(fd)
print(json.dumps({'event':'single-driver-ended','actualExitCode':returncode,'receipt':receipt}),flush=True)
sys.exit(1 if returncode is None else returncode)
