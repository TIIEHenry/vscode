from pathlib import Path
import json, subprocess, time, os, signal
base=Path(__file__).resolve().parent
import sys
sys.path.insert(0,str(base.parent/'common'))
from gates import verify
runtime_gate=verify('E',native=False,require_launch=True)
session='D-E-r3-controlled-session'
records=[]
def control(value):
    with (base/'fake-control.jsonl').open('a') as f:f.write(json.dumps(value)+'\n')
    time.sleep(.2)
def held(id):return [v for v in map(json.loads,(base/'fake-io.jsonl').read_text().splitlines()) if v.get('type')=='response-held' and v.get('id')==id]
def step(number,stage,**action):
    label=f'{number:02}-R3-transport-{stage}';action['label']=label
    r=subprocess.run(['rtk','proxy','node',str(base/'driver.cjs'),json.dumps(action)],capture_output=True,text=True)
    with (base/'driver-stdout.jsonl').open('a') as f:f.write(json.dumps({'action':action,'exit':r.returncode,'stdout':r.stdout,'stderr':r.stderr})+'\n')
    records.append(label)
    if r.returncode:raise RuntimeError(r.stdout+r.stderr)
    value=json.loads((base/'steps'/(label+'.json')).read_text());print(json.dumps({'label':label,'phase':value['state']['connection']['phase'],'linkId':value['state']['connection'].get('linkId')}),flush=True);return value
def seats(value,id):return [s for s in value['state']['seats'] if s.get('sessionKey')==session and s.get('turnId')==id]
def sel(id,suffix):return f'[data-session-key="{session}"] [data-turn-id="{id}"] '+suffix
try:
    a='D-E-R3-transport-old-failure'; b='D-E-R3-transport-old-busy'
    control({'op':'emit','kind':'permission','id':a})
    step(55,'old-permission-pending',type='inspect')
    step(56,'old-permission-first-held',type='click',selector=sel(a,'[role="button"]'),index=0)
    assert len(held(a))==1
    control({'op':'settle','token':held(a)[0]['token'],'outcome':'false'})
    failed=step(57,'old-permission-failed',type='inspect')
    assert len(seats(failed,a))==2 and all("Couldn't send" in s['text'] for s in seats(failed,a))
    control({'op':'emit','kind':'clientTool','id':b})
    step(58,'old-clientTool-pending',type='inspect')
    busy=step(59,'old-clientTool-held-with-old-permission-failure',type='click',selector=sel(b,'.conversation-process-fold-tool-respond'),index=0)
    assert len(held(b))==1 and len(seats(busy,b))==2 and all(s['busy']=='true' for s in seats(busy,b))
    assert all("Couldn't send" in s['text'] for s in seats(busy,a))
    (base/'transport-before-loss.json').write_text(json.dumps({'steps':records,'oldFailureRequest':a,'oldBusyRequest':b,'linkId':busy['state']['connection']['linkId'],'paneScopes':[p['responseProjection']['scope'] for p in busy['state']['actualPaneDiagnostics']]},indent=2)+'\n')
except Exception as error:
    (base/'transport-prep-failure.json').write_text(json.dumps({'steps':records,'error':str(error)},indent=2)+'\n');raise
