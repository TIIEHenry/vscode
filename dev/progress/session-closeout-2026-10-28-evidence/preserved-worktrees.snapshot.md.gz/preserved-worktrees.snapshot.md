# 工位保全清单（2026-10-28）

观察时间 UTC：`2026-10-28T07:20:34.104997+00:00`。只读观察，未编辑仓库/out、未运行测试、未终止任何进程。机器快照：`/tmp/vscode-closeout-preserved-worktrees.json`。

## 主工位与唯一 merge

- 主工位 `agent-ide` HEAD：`ed5727da0f2a44d9b6ef1c5a4d7b1bbd2461efb1`。
- **观察时主工位不是 clean**：`dev/plans/chatgpt-visual-language.md`、`src/vs/workbench/contrib/conversation/browser/conversationLensProjection.ts`、`src/vs/workbench/contrib/conversation/test/browser/conversationLens.test.ts` 三份新 WIP；已通知 root，原样保留。这些不是本审计新增。
- merge HEAD：`ad4a7bced198929239c4ed4b737f72f900a1dc80`；由唯一集成者负责，不在本清单操作。
- 本审计未执行 push。仅本地远端跟踪 `origin/agent-ide` 为 `e8b8538cf5a5b0e6ec021e1492058182548cc5fa`，比主工位少264个祖先提交；未联网核验实际远端，不能将本地跟踪描述成实时远端。
- 该次 `/proc` 采样未见 cwd 属本仓/工位的 compile/transpile/typecheck/gulp/watch/test 实际进程。是点时观察，不保证随后唯一 merge 尚未启动其授权验证。

## A–J 与视觉工位

| 槽 | HEAD | 分支 | 已跟踪 WIP | 未跟踪条目 | 当前 merge 已包含 HEAD |
| --- | --- | --- | ---: | ---: | --- |
| A | `24a3850cc46c` | `loop/A` | 0 | 0 | 是 |
| B | `38ded54dab77` | `loop/B` | 13 | 531 | 是 |
| C | `d03c2bb61b52` | `fix/c-engine-write-ownership-20261028` | 0 | 0 | 否 |
| D | `22d39579e8e3` | `fix/d-sources-stale-render-stub-amendment-20261027` | 0 | 0 | 否 |
| E | `b078a9a7613e` | `fix/e-conversation-visible-lease-recovery-20261027` | 0 | 0 | 是 |
| F | `3e2685118d4a` | `fix/f-skills-draft-recovery-20261028` | 0 | 0 | 否 |
| G | `24a3850cc46c` | `loop/G` | 0 | 0 | 是 |
| H | `24a3850cc46c` | `loop/H` | 0 | 4 | 是 |
| I | `c6ded6c918c4` | `loop/I` | 0 | 2 | 是 |
| J | `b071406ee489` | `fix/j-sources-pane-cancelled-model-resolution-20261027` | 0 | 0 | 否 |
| visual-readonly-agent | `21162cc5039e` | `visual/readonly-agent-chevron` | 0 | 0 | 是 |

B：13份已跟踪修改全为 `dev/` 文档/索引/证据账；531个未跟踪文件全在 `dev/progress/` 证据目录。当前13份 tracked WIP 的 SHA256 记入 JSON，未暂存或提交。
H：4个未跟踪附件，位于 `attachments/q1bind2`、`q1env1`、`q1overlap1`、`q1probe1`；未清理。
I：2个未跟踪条目是 `.build` 与 `out` **符号链接**，不是声称只有2个构建产物文件；均指 `/sdd/tmp/vscode-conversation-visible-lease-after-I-20261028-reservation1/writable/` 对应目录。未动链接或目标。

## 尚未合入的正式来源

以下 count 为 `git rev-list merge..HEAD`，不是互相独立的可相加工作量；F含C共享依赖，J含D slice。所有四工位当前 clean，保留其正式提交，不随本次收尾强行合入：

| 槽 | merge未包含提交数 | 这些提交触及的不同路径数 | 路径类别 |
| --- | ---: | ---: | --- |
| C | 7 | 54 | dev 36, docs 5, src 13 |
| F | 10 | 59 | dev 43, docs 5, src 11 |
| D | 8 | 27 | dev 22, docs 1, src 4 |
| J | 14 | 50 | dev 45, docs 1, src 4 |

C：引擎写操作 IPC/目标 owner 归属；F：Skills 草稿恢复/owner cancellation（包含共享归属依赖）；D：Local Git 完成反馈原宿主归属；J：Sources Pane 原始模型后的取消隔离（包含D slice）。正式提交与分支全名见 JSON，不将其现有源码 peer 等同本次集成运行验证。

## 初始清单比较边界

`/tmp/vscode-closeout-merge-docs-20261028T070721Z/before.json` 只有 merge 的 HEAD、src tree、docs WIP状态及 Included 文档hash；不含 A–J 的逐文件初始源/hash清单，无法据此宣称各槽WIP字节与初始完全一致。该文件所述初始 merge HEAD 是 `c5eeabbb7e14d783640ed80960a732978ed7a180`；当前 merge 已经授权前进，不能把其当前 src tree变化当作保全失败。

本次 live HEAD 与先前 root/本审计工作树列表所见的 A–J/visual各HEAD相同；所有字母槽没有新的未提交 `src/` 改动。对已有提交，HEAD未变即保持其 Git 源树对象。对 B 文档/未跟踪证据、H附件、I链接，只报告当前状态及可获得的hash，不杜撰缺失的原始逐字节比较。

**这是保全清单，不是“全部工位同步/全部关仓/产品全部验收完成”声明。**
