from pathlib import Path
import json,re,collections,hashlib
base=Path(__file__).resolve().parent;config=json.loads((base.parent/'run-config.json').read_text());script=(base/'fake-uds-engine.cjs').read_text()
registered={'/agentservice.'+s+'/'+m for s,m in re.findall(r"(?:unary|add)\('([^']+)', '([^']+)'",script)}
assert len(registered)==13
paths=[base]+sorted(p for p in base.glob('transport-episode-*') if p.is_dir())
allCounts=collections.Counter();episodes=[];held=0;chatWrites=0
for p in paths:
    trace=p/'fake-grpc-trace.log';io=p/'fake-io.jsonl';assert trace.exists() and io.exists()
    raw=trace.read_text();calls=collections.Counter(re.findall(r'Received call to method ([^\s]+)',raw));values=[json.loads(v) for v in io.read_text().splitlines()]
    assert values[0]['type']=='fake-server-started' and values[-1]['type']=='fake-server-stopped','complete fake lifetime required'
    unknown={k:v for k,v in calls.items() if k not in registered};assert not unknown,unknown
    unary=collections.Counter('/agentservice.'+v['service']+'/'+v['method'] for v in values if v.get('type')=='unary');expect=unary.copy();expect['/agentservice.SessionService/SessionEventStream']+=sum(v.get('type')=='session-stream-handshake' for v in values);expect['/agentservice.AgentService/Chat']+=calls['/agentservice.AgentService/Chat'];assert expect==calls
    allCounts.update(calls);held+=sum(v.get('type')=='response-held' for v in values);chatWrites+=sum(v.get('type')=='chat-write' for v in values)
    episodes.append({'directory':str(p.relative_to(base)),'traceSha256':hashlib.sha256(trace.read_bytes()).hexdigest(),'ioSha256':hashlib.sha256(io.read_bytes()).hexdigest(),'receivedMethods':dict(calls),'completeLifetime':True,'knownUnaryAndHandshakeCrosscheck':True,'residentChatStreamOpens':calls['/agentservice.AgentService/Chat'],'chatWritePayloads':sum(v.get('type')=='chat-write' for v in values)})
for path in ['/agentservice.AgentService/GetQueue','/agentservice.AgentService/SaveSkillContent']:assert allCounts[path]==0
result={'runId':config['runId'],'state':'OBSERVED_COMPLETE_FAKE_LIFETIMES','episodes':episodes,'receivedMethodCounts':dict(allCounts),'receivedCalls':sum(allCounts.values()),'responseUnary':held,'residentChatStreamOpens':allCounts['/agentservice.AgentService/Chat'],'chatWritePayloads':chatWrites,'getQueueReceived':allCounts['/agentservice.AgentService/GetQueue'],'saveSkillContentReceived':allCounts['/agentservice.AgentService/SaveSkillContent'],'unknownMethodCount':0,'doesNotImplyUiWriteGatePass':True};out=base/'grpc-full-lifetime-summary.json';assert not out.exists();out.write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result))
