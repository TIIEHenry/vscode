from pathlib import Path
import subprocess,json,datetime,os,hashlib,sys
D=Path('/sdd/tmp/vscode-conversation-visible-lease-old-business-20261028-prep3-review/authorized-old-once-20261027T211409194358Z')
name=sys.argv[1];argv=sys.argv[2:];started=datetime.datetime.now(datetime.timezone.utc).isoformat()
assert name and '/' not in name
for n in [name+'.stdout.raw',name+'.stderr.raw',name+'.actual-result.json']:assert not (D/n).exists()
with (D/(name+'.stdout.raw')).open('xb') as o,(D/(name+'.stderr.raw')).open('xb') as e:
 r=subprocess.run(argv,stdout=o,stderr=e,cwd='/home/clarence/Projects/Agents/vscode-WorkTrees/merge')
 for f in [o,e]:f.flush();os.fchmod(f.fileno(),0o444);os.fsync(f.fileno())
def ref(n):
 p=D/n;b=p.read_bytes();return dict(path=str(p),bytes=len(b),sha256=hashlib.sha256(b).hexdigest())
x=dict(startedAtUtc=started,endedAtUtc=datetime.datetime.now(datetime.timezone.utc).isoformat(),actualArgv=argv,actualExitCode=r.returncode,stdout=ref(name+'.stdout.raw'),stderr=ref(name+'.stderr.raw'),scope='Executor-owned static operation; no candidate import/execution or runtime credit')
with (D/(name+'.actual-result.json')).open('xb') as f:f.write((json.dumps(x,indent=2)+'\n').encode());f.flush();os.fchmod(f.fileno(),0o444);os.fsync(f.fileno())
print(json.dumps(x));sys.exit(r.returncode)
