# S2 audit artifact format

This bundle preserves the five complete audit attempts and all S2 preparation
versions. Raw manifests, execution tokens, reports, logs and absolute paths keep
their original bytes. Tokens are historical records; all runtime authorization
has closed. No S1 archive is copied or changed.

Snapshot bytes live once at objects/sha256/<prefix>/<sha256>. snapshot-map.json
maps every original snapshot path to its object. original-file-inventory.json
also lists excluded ephemeral files; excluded-ephemeral-files.json gives exact
paths and identities. Temporary Chromium profiles and XDG/npm caches remain at
their original /sdd paths. npm logs and crash diagnostics remain in this bundle.

The external ipc-ui-artifact-inventory.json lists every regular archive member,
including payload-inventory.json itself. The internal payload inventory lists
all other payload members, avoiding a recursive self-hash.

Use ipc-ui-replay-inputs.py extract with the published archive SHA and a new
destination, then verify. The prepare command restores only frozen snapshots
and derivative manifests into another new destination. Every derivative has
runtimeAuthorized=false and preparationOnly=true. It does not execute archived
runners, supply external dependencies, create an output tree, acquire locks,
use Git, or reauthorize tests. Before writing, both extraction and preparation
reject any Git checkout/worktree ancestor, including resolved symlink targets.
Historical live-source scans are relocated to
the corresponding frozen new snapshot only for inspection.

C's final validation-time plan bytes were preserved separately and are included.
F's final validation-time plan has only its recorded hash: no original bytes were
saved. Its post-runtime plan is explicitly separate. Source/test input snapshots
are complete for all five attempts; no plan bytes were reconstructed from a diff.
