import json,os,pathlib,shutil,signal,time
base=pathlib.Path(__file__).resolve().parent
lease=json.loads((base/'lease.json').read_text()) if (base/'lease.json').exists() else {}
info=json.loads((base/'launch.json').read_text()) if (base/'launch.json').exists() else {}
assert not lease or lease.get('createdBy')=='/root/sources_audit','not own lease'
assert not info or info.get('createdBy')=='/root/sources_audit','not own launch'
run=info.get('runDir',lease.get('runDir'))
if run:
    folder=pathlib.Path(run);assert folder.parent==pathlib.Path('/tmp') and folder.name.startswith('code-oss-dev-')
    assert info.get('repo')=='/home/clarence/Projects/Agents/vscode-WorkTrees/merge'
else:folder=None

def processes():
    out={}
    for p in pathlib.Path('/proc').iterdir():
        if not p.name.isdigit():continue
        try:
            args=(p/'cmdline').read_bytes().split(b'\0');args=[a.decode(errors='replace') for a in args if a]
            stat=(p/'stat').read_text();ppid=int(stat[stat.rfind(')')+2:].split()[1])
            out[int(p.name)]=(ppid,args)
        except (OSError,ValueError):pass
    return out
allprocs=processes();owned=set()
if run:
    for pid,(_,args) in allprocs.items():
        if any(a==run or a.startswith(run+'/') or a.startswith('--user-data-dir='+run+'/') or a.startswith('--shared-data-dir='+run+'/') or a.startswith('--extensions-dir='+run+'/') for a in args):owned.add(pid)
xpid=lease.get('xvfbPid')
if xpid in allprocs and any('Xvfb' in a for a in allprocs[xpid][1]):
    stat=pathlib.Path('/proc',str(xpid),'stat').read_text();ticks=stat[stat.rfind(')')+2:].split()[19]
    if ticks==lease.get('xvfbStartTimeTicks'):owned.add(xpid)
changed=True
while changed:
    changed=False
    for pid,(ppid,_) in allprocs.items():
        if ppid in owned and pid not in owned:owned.add(pid);changed=True
owned.discard(os.getpid())
for pid in sorted(owned,reverse=True):
    try:os.kill(pid,signal.SIGTERM)
    except ProcessLookupError:pass
time.sleep(.6)
remaining=[pid for pid in owned if pathlib.Path('/proc',str(pid)).exists()]
# Only these already-proven owned PIDs can be escalated.
for pid in remaining:
    try:os.kill(pid,signal.SIGKILL)
    except ProcessLookupError:pass
time.sleep(.2)
if folder and folder.exists():shutil.rmtree(folder)
lease.update(released=True,releasedAt=time.time());(base/'lease.json').write_text(json.dumps(lease,indent=2)+'\n')
result={'runDir':run,'ownedPids':sorted(owned),'remainingOwned':[pid for pid in owned if pathlib.Path('/proc',str(pid)).exists()],'profileRemoved':not folder or not folder.exists(),'fixturePreserved':True}
(base/'cleanup.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result))
