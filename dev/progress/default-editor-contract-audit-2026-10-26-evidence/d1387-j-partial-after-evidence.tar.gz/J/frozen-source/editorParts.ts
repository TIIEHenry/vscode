/*---------------------------------------------------------------------------------------------
 *  Copyright (c) Microsoft Corporation. All rights reserved.
 *  Licensed under the MIT License. See License.txt in the project root for license information.
 *--------------------------------------------------------------------------------------------*/

import { localize } from '../../../../nls.js';
import { EditorGroupLayout, GroupActivationReason, GroupDirection, GroupLocation, GroupOrientation, GroupsArrangement, GroupsOrder, IAuxiliaryEditorPart, IEditorGroupContextKeyProvider, IEditorDropTargetDelegate, IEditorGroupsService, IEditorSideGroup, IEditorWorkingSet, IFindGroupScope, IMergeGroupOptions, IEditorWorkingSetOptions, IEditorPart, IModalEditorPart, IEditorGroupActivationEvent, IConversationEditorPart, isExcludedFromGlobalEditorAggregation } from '../../../services/editor/common/editorGroupsService.js';
import { Emitter } from '../../../../base/common/event.js';
import { DisposableMap, DisposableStore, IDisposable, toDisposable } from '../../../../base/common/lifecycle.js';
import { GroupIdentifier, IEditorPartOptions } from '../../../common/editor.js';
import { EditorPart, IEditorPartUIState, MainEditorPart } from './editorPart.js';
import { CategorizedMainEditorPart } from './categorizedMainEditorPart.js';
import { isEditorGroupShown } from '../../../services/editor/common/previewCategoryRouting.js';
import { IEditorGroupView, IEditorPartsView } from './editor.js';
import { InstantiationType, registerSingleton } from '../../../../platform/instantiation/common/extensions.js';
import { IInstantiationService } from '../../../../platform/instantiation/common/instantiation.js';
import { distinct } from '../../../../base/common/arrays.js';
import { onUnexpectedError } from '../../../../base/common/errors.js';
import { AuxiliaryEditorPart, IAuxiliaryEditorPartOpenOptions } from './auxiliaryEditorPart.js';
import { ModalEditorPart } from './modalEditorPart.js';
import { ConversationEditorPartImpl } from './conversationEditorPart.js';
import { MultiWindowParts } from '../../part.js';
import { DeferredPromise } from '../../../../base/common/async.js';
import { IStorageService, IStorageValueChangeEvent, StorageScope, StorageTarget } from '../../../../platform/storage/common/storage.js';
import { IThemeService } from '../../../../platform/theme/common/themeService.js';
import { IAuxiliaryWindowOpenOptions, IAuxiliaryWindowService } from '../../../services/auxiliaryWindow/browser/auxiliaryWindowService.js';
import { generateUuid } from '../../../../base/common/uuid.js';
import { ContextKeyValue, IContextKey, IContextKeyService, RawContextKey } from '../../../../platform/contextkey/common/contextkey.js';
import { getActiveElement, getWindow, IDimension, isAncestor, isHTMLElement } from '../../../../base/browser/dom.js';
import { conversationSessionLeafHiddenClass, conversationSessionLeafPrimaryClass } from '../conversation/conversationPart.js';
import { ServiceCollection } from '../../../../platform/instantiation/common/serviceCollection.js';
import { IEditorService } from '../../../services/editor/common/editorService.js';
import { DeepPartial } from '../../../../base/common/types.js';
import { IStatusbarService } from '../../../services/statusbar/browser/statusbar.js';
import { mainWindow } from '../../../../base/browser/window.js';
import { IModalEditorPartOptions } from '../../../../platform/editor/common/editor.js';
import { EditorPartModalVisibleContext } from '../../../common/contextkeys.js';
import { ConversationChatInput, getDefaultConversationChatResource } from '../../../contrib/conversation/common/conversationChatInput.js';

interface IEditorPartsUIState {
	readonly auxiliary: IAuxiliaryEditorPartState[];
	readonly mru: number[];
	// main state is managed by the main part
}

interface IAuxiliaryEditorPartState extends IAuxiliaryWindowOpenOptions {
	readonly state: IEditorPartUIState;
}

interface IEditorWorkingSetState extends IEditorWorkingSet {
	readonly main: IEditorPartUIState;
	readonly auxiliary: IEditorPartsUIState;
}

interface IModalEditorPartState {
	readonly maximized: boolean;
	readonly size?: { readonly width: number; readonly height: number };
	readonly position?: { readonly left: number; readonly top: number };
	readonly sidebarWidth?: number;
	readonly sidebarHidden?: boolean;
}

interface IEditorPartsMemento {
	'editorparts.state'?: IEditorPartsUIState;
	'editorparts.modalState'?: IModalEditorPartState;
}

export class EditorParts extends MultiWindowParts<EditorPart, IEditorPartsMemento> implements IEditorGroupsService, IEditorPartsView {

	declare readonly _serviceBrand: undefined;

	readonly mainPart: MainEditorPart;
	private readonly modalEditorVisibleContext: IContextKey<boolean>;

	// Most recently active parts across all windows. Multiple parts can
	// share the same window (e.g. main part and modal part both live in
	// the main window) so this list also acts as a per-window MRU when
	// filtered by document. See `getMostRecentlyActivePartByDocument`.
	private mostRecentActiveParts: EditorPart[];

	constructor(
		@IInstantiationService protected readonly instantiationService: IInstantiationService,
		@IStorageService private readonly storageService: IStorageService,
		@IThemeService themeService: IThemeService,
		@IAuxiliaryWindowService private readonly auxiliaryWindowService: IAuxiliaryWindowService,
		@IContextKeyService private readonly contextKeyService: IContextKeyService
	) {
		super('workbench.editorParts', themeService, storageService);
		this.modalEditorVisibleContext = EditorPartModalVisibleContext.bindTo(this.contextKeyService);

		this.editorWorkingSets = (() => {
			const workingSetsRaw = this.storageService.get(EditorParts.EDITOR_WORKING_SETS_STORAGE_KEY, StorageScope.WORKSPACE);
			if (workingSetsRaw) {
				return JSON.parse(workingSetsRaw);
			}

			return [];
		})();

		const modalState = this.profileMemento[EditorParts.MODAL_EDITOR_STATE_STORAGE_KEY];
		if (modalState) {
			this.modalEditorMaximized = modalState.maximized;
			this.modalEditorSize = modalState.size;
			this.modalEditorPosition = modalState.position;
			this.modalEditorSidebarWidth = modalState.sidebarWidth;
			this.modalEditorSidebarHidden = modalState.sidebarHidden;
		}

		this.mainPart = this._register(this.createMainEditorPart());
		this._register(this.registerPart(this.mainPart));

		this.mostRecentActiveParts = [this.mainPart];

		this.restoreParts().catch(onUnexpectedError).catch(onUnexpectedError);
		this.registerListeners();
	}

	private registerListeners(): void {
		this._register(this.onDidChangeMementoValue(StorageScope.WORKSPACE, this._store)(e => this.onDidChangeMementoState(e)));
		this.whenReady.then(() => this.registerGroupsContextKeyListeners()).catch(onUnexpectedError).catch(onUnexpectedError);
	}

	protected createMainEditorPart(): MainEditorPart {
		return this.instantiationService.createInstance(CategorizedMainEditorPart, this);
	}

	//#region Scoped Instantiation Services

	private readonly mapPartToInstantiationService = new Map<IEditorPart, IInstantiationService>();
	private modalPartInstantiationService: IInstantiationService | undefined;

	getScopedInstantiationService(part: IEditorPart): IInstantiationService {

		// Main Part
		if (part === this.mainPart) {
			let mainPartInstantiationService = this.mapPartToInstantiationService.get(part);
			if (!mainPartInstantiationService) {
				mainPartInstantiationService = this.instantiationService.invokeFunction(accessor => {
					const editorService = accessor.get(IEditorService);
					const statusbarService = accessor.get(IStatusbarService);

					const scoped = this._register(this.mainPart.scopedInstantiationService.createChild(new ServiceCollection(
						[IEditorService, editorService.createScoped(this.mainPart, this._store)],
						[IStatusbarService, statusbarService.createScoped(statusbarService, this._store)]
					)));
					this.mapPartToInstantiationService.set(part, scoped);

					return scoped;
				});
			}

			return mainPartInstantiationService;
		}

		// Modal Part (if opened)
		if (part === this.modalEditorPart && this.modalPartInstantiationService) {
			return this.modalPartInstantiationService;
		}

		const scoped = this.mapPartToInstantiationService.get(part);
		if (scoped) {
			return scoped;
		}

		return this.instantiationService;
	}

	private setScopedInstantiationService(part: IEditorPart, instantiationService: IInstantiationService, owner: DisposableStore): void {
		this.mapPartToInstantiationService.set(part, instantiationService);
		owner.add(toDisposable(() => this.mapPartToInstantiationService.delete(part)));
	}

	//#endregion

	//#region Auxiliary Editor Parts

	private readonly _onDidCreateAuxiliaryEditorPart = this._register(new Emitter<IAuxiliaryEditorPart>());
	readonly onDidCreateAuxiliaryEditorPart = this._onDidCreateAuxiliaryEditorPart.event;

	async createAuxiliaryEditorPart(options?: IAuxiliaryEditorPartOpenOptions): Promise<IAuxiliaryEditorPart> {
		const { part, instantiationService, disposables } = await this.instantiationService.createInstance(AuxiliaryEditorPart, this).create(this.getGroupsLabel(this._parts.size), options);

		// Keep instantiation service
		this.setScopedInstantiationService(part, instantiationService, disposables);

		// Events
		this._onDidAddGroup.fire(part.activeGroup);

		this._onDidCreateAuxiliaryEditorPart.fire(part);

		return part;
	}

	//#endregion

	//#region Conversation Editor Parts

	private readonly conversationEditorParts = new Map<string, IConversationEditorPart>();
	private readonly conversationEditorPartStores = this._register(new DisposableMap<string, DisposableStore>());
	private focusedConversationLeaf: string | undefined;

	get conversationParts(): ReadonlyArray<IConversationEditorPart> {
		return [...this.conversationEditorParts.values()];
	}

	setFocusedConversationLeaf(sessionKey: string | undefined): void {
		this.focusedConversationLeaf = sessionKey;
	}

	getFocusedConversationLeaf(): string | undefined {
		return this.focusedConversationLeaf;
	}

	getActiveConversationEditorPart(): IConversationEditorPart | undefined {
		const activeElement = getActiveElement();
		for (const part of this.conversationParts) {
			const container = (part as ConversationEditorPartImpl).getContainer();
			const leaf = container?.closest('.conversation-session-leaf') as HTMLElement | null;
			if (container && !leaf?.classList.contains(conversationSessionLeafHiddenClass) && isAncestor(activeElement, container)) {
				return part;
			}
		}

		if (this.focusedConversationLeaf) {
			const focused = this.conversationEditorParts.get(this.focusedConversationLeaf);
			const leaf = (focused as ConversationEditorPartImpl | undefined)?.getContainer()?.closest('.conversation-session-leaf') as HTMLElement | null;
			if (focused && !leaf?.classList.contains(conversationSessionLeafHiddenClass)) {
				return focused;
			}
		}

		for (const part of this.conversationParts) {
			const leaf = (part as ConversationEditorPartImpl).getContainer()?.closest('.conversation-session-leaf') as HTMLElement | null;
			if (leaf && !leaf.classList.contains(conversationSessionLeafHiddenClass) && leaf.classList.contains(conversationSessionLeafPrimaryClass)) {
				return part;
			}
		}

		for (const part of this.conversationParts) {
			const leaf = (part as ConversationEditorPartImpl).getContainer()?.closest('.conversation-session-leaf') as HTMLElement | null;
			if (leaf && !leaf.classList.contains(conversationSessionLeafHiddenClass)) {
				return part;
			}
		}

		return undefined;
	}

	disposeConversationEditorPart(sessionKey: string): void {
		this.conversationEditorPartStores.deleteAndDispose(sessionKey);
		this.conversationEditorParts.delete(sessionKey);
		if (this.focusedConversationLeaf === sessionKey) {
			this.focusedConversationLeaf = undefined;
		}
	}

	createConversationEditorPart(parent: unknown /* HTMLElement */, sessionKey: string): IConversationEditorPart {
		const existing = this.conversationEditorParts.get(sessionKey);
		if (existing) {
			return existing;
		}

		const disposables = new DisposableStore();
		this.conversationEditorPartStores.set(sessionKey, disposables);
		const host = parent as HTMLElement;

		const editorPart = disposables.add(this.instantiationService.createInstance(
			ConversationEditorPartImpl,
			sessionKey,
			mainWindow.vscodeWindowId,
			this,
		));
		disposables.add(this.registerPart(editorPart));
		editorPart.create(host);
		let lastMeasuredWidth = 0;
		let lastMeasuredHeight = 0;
		if (host.clientWidth > 0 && host.clientHeight > 0) {
			lastMeasuredWidth = host.clientWidth;
			lastMeasuredHeight = host.clientHeight;
			editorPart.layout(lastMeasuredWidth, lastMeasuredHeight, 0, 0);
		} else {
			editorPart.layout(800, 600, 0, 0);
		}

		const targetWindow = getWindow(host);
		const ResizeObserverCtor = (typeof targetWindow?.ResizeObserver === 'function' ? targetWindow.ResizeObserver : undefined)
			?? (typeof mainWindow?.ResizeObserver === 'function' ? mainWindow.ResizeObserver : undefined)
			?? (typeof ResizeObserver === 'function' ? ResizeObserver : undefined);
		if (typeof ResizeObserverCtor === 'function') {
			const observer = new ResizeObserverCtor(() => {
				const currentWidth = host.clientWidth;
				const currentHeight = host.clientHeight;
				if (currentWidth > 0 && currentHeight > 0 && (currentWidth !== lastMeasuredWidth || currentHeight !== lastMeasuredHeight)) {
					lastMeasuredWidth = currentWidth;
					lastMeasuredHeight = currentHeight;
					editorPart.layout(currentWidth, currentHeight, 0, 0);
				}
			});
			observer.observe(host);
			disposables.add(toDisposable(() => observer.disconnect()));
		}

		const scopedInstantiationService = this.instantiationService.invokeFunction(accessor => {
			const editorService = accessor.get(IEditorService);
			return editorPart.scopedInstantiationService.createChild(new ServiceCollection(
				[IEditorService, editorService.createScoped(editorPart, disposables)]
			));
		});
		this.setScopedInstantiationService(editorPart, scopedInstantiationService, disposables);

		const defaultInput = disposables.add(this.instantiationService.createInstance(
			ConversationChatInput,
			getDefaultConversationChatResource(sessionKey),
			{ isDefaultRoot: true },
		));
		void editorPart.activeGroup.openEditor(defaultInput).catch(onUnexpectedError).catch(onUnexpectedError);

		this.conversationEditorParts.set(sessionKey, editorPart);
		disposables.add(toDisposable(() => this.conversationEditorParts.delete(sessionKey)));

		this._onDidAddGroup.fire(editorPart.activeGroup);

		return editorPart;
	}

	//#endregion

	//#region Modal Editor Part

	private modalEditorPart: IModalEditorPart | undefined;
	get activeModalEditorPart(): IModalEditorPart | undefined { return this.modalEditorPart; }

	private modalEditorMaximized = false;
	private modalEditorSize: IDimension | undefined;
	private modalEditorPosition: { readonly left: number; readonly top: number } | undefined;
	private modalEditorSidebarWidth: number | undefined;
	private modalEditorSidebarHidden: boolean | undefined;

	// Tracks an in-flight creation so concurrent callers await and reuse the
	// same singleton instance instead of each racing to create their own.
	private modalEditorPartCreatePromise: Promise<IModalEditorPart> | undefined;

	async createModalEditorPart(options?: IModalEditorPartOptions): Promise<IModalEditorPart> {

		// Reuse existing modal editor part if it exists
		if (this.modalEditorPart) {
			this.modalEditorPart.updateOptions(options);

			return this.modalEditorPart;
		}

		// Another creation is already in flight: await it instead of starting
		// a second one, then apply this call's options to the shared instance
		if (this.modalEditorPartCreatePromise) {
			const part = await this.modalEditorPartCreatePromise;
			part.updateOptions(options);

			return part;
		}

		const createPromise = this.doCreateModalEditorPart(options).finally(() => {
			this.modalEditorPartCreatePromise = undefined;
		});
		this.modalEditorPartCreatePromise = createPromise;

		return createPromise;
	}

	private async doCreateModalEditorPart(options: IModalEditorPartOptions | undefined): Promise<IModalEditorPart> {
		this.modalEditorVisibleContext.set(true);
		let result;
		try {
			result = await this.instantiationService.createInstance(ModalEditorPart, this).create({
				...options,
				maximized: options?.maximized ?? this.modalEditorMaximized,
				size: options?.size ?? this.modalEditorSize,
				position: options?.position ?? this.modalEditorPosition,
				sidebar: options?.sidebar ? {
					...options.sidebar,
					sidebarWidth: options.sidebar.sidebarWidth ?? this.modalEditorSidebarWidth,
					sidebarHidden: options.sidebar.sidebarHidden ?? this.modalEditorSidebarHidden
				} : undefined
			});
		} catch (error) {
			this.modalEditorVisibleContext.set(false);
			throw error;
		}
		const { part, instantiationService, disposables } = result;

		// Keep instantiation service and reference to reuse
		this.modalEditorPart = part;
		this.modalPartInstantiationService = instantiationService;

		// Remember state on dispose to restore when opening next time
		disposables.add(toDisposable(() => {
			this.modalEditorMaximized = part.maximized;
			this.modalEditorSize = part.size;
			this.modalEditorPosition = part.position;
			if (part.hasSidebar) {
				this.modalEditorSidebarWidth = part.sidebarWidth;
				this.modalEditorSidebarHidden = part.sidebarHidden || undefined;
			}

			this.modalPartInstantiationService = undefined;
			this.modalEditorPart = undefined;
			this.modalEditorVisibleContext.set(false);
		}));

		// Events
		this._onDidAddGroup.fire(part.activeGroup);

		return part;
	}

	//#endregion

	//#region Registration

	override registerPart(part: EditorPart): IDisposable {
		const disposables = this._register(new DisposableStore());
		disposables.add(super.registerPart(part));

		this.registerEditorPartListeners(part, disposables);

		return disposables;
	}

	protected override unregisterPart(part: EditorPart): void {
		super.unregisterPart(part);

		// Notify all parts about a groups label change
		// given it is computed based on the index

		this.parts.forEach((part, index) => {
			if (part === this.mainPart) {
				return;
			}

			part.notifyGroupsLabelChange(this.getGroupsLabel(index));
		});
	}

	private registerEditorPartListeners(part: EditorPart, disposables: DisposableStore): void {
		disposables.add(part.onDidFocus(() => {
			this.doUpdateMostRecentActive(part, true);

			if (this._parts.size > 1) {
				// Either main or auxiliary editor part got focus
				// which we have to treat as a group change event.
				this._onDidActiveGroupChange.fire(this.activeGroup);
			}
		}));
		disposables.add(toDisposable(() => {
			this.doUpdateMostRecentActive(part);

			if (part.windowId !== mainWindow.vscodeWindowId) {
				// An auxiliary editor part is closing which we have
				// to treat as group change event for the next editor
				// part that becomes active.
				// Refs: https://github.com/microsoft/vscode/issues/257058
				this._onDidActiveGroupChange.fire(this.activeGroup);
			}
		}));

		disposables.add(part.onDidChangeActiveGroup(group => this._onDidActiveGroupChange.fire(group)));
		disposables.add(part.onDidAddGroup(group => this._onDidAddGroup.fire(group)));
		disposables.add(part.onDidRemoveGroup(group => this._onDidRemoveGroup.fire(group)));
		disposables.add(part.onDidMoveGroup(group => this._onDidMoveGroup.fire(group)));
		disposables.add(part.onDidActivateGroup(e => {
			// A part-close activation means a modal or auxiliary editor part is
			// closing and another part is being made the active one. Update our
			// MRU eagerly here so that downstream queries during the close flow
			// (e.g. `getPartByDocument` triggered by `onDidRemoveGroup` from the
			// closing part) see the new active part instead of the closing one
			// which has not yet been unregistered.
			if (e.reason === GroupActivationReason.PART_CLOSE) {
				this.doUpdateMostRecentActive(part, true);
			}

			this._onDidActivateGroup.fire(e);
		}));
		disposables.add(part.onDidChangeGroupMaximized(maximized => this._onDidChangeGroupMaximized.fire(maximized)));

		disposables.add(part.onDidChangeGroupIndex(group => this._onDidChangeGroupIndex.fire(group)));
		disposables.add(part.onDidChangeGroupLocked(group => this._onDidChangeGroupLocked.fire(group)));
	}

	private doUpdateMostRecentActive(part: EditorPart, makeMostRecentlyActive?: boolean): void {
		if (isExcludedFromGlobalEditorAggregation(part)) {
			return;
		}

		const index = this.mostRecentActiveParts.indexOf(part);

		// Remove from MRU list
		if (index !== -1) {
			this.mostRecentActiveParts.splice(index, 1);
		}

		// Add to front as needed
		if (makeMostRecentlyActive) {
			this.mostRecentActiveParts.unshift(part);
		}
	}

	private getGroupsLabel(index: number): string {
		return localize('groupLabel', "Window {0}", index + 1);
	}

	//#endregion

	//#region Helpers

	private getGloballyAggregatedParts(): EditorPart[] {
		return this.parts.filter(part => !isExcludedFromGlobalEditorAggregation(part));
	}

	override get activePart(): EditorPart {
		const activeElement = getActiveElement();
		for (const part of this.mostRecentActiveParts) {
			if (isExcludedFromGlobalEditorAggregation(part)) {
				continue;
			}
			const container = part.getContainer();
			if (container && isAncestor(activeElement, container)) {
				return part;
			}
		}

		return this.mainPart;
	}

	protected override getPartByDocument(document: Document): EditorPart {
		// Multiple editor parts can share the same document because
		// the main part and a modal part both live in the main window.

		const mruParts = this.mostRecentActiveParts.filter(part => !isExcludedFromGlobalEditorAggregation(part));
		const mruDocumentParts = mruParts.filter(part => part.element?.ownerDocument === document);
		if (mruDocumentParts.length > 1) {
			// First try to find the part that has the currently focused element, which is the most likely candidate to be the active part for that document.
			const activeElement = getActiveElement();
			for (const part of mruDocumentParts) {
				const container = part.getContainer();
				if (container && isAncestor(activeElement, container)) {
					return part;
				}
			}

			// Pick the part that was set active last for that document
			return mruDocumentParts[0];
		}

		if (mruDocumentParts.length === 1) {
			return mruDocumentParts[0];
		}

		return super.getPartByDocument(document);
	}

	override getPart(group: IEditorGroupView | GroupIdentifier): EditorPart;
	override getPart(element: HTMLElement): EditorPart;
	override getPart(groupOrElement: IEditorGroupView | GroupIdentifier | HTMLElement): EditorPart {
		if (this._parts.size > 1) {
			if (isHTMLElement(groupOrElement)) {
				const element = groupOrElement;

				return this.getPartByDocument(element.ownerDocument);
			} else {
				const group = groupOrElement;

				let id: GroupIdentifier;
				if (typeof group === 'number') {
					id = group;
				} else {
					id = group.id;
				}

				for (const part of this._parts) {
					if (part.hasGroup(id)) {
						return part;
					}
				}
			}
		}

		return this.mainPart;
	}

	//#endregion

	//#region Lifecycle / State

	private static readonly EDITOR_PARTS_UI_STATE_STORAGE_KEY = 'editorparts.state';
	private static readonly MODAL_EDITOR_STATE_STORAGE_KEY = 'editorparts.modalState';

	private readonly workspaceMemento = this.getMemento(StorageScope.WORKSPACE, StorageTarget.USER);
	private readonly profileMemento = this.getMemento(StorageScope.PROFILE, StorageTarget.MACHINE);

	private _isReady = false;
	get isReady(): boolean { return this._isReady; }

	private readonly whenReadyPromise = new DeferredPromise<void>();
	readonly whenReady = this.whenReadyPromise.p;

	private readonly whenRestoredPromise = new DeferredPromise<void>();
	readonly whenRestored = this.whenRestoredPromise.p;

	private async restoreParts(): Promise<void> {

		// Join on the main part being ready to pick
		// the right moment to begin restoring.
		// The main part is automatically being created
		// as part of the overall startup process.
		await this.mainPart.whenReady;

		// Only attempt to restore auxiliary editor parts
		// when the main part did restore. It is possible
		// that restoring was not attempted because specific
		// editors were opened.
		if (this.mainPart.willRestoreState) {
			const state = this.loadState();
			if (state) {
				await this.restoreState(state);
			}
		}

		const mostRecentActivePart = this.mostRecentActiveParts.at(0);
		mostRecentActivePart?.activeGroup.focus();

		this._isReady = true;
		this.whenReadyPromise.complete();

		// Await restored
		await Promise.allSettled(this.parts.map(part => part.whenRestored));
		this.whenRestoredPromise.complete();
	}

	private loadState(): IEditorPartsUIState | undefined {
		return this.workspaceMemento[EditorParts.EDITOR_PARTS_UI_STATE_STORAGE_KEY];
	}

	protected override saveState(): void {
		const state = this.createState();
		if (state.auxiliary.length === 0) {
			delete this.workspaceMemento[EditorParts.EDITOR_PARTS_UI_STATE_STORAGE_KEY];
		} else {
			this.workspaceMemento[EditorParts.EDITOR_PARTS_UI_STATE_STORAGE_KEY] = state;
		}

		this.saveModalState();
	}

	private saveModalState(): void {

		// Also capture state from any currently open modal editor part
		if (this.modalEditorPart) {
			this.modalEditorMaximized = this.modalEditorPart.maximized;
			this.modalEditorSize = this.modalEditorPart.size;
			this.modalEditorPosition = this.modalEditorPart.position;
			if (this.modalEditorPart.hasSidebar) {
				this.modalEditorSidebarWidth = this.modalEditorPart.sidebarWidth;
				this.modalEditorSidebarHidden = this.modalEditorPart.sidebarHidden || undefined;
			}
		}

		// Only persist when there is meaningful state to restore.
		// When all values are at their defaults (not maximized, no
		// custom size or position), we delete the key to avoid
		// storing unnecessary data.
		if (this.modalEditorMaximized || this.modalEditorSize || this.modalEditorPosition || this.modalEditorSidebarWidth || this.modalEditorSidebarHidden) {
			this.profileMemento[EditorParts.MODAL_EDITOR_STATE_STORAGE_KEY] = {
				maximized: this.modalEditorMaximized,
				size: this.modalEditorSize ? { width: this.modalEditorSize.width, height: this.modalEditorSize.height } : undefined,
				position: this.modalEditorPosition,
				sidebarWidth: this.modalEditorSidebarWidth,
				sidebarHidden: this.modalEditorSidebarHidden,
			};
		} else {
			delete this.profileMemento[EditorParts.MODAL_EDITOR_STATE_STORAGE_KEY];
		}
	}

	private createState(): IEditorPartsUIState {
		return {
			auxiliary: this.parts
				.map(part => ({ part, auxiliaryWindow: this.auxiliaryWindowService.getWindow(part.windowId) }))
				.filter(({ auxiliaryWindow }) => auxiliaryWindow !== undefined)
				.map(({ part, auxiliaryWindow }) => ({
					state: part.createState(),
					...auxiliaryWindow!.createState()
				})),
			mru: this.mostRecentActiveParts.map(part => this.parts.indexOf(part))
		};
	}

	private async restoreState(state: IEditorPartsUIState): Promise<void> {
		if (state.auxiliary.length) {
			const auxiliaryEditorPartPromises: Promise<IAuxiliaryEditorPart>[] = [];

			// Create auxiliary editor parts
			for (const auxiliaryEditorPartState of state.auxiliary) {
				auxiliaryEditorPartPromises.push(this.createAuxiliaryEditorPart(auxiliaryEditorPartState));
			}

			// Await creation
			await Promise.allSettled(auxiliaryEditorPartPromises);

			// Update MRU list
			if (state.mru.length === this.parts.length) {
				this.mostRecentActiveParts = state.mru.map(index => this.parts[index]);
			} else {
				this.mostRecentActiveParts = [...this.parts];
			}

			// Await ready
			await Promise.allSettled(this.parts.map(part => part.whenReady));
		}
	}

	get hasRestorableState(): boolean {
		return this.parts.some(part => part.hasRestorableState);
	}

	private onDidChangeMementoState(e: IStorageValueChangeEvent): void {
		if (e.external && e.scope === StorageScope.WORKSPACE) {
			this.reloadMemento(e.scope);

			const state = this.loadState();
			if (state) {
				this.applyState(state).catch(onUnexpectedError).catch(onUnexpectedError);
			}
		}
	}

	private async applyState(state: IEditorPartsUIState | 'empty'): Promise<boolean> {

		// Before closing windows, try to close as many editors as
		// possible, but skip over those that would trigger a dialog
		// (for example when being dirty). This is to be able to have
		// them merge into the main part.

		for (const part of this.parts) {
			if (part === this.mainPart || isExcludedFromGlobalEditorAggregation(part)) {
				continue; // main part takes care on its own; conversation parts are hide-only
			}

			for (const group of part.getGroups(GroupsOrder.MOST_RECENTLY_ACTIVE)) {
				await group.closeAllEditors({ excludeConfirming: true, force: true });
			}

			const closed = (part as unknown as IAuxiliaryEditorPart).close(); // will move remaining editors to main part
			if (!closed) {
				return false; // this indicates that closing was vetoed
			}
		}

		// Restore auxiliary state unless we are in an empty state
		if (state !== 'empty') {
			await this.restoreState(state);
		}

		return true;
	}

	//#endregion

	//#region Working Sets

	private static readonly EDITOR_WORKING_SETS_STORAGE_KEY = 'editor.workingSets';

	private editorWorkingSets: IEditorWorkingSetState[];

	saveWorkingSet(name: string): IEditorWorkingSet {
		const workingSet: IEditorWorkingSetState = {
			id: generateUuid(),
			name,
			main: this.mainPart.createState(),
			auxiliary: this.createState()
		};

		this.editorWorkingSets.push(workingSet);

		this.saveWorkingSets();

		return {
			id: workingSet.id,
			name: workingSet.name
		};
	}

	getWorkingSets(): IEditorWorkingSet[] {
		return this.editorWorkingSets.map(workingSet => ({ id: workingSet.id, name: workingSet.name }));
	}

	deleteWorkingSet(workingSet: IEditorWorkingSet): void {
		const index = this.indexOfWorkingSet(workingSet);
		if (typeof index === 'number') {
			this.editorWorkingSets.splice(index, 1);

			this.saveWorkingSets();
		}
	}

	async applyWorkingSet(workingSet: IEditorWorkingSet | 'empty', options?: IEditorWorkingSetOptions): Promise<boolean> {
		let workingSetState: IEditorWorkingSetState | 'empty' | undefined;
		if (workingSet === 'empty') {
			workingSetState = 'empty';
		} else {
			workingSetState = this.editorWorkingSets[this.indexOfWorkingSet(workingSet) ?? -1];
		}

		if (!workingSetState) {
			return false;
		}

		// Apply state: begin with auxiliary windows first because it helps to keep
		// editors around that need confirmation by moving them into the main part.
		// Also, in rare cases, the auxiliary part may not be able to apply the state
		// for certain editors that cannot move to the main part.
		const applied = await this.applyState(workingSetState === 'empty' ? workingSetState : workingSetState.auxiliary);
		if (!applied) {
			return false;
		}
		await this.mainPart.applyState(workingSetState === 'empty' ? workingSetState : workingSetState.main, options);

		// Restore Focus unless instructed otherwise
		if (!options?.preserveFocus) {
			const mostRecentActivePart = this.mostRecentActiveParts.at(0);
			if (mostRecentActivePart) {
				await mostRecentActivePart.whenReady;
				mostRecentActivePart.activeGroup.focus();
			}
		}

		return true;
	}

	private indexOfWorkingSet(workingSet: IEditorWorkingSet): number | undefined {
		for (let i = 0; i < this.editorWorkingSets.length; i++) {
			if (this.editorWorkingSets[i].id === workingSet.id) {
				return i;
			}
		}

		return undefined;
	}

	private saveWorkingSets(): void {
		this.storageService.store(EditorParts.EDITOR_WORKING_SETS_STORAGE_KEY, JSON.stringify(this.editorWorkingSets), StorageScope.WORKSPACE, StorageTarget.MACHINE);
	}

	//#endregion

	//#region Events

	private readonly _onDidActiveGroupChange = this._register(new Emitter<IEditorGroupView>());
	readonly onDidChangeActiveGroup = this._onDidActiveGroupChange.event;

	private readonly _onDidAddGroup = this._register(new Emitter<IEditorGroupView>());
	readonly onDidAddGroup = this._onDidAddGroup.event;

	private readonly _onDidRemoveGroup = this._register(new Emitter<IEditorGroupView>());
	readonly onDidRemoveGroup = this._onDidRemoveGroup.event;

	private readonly _onDidMoveGroup = this._register(new Emitter<IEditorGroupView>());
	readonly onDidMoveGroup = this._onDidMoveGroup.event;

	private readonly _onDidActivateGroup = this._register(new Emitter<IEditorGroupActivationEvent>());
	readonly onDidActivateGroup = this._onDidActivateGroup.event;

	private readonly _onDidChangeGroupIndex = this._register(new Emitter<IEditorGroupView>());
	readonly onDidChangeGroupIndex = this._onDidChangeGroupIndex.event;

	private readonly _onDidChangeGroupLocked = this._register(new Emitter<IEditorGroupView>());
	readonly onDidChangeGroupLocked = this._onDidChangeGroupLocked.event;

	private readonly _onDidChangeGroupMaximized = this._register(new Emitter<boolean>());
	readonly onDidChangeGroupMaximized = this._onDidChangeGroupMaximized.event;

	//#endregion

	//#region Group Management

	get activeGroup(): IEditorGroupView {
		return this.activePart.activeGroup;
	}

	get sideGroup(): IEditorSideGroup {
		return this.activePart.sideGroup;
	}

	get groups(): IEditorGroupView[] {
		return this.getGroups();
	}

	get count(): number {
		return this.groups.length;
	}

	getGroups(order = GroupsOrder.CREATION_TIME): IEditorGroupView[] {
		const aggregatedParts = this.getGloballyAggregatedParts();
		if (aggregatedParts.length > 1 || (aggregatedParts.length === 1 && aggregatedParts[0] !== this.mainPart)) {
			let parts: EditorPart[];
			switch (order) {
				case GroupsOrder.GRID_APPEARANCE: // we currently do not have a way to compute by appearance over multiple windows
				case GroupsOrder.CREATION_TIME:
					parts = aggregatedParts;
					break;
				case GroupsOrder.MOST_RECENTLY_ACTIVE:
					parts = distinct([...this.mostRecentActiveParts.filter(part => !isExcludedFromGlobalEditorAggregation(part)), ...aggregatedParts]); // always ensure all parts are included
					break;
			}

			return parts.flatMap(part => part.getGroups(order));
		}

		return this.mainPart.getGroups(order);
	}

	getGroup(identifier: GroupIdentifier): IEditorGroupView | undefined {
		if (this._parts.size > 1) {
			for (const part of this._parts) {
				const group = part.getGroup(identifier);
				if (group) {
					return group;
				}
			}
		}

		return this.mainPart.getGroup(identifier);
	}

	private assertGroupView(group: IEditorGroupView | GroupIdentifier): IEditorGroupView {
		let groupView: IEditorGroupView | undefined;
		if (typeof group === 'number') {
			groupView = this.getGroup(group);
		} else {
			groupView = group;
		}

		if (!groupView) {
			throw new Error('Invalid editor group provided!');
		}

		return groupView;
	}

	activateGroup(group: IEditorGroupView | GroupIdentifier): IEditorGroupView {
		return this.getPart(group).activateGroup(group);
	}

	getSize(group: IEditorGroupView | GroupIdentifier): { width: number; height: number } {
		return this.getPart(group).getSize(group);
	}

	setSize(group: IEditorGroupView | GroupIdentifier, size: { width: number; height: number }): void {
		this.getPart(group).setSize(group, size);
	}

	arrangeGroups(arrangement: GroupsArrangement, group: IEditorGroupView | GroupIdentifier = this.activePart.activeGroup): void {
		this.getPart(group).arrangeGroups(arrangement, group);
	}

	toggleMaximizeGroup(group: IEditorGroupView | GroupIdentifier = this.activePart.activeGroup): void {
		this.getPart(group).toggleMaximizeGroup(group);
	}

	toggleExpandGroup(group: IEditorGroupView | GroupIdentifier = this.activePart.activeGroup): void {
		this.getPart(group).toggleExpandGroup(group);
	}

	restoreGroup(group: IEditorGroupView | GroupIdentifier): IEditorGroupView {
		return this.getPart(group).restoreGroup(group);
	}

	applyLayout(layout: EditorGroupLayout): void {
		this.activePart.applyLayout(layout);
	}

	getLayout(): EditorGroupLayout {
		return this.activePart.getLayout();
	}

	get orientation() {
		return this.activePart.orientation;
	}

	setGroupOrientation(orientation: GroupOrientation): void {
		this.activePart.setGroupOrientation(orientation);
	}

	findGroup(scope: IFindGroupScope, source: IEditorGroupView | GroupIdentifier = this.activeGroup, wrap?: boolean): IEditorGroupView | undefined {
		const sourcePart = this.getPart(source);
		const aggregatedParts = this.getGloballyAggregatedParts();
		if (aggregatedParts.length > 1 || (aggregatedParts.length === 1 && aggregatedParts[0] !== this.mainPart)) {
			const groups = this.getGroups(GroupsOrder.GRID_APPEARANCE).filter(group => isEditorGroupShown(this, group));

			// Ensure that FIRST/LAST dispatches globally over all parts
			if (scope.location === GroupLocation.FIRST || scope.location === GroupLocation.LAST) {
				return scope.location === GroupLocation.FIRST ? groups[0] : groups[groups.length - 1];
			}

			// Try to find in target part first without wrapping
			const group = sourcePart.findGroup(scope, source, false);
			if (group) {
				return group;
			}

			// Ensure that NEXT/PREVIOUS dispatches globally over all parts
			if (scope.location === GroupLocation.NEXT || scope.location === GroupLocation.PREVIOUS) {
				const sourceGroup = this.assertGroupView(source);
				const index = groups.indexOf(sourceGroup);

				if (scope.location === GroupLocation.NEXT) {
					let nextGroup: IEditorGroupView | undefined = groups[index + 1];
					if (!nextGroup && wrap) {
						nextGroup = groups[0];
					}

					return nextGroup;
				} else {
					let previousGroup: IEditorGroupView | undefined = groups[index - 1];
					if (!previousGroup && wrap) {
						previousGroup = groups[groups.length - 1];
					}

					return previousGroup;
				}
			}
		}

		return sourcePart.findGroup(scope, source, wrap);
	}

	addGroup(location: IEditorGroupView | GroupIdentifier, direction: GroupDirection): IEditorGroupView {
		return this.getPart(location).addGroup(location, direction);
	}

	removeGroup(group: IEditorGroupView | GroupIdentifier): void {
		this.getPart(group).removeGroup(group);
	}

	moveGroup(group: IEditorGroupView | GroupIdentifier, location: IEditorGroupView | GroupIdentifier, direction: GroupDirection): IEditorGroupView {
		return this.getPart(group).moveGroup(group, location, direction);
	}

	mergeGroup(group: IEditorGroupView | GroupIdentifier, target: IEditorGroupView | GroupIdentifier, options?: IMergeGroupOptions): boolean {
		return this.getPart(group).mergeGroup(group, target, options);
	}

	mergeAllGroups(target: IEditorGroupView | GroupIdentifier, options?: IMergeGroupOptions): boolean {
		return this.activePart.mergeAllGroups(target, options);
	}

	copyGroup(group: IEditorGroupView | GroupIdentifier, location: IEditorGroupView | GroupIdentifier, direction: GroupDirection): IEditorGroupView {
		return this.getPart(group).copyGroup(group, location, direction);
	}

	createEditorDropTarget(container: HTMLElement, delegate: IEditorDropTargetDelegate): IDisposable {
		return this.getPart(container).createEditorDropTarget(container, delegate);
	}

	//#endregion

	//#region Editor Group Context Key Handling

	private readonly globalContextKeys = new Map<string, IContextKey<ContextKeyValue>>();
	private readonly scopedContextKeys = new Map<GroupIdentifier, Map<string, IContextKey<ContextKeyValue>>>();

	private registerGroupsContextKeyListeners(): void {
		this._register(this.onDidChangeActiveGroup(() => this.updateGlobalContextKeys()));
		this.groups.forEach(group => this.registerGroupContextKeyProvidersListeners(group));
		this._register(this.onDidAddGroup(group => this.registerGroupContextKeyProvidersListeners(group)));
		this._register(this.onDidRemoveGroup(group => {
			this.scopedContextKeys.delete(group.id);
			this.registeredContextKeys.delete(group.id);
			this.contextKeyProviderDisposables.deleteAndDispose(group.id);
		}));
	}

	private updateGlobalContextKeys(): void {
		const activeGroupScopedContextKeys = this.scopedContextKeys.get(this.activeGroup.id);
		if (!activeGroupScopedContextKeys) {
			return;
		}

		for (const [key, globalContextKey] of this.globalContextKeys) {
			const scopedContextKey = activeGroupScopedContextKeys.get(key);
			if (scopedContextKey) {
				globalContextKey.set(scopedContextKey.get());
			} else {
				globalContextKey.reset();
			}
		}
	}

	bind<T extends ContextKeyValue>(contextKey: RawContextKey<T>, group: IEditorGroupView): IContextKey<T> {

		// Ensure we only bind to the same context key once globaly
		let globalContextKey = this.globalContextKeys.get(contextKey.key);
		if (!globalContextKey) {
			globalContextKey = contextKey.bindTo(this.contextKeyService);
			this.globalContextKeys.set(contextKey.key, globalContextKey);
		}

		// Ensure we only bind to the same context key once per group
		let groupScopedContextKeys = this.scopedContextKeys.get(group.id);
		if (!groupScopedContextKeys) {
			groupScopedContextKeys = new Map<string, IContextKey<ContextKeyValue>>();
			this.scopedContextKeys.set(group.id, groupScopedContextKeys);
		}
		let scopedContextKey = groupScopedContextKeys.get(contextKey.key);
		if (!scopedContextKey) {
			scopedContextKey = contextKey.bindTo(group.scopedContextKeyService);
			groupScopedContextKeys.set(contextKey.key, scopedContextKey);
		}

		const that = this;
		return {
			get(): T | undefined {
				return scopedContextKey.get() as T | undefined;
			},
			set(value: T): void {
				if (that.activeGroup === group) {
					globalContextKey.set(value);
				}
				scopedContextKey.set(value);
			},
			reset(): void {
				if (that.activeGroup === group) {
					globalContextKey.reset();
				}
				scopedContextKey.reset();
			},
		};
	}

	private readonly contextKeyProviders = new Map<string, IEditorGroupContextKeyProvider<ContextKeyValue>>();
	private readonly registeredContextKeys = new Map<GroupIdentifier, Map<string, IContextKey>>();

	registerContextKeyProvider<T extends ContextKeyValue>(provider: IEditorGroupContextKeyProvider<T>): IDisposable {
		if (this.contextKeyProviders.has(provider.contextKey.key) || this.globalContextKeys.has(provider.contextKey.key)) {
			throw new Error(`A context key provider for key ${provider.contextKey.key} already exists.`);
		}

		this.contextKeyProviders.set(provider.contextKey.key, provider);

		const setContextKeyForGroups = () => {
			for (const group of this.groups) {
				this.updateRegisteredContextKey(group, provider);
			}
		};

		// Run initially and on change
		setContextKeyForGroups();
		const onDidChange = provider.onDidChange?.(() => setContextKeyForGroups());

		return toDisposable(() => {
			onDidChange?.dispose();

			this.globalContextKeys.delete(provider.contextKey.key);
			this.scopedContextKeys.forEach(scopedContextKeys => scopedContextKeys.delete(provider.contextKey.key));

			this.contextKeyProviders.delete(provider.contextKey.key);
			this.registeredContextKeys.forEach(registeredContextKeys => registeredContextKeys.delete(provider.contextKey.key));
		});
	}

	private readonly contextKeyProviderDisposables = this._register(new DisposableMap<GroupIdentifier, IDisposable>());
	private registerGroupContextKeyProvidersListeners(group: IEditorGroupView): void {

		// Update context keys from providers for the group when its active editor changes
		const disposable = group.onDidActiveEditorChange(() => {
			for (const contextKeyProvider of this.contextKeyProviders.values()) {
				this.updateRegisteredContextKey(group, contextKeyProvider);
			}
		});

		this.contextKeyProviderDisposables.set(group.id, disposable);
	}

	private updateRegisteredContextKey<T extends ContextKeyValue>(group: IEditorGroupView, provider: IEditorGroupContextKeyProvider<T>): void {

		// Get the group scoped context keys for the provider
		// If the providers context key has not yet been bound
		// to the group, do so now.

		let groupRegisteredContextKeys = this.registeredContextKeys.get(group.id);
		if (!groupRegisteredContextKeys) {
			groupRegisteredContextKeys = new Map<string, IContextKey>();
			this.registeredContextKeys.set(group.id, groupRegisteredContextKeys);
		}

		let scopedRegisteredContextKey = groupRegisteredContextKeys.get(provider.contextKey.key);
		if (!scopedRegisteredContextKey) {
			scopedRegisteredContextKey = this.bind(provider.contextKey, group);
			groupRegisteredContextKeys.set(provider.contextKey.key, scopedRegisteredContextKey);
		}

		// Set the context key value for the group context
		scopedRegisteredContextKey.set(provider.getGroupContextKeyValue(group));
	}

	//#endregion

	//#region Main Editor Part Only

	get partOptions() { return this.mainPart.partOptions; }
	get onDidChangeEditorPartOptions() { return this.mainPart.onDidChangeEditorPartOptions; }

	enforcePartOptions(options: DeepPartial<IEditorPartOptions>): IDisposable {
		return this.mainPart.enforcePartOptions(options);
	}

	//#endregion
}

registerSingleton(IEditorGroupsService, EditorParts, InstantiationType.Eager);
