/*---------------------------------------------------------------------------------------------
 *  Copyright (c) Microsoft Corporation. All rights reserved.
 *  Licensed under the MIT License. See License.txt in the project root for license information.
 *--------------------------------------------------------------------------------------------*/

import assert from 'assert';
import { DeferredPromise, timeout } from '../../../../base/common/async.js';
import type { VSBuffer } from '../../../../base/common/buffer.js';
import type { CancellationToken } from '../../../../base/common/cancellation.js';
import { CancellationError, isCancellationError } from '../../../../base/common/errors.js';
import { Emitter, Event } from '../../../../base/common/event.js';
import { Disposable, DisposableStore } from '../../../../base/common/lifecycle.js';
import { ChannelClient, ChannelServer, ProxyChannel, type IMessagePassingProtocol } from '../../../../base/parts/ipc/common/ipc.js';
import { ensureNoDisposablesAreLeakedInTestSuite } from '../../../../base/test/common/utils.js';
import type {
	UniverseAgentChatRequest,
	UniverseAgentChatResponse,
	UniverseAgentChatSyncRequest,
	UniverseAgentChatSyncResult,
	UniverseAgentSyncInputDeliveryRequest,
	UniverseAgentSyncInputDeliveryResult,
	UniverseAgentChatStream,
	UniverseAgentContinueGenerationRequest,
	UniverseAgentRegenerateRequest,
	UniverseAgentResumeRequest,
	UniverseAgentSubscribeToolDetailRequest,
	UniverseAgentSubscribeToolDetailChunk,
	UniverseAgentConnectRequest,
	UniverseAgentConnectResult,
	UniverseAgentCreateSessionRequest,
	UniverseAgentCreateSessionResult,
	UniverseAgentDeleteSessionRequest,
	UniverseAgentSessionInfoRequest,
	UniverseAgentSessionInfoResult,
	UniverseAgentResumeSessionRequest,
	UniverseAgentResumeSessionResult,
	UniverseAgentPrewarmSessionsRequest,
	UniverseAgentPrewarmSessionsResult,
	UniverseAgentShelveSessionRequest,
	UniverseAgentShelveSessionResult,
	UniverseAgentUnshelveSessionRequest,
	UniverseAgentUnshelveSessionResult,
	UniverseAgentPurgeSessionRequest,
	UniverseAgentPurgeSessionResult,
	UniverseAgentExportSessionRequest,
	UniverseAgentExportSessionResult,
	UniverseAgentResolveTurnRequest,
	UniverseAgentResolveTurnResult,
	UniverseAgentAgentStatusRequest,
	UniverseAgentAgentStatusResult,
	UniverseAgentTodoRequest,
	UniverseAgentTodoResult,
	UniverseAgentCompactRequest,
	UniverseAgentCompactResult,
	UniverseAgentResolveAnchorRequest,
	UniverseAgentResolveAnchorResult,
	UniverseAgentUsageRequest,
	UniverseAgentUsageResult,
	UniverseAgentListAgentsRequest,
	UniverseAgentListAgentsResult,
	UniverseAgentAgentHistoryRequest,
	UniverseAgentAgentHistoryResult,
	UniverseAgentPauseAgentRequest,
	UniverseAgentPauseAgentResult,
	UniverseAgentBackRequest,
	UniverseAgentBackResult,
	UniverseAgentPruneRequest,
	UniverseAgentPruneResult,
	UniverseAgentResetAgentRequest,
	UniverseAgentResetAgentResult,
	UniverseAgentBranchRequest,
	UniverseAgentBranchResult,
	UniverseAgentSuspendLoopRequest,
	UniverseAgentSuspendLoopResult,
	UniverseAgentResumeLoopRequest,
	UniverseAgentResumeLoopResult,
	UniverseAgentStopLoopRequest,
	UniverseAgentStopLoopResult,
	UniverseAgentRenameSessionRequest,
	UniverseAgentRenameSessionResult,
	UniverseAgentCancelGenerationRequest,
	UniverseAgentCancelGenerationResult,
	UniverseAgentCancelToolCallRequest,
	UniverseAgentCancelToolCallResult,
	UniverseAgentRunToolInBackgroundRequest,
	UniverseAgentRunToolInBackgroundResult,
	UniverseAgentStopShellTaskRequest,
	UniverseAgentStopShellTaskResult,
	UniverseAgentSendShellSessionClientControlRequest,
	UniverseAgentSendShellSessionClientControlResult,
	UniverseAgentFetchToolUsageDetailRequest,
	UniverseAgentFetchToolUsageDetailResult,
	UniverseAgentFireTriggerWebhookRequest,
	UniverseAgentFireTriggerWebhookResult,
	UniverseAgentInstallSessionDemoFakeRequest,
	UniverseAgentInstallSessionDemoFakeResult,
	UniverseAgentClearSessionDemoFakeRequest,
	UniverseAgentClearSessionDemoFakeResult,
	UniverseAgentSwitchWorkDirRequest,
	UniverseAgentSwitchWorkDirResult,
	UniverseAgentTestModelProfileRequest,
	UniverseAgentTestModelProfileResult,
	UniverseAgentSetConfigRequest,
	UniverseAgentSetConfigResult,
	UniverseAgentSetModelPreferencesRequest,
	UniverseAgentSetModelPreferencesResult,
	UniverseAgentSetSessionGoalRequest,
	UniverseAgentSetSessionGoalResult,
	UniverseAgentCancelSessionGoalRequest,
	UniverseAgentCancelSessionGoalResult,
	UniverseAgentRespondPermissionRequest,
	UniverseAgentRespondPermissionResult,
	UniverseAgentSyncPermissionRuleRequest,
	UniverseAgentSyncPermissionRuleResult,
	UniverseAgentPromotePermissionRuleRequest,
	UniverseAgentPromotePermissionRuleResult,
	UniverseAgentGetSessionRulesRequest,
	UniverseAgentGetSessionRulesResult,
	UniverseAgentSetPermissionModeRequest,
	UniverseAgentSetClientToolProfileRequest,
	UniverseAgentSetClientToolProfileResult,
	UniverseAgentRegisterSessionEngineTriggerRequest,
	UniverseAgentRegisterSessionEngineTriggerResult,
	UniverseAgentSetPermissionModeResult,
	UniverseAgentTaskUpdateRequest,
	UniverseAgentTaskUpdateResult,
	UniverseAgentTaskCancelRequest,
	UniverseAgentTaskCancelResult,
	UniverseAgentMessageMemberRequest,
	UniverseAgentMessageMemberResult,
	UniverseAgentCreateTeamRequest,
	UniverseAgentCreateTeamResult,
	UniverseAgentStartMemberRequest,
	UniverseAgentStartMemberResult,
	UniverseAgentKillMemberRequest,
	UniverseAgentKillMemberResult,
	UniverseAgentAbortTeamRequest,
	UniverseAgentAbortTeamResult,
	UniverseAgentGetConfigRequest,
	UniverseAgentGetConfigResult,
	UniverseAgentSwitchModelRequest,
	UniverseAgentSwitchModelResult,
	UniverseAgentResolveModelRequest,
	UniverseAgentResolveModelResult,
	UniverseAgentWatchConfigRequest,
	UniverseAgentConfigChangedEvent,
	UniverseAgentUploadChunk,
	UniverseAgentUploadAttachmentResult,
	UniverseAgentSetPermissionPolicyRequest,
	UniverseAgentSetPermissionPolicyResult,
	UniverseAgentGetModelPreferencesRequest,
	UniverseAgentGetModelPreferencesResult,
	UniverseAgentRespondQuestionRequest,
	UniverseAgentRespondQuestionResult,
	UniverseAgentEnqueueQueueItemRequest,
	UniverseAgentInsertQueueItemRequest,
	UniverseAgentReorderQueueRequest,
	UniverseAgentDeleteQueueItemRequest,
	UniverseAgentRetryQueueItemRequest,
	UniverseAgentRetryAllFailedRequest,
	UniverseAgentRetryQueueItemUploadRequest,
	UniverseAgentPinQueueItemRequest,
	UniverseAgentSetQueueItemLockedRequest,
	UniverseAgentInjectQueueItemRequest,
	UniverseAgentSetQueueItemForkAnchorRequest,
	UniverseAgentEditQueueItemRequest,
	UniverseAgentHoldQueueItemRequest,
	UniverseAgentQueueItemRefRequest,
	UniverseAgentQueueMutationResult,
	UniverseAgentQueueRefRequest,
	UniverseAgentForkAgentRequest,
	UniverseAgentForkAgentResult,
	UniverseAgentKillAgentRequest,
	UniverseAgentKillAgentResult,
	UniverseAgentDeleteMessageRequest,
	UniverseAgentDeleteMessageResult,
	UniverseAgentEditMessageRequest,
	UniverseAgentEditMessageResult,
	UniverseAgentSendClientToolResponseRequest,
	UniverseAgentSendClientToolResponseResult,
	UniverseAgentListSnapshotsRequest,
	UniverseAgentListSnapshotsResult,
	UniverseAgentListLoopSnapshotsRequest,
	UniverseAgentListLoopSnapshotsResult,
	UniverseAgentCreateSnapshotRequest,
	UniverseAgentCreateSnapshotResult,
	UniverseAgentRestoreSnapshotRequest,
	UniverseAgentRestoreSnapshotResult,
	UniverseAgentDeleteSnapshotRequest,
	UniverseAgentDeleteSnapshotResult,
	UniverseAgentToolInfoRequest,
	UniverseAgentToolInfoResult,
	UniverseAgentListCommandsResult,
	UniverseAgentGetCommandDefRequest,
	UniverseAgentGetCommandDefResult,
	UniverseAgentListFilesRequest,
	UniverseAgentListFilesResult,
	UniverseAgentReadFileRequest,
	UniverseAgentReadFileResult,
	UniverseAgentGetFileInfoRequest,
	UniverseAgentGetFileInfoResult,
	UniverseAgentWriteFileRequest,
	UniverseAgentWriteFileResult,
	UniverseAgentForceWriteFileRequest,
	UniverseAgentAgentMergeRequest,
	UniverseAgentAgentMergeResult,
	UniverseAgentReadGitSummaryRequest,
	UniverseAgentReadGitSummaryResult,
	UniverseAgentReadGitChangesRequest,
	UniverseAgentReadGitChangesResult,
	UniverseAgentReadGitFileDiffRequest,
	UniverseAgentReadGitFileDiffResult,
	UniverseAgentWriteGitStagePathsRequest,
	UniverseAgentWriteGitCommitRequest,
	UniverseAgentWriteGitApplyHunksRequest,
	UniverseAgentWriteGitWriteResult,
	UniverseAgentGetSessionUsageRequest,
	UniverseAgentGetSessionUsageResult,
	UniverseAgentGetGlobalUsageResult,
	UniverseAgentSaveMemoryRequest,
	UniverseAgentSaveMemoryResult,
	UniverseAgentMemorySearchRequest,
	UniverseAgentMemorySearchResult,
	UniverseAgentMemorySearchDeepRequest,
	UniverseAgentMemorySearchDeepResult,
	UniverseAgentReadMemoryRequest,
	UniverseAgentReadMemoryResult,
	UniverseAgentMemoryListRequest,
	UniverseAgentMemoryListResult,
	UniverseAgentDeleteMemoryRequest,
	UniverseAgentDeleteMemoryResult,
	UniverseAgentReflectMemoryRequest,
	UniverseAgentReflectMemoryResult,
	UniverseAgentMemoryRebuildRequest,
	UniverseAgentMemoryRebuildEvent,
	UniverseAgentRevertMemoryRequest,
	UniverseAgentRevertMemoryResult,
	UniverseAgentMemoryHistoryRequest,
	UniverseAgentMemoryHistoryResult,
	UniverseAgentContextVariableListRequest,
	UniverseAgentContextVariableListResult,
	UniverseAgentContextVariableReadRequest,
	UniverseAgentContextVariableReadResult,
	UniverseAgentListNodesRequest,
	UniverseAgentListNodesResult,
	UniverseAgentGetNodeRequest,
	UniverseAgentRemoteAgentInfo,
	UniverseAgentCheckConnectionRequest,
	UniverseAgentConnectionReport,
	UniverseAgentSetMaintenanceRequest,
	UniverseAgentSetMaintenanceResult,
	UniverseAgentExitMaintenanceRequest,
	UniverseAgentExitMaintenanceResult,
	UniverseAgentListConfigsResult,
	UniverseAgentGetRemoteAgentConfigRequest,
	UniverseAgentSaveRemoteAgentConfigRequest,
	UniverseAgentSaveRemoteAgentConfigResult,
	UniverseAgentRemoteAgentConfig,
	UniverseAgentResetErrorRequest,
	UniverseAgentResetErrorResult,
	UniverseAgentDeleteRemoteAgentConfigRequest,
	UniverseAgentDeleteRemoteAgentConfigResult,
	UniverseAgentReloadRemoteAgentsResult,
	UniverseAgentCreateRemoteSessionRequest,
	UniverseAgentCreateRemoteSessionResult,
	UniverseAgentDestroyRemoteSessionRequest,
	UniverseAgentDestroyRemoteSessionResult,
	UniverseAgentGetRemoteSessionStatusRequest,
	UniverseAgentGetRemoteSessionStatusResult,
	UniverseAgentGetRemoteSessionHistoryRequest,
	UniverseAgentGetRemoteSessionHistoryResult,
	UniverseAgentResumeRemoteSessionRequest,
	UniverseAgentResumeRemoteSessionResult,
	UniverseAgentCancelRemoteSessionRequest,
	UniverseAgentCancelRemoteSessionResult,
	UniverseAgentRemoteChatRequest,
	UniverseAgentRemoteChatResponse,
	UniverseAgentGetUploadProgressRequest,
	UniverseAgentGetUploadProgressResult,
	UniverseAgentShutdownRequest,
	UniverseAgentShutdownResult,
	UniverseAgentWriteClipboardRequest,
	UniverseAgentWriteClipboardResult,
	UniverseAgentReadClipboardRequest,
	UniverseAgentReadClipboardResult,
	UniverseAgentListClipboardRequest,
	UniverseAgentListClipboardResult,
	UniverseAgentClearClipboardRequest,
	UniverseAgentClearClipboardResult,
	UniverseAgentDownloadAttachmentRequest,
	UniverseAgentDownloadChunk,
	UniverseAgentPtyClientMessage,
	UniverseAgentPtyServerMessage,
	UniverseAgentHealthCheckResult,
	UniverseAgentDoctorResult,
	UniverseAgentListDevicesResult,
	UniverseAgentPairApproveRequest,
	UniverseAgentPairApproveResult,
	UniverseAgentPairRejectRequest,
	UniverseAgentPairRejectResult,
	UniverseAgentRevokeRequest,
	UniverseAgentRevokeResult,
	UniverseAgentRotateTokenRequest,
	UniverseAgentRotateTokenResult,
	UniverseAgentListPendingResult,
	UniverseAgentListTriggersRequest,
	UniverseAgentListTriggersResult,
	UniverseAgentUpsertTriggerRequest,
	UniverseAgentUpsertTriggerResult,
	UniverseAgentDeleteTriggerRequest,
	UniverseAgentDeleteTriggerResult,
	UniverseAgentSetTriggerEnabledRequest,
	UniverseAgentSetTriggerEnabledResult,
	UniverseAgentFireTriggerRequest,
	UniverseAgentFireTriggerResult,
	UniverseAgentGetHistoryRequest,
	UniverseAgentGetHistoryResult,
	UniverseAgentListSessionsRequest,
	UniverseAgentListSessionsResult,
	UniverseAgentSaveAgentProfileRequest,
	UniverseAgentSessionEvent,
	UniverseAgentSessionStreamCloseCause,
	UniverseAgentSaveSkillContentRequest,
	UniverseAgentSaveSkillContentResult,
	UniverseAgentSetSkillEnabledRequest,
	UniverseAgentSkillInfoRequest,
	UniverseAgentFetchToolDetailRequest,
	UniverseAgentFetchToolDetailWireResult,
	UniverseAgentListProviderStatusResult,
	UniverseAgentUpsertProviderCredentialsRequest,
	UniverseAgentClearProviderCredentialsRequest,
	UniverseAgentProviderStatus,
	UniverseAgentUpsertModelRequest,
	UniverseAgentModelEntry,
	UniverseAgentDeleteModelRequest,
	UniverseAgentSetModelEnabledRequest,
} from '../../common/universeAgentTypes.js';
import { GrpcStatusCode, IUniverseAgentGrpcTransport, UniverseAgentAuthNonceRequest, UniverseAgentAuthNonceResult, UniverseAgentDeviceAuthConnectRequest, UniverseAgentGrpcServices, UniverseAgentSaveSkillContentMethodKey, UniverseAgentSessionListMethodKey, UniverseAgentTransportError } from '../../node/grpc/grpcTransport.js';
import type { IUniverseAgentConnection } from '../../common/universeAgentConnection.js';
import { UniverseAgentConnectionChannelClient } from '../../common/universeAgentConnectionChannelClient.js';
import { UniverseAgentConnectionIpcChannel } from '../../common/universeAgentConnectionIpcChannel.js';
import type { UniverseAgentExpectedOwner } from '../../common/universeAgentExpectedOwner.js';
import { createStreamCloseGate } from '../../common/sessionStreamClose.js';
import { DEVICE_AUTH_RPC_NOT_UNAVAILABLE_PREFIX } from '../../node/deviceAuthHandshake.js';
import { SESSION_TOKEN_REJECT_GRACE_MS, SESSION_TOKEN_REJECTED_REASON, TRANSPORT_UNAVAILABLE_REASON, UniverseAgentConnectionService, type UniverseAgentConnectionServiceOptions } from '../../node/universeAgentConnectionService.js';
import type { GrpcUniverseAgentClient } from '../../node/grpc/grpcClient.js';
import type { LocalEngineTarget } from '../../node/localEngineDiscovery.js';
import type { ConnectionProfile, IConnectionProfileStore } from '../../node/connectionProfileStore.js';
import type { IClientIdentityStore } from '../../node/clientIdentityTypes.js';
import { createEngineTrustRecord } from '../../node/engineTrustStore.js';
import { createConnectionResolver, type ConnectionResolver } from '../../node/connectionResolver.js';
import type { PairingOrchestrator } from '../../node/pairingOrchestrator.js';
import { PAIRING_REQUIRED_USE_CONNECT_REASON } from '../../common/connectionHubTypes.js';
import { WEB_UNSUPPORTED_LOCAL_ENGINE_REASON } from '../../common/universeAgentRendererSync.js';
import { createEmptyCapabilitySnapshot } from '../../common/universeAgentCapabilities.js';
import { InMemoryHubSessionStore } from '../../node/hubSessionStore.js';
import type { ParsedAuthSessionV1 } from '../../node/hub/hub-auth-client.js';
import { randomUUID } from 'node:crypto';

class MockUniverseAgentGrpcTransport implements IUniverseAgentGrpcTransport {

	private _alive = true;
	private _emittersDisposed = false;
	readonly installedSessionTokens: string[] = [];
	readonly sessionTokenRejected = new Emitter<void>();
	readonly unavailableObserved = new Emitter<void>();
	readonly onDidRejectSessionToken = this.sessionTokenRejected.event;
	readonly onDidObserveUnavailable = this.unavailableObserved.event;

	constructor(
		private readonly handlers: {
			ownedOperation?: (method: string) => Promise<void>;
			connect?: (request: UniverseAgentConnectRequest) => Promise<UniverseAgentConnectResult>;
			probeRpc?: (service: string, method: string) => Promise<number>;
			listSessions?: (request: UniverseAgentListSessionsRequest) => Promise<UniverseAgentListSessionsResult>;
			saveSkillContent?: (request: UniverseAgentSaveSkillContentRequest) => Promise<UniverseAgentSaveSkillContentResult>;
			fetchAgentTree?: (sessionId: string) => Promise<import('../../common/universeAgentTypes.js').UniverseAgentAgentTreeNode | undefined>;
			fetchToolDetail?: (request: UniverseAgentFetchToolDetailRequest) => Promise<UniverseAgentFetchToolDetailWireResult>;
			listProviderStatus?: () => Promise<UniverseAgentListProviderStatusResult>;
			upsertProviderCredentials?: (request: UniverseAgentUpsertProviderCredentialsRequest) => Promise<UniverseAgentProviderStatus>;
			upsertModel?: (request: UniverseAgentUpsertModelRequest) => Promise<UniverseAgentModelEntry>;
		} = {},
	) { }

	get isChannelAlive(): boolean {
		return this._alive;
	}

	setChannelAlive(alive: boolean): void {
		this._alive = alive;
	}

	async connect(request: UniverseAgentConnectRequest): Promise<UniverseAgentConnectResult> {
		if (this.handlers.connect) {
			return this.handlers.connect(request);
		}
		return {
			sessionToken: 'token-1',
			workDir: '/tmp/work',
			methods: ['ToolService.ListSkills'],
			events: [],
		};
	}

	async connectWithoutDeviceAuth(): Promise<UniverseAgentConnectResult> {
		return this.connect({ clientId: 'local-fixture', protocolVersion: '1' });
	}

	async getAuthNonce(_request: UniverseAgentAuthNonceRequest): Promise<UniverseAgentAuthNonceResult> {
		return {
			authNonce: new Uint8Array(32),
			engineIdentityId: 'engine-id',
			engineCertFingerprint: 'a'.repeat(64),
		};
	}

	async connectWithDeviceAuth(_request: UniverseAgentDeviceAuthConnectRequest): Promise<UniverseAgentConnectResult> {
		return {
			sessionToken: 'token-1',
			methods: [],
			events: [],
		};
	}

	installSessionToken(token: string): void {
		if (token.length === 0) {
			return;
		}
		this.installedSessionTokens.push(token);
	}

	rejectSessionToken(): void {
		this.sessionTokenRejected.fire();
	}

	observeUnavailable(): void {
		this.unavailableObserved.fire();
	}

	close(): void {
		this._alive = false;
		if (this._emittersDisposed) {
			return;
		}
		this._emittersDisposed = true;
		this.sessionTokenRejected.dispose();
		this.unavailableObserved.dispose();
	}

	async probeRpc(service: string, method: string): Promise<number> {
		if (this.handlers.probeRpc) {
			return this.handlers.probeRpc(service, method);
		}
		return GrpcStatusCode.OK;
	}

	async listSessions(_request: UniverseAgentListSessionsRequest): Promise<UniverseAgentListSessionsResult> {
		if (this.handlers.listSessions) {
			return this.handlers.listSessions(_request);
		}
		return { sessions: [], totalCount: 0 };
	}

	async createSession(_request: UniverseAgentCreateSessionRequest): Promise<UniverseAgentCreateSessionResult> {
		return { sessionId: 'new-session' };
	}

	async deleteSession(_request: UniverseAgentDeleteSessionRequest): Promise<void> {
	}

	readonly getSessionInfoCalls: UniverseAgentSessionInfoRequest[] = [];
	getSessionInfoResult: UniverseAgentSessionInfoResult = {
		sessionId: '',
		createdAt: 0,
		lastAccessedAt: 0,
		provider: '',
		model: '',
	};

	async getSessionInfo(request: UniverseAgentSessionInfoRequest): Promise<UniverseAgentSessionInfoResult> {
		this.getSessionInfoCalls.push(request);
		return this.getSessionInfoResult;
	}

	readonly resumeSessionCalls: UniverseAgentResumeSessionRequest[] = [];
	resumeSessionResult: UniverseAgentResumeSessionResult = { ok: true };

	async resumeSession(request: UniverseAgentResumeSessionRequest): Promise<UniverseAgentResumeSessionResult> {
		this.resumeSessionCalls.push(request);
		return this.resumeSessionResult;
	}

	readonly prewarmSessionsCalls: UniverseAgentPrewarmSessionsRequest[] = [];
	prewarmSessionsResult: UniverseAgentPrewarmSessionsResult = { entries: [] };

	async prewarmSessions(request: UniverseAgentPrewarmSessionsRequest): Promise<UniverseAgentPrewarmSessionsResult> {
		this.prewarmSessionsCalls.push(request);
		return this.prewarmSessionsResult;
	}

	readonly shelveSessionCalls: UniverseAgentShelveSessionRequest[] = [];
	shelveSessionResult: UniverseAgentShelveSessionResult = { ok: true };

	async shelveSession(request: UniverseAgentShelveSessionRequest): Promise<UniverseAgentShelveSessionResult> {
		this.shelveSessionCalls.push(request);
		return this.shelveSessionResult;
	}

	readonly unshelveSessionCalls: UniverseAgentUnshelveSessionRequest[] = [];
	unshelveSessionResult: UniverseAgentUnshelveSessionResult = { ok: true };

	async unshelveSession(request: UniverseAgentUnshelveSessionRequest): Promise<UniverseAgentUnshelveSessionResult> {
		this.unshelveSessionCalls.push(request);
		return this.unshelveSessionResult;
	}

	readonly purgeSessionCalls: UniverseAgentPurgeSessionRequest[] = [];
	purgeSessionResult: UniverseAgentPurgeSessionResult = { ok: true };

	async purgeSession(request: UniverseAgentPurgeSessionRequest): Promise<UniverseAgentPurgeSessionResult> {
		this.purgeSessionCalls.push(request);
		return this.purgeSessionResult;
	}

	readonly exportSessionCalls: UniverseAgentExportSessionRequest[] = [];
	exportSessionResult: UniverseAgentExportSessionResult = { content: '', format: '' };

	async exportSession(request: UniverseAgentExportSessionRequest): Promise<UniverseAgentExportSessionResult> {
		this.exportSessionCalls.push(request);
		return this.exportSessionResult;
	}

	readonly resolveTurnCalls: UniverseAgentResolveTurnRequest[] = [];
	resolveTurnResult: UniverseAgentResolveTurnResult = { kind: 'unspecified' };

	async resolveTurn(request: UniverseAgentResolveTurnRequest): Promise<UniverseAgentResolveTurnResult> {
		this.resolveTurnCalls.push(request);
		return this.resolveTurnResult;
	}

	readonly getAgentStatusCalls: UniverseAgentAgentStatusRequest[] = [];
	getAgentStatusResult: UniverseAgentAgentStatusResult = {};

	async getAgentStatus(request: UniverseAgentAgentStatusRequest): Promise<UniverseAgentAgentStatusResult> {
		this.getAgentStatusCalls.push(request);
		return this.getAgentStatusResult;
	}

	readonly getTodoCalls: UniverseAgentTodoRequest[] = [];
	getTodoResult: UniverseAgentTodoResult = { items: [] };

	async getTodo(request: UniverseAgentTodoRequest): Promise<UniverseAgentTodoResult> {
		this.getTodoCalls.push(request);
		return this.getTodoResult;
	}

	readonly compactCalls: UniverseAgentCompactRequest[] = [];
	compactResult: UniverseAgentCompactResult = { ok: true };

	async compact(request: UniverseAgentCompactRequest): Promise<UniverseAgentCompactResult> {
		this.compactCalls.push(request);
		return this.compactResult;
	}

	readonly resolveAnchorCalls: UniverseAgentResolveAnchorRequest[] = [];
	resolveAnchorResult: UniverseAgentResolveAnchorResult = {};

	async resolveAnchor(request: UniverseAgentResolveAnchorRequest): Promise<UniverseAgentResolveAnchorResult> {
		this.resolveAnchorCalls.push(request);
		return this.resolveAnchorResult;
	}

	readonly getUsageCalls: UniverseAgentUsageRequest[] = [];
	getUsageResult: UniverseAgentUsageResult = {
		totalInputTokens: 0,
		totalOutputTokens: 0,
		totalTurns: 0,
		agentUsages: [],
		recentRequestSpans: [],
	};

	async getUsage(request: UniverseAgentUsageRequest): Promise<UniverseAgentUsageResult> {
		this.getUsageCalls.push(request);
		return this.getUsageResult;
	}

	readonly listAgentsCalls: UniverseAgentListAgentsRequest[] = [];
	listAgentsResult: UniverseAgentListAgentsResult = { agents: [] };

	async listAgents(request: UniverseAgentListAgentsRequest): Promise<UniverseAgentListAgentsResult> {
		this.listAgentsCalls.push(request);
		return this.listAgentsResult;
	}

	readonly getAgentHistoryCalls: UniverseAgentAgentHistoryRequest[] = [];
	getAgentHistoryResult: UniverseAgentAgentHistoryResult = { entries: [], total: 0 };

	async getAgentHistory(request: UniverseAgentAgentHistoryRequest): Promise<UniverseAgentAgentHistoryResult> {
		this.getAgentHistoryCalls.push(request);
		return this.getAgentHistoryResult;
	}

	readonly pauseAgentCalls: UniverseAgentPauseAgentRequest[] = [];
	pauseAgentResult: UniverseAgentPauseAgentResult = { ok: true };

	async pauseAgent(request: UniverseAgentPauseAgentRequest): Promise<UniverseAgentPauseAgentResult> {
		this.pauseAgentCalls.push(request);
		return this.pauseAgentResult;
	}

	readonly backCalls: UniverseAgentBackRequest[] = [];
	backResult: UniverseAgentBackResult = { ok: true };

	async back(request: UniverseAgentBackRequest): Promise<UniverseAgentBackResult> {
		this.backCalls.push(request);
		return this.backResult;
	}
	readonly pruneCalls: UniverseAgentPruneRequest[] = [];
	pruneResult: UniverseAgentPruneResult = { ok: true, removedCount: 0 };

	async prune(request: UniverseAgentPruneRequest): Promise<UniverseAgentPruneResult> {
		this.pruneCalls.push(request);
		return this.pruneResult;
	}
	readonly resetAgentCalls: UniverseAgentResetAgentRequest[] = [];
	resetAgentResult: UniverseAgentResetAgentResult = { ok: true };

	async resetAgent(request: UniverseAgentResetAgentRequest): Promise<UniverseAgentResetAgentResult> {
		this.resetAgentCalls.push(request);
		return this.resetAgentResult;
	}

	readonly branchCalls: UniverseAgentBranchRequest[] = [];
	branchResult: UniverseAgentBranchResult = { ok: true, currentBranch: 0, totalBranches: 0 };

	async branch(request: UniverseAgentBranchRequest): Promise<UniverseAgentBranchResult> {
		this.branchCalls.push(request);
		return this.branchResult;
	}

	readonly suspendLoopCalls: UniverseAgentSuspendLoopRequest[] = [];
	suspendLoopResult: UniverseAgentSuspendLoopResult = { ok: true };

	async suspendLoop(request: UniverseAgentSuspendLoopRequest): Promise<UniverseAgentSuspendLoopResult> {
		this.suspendLoopCalls.push(request);
		return this.suspendLoopResult;
	}

	readonly resumeLoopCalls: UniverseAgentResumeLoopRequest[] = [];
	resumeLoopResult: UniverseAgentResumeLoopResult = { ok: true };

	async resumeLoop(request: UniverseAgentResumeLoopRequest): Promise<UniverseAgentResumeLoopResult> {
		this.resumeLoopCalls.push(request);
		return this.resumeLoopResult;
	}

	readonly stopLoopCalls: UniverseAgentStopLoopRequest[] = [];
	stopLoopResult: UniverseAgentStopLoopResult = { ok: true };

	async stopLoop(request: UniverseAgentStopLoopRequest): Promise<UniverseAgentStopLoopResult> {
		this.stopLoopCalls.push(request);
		return this.stopLoopResult;
	}

	readonly renameCalls: UniverseAgentRenameSessionRequest[] = [];
	renameResult: UniverseAgentRenameSessionResult = { ok: true };

	async renameSession(request: UniverseAgentRenameSessionRequest): Promise<UniverseAgentRenameSessionResult> {
		this.renameCalls.push(request);
		return this.renameResult;
	}

	readonly cancelCalls: UniverseAgentCancelGenerationRequest[] = [];
	cancelResult: UniverseAgentCancelGenerationResult = { ok: true };

	async cancelGeneration(request: UniverseAgentCancelGenerationRequest): Promise<UniverseAgentCancelGenerationResult> {
		this.cancelCalls.push(request);
		return this.cancelResult;
	}

	readonly cancelToolCallCalls: UniverseAgentCancelToolCallRequest[] = [];
	cancelToolCallResult: UniverseAgentCancelToolCallResult = { ok: true };

	async cancelToolCall(request: UniverseAgentCancelToolCallRequest): Promise<UniverseAgentCancelToolCallResult> {
		this.cancelToolCallCalls.push(request);
		return this.cancelToolCallResult;
	}

	readonly runToolInBackgroundCalls: UniverseAgentRunToolInBackgroundRequest[] = [];
	runToolInBackgroundResult: UniverseAgentRunToolInBackgroundResult = { ok: true };

	async runToolInBackground(request: UniverseAgentRunToolInBackgroundRequest): Promise<UniverseAgentRunToolInBackgroundResult> {
		this.runToolInBackgroundCalls.push(request);
		return this.runToolInBackgroundResult;
	}

	readonly stopShellTaskCalls: UniverseAgentStopShellTaskRequest[] = [];
	stopShellTaskResult: UniverseAgentStopShellTaskResult = { ok: true };

	async stopShellTask(request: UniverseAgentStopShellTaskRequest): Promise<UniverseAgentStopShellTaskResult> {
		this.stopShellTaskCalls.push(request);
		return this.stopShellTaskResult;
	}

	readonly sendShellSessionClientControlCalls: UniverseAgentSendShellSessionClientControlRequest[] = [];
	sendShellSessionClientControlResult: UniverseAgentSendShellSessionClientControlResult = { ok: true };

	async sendShellSessionClientControl(request: UniverseAgentSendShellSessionClientControlRequest): Promise<UniverseAgentSendShellSessionClientControlResult> {
		this.sendShellSessionClientControlCalls.push(request);
		return this.sendShellSessionClientControlResult;
	}

	readonly fetchToolUsageDetailCalls: UniverseAgentFetchToolUsageDetailRequest[] = [];
	fetchToolUsageDetailResult: UniverseAgentFetchToolUsageDetailResult = { ok: true, toolCallId: '', contextSources: [] };

	async fetchToolUsageDetail(request: UniverseAgentFetchToolUsageDetailRequest): Promise<UniverseAgentFetchToolUsageDetailResult> {
		this.fetchToolUsageDetailCalls.push(request);
		return this.fetchToolUsageDetailResult;
	}

	readonly fireTriggerWebhookCalls: UniverseAgentFireTriggerWebhookRequest[] = [];
	fireTriggerWebhookResult: UniverseAgentFireTriggerWebhookResult = { status: '', eventId: '', reason: '' };

	async fireTriggerWebhook(request: UniverseAgentFireTriggerWebhookRequest): Promise<UniverseAgentFireTriggerWebhookResult> {
		this.fireTriggerWebhookCalls.push(request);
		return this.fireTriggerWebhookResult;
	}

	readonly installSessionDemoFakeCalls: UniverseAgentInstallSessionDemoFakeRequest[] = [];
	installSessionDemoFakeResult: UniverseAgentInstallSessionDemoFakeResult = { ok: true, reasonCode: '' };

	async installSessionDemoFake(request: UniverseAgentInstallSessionDemoFakeRequest): Promise<UniverseAgentInstallSessionDemoFakeResult> {
		this.installSessionDemoFakeCalls.push(request);
		return this.installSessionDemoFakeResult;
	}

	readonly clearSessionDemoFakeCalls: UniverseAgentClearSessionDemoFakeRequest[] = [];
	clearSessionDemoFakeResult: UniverseAgentClearSessionDemoFakeResult = { ok: true, reasonCode: '' };

	async clearSessionDemoFake(request: UniverseAgentClearSessionDemoFakeRequest): Promise<UniverseAgentClearSessionDemoFakeResult> {
		this.clearSessionDemoFakeCalls.push(request);
		return this.clearSessionDemoFakeResult;
	}

	readonly switchWorkDirCalls: UniverseAgentSwitchWorkDirRequest[] = [];
	switchWorkDirResult: UniverseAgentSwitchWorkDirResult = { ok: true, previousWorkDir: '', currentWorkDir: '' };

	async switchWorkDir(request: UniverseAgentSwitchWorkDirRequest): Promise<UniverseAgentSwitchWorkDirResult> {
		this.switchWorkDirCalls.push(request);
		return this.switchWorkDirResult;
	}

	readonly testModelProfileCalls: UniverseAgentTestModelProfileRequest[] = [];
	testModelProfileResult: UniverseAgentTestModelProfileResult = { ok: true };

	async testModelProfile(request: UniverseAgentTestModelProfileRequest): Promise<UniverseAgentTestModelProfileResult> {
		const ownedOperation = this.recordOwnedOperation('testModelProfile', request);
		if (ownedOperation) { await ownedOperation; }
		this.testModelProfileCalls.push(request);
		return this.testModelProfileResult;
	}

	readonly setConfigCalls: UniverseAgentSetConfigRequest[] = [];
	setConfigResult: UniverseAgentSetConfigResult = { ok: true };

	async setConfig(request: UniverseAgentSetConfigRequest): Promise<UniverseAgentSetConfigResult> {
		this.setConfigCalls.push(request);
		return this.setConfigResult;
	}

	readonly setModelPreferencesCalls: UniverseAgentSetModelPreferencesRequest[] = [];
	setModelPreferencesResult: UniverseAgentSetModelPreferencesResult = { minLevel: 0, maxCost: '', minSpeed: '', strategy: '' };

	async setModelPreferences(request: UniverseAgentSetModelPreferencesRequest): Promise<UniverseAgentSetModelPreferencesResult> {
		this.setModelPreferencesCalls.push(request);
		return this.setModelPreferencesResult;
	}

	readonly setGoalCalls: UniverseAgentSetSessionGoalRequest[] = [];
	setGoalResult: UniverseAgentSetSessionGoalResult = { ok: true };

	async setSessionGoal(request: UniverseAgentSetSessionGoalRequest): Promise<UniverseAgentSetSessionGoalResult> {
		this.setGoalCalls.push(request);
		return this.setGoalResult;
	}

	readonly cancelGoalCalls: UniverseAgentCancelSessionGoalRequest[] = [];
	cancelGoalResult: UniverseAgentCancelSessionGoalResult = { ok: true };

	async cancelSessionGoal(request: UniverseAgentCancelSessionGoalRequest): Promise<UniverseAgentCancelSessionGoalResult> {
		this.cancelGoalCalls.push(request);
		return this.cancelGoalResult;
	}

	readonly respondPermissionCalls: UniverseAgentRespondPermissionRequest[] = [];
	respondPermissionResult: UniverseAgentRespondPermissionResult = { ok: true };

	async respondPermission(request: UniverseAgentRespondPermissionRequest): Promise<UniverseAgentRespondPermissionResult> {
		this.respondPermissionCalls.push(request);
		return this.respondPermissionResult;
	}

	readonly syncPermissionRuleCalls: UniverseAgentSyncPermissionRuleRequest[] = [];
	syncPermissionRuleResult: UniverseAgentSyncPermissionRuleResult = { ok: true, ruleId: '' };

	async syncPermissionRule(request: UniverseAgentSyncPermissionRuleRequest): Promise<UniverseAgentSyncPermissionRuleResult> {
		this.syncPermissionRuleCalls.push(request);
		return this.syncPermissionRuleResult;
	}

	readonly promotePermissionRuleCalls: UniverseAgentPromotePermissionRuleRequest[] = [];
	promotePermissionRuleResult: UniverseAgentPromotePermissionRuleResult = { ok: true };

	async promotePermissionRule(request: UniverseAgentPromotePermissionRuleRequest): Promise<UniverseAgentPromotePermissionRuleResult> {
		this.promotePermissionRuleCalls.push(request);
		return this.promotePermissionRuleResult;
	}

	readonly getSessionRulesCalls: UniverseAgentGetSessionRulesRequest[] = [];
	getSessionRulesResult: UniverseAgentGetSessionRulesResult = { rules: [] };

	async getSessionRules(request: UniverseAgentGetSessionRulesRequest): Promise<UniverseAgentGetSessionRulesResult> {
		this.getSessionRulesCalls.push(request);
		return this.getSessionRulesResult;
	}

	readonly setPermissionModeCalls: UniverseAgentSetPermissionModeRequest[] = [];
	setPermissionModeResult: UniverseAgentSetPermissionModeResult = { ok: true };

	readonly setClientToolProfileCalls: UniverseAgentSetClientToolProfileRequest[] = [];
	readonly registerSessionEngineTriggerCalls: UniverseAgentRegisterSessionEngineTriggerRequest[] = [];

	async setClientToolProfile(request: UniverseAgentSetClientToolProfileRequest): Promise<UniverseAgentSetClientToolProfileResult> {
		this.setClientToolProfileCalls.push(request);
		return { ok: false, error: 'Session not found' };
	}

	async registerSessionEngineTrigger(request: UniverseAgentRegisterSessionEngineTriggerRequest): Promise<UniverseAgentRegisterSessionEngineTriggerResult> {
		this.registerSessionEngineTriggerCalls.push(request);
		return this.upsertTriggerResult;
	}

	async setPermissionMode(request: UniverseAgentSetPermissionModeRequest): Promise<UniverseAgentSetPermissionModeResult> {
		this.setPermissionModeCalls.push(request);
		return this.setPermissionModeResult;
	}

	readonly taskUpdateCalls: UniverseAgentTaskUpdateRequest[] = [];
	taskUpdateResult: UniverseAgentTaskUpdateResult = { ok: true };

	async taskUpdate(request: UniverseAgentTaskUpdateRequest): Promise<UniverseAgentTaskUpdateResult> {
		this.taskUpdateCalls.push(request);
		return this.taskUpdateResult;
	}

	readonly taskCancelCalls: UniverseAgentTaskCancelRequest[] = [];
	taskCancelResult: UniverseAgentTaskCancelResult = { ok: true };

	async taskCancel(request: UniverseAgentTaskCancelRequest): Promise<UniverseAgentTaskCancelResult> {
		this.taskCancelCalls.push(request);
		return this.taskCancelResult;
	}

	readonly messageMemberCalls: UniverseAgentMessageMemberRequest[] = [];
	messageMemberResult: UniverseAgentMessageMemberResult = { ok: true };

	async messageMember(request: UniverseAgentMessageMemberRequest): Promise<UniverseAgentMessageMemberResult> {
		this.messageMemberCalls.push(request);
		return this.messageMemberResult;
	}

	readonly createTeamCalls: UniverseAgentCreateTeamRequest[] = [];
	createTeamResult: UniverseAgentCreateTeamResult = { teamId: 0, memberCount: 0 };

	async createTeam(request: UniverseAgentCreateTeamRequest): Promise<UniverseAgentCreateTeamResult> {
		this.createTeamCalls.push(request);
		return this.createTeamResult;
	}

	readonly startMemberCalls: UniverseAgentStartMemberRequest[] = [];
	startMemberResult: UniverseAgentStartMemberResult = { memberAgentId: '', memberName: '', dynamic: false };

	async startMember(request: UniverseAgentStartMemberRequest): Promise<UniverseAgentStartMemberResult> {
		this.startMemberCalls.push(request);
		return this.startMemberResult;
	}

	readonly killMemberCalls: UniverseAgentKillMemberRequest[] = [];
	killMemberResult: UniverseAgentKillMemberResult = { ok: true };

	async killMember(request: UniverseAgentKillMemberRequest): Promise<UniverseAgentKillMemberResult> {
		this.killMemberCalls.push(request);
		return this.killMemberResult;
	}

	readonly abortCalls: UniverseAgentAbortTeamRequest[] = [];
	abortResult: UniverseAgentAbortTeamResult = { ok: true, stoppedMembers: [] };

	async abort(request: UniverseAgentAbortTeamRequest): Promise<UniverseAgentAbortTeamResult> {
		this.abortCalls.push(request);
		return this.abortResult;
	}

	readonly switchModelCalls: UniverseAgentSwitchModelRequest[] = [];
	switchModelResult: UniverseAgentSwitchModelResult = {
		resolvedModelId: '',
		provider: '',
		level: 0,
		cost: '',
		speed: '',
	};

	async switchModel(request: UniverseAgentSwitchModelRequest): Promise<UniverseAgentSwitchModelResult> {
		this.switchModelCalls.push(request);
		return this.switchModelResult;
	}

	readonly resolveModelCalls: UniverseAgentResolveModelRequest[] = [];
	resolveModelResult: UniverseAgentResolveModelResult = { candidates: [], filtered: [] };

	async resolveModel(request: UniverseAgentResolveModelRequest): Promise<UniverseAgentResolveModelResult> {
		this.resolveModelCalls.push(request);
		return this.resolveModelResult;
	}

	readonly setPermissionPolicyCalls: UniverseAgentSetPermissionPolicyRequest[] = [];
	setPermissionPolicyResult: UniverseAgentSetPermissionPolicyResult = { ok: true };

	async setPermissionPolicy(request: UniverseAgentSetPermissionPolicyRequest): Promise<UniverseAgentSetPermissionPolicyResult> {
		this.setPermissionPolicyCalls.push(request);
		return this.setPermissionPolicyResult;
	}

	readonly respondQuestionCalls: UniverseAgentRespondQuestionRequest[] = [];
	respondQuestionResult: UniverseAgentRespondQuestionResult = { ok: true };

	async respondQuestion(request: UniverseAgentRespondQuestionRequest): Promise<UniverseAgentRespondQuestionResult> {
		this.respondQuestionCalls.push(request);
		return this.respondQuestionResult;
	}

	readonly enqueueCalls: UniverseAgentEnqueueQueueItemRequest[] = [];
	readonly insertCalls: UniverseAgentInsertQueueItemRequest[] = [];
	readonly reorderCalls: UniverseAgentReorderQueueRequest[] = [];
	readonly deleteCalls: UniverseAgentDeleteQueueItemRequest[] = [];
	readonly retryCalls: UniverseAgentRetryQueueItemRequest[] = [];
	readonly retryAllFailedCalls: UniverseAgentRetryAllFailedRequest[] = [];
	readonly retryQueueItemUploadCalls: UniverseAgentRetryQueueItemUploadRequest[] = [];
	readonly pinCalls: UniverseAgentPinQueueItemRequest[] = [];
	readonly setQueueItemLockedCalls: UniverseAgentSetQueueItemLockedRequest[] = [];
	readonly injectCalls: UniverseAgentInjectQueueItemRequest[] = [];
	readonly setQueueItemForkAnchorCalls: UniverseAgentSetQueueItemForkAnchorRequest[] = [];
	readonly pauseCalls: UniverseAgentQueueRefRequest[] = [];
	readonly resumeCalls: UniverseAgentQueueRefRequest[] = [];
	readonly clearCalls: UniverseAgentQueueRefRequest[] = [];
	readonly holdCalls: UniverseAgentHoldQueueItemRequest[] = [];
	readonly releaseHoldCalls: UniverseAgentQueueItemRefRequest[] = [];
	readonly editCalls: UniverseAgentEditQueueItemRequest[] = [];
	queueResult: UniverseAgentQueueMutationResult = { ok: true };

	async getQueue() { return { items: [], isPaused: false, isProcessing: false, pauseReason: 'NONE' as const, version: '0' }; }
	async enqueueQueueItem(request: UniverseAgentEnqueueQueueItemRequest): Promise<UniverseAgentQueueMutationResult> {
		this.enqueueCalls.push(request);
		return this.queueResult;
	}

	async insertQueueItem(request: UniverseAgentInsertQueueItemRequest): Promise<UniverseAgentQueueMutationResult> {
		this.insertCalls.push(request);
		return this.queueResult;
	}

	async reorderQueue(request: UniverseAgentReorderQueueRequest): Promise<UniverseAgentQueueMutationResult> {
		this.reorderCalls.push(request);
		return this.queueResult;
	}

	async deleteQueueItem(request: UniverseAgentDeleteQueueItemRequest): Promise<UniverseAgentQueueMutationResult> {
		this.deleteCalls.push(request);
		return this.queueResult;
	}

	async retryQueueItem(request: UniverseAgentRetryQueueItemRequest): Promise<UniverseAgentQueueMutationResult> {
		this.retryCalls.push(request);
		return this.queueResult;
	}

	async retryAllFailed(request: UniverseAgentRetryAllFailedRequest): Promise<UniverseAgentQueueMutationResult> {
		this.retryAllFailedCalls.push(request);
		return this.queueResult;
	}

	async retryQueueItemUpload(request: UniverseAgentRetryQueueItemUploadRequest): Promise<UniverseAgentQueueMutationResult> {
		this.retryQueueItemUploadCalls.push(request);
		return this.queueResult;
	}

	async pinQueueItem(request: UniverseAgentPinQueueItemRequest): Promise<UniverseAgentQueueMutationResult> {
		this.pinCalls.push(request);
		return this.queueResult;
	}

	async setQueueItemLocked(request: UniverseAgentSetQueueItemLockedRequest): Promise<UniverseAgentQueueMutationResult> {
		this.setQueueItemLockedCalls.push(request);
		return this.queueResult;
	}

	async injectQueueItem(request: UniverseAgentInjectQueueItemRequest): Promise<UniverseAgentQueueMutationResult> {
		this.injectCalls.push(request);
		return this.queueResult;
	}

	async setQueueItemForkAnchor(request: UniverseAgentSetQueueItemForkAnchorRequest): Promise<UniverseAgentQueueMutationResult> {
		this.setQueueItemForkAnchorCalls.push(request);
		return this.queueResult;
	}

	async pauseQueue(request: UniverseAgentQueueRefRequest): Promise<UniverseAgentQueueMutationResult> {
		this.pauseCalls.push(request);
		return this.queueResult;
	}

	async resumeQueue(request: UniverseAgentQueueRefRequest): Promise<UniverseAgentQueueMutationResult> {
		this.resumeCalls.push(request);
		return this.queueResult;
	}

	async clearQueue(request: UniverseAgentQueueRefRequest): Promise<UniverseAgentQueueMutationResult> {
		this.clearCalls.push(request);
		return this.queueResult;
	}

	async holdQueueItem(request: UniverseAgentHoldQueueItemRequest): Promise<UniverseAgentQueueMutationResult> {
		this.holdCalls.push(request);
		return this.queueResult;
	}

	async releaseQueueItemHold(request: UniverseAgentQueueItemRefRequest): Promise<UniverseAgentQueueMutationResult> {
		this.releaseHoldCalls.push(request);
		return this.queueResult;
	}

	async editQueueItem(request: UniverseAgentEditQueueItemRequest): Promise<UniverseAgentQueueMutationResult> {
		this.editCalls.push(request);
		return this.queueResult;
	}

	readonly forkCalls: UniverseAgentForkAgentRequest[] = [];
	forkResult: UniverseAgentForkAgentResult = { ok: true, agentId: 'sub:reviewer' };

	async forkAgent(request: UniverseAgentForkAgentRequest): Promise<UniverseAgentForkAgentResult> {
		this.forkCalls.push(request);
		return this.forkResult;
	}

	readonly killCalls: UniverseAgentKillAgentRequest[] = [];
	killResult: UniverseAgentKillAgentResult = { ok: true };

	async killAgent(request: UniverseAgentKillAgentRequest): Promise<UniverseAgentKillAgentResult> {
		this.killCalls.push(request);
		return this.killResult;
	}

	readonly deleteMessageCalls: UniverseAgentDeleteMessageRequest[] = [];
	deleteMessageResult: UniverseAgentDeleteMessageResult = { ok: true };

	async deleteMessage(request: UniverseAgentDeleteMessageRequest): Promise<UniverseAgentDeleteMessageResult> {
		this.deleteMessageCalls.push(request);
		return this.deleteMessageResult;
	}

	readonly editMessageCalls: UniverseAgentEditMessageRequest[] = [];
	editMessageResult: UniverseAgentEditMessageResult = { ok: true };

	async editMessage(request: UniverseAgentEditMessageRequest): Promise<UniverseAgentEditMessageResult> {
		this.editMessageCalls.push(request);
		return this.editMessageResult;
	}

	readonly sendClientToolResponseCalls: UniverseAgentSendClientToolResponseRequest[] = [];
	sendClientToolResponseResult: UniverseAgentSendClientToolResponseResult = { ok: true };

	async sendClientToolResponse(request: UniverseAgentSendClientToolResponseRequest): Promise<UniverseAgentSendClientToolResponseResult> {
		this.sendClientToolResponseCalls.push(request);
		return this.sendClientToolResponseResult;
	}

	readonly listSnapshotsCalls: UniverseAgentListSnapshotsRequest[] = [];
	listSnapshotsResult: UniverseAgentListSnapshotsResult = { snapshots: [] };

	async listSnapshots(request: UniverseAgentListSnapshotsRequest): Promise<UniverseAgentListSnapshotsResult> {
		this.listSnapshotsCalls.push(request);
		return this.listSnapshotsResult;
	}

	readonly listLoopSnapshotsCalls: UniverseAgentListLoopSnapshotsRequest[] = [];
	listLoopSnapshotsResult: UniverseAgentListLoopSnapshotsResult = { snapshots: [] };

	async listLoopSnapshots(request: UniverseAgentListLoopSnapshotsRequest): Promise<UniverseAgentListLoopSnapshotsResult> {
		this.listLoopSnapshotsCalls.push(request);
		return this.listLoopSnapshotsResult;
	}

	readonly createSnapshotCalls: UniverseAgentCreateSnapshotRequest[] = [];
	createSnapshotResult: UniverseAgentCreateSnapshotResult = { ok: true };

	async createSnapshot(request: UniverseAgentCreateSnapshotRequest): Promise<UniverseAgentCreateSnapshotResult> {
		this.createSnapshotCalls.push(request);
		return this.createSnapshotResult;
	}

	readonly restoreSnapshotCalls: UniverseAgentRestoreSnapshotRequest[] = [];
	restoreSnapshotResult: UniverseAgentRestoreSnapshotResult = { ok: true };

	async restoreSnapshot(request: UniverseAgentRestoreSnapshotRequest): Promise<UniverseAgentRestoreSnapshotResult> {
		this.restoreSnapshotCalls.push(request);
		return this.restoreSnapshotResult;
	}

	readonly deleteSnapshotCalls: UniverseAgentDeleteSnapshotRequest[] = [];
	deleteSnapshotResult: UniverseAgentDeleteSnapshotResult = { ok: true };

	async deleteSnapshot(request: UniverseAgentDeleteSnapshotRequest): Promise<UniverseAgentDeleteSnapshotResult> {
		this.deleteSnapshotCalls.push(request);
		return this.deleteSnapshotResult;
	}

	async getHistory(_request: UniverseAgentGetHistoryRequest): Promise<UniverseAgentGetHistoryResult> {
		return { envelopes: [] };
	}

	private _sessionStreamGate: ReturnType<typeof createStreamCloseGate> | undefined;

	subscribeSessionEventStream(
		_sessionId: string,
		_listener: (event: UniverseAgentSessionEvent) => void,
		onClosed?: (cause: UniverseAgentSessionStreamCloseCause) => void,
	): { dispose(): void } {
		const gate = createStreamCloseGate(onClosed);
		this._sessionStreamGate = gate;
		return {
			dispose: () => {
				gate.closeLocal();
				if (this._sessionStreamGate === gate) {
					this._sessionStreamGate = undefined;
				}
			},
		};
	}

	fireSessionStreamClosed(cause: UniverseAgentSessionStreamCloseCause): void {
		this._sessionStreamGate?.finish(cause);
	}

	async chat(_request: UniverseAgentChatRequest, _onResponse: (response: UniverseAgentChatResponse) => void): Promise<void> {
	}

	readonly chatSyncCalls: UniverseAgentChatSyncRequest[] = [];
	chatSyncResult: UniverseAgentChatSyncResult = {
		sessionId: '',
		agentId: '',
		text: '',
		stopReason: '',
		inputTokens: 0,
		outputTokens: 0,
		turnCount: 0,
		toolResults: [],
		error: '',
		inputDeliveryEvents: [],
	};

	async chatSync(request: UniverseAgentChatSyncRequest): Promise<UniverseAgentChatSyncResult> {
		this.chatSyncCalls.push(request);
		return this.chatSyncResult;
	}

	readonly syncInputDeliveryCalls: UniverseAgentSyncInputDeliveryRequest[] = [];
	syncInputDeliveryResult: UniverseAgentSyncInputDeliveryResult = {
		inputDeliveryEvents: [],
	};

	async syncInputDelivery(request: UniverseAgentSyncInputDeliveryRequest): Promise<UniverseAgentSyncInputDeliveryResult> {
		this.syncInputDeliveryCalls.push(request);
		return this.syncInputDeliveryResult;
	}

	private _chatGate: ReturnType<typeof createStreamCloseGate> | undefined;
	readonly chatOpens: string[] = [];

	openChatStream(
		sessionId: string,
		_onResponse: (response: UniverseAgentChatResponse) => void,
		onClosed?: (cause: UniverseAgentSessionStreamCloseCause) => void,
	): UniverseAgentChatStream {
		this.chatOpens.push(sessionId);
		const gate = createStreamCloseGate(onClosed);
		this._chatGate = gate;
		return {
			write() { },
			dispose: () => {
				gate.closeLocal();
				if (this._chatGate === gate) {
					this._chatGate = undefined;
				}
			},
		};
	}

	fireChatClosed(cause: UniverseAgentSessionStreamCloseCause): void {
		this._chatGate?.finish(cause);
	}

	private _continuationGate: ReturnType<typeof createStreamCloseGate> | undefined;
	readonly continuationOpens: UniverseAgentContinueGenerationRequest[] = [];

	openContinuationStream(
		request: UniverseAgentContinueGenerationRequest,
		_onResponse: (response: UniverseAgentChatResponse) => void,
		onClosed?: (cause: UniverseAgentSessionStreamCloseCause) => void,
	): { dispose(): void } {
		this.continuationOpens.push(request);
		const gate = createStreamCloseGate(onClosed);
		this._continuationGate = gate;
		return {
			dispose: () => {
				gate.closeLocal();
				if (this._continuationGate === gate) {
					this._continuationGate = undefined;
				}
			},
		};
	}

	fireContinuationClosed(cause: UniverseAgentSessionStreamCloseCause): void {
		this._continuationGate?.finish(cause);
	}

	private _regenerateGate: ReturnType<typeof createStreamCloseGate> | undefined;
	readonly regenerateOpens: UniverseAgentRegenerateRequest[] = [];

	openRegenerateStream(
		request: UniverseAgentRegenerateRequest,
		_onResponse: (response: UniverseAgentChatResponse) => void,
		onClosed?: (cause: UniverseAgentSessionStreamCloseCause) => void,
	): { dispose(): void } {
		this.regenerateOpens.push(request);
		const gate = createStreamCloseGate(onClosed);
		this._regenerateGate = gate;
		return {
			dispose: () => {
				gate.closeLocal();
				if (this._regenerateGate === gate) {
					this._regenerateGate = undefined;
				}
			},
		};
	}

	fireRegenerateClosed(cause: UniverseAgentSessionStreamCloseCause): void {
		this._regenerateGate?.finish(cause);
	}

	private _resumeGate: ReturnType<typeof createStreamCloseGate> | undefined;
	readonly resumeOpens: UniverseAgentResumeRequest[] = [];

	openResumeStream(
		request: UniverseAgentResumeRequest,
		_onResponse: (response: UniverseAgentChatResponse) => void,
		onClosed?: (cause: UniverseAgentSessionStreamCloseCause) => void,
	): { dispose(): void } {
		this.resumeOpens.push(request);
		const gate = createStreamCloseGate(onClosed);
		this._resumeGate = gate;
		return {
			dispose: () => {
				gate.closeLocal();
				if (this._resumeGate === gate) {
					this._resumeGate = undefined;
				}
			},
		};
	}

	fireResumeClosed(cause: UniverseAgentSessionStreamCloseCause): void {
		this._resumeGate?.finish(cause);
	}

	private _subscribeToolDetailGate: ReturnType<typeof createStreamCloseGate> | undefined;
	readonly subscribeToolDetailOpens: UniverseAgentSubscribeToolDetailRequest[] = [];

	openSubscribeToolDetailStream(
		request: UniverseAgentSubscribeToolDetailRequest,
		_onResponse: (response: UniverseAgentSubscribeToolDetailChunk) => void,
		onClosed?: (cause: UniverseAgentSessionStreamCloseCause) => void,
	): { dispose(): void } {
		this.subscribeToolDetailOpens.push(request);
		const gate = createStreamCloseGate(onClosed);
		this._subscribeToolDetailGate = gate;
		return {
			dispose: () => {
				gate.closeLocal();
				if (this._subscribeToolDetailGate === gate) {
					this._subscribeToolDetailGate = undefined;
				}
			},
		};
	}

	fireSubscribeToolDetailClosed(cause: UniverseAgentSessionStreamCloseCause): void {
		this._subscribeToolDetailGate?.finish(cause);
	}

	private _watchConfigGate: ReturnType<typeof createStreamCloseGate> | undefined;
	readonly watchConfigOpens: UniverseAgentWatchConfigRequest[] = [];

	openWatchConfigStream(
		request: UniverseAgentWatchConfigRequest,
		_onResponse: (response: UniverseAgentConfigChangedEvent) => void,
		onClosed?: (cause: UniverseAgentSessionStreamCloseCause) => void,
	): { dispose(): void } {
		this.watchConfigOpens.push(request);
		const gate = createStreamCloseGate(onClosed);
		this._watchConfigGate = gate;
		return {
			dispose: () => {
				gate.closeLocal();
				if (this._watchConfigGate === gate) {
					this._watchConfigGate = undefined;
				}
			},
		};
	}

	fireWatchConfigClosed(cause: UniverseAgentSessionStreamCloseCause): void {
		this._watchConfigGate?.finish(cause);
	}

	private _uploadAttachmentGate: ReturnType<typeof createStreamCloseGate> | undefined;
	readonly uploadAttachmentWrites: UniverseAgentUploadChunk[] = [];
	uploadAttachmentOpenCount = 0;

	openUploadAttachmentStream(
		_onResponse: (response: UniverseAgentUploadAttachmentResult) => void,
		onClosed?: (cause: UniverseAgentSessionStreamCloseCause) => void,
	): { write(chunk: UniverseAgentUploadChunk): void; end(): void; dispose(): void } {
		this.uploadAttachmentOpenCount++;
		const gate = createStreamCloseGate(onClosed);
		this._uploadAttachmentGate = gate;
		return {
			write: (chunk: UniverseAgentUploadChunk) => {
				this.uploadAttachmentWrites.push(chunk);
			},
			end: () => { },
			dispose: () => {
				gate.closeLocal();
				if (this._uploadAttachmentGate === gate) {
					this._uploadAttachmentGate = undefined;
				}
			},
		};
	}

	fireUploadAttachmentClosed(cause: UniverseAgentSessionStreamCloseCause): void {
		this._uploadAttachmentGate?.finish(cause);
	}

	async listSkills() {
		const ownedOperation = this.recordOwnedOperation('listSkills');
		if (ownedOperation) { await ownedOperation; }
		return { skills: [] };
	}

	async setSkillEnabled(request: UniverseAgentSetSkillEnabledRequest) {
		const ownedOperation = this.recordOwnedOperation('setSkillEnabled', request);
		if (ownedOperation) { await ownedOperation; }
		return { ok: true };
	}

	async getSkillInfo(request: UniverseAgentSkillInfoRequest) {
		const ownedOperation = this.recordOwnedOperation('getSkillInfo', request);
		if (ownedOperation) { await ownedOperation; }
		return { name: '', content: '', source: 'unknown' as const, enabled: false };
	}

	async saveSkillContent(request: UniverseAgentSaveSkillContentRequest): Promise<UniverseAgentSaveSkillContentResult> {
		const ownedOperation = this.recordOwnedOperation('saveSkillContent', request);
		if (ownedOperation) { await ownedOperation; }
		if (this.handlers.saveSkillContent) {
			return this.handlers.saveSkillContent(request);
		}
		return { ok: true };
	}

	async listAgentProfiles() {
		return { profiles: [] };
	}

	async saveAgentProfile(request: UniverseAgentSaveAgentProfileRequest) {
		return { profile: request.profile };
	}

	async deleteAgentProfile() {
		return { ok: true };
	}

	async resetAgentProfile() {
		return { ok: true };
	}

	async listMcpServers() {
		return { servers: [] };
	}

	async getMcpServerStatuses() {
		return { statuses: [] };
	}

	async getMcpServerTools() {
		return { tools: [] };
	}

	async listPlugins() {
		return { plugins: [] };
	}

	async getPluginInfo() {
		return { summary: { id: '', displayName: '', version: '', source: '', hookCount: 0, status: 'unknown' as const }, hooks: [] };
	}

	async enablePlugin() {
		return { plugin: { id: '', displayName: '', version: '', source: '', hookCount: 0, status: 'unknown' as const } };
	}

	async reloadPlugin() {
		return { plugin: { id: '', displayName: '', version: '', source: '', hookCount: 0, status: 'unknown' as const } };
	}

	async unloadPlugin() {
		return { removedHookCount: 0 };
	}

	async scanNewPlugins() {
		return { newPlugins: [], skippedCount: 0 };
	}

	async toggleMcpServer() {
		return { ok: true };
	}

	async addMcpServer() {
		return { ok: true };
	}

	async updateMcpServer() {
		return { ok: true };
	}

	async removeMcpServer() {
		return { ok: true };
	}

	async listTools() {
		return { tools: [] };
	}

	readonly toolInfoCalls: UniverseAgentToolInfoRequest[] = [];
	toolInfoResult: UniverseAgentToolInfoResult = {
		name: 'bash',
		description: 'Run a command',
		category: 'shell',
		inputSchemaJson: '{"type":"object"}',
		destructive: true,
		requiresPermission: true,
		aliases: ['sh'],
	};

	async getToolInfo(request: UniverseAgentToolInfoRequest): Promise<UniverseAgentToolInfoResult> {
		this.toolInfoCalls.push(request);
		return this.toolInfoResult;
	}

	listCommandsCalls = 0;
	listCommandsResult: UniverseAgentListCommandsResult = { commands: [], total: 0 };

	async listCommands(): Promise<UniverseAgentListCommandsResult> {
		this.listCommandsCalls += 1;
		return this.listCommandsResult;
	}

	readonly getCommandDefCalls: UniverseAgentGetCommandDefRequest[] = [];
	getCommandDefResult: UniverseAgentGetCommandDefResult = {
		name: '',
		source: '',
		template: '',
		agent: '',
		model: '',
		subtask: false,
		mcpServerId: '',
		mcpPromptName: '',
		mcpArgumentNames: [],
		skillSource: '',
	};

	async getCommandDef(request: UniverseAgentGetCommandDefRequest): Promise<UniverseAgentGetCommandDefResult> {
		this.getCommandDefCalls.push(request);
		return this.getCommandDefResult;
	}

	readonly listFilesCalls: UniverseAgentListFilesRequest[] = [];
	listFilesResult: UniverseAgentListFilesResult = { entries: [], total: 0 };

	async listFiles(request: UniverseAgentListFilesRequest): Promise<UniverseAgentListFilesResult> {
		this.listFilesCalls.push(request);
		return this.listFilesResult;
	}

	readonly readFileCalls: UniverseAgentReadFileRequest[] = [];
	readFileResult: UniverseAgentReadFileResult = {
		content: new Uint8Array(0),
		totalSize: 0,
		mimeType: '',
		lineCount: 0,
		contentHash: '',
	};

	async readFile(request: UniverseAgentReadFileRequest): Promise<UniverseAgentReadFileResult> {
		this.readFileCalls.push(request);
		return this.readFileResult;
	}

	readonly getFileInfoCalls: UniverseAgentGetFileInfoRequest[] = [];
	getFileInfoResult: UniverseAgentGetFileInfoResult = {
		file: {
			name: '',
			path: '',
			isDirectory: false,
			size: 0,
			lastModified: 0,
			mimeType: '',
		},
	};

	async getFileInfo(request: UniverseAgentGetFileInfoRequest): Promise<UniverseAgentGetFileInfoResult> {
		this.getFileInfoCalls.push(request);
		return this.getFileInfoResult;
	}

	readonly writeFileCalls: UniverseAgentWriteFileRequest[] = [];
	writeFileResult: UniverseAgentWriteFileResult = {
		status: 'SAVED',
		newHash: '',
		size: 0,
		modifiedAt: 0,
		currentContent: new Uint8Array(0),
		currentHash: '',
		mergedContent: new Uint8Array(0),
	};

	async writeFile(request: UniverseAgentWriteFileRequest): Promise<UniverseAgentWriteFileResult> {
		this.writeFileCalls.push(request);
		return this.writeFileResult;
	}

	readonly forceWriteFileCalls: UniverseAgentForceWriteFileRequest[] = [];
	forceWriteFileResult: UniverseAgentWriteFileResult = {
		status: 'SAVED',
		newHash: '',
		size: 0,
		modifiedAt: 0,
		currentContent: new Uint8Array(0),
		currentHash: '',
		mergedContent: new Uint8Array(0),
	};

	async forceWriteFile(request: UniverseAgentForceWriteFileRequest): Promise<UniverseAgentWriteFileResult> {
		this.forceWriteFileCalls.push(request);
		return this.forceWriteFileResult;
	}

	readonly agentMergeCalls: UniverseAgentAgentMergeRequest[] = [];
	agentMergeResult: UniverseAgentAgentMergeResult = {
		accepted: false,
	};

	async agentMerge(request: UniverseAgentAgentMergeRequest): Promise<UniverseAgentAgentMergeResult> {
		this.agentMergeCalls.push(request);
		return this.agentMergeResult;
	}

	readonly readGitSummaryCalls: UniverseAgentReadGitSummaryRequest[] = [];
	readGitSummaryResult: UniverseAgentReadGitSummaryResult = {
		supported: false,
		reason: '',
		branch: '',
		changeCount: 0,
	};

	async readGitSummary(request: UniverseAgentReadGitSummaryRequest): Promise<UniverseAgentReadGitSummaryResult> {
		this.readGitSummaryCalls.push(request);
		return this.readGitSummaryResult;
	}

	readonly readGitChangesCalls: UniverseAgentReadGitChangesRequest[] = [];
	readGitChangesResult: UniverseAgentReadGitChangesResult = {
		supported: false,
		reason: '',
		branch: '',
		entries: [],
	};

	async readGitChanges(request: UniverseAgentReadGitChangesRequest): Promise<UniverseAgentReadGitChangesResult> {
		this.readGitChangesCalls.push(request);
		return this.readGitChangesResult;
	}

	readonly readGitFileDiffCalls: UniverseAgentReadGitFileDiffRequest[] = [];
	readGitFileDiffResult: UniverseAgentReadGitFileDiffResult = {
		supported: false,
		reason: '',
		path: '',
		unifiedDiff: '',
	};

	async readGitFileDiff(request: UniverseAgentReadGitFileDiffRequest): Promise<UniverseAgentReadGitFileDiffResult> {
		this.readGitFileDiffCalls.push(request);
		return this.readGitFileDiffResult;
	}

	readonly writeGitStagePathsCalls: UniverseAgentWriteGitStagePathsRequest[] = [];
	writeGitStagePathsResult: UniverseAgentWriteGitWriteResult = {
		supported: false,
		reason: '',
		success: false,
		errorMessage: '',
		exitCode: 0,
		stdout: '',
	};

	async writeGitStagePaths(request: UniverseAgentWriteGitStagePathsRequest): Promise<UniverseAgentWriteGitWriteResult> {
		this.writeGitStagePathsCalls.push(request);
		return this.writeGitStagePathsResult;
	}

	readonly writeGitCommitCalls: UniverseAgentWriteGitCommitRequest[] = [];
	writeGitCommitResult: UniverseAgentWriteGitWriteResult = {
		supported: false,
		reason: '',
		success: false,
		errorMessage: '',
		exitCode: 0,
		stdout: '',
	};

	async writeGitCommit(request: UniverseAgentWriteGitCommitRequest): Promise<UniverseAgentWriteGitWriteResult> {
		this.writeGitCommitCalls.push(request);
		return this.writeGitCommitResult;
	}

	readonly writeGitApplyHunksCalls: UniverseAgentWriteGitApplyHunksRequest[] = [];
	writeGitApplyHunksResult: UniverseAgentWriteGitWriteResult = {
		supported: false,
		reason: '',
		success: false,
		errorMessage: '',
		exitCode: 0,
		stdout: '',
	};

	async writeGitApplyHunks(request: UniverseAgentWriteGitApplyHunksRequest): Promise<UniverseAgentWriteGitWriteResult> {
		this.writeGitApplyHunksCalls.push(request);
		return this.writeGitApplyHunksResult;
	}

	readonly getSessionUsageCalls: UniverseAgentGetSessionUsageRequest[] = [];
	getSessionUsageResult: UniverseAgentGetSessionUsageResult = {
		usage: {
			inputTokens: 0,
			outputTokens: 0,
			thinkingTokens: 0,
			cacheReadTokens: 0,
			cacheWriteTokens: 0,
			totalCostMicros: 0,
			currency: '',
			requestCount: 0,
		},
	};

	getGlobalUsageCalls = 0;
	getGlobalUsageResult: UniverseAgentGetGlobalUsageResult = {
		usage: {
			inputTokens: 0,
			outputTokens: 0,
			thinkingTokens: 0,
			cacheReadTokens: 0,
			cacheWriteTokens: 0,
			totalCostMicros: 0,
			currency: '',
			requestCount: 0,
		},
	};

	async getSessionUsage(request: UniverseAgentGetSessionUsageRequest): Promise<UniverseAgentGetSessionUsageResult> {
		this.getSessionUsageCalls.push(request);
		return this.getSessionUsageResult;
	}

	async getGlobalUsage(): Promise<UniverseAgentGetGlobalUsageResult> {
		this.getGlobalUsageCalls++;
		return this.getGlobalUsageResult;
	}

	readonly saveMemoryCalls: UniverseAgentSaveMemoryRequest[] = [];
	saveMemoryResult: UniverseAgentSaveMemoryResult = {
		success: false,
		message: '',
		filePath: '',
	};

	async saveMemory(request: UniverseAgentSaveMemoryRequest): Promise<UniverseAgentSaveMemoryResult> {
		this.saveMemoryCalls.push(request);
		return this.saveMemoryResult;
	}

	readonly searchMemoryCalls: UniverseAgentMemorySearchRequest[] = [];
	searchMemoryResult: UniverseAgentMemorySearchResult = {
		results: [],
	};

	async searchMemory(request: UniverseAgentMemorySearchRequest): Promise<UniverseAgentMemorySearchResult> {
		this.searchMemoryCalls.push(request);
		return this.searchMemoryResult;
	}

	readonly searchDeepMemoryCalls: UniverseAgentMemorySearchDeepRequest[] = [];
	searchDeepMemoryResult: UniverseAgentMemorySearchDeepResult = {
		results: [],
		searchedCategories: [],
	};

	async searchDeepMemory(request: UniverseAgentMemorySearchDeepRequest): Promise<UniverseAgentMemorySearchDeepResult> {
		this.searchDeepMemoryCalls.push(request);
		return this.searchDeepMemoryResult;
	}

	readonly readMemoryCalls: UniverseAgentReadMemoryRequest[] = [];
	readMemoryResult: UniverseAgentReadMemoryResult = {
		content: '',
		metadata: {
			category: '',
			filename: '',
			title: '',
			tags: [],
			createdAt: 0,
			updatedAt: 0,
			version: 0,
		},
	};

	async readMemory(request: UniverseAgentReadMemoryRequest): Promise<UniverseAgentReadMemoryResult> {
		this.readMemoryCalls.push(request);
		return this.readMemoryResult;
	}

	readonly listMemoryCalls: UniverseAgentMemoryListRequest[] = [];
	listMemoryResult: UniverseAgentMemoryListResult = {
		categories: [],
	};

	async listMemory(request: UniverseAgentMemoryListRequest): Promise<UniverseAgentMemoryListResult> {
		this.listMemoryCalls.push(request);
		return this.listMemoryResult;
	}

	readonly deleteMemoryCalls: UniverseAgentDeleteMemoryRequest[] = [];
	deleteMemoryResult: UniverseAgentDeleteMemoryResult = {
		success: false,
		message: '',
	};

	async deleteMemory(request: UniverseAgentDeleteMemoryRequest): Promise<UniverseAgentDeleteMemoryResult> {
		this.deleteMemoryCalls.push(request);
		return this.deleteMemoryResult;
	}

	readonly reflectMemoryCalls: UniverseAgentReflectMemoryRequest[] = [];
	reflectMemoryResult: UniverseAgentReflectMemoryResult = {
		diagnoses: [],
		summary: '',
	};

	async reflectMemory(request: UniverseAgentReflectMemoryRequest): Promise<UniverseAgentReflectMemoryResult> {
		this.reflectMemoryCalls.push(request);
		return this.reflectMemoryResult;
	}

	private _rebuildMemoryGate: ReturnType<typeof createStreamCloseGate> | undefined;
	readonly rebuildMemoryOpens: UniverseAgentMemoryRebuildRequest[] = [];

	openRebuildMemoryStream(
		request: UniverseAgentMemoryRebuildRequest,
		_onResponse: (response: UniverseAgentMemoryRebuildEvent) => void,
		onClosed?: (cause: UniverseAgentSessionStreamCloseCause) => void,
	): { dispose(): void } {
		this.rebuildMemoryOpens.push(request);
		const gate = createStreamCloseGate(onClosed);
		this._rebuildMemoryGate = gate;
		return {
			dispose: () => {
				gate.closeLocal();
				if (this._rebuildMemoryGate === gate) {
					this._rebuildMemoryGate = undefined;
				}
			},
		};
	}

	fireRebuildMemoryClosed(cause: UniverseAgentSessionStreamCloseCause): void {
		this._rebuildMemoryGate?.finish(cause);
	}

	readonly revertMemoryCalls: UniverseAgentRevertMemoryRequest[] = [];
	revertMemoryResult: UniverseAgentRevertMemoryResult = {
		success: false,
		message: '',
		revertedToVersion: 0,
	};

	async revertMemory(request: UniverseAgentRevertMemoryRequest): Promise<UniverseAgentRevertMemoryResult> {
		this.revertMemoryCalls.push(request);
		return this.revertMemoryResult;
	}

	readonly historyMemoryCalls: UniverseAgentMemoryHistoryRequest[] = [];
	historyMemoryResult: UniverseAgentMemoryHistoryResult = {
		changes: [],
	};

	async historyMemory(request: UniverseAgentMemoryHistoryRequest): Promise<UniverseAgentMemoryHistoryResult> {
		this.historyMemoryCalls.push(request);
		return this.historyMemoryResult;
	}

	readonly listContextVariableCalls: UniverseAgentContextVariableListRequest[] = [];
	listContextVariableResult: UniverseAgentContextVariableListResult = {
		current: [],
		inherited: [],
	};

	async listContextVariable(request: UniverseAgentContextVariableListRequest): Promise<UniverseAgentContextVariableListResult> {
		this.listContextVariableCalls.push(request);
		return this.listContextVariableResult;
	}

	readonly readContextVariableCalls: UniverseAgentContextVariableReadRequest[] = [];
	readContextVariableResult: UniverseAgentContextVariableReadResult = {
		entry: {
			name: '',
			content: '',
			scope: 'VARIABLE_GLOBAL',
			updatedBy: '',
			updatedAt: 0,
		},
	};

	async readContextVariable(request: UniverseAgentContextVariableReadRequest): Promise<UniverseAgentContextVariableReadResult> {
		this.readContextVariableCalls.push(request);
		return this.readContextVariableResult;
	}

	readonly listNodesCalls: UniverseAgentListNodesRequest[] = [];
	listNodesResult: UniverseAgentListNodesResult = {
		nodes: [],
		total: 0,
		onlineCount: 0,
	};

	async listNodes(request: UniverseAgentListNodesRequest): Promise<UniverseAgentListNodesResult> {
		this.listNodesCalls.push(request);
		return this.listNodesResult;
	}

	readonly getNodeCalls: UniverseAgentGetNodeRequest[] = [];
	getNodeResult: UniverseAgentRemoteAgentInfo = {
		id: '',
		name: '',
		description: '',
		status: '',
		endpoint: '',
		tags: [],
		capabilities: {
			models: [],
			tools: [],
			modes: [],
			serverVersion: '',
			protocolVersion: '',
			properties: {},
		},
		load: {
			activeSessions: 0,
			queueDepth: 0,
			cpuPercent: 0,
			memoryUsedMb: 0,
		},
		lastHeartbeatAt: 0,
	};

	async getNode(request: UniverseAgentGetNodeRequest): Promise<UniverseAgentRemoteAgentInfo> {
		this.getNodeCalls.push(request);
		return this.getNodeResult;
	}

	readonly checkConnectionCalls: UniverseAgentCheckConnectionRequest[] = [];
	checkConnectionResult: UniverseAgentConnectionReport = {
		reachable: false,
		authenticated: false,
		canCreateSession: false,
		latencyMs: 0,
		capabilities: {
			models: [],
			tools: [],
			modes: [],
			serverVersion: '',
			protocolVersion: '',
			properties: {},
		},
		errors: [],
		load: {
			activeSessions: 0,
			queueDepth: 0,
			cpuPercent: 0,
			memoryUsedMb: 0,
		},
	};

	async checkConnection(request: UniverseAgentCheckConnectionRequest): Promise<UniverseAgentConnectionReport> {
		this.checkConnectionCalls.push(request);
		return this.checkConnectionResult;
	}

	readonly setMaintenanceCalls: UniverseAgentSetMaintenanceRequest[] = [];
	setMaintenanceResult: UniverseAgentSetMaintenanceResult = {
		success: false,
	};

	async setMaintenance(request: UniverseAgentSetMaintenanceRequest): Promise<UniverseAgentSetMaintenanceResult> {
		this.setMaintenanceCalls.push(request);
		return this.setMaintenanceResult;
	}

	readonly exitMaintenanceCalls: UniverseAgentExitMaintenanceRequest[] = [];
	exitMaintenanceResult: UniverseAgentExitMaintenanceResult = {
		success: false,
	};

	async exitMaintenance(request: UniverseAgentExitMaintenanceRequest): Promise<UniverseAgentExitMaintenanceResult> {
		this.exitMaintenanceCalls.push(request);
		return this.exitMaintenanceResult;
	}

	listConfigsCalls = 0;
	listConfigsResult: UniverseAgentListConfigsResult = {
		configs: [],
	};

	async listConfigs(): Promise<UniverseAgentListConfigsResult> {
		this.listConfigsCalls++;
		return this.listConfigsResult;
	}

	readonly getRemoteAgentConfigCalls: UniverseAgentGetRemoteAgentConfigRequest[] = [];
	getRemoteAgentConfigResult: UniverseAgentRemoteAgentConfig = {
		id: '',
		name: '',
		description: '',
		enabled: false,
		endpoint: { host: '', port: 0, tls: false, tlsCertPath: '' },
		auth: { type: '', apiKeyRef: '', tokenRef: '' },
		tags: [],
		maxConcurrentSessions: 0,
		sessionLifecycle: '',
		defaultPermissionDelegate: {
			mode: '',
			whitelist: [],
			budget: { maxToolCalls: 0, maxTokens: 0, timeoutMs: 0, windowMs: 0, maxBubbleToUserPerDay: 0 },
			timeoutPolicy: '',
			fallback: '',
			bubbleTarget: '',
		},
		healthCheck: {
			intervalMs: 0,
			timeoutMs: 0,
			unhealthyThreshold: 0,
			healthyThreshold: 0,
			useWatch: false,
			degradedErrorRateThreshold: 0,
			degradedP99LatencyMs: 0,
		},
	};

	async getRemoteAgentConfig(request: UniverseAgentGetRemoteAgentConfigRequest): Promise<UniverseAgentRemoteAgentConfig> {
		this.getRemoteAgentConfigCalls.push(request);
		return this.getRemoteAgentConfigResult;
	}

	readonly saveRemoteAgentConfigCalls: UniverseAgentSaveRemoteAgentConfigRequest[] = [];
	saveRemoteAgentConfigResult: UniverseAgentSaveRemoteAgentConfigResult = {
		success: false,
		message: '',
		connectionTest: {
			reachable: false,
			authenticated: false,
			canCreateSession: false,
			latencyMs: 0,
			capabilities: {
				models: [],
				tools: [],
				modes: [],
				serverVersion: '',
				protocolVersion: '',
				properties: {},
			},
			errors: [],
			load: {
				activeSessions: 0,
				queueDepth: 0,
				cpuPercent: 0,
				memoryUsedMb: 0,
			},
		},
		asyncTestId: '',
	};

	async saveRemoteAgentConfig(request: UniverseAgentSaveRemoteAgentConfigRequest): Promise<UniverseAgentSaveRemoteAgentConfigResult> {
		this.saveRemoteAgentConfigCalls.push(request);
		return this.saveRemoteAgentConfigResult;
	}

	readonly resetErrorCalls: UniverseAgentResetErrorRequest[] = [];
	resetErrorResult: UniverseAgentResetErrorResult = {
		success: false,
	};

	async resetError(request: UniverseAgentResetErrorRequest): Promise<UniverseAgentResetErrorResult> {
		this.resetErrorCalls.push(request);
		return this.resetErrorResult;
	}

	readonly deleteRemoteAgentConfigCalls: UniverseAgentDeleteRemoteAgentConfigRequest[] = [];
	deleteRemoteAgentConfigResult: UniverseAgentDeleteRemoteAgentConfigResult = {
		success: false,
	};

	async deleteRemoteAgentConfig(request: UniverseAgentDeleteRemoteAgentConfigRequest): Promise<UniverseAgentDeleteRemoteAgentConfigResult> {
		this.deleteRemoteAgentConfigCalls.push(request);
		return this.deleteRemoteAgentConfigResult;
	}

	reloadRemoteAgentsCalls = 0;
	reloadRemoteAgentsResult: UniverseAgentReloadRemoteAgentsResult = {
		success: false,
		added: [],
		removed: [],
		changed: [],
		errors: [],
		durationMs: 0,
	};

	async reloadRemoteAgents(): Promise<UniverseAgentReloadRemoteAgentsResult> {
		this.reloadRemoteAgentsCalls++;
		return this.reloadRemoteAgentsResult;
	}

	private _remoteChatGate: ReturnType<typeof createStreamCloseGate> | undefined;
	readonly remoteChatOpens: UniverseAgentRemoteChatRequest[] = [];

	openRemoteChatStream(
		request: UniverseAgentRemoteChatRequest,
		_onResponse: (response: UniverseAgentRemoteChatResponse) => void,
		onClosed?: (cause: UniverseAgentSessionStreamCloseCause) => void,
	): { dispose(): void } {
		this.remoteChatOpens.push(request);
		const gate = createStreamCloseGate(onClosed);
		this._remoteChatGate = gate;
		return {
			dispose: () => {
				gate.closeLocal();
				if (this._remoteChatGate === gate) {
					this._remoteChatGate = undefined;
				}
			},
		};
	}

	fireRemoteChatClosed(cause: UniverseAgentSessionStreamCloseCause): void {
		this._remoteChatGate?.finish(cause);
	}

	readonly createRemoteSessionCalls: UniverseAgentCreateRemoteSessionRequest[] = [];
	createRemoteSessionResult: UniverseAgentCreateRemoteSessionResult = {
		callId: '',
		status: '',
		createdAt: 0,
		expiresAt: 0,
	};

	async createRemoteSession(request: UniverseAgentCreateRemoteSessionRequest): Promise<UniverseAgentCreateRemoteSessionResult> {
		this.createRemoteSessionCalls.push(request);
		return this.createRemoteSessionResult;
	}

	readonly destroyRemoteSessionCalls: UniverseAgentDestroyRemoteSessionRequest[] = [];
	destroyRemoteSessionResult: UniverseAgentDestroyRemoteSessionResult = {
		success: false,
		message: '',
	};

	async destroyRemoteSession(request: UniverseAgentDestroyRemoteSessionRequest): Promise<UniverseAgentDestroyRemoteSessionResult> {
		this.destroyRemoteSessionCalls.push(request);
		return this.destroyRemoteSessionResult;
	}

	readonly getRemoteSessionStatusCalls: UniverseAgentGetRemoteSessionStatusRequest[] = [];
	getRemoteSessionStatusResult: UniverseAgentGetRemoteSessionStatusResult = {
		status: '',
		callId: '',
		progress: '',
		elapsedMs: 0,
		expiresAt: 0,
		pendingPermissions: [],
		pendingQuestions: [],
	};

	async getRemoteSessionStatus(request: UniverseAgentGetRemoteSessionStatusRequest): Promise<UniverseAgentGetRemoteSessionStatusResult> {
		this.getRemoteSessionStatusCalls.push(request);
		return this.getRemoteSessionStatusResult;
	}

	readonly getRemoteSessionHistoryCalls: UniverseAgentGetRemoteSessionHistoryRequest[] = [];
	getRemoteSessionHistoryResult: UniverseAgentGetRemoteSessionHistoryResult = {
		messages: [],
		version: 0,
		hasMore: false,
	};

	async getRemoteSessionHistory(request: UniverseAgentGetRemoteSessionHistoryRequest): Promise<UniverseAgentGetRemoteSessionHistoryResult> {
		this.getRemoteSessionHistoryCalls.push(request);
		return this.getRemoteSessionHistoryResult;
	}
	readonly resumeRemoteSessionCalls: UniverseAgentResumeRemoteSessionRequest[] = [];
	resumeRemoteSessionResult: UniverseAgentResumeRemoteSessionResult = {
		success: false,
		callId: '',
		status: '',
		message: '',
		expiresAt: 0,
	};

	async resumeRemoteSession(request: UniverseAgentResumeRemoteSessionRequest): Promise<UniverseAgentResumeRemoteSessionResult> {
		this.resumeRemoteSessionCalls.push(request);
		return this.resumeRemoteSessionResult;
	}
	readonly cancelRemoteSessionCalls: UniverseAgentCancelRemoteSessionRequest[] = [];
	cancelRemoteSessionResult: UniverseAgentCancelRemoteSessionResult = {
		success: false,
		callId: '',
		status: '',
		message: '',
	};

	async cancelRemoteSession(request: UniverseAgentCancelRemoteSessionRequest): Promise<UniverseAgentCancelRemoteSessionResult> {
		this.cancelRemoteSessionCalls.push(request);
		return this.cancelRemoteSessionResult;
	}

	readonly getUploadProgressCalls: UniverseAgentGetUploadProgressRequest[] = [];
	getUploadProgressResult: UniverseAgentGetUploadProgressResult = {
		exists: false,
		bytesReceived: 0,
		partialPath: '',
	};

	async getUploadProgress(request: UniverseAgentGetUploadProgressRequest): Promise<UniverseAgentGetUploadProgressResult> {
		this.getUploadProgressCalls.push(request);
		return this.getUploadProgressResult;
	}

	readonly shutdownCalls: UniverseAgentShutdownRequest[] = [];
	shutdownResult: UniverseAgentShutdownResult = {
		accepted: false,
		message: '',
	};

	async shutdown(request: UniverseAgentShutdownRequest): Promise<UniverseAgentShutdownResult> {
		this.shutdownCalls.push(request);
		return this.shutdownResult;
	}

	readonly writeClipboardCalls: UniverseAgentWriteClipboardRequest[] = [];
	writeClipboardResult: UniverseAgentWriteClipboardResult = {
		clipId: '',
	};

	async writeClipboard(request: UniverseAgentWriteClipboardRequest): Promise<UniverseAgentWriteClipboardResult> {
		this.writeClipboardCalls.push(request);
		return this.writeClipboardResult;
	}

	readonly readClipboardCalls: UniverseAgentReadClipboardRequest[] = [];
	readClipboardResult: UniverseAgentReadClipboardResult = {
		entry: {
			clipId: '',
			label: '',
			type: 'CLIPBOARD_TEXT',
			content: '',
			createdBy: '',
			createdAt: 0,
		},
	};

	async readClipboard(request: UniverseAgentReadClipboardRequest): Promise<UniverseAgentReadClipboardResult> {
		this.readClipboardCalls.push(request);
		return this.readClipboardResult;
	}

	readonly listClipboardCalls: UniverseAgentListClipboardRequest[] = [];
	listClipboardResult: UniverseAgentListClipboardResult = {
		entries: [],
	};

	async listClipboard(request: UniverseAgentListClipboardRequest): Promise<UniverseAgentListClipboardResult> {
		this.listClipboardCalls.push(request);
		return this.listClipboardResult;
	}

	readonly clearClipboardCalls: UniverseAgentClearClipboardRequest[] = [];
	clearClipboardResult: UniverseAgentClearClipboardResult = {
		removedCount: 0,
	};

	async clearClipboard(request: UniverseAgentClearClipboardRequest): Promise<UniverseAgentClearClipboardResult> {
		this.clearClipboardCalls.push(request);
		return this.clearClipboardResult;
	}

	private _downloadAttachmentGate: ReturnType<typeof createStreamCloseGate> | undefined;
	readonly downloadAttachmentOpens: UniverseAgentDownloadAttachmentRequest[] = [];

	openDownloadAttachmentStream(
		request: UniverseAgentDownloadAttachmentRequest,
		_onResponse: (response: UniverseAgentDownloadChunk) => void,
		onClosed?: (cause: UniverseAgentSessionStreamCloseCause) => void,
	): { dispose(): void } {
		this.downloadAttachmentOpens.push(request);
		const gate = createStreamCloseGate(onClosed);
		this._downloadAttachmentGate = gate;
		return {
			dispose: () => {
				gate.closeLocal();
				if (this._downloadAttachmentGate === gate) {
					this._downloadAttachmentGate = undefined;
				}
			},
		};
	}

	fireDownloadAttachmentClosed(cause: UniverseAgentSessionStreamCloseCause): void {
		this._downloadAttachmentGate?.finish(cause);
	}

	private _ptyStreamGate: ReturnType<typeof createStreamCloseGate> | undefined;
	private _ptyStreamOnResponse: ((response: UniverseAgentPtyServerMessage) => void) | undefined;
	readonly ptyStreamWrites: UniverseAgentPtyClientMessage[] = [];
	ptyStreamOpenCount = 0;

	openPtyStream(
		onResponse: (response: UniverseAgentPtyServerMessage) => void,
		onClosed?: (cause: UniverseAgentSessionStreamCloseCause) => void,
	): { write(message: UniverseAgentPtyClientMessage): void; end(): void; dispose(): void } {
		this.ptyStreamOpenCount++;
		this._ptyStreamOnResponse = onResponse;
		const gate = createStreamCloseGate(onClosed);
		this._ptyStreamGate = gate;
		return {
			write: (message: UniverseAgentPtyClientMessage) => {
				this.ptyStreamWrites.push(message);
			},
			end: () => { },
			dispose: () => {
				gate.closeLocal();
				if (this._ptyStreamGate === gate) {
					this._ptyStreamGate = undefined;
					this._ptyStreamOnResponse = undefined;
				}
			},
		};
	}

	firePtyStreamMessage(message: UniverseAgentPtyServerMessage): void {
		this._ptyStreamOnResponse?.(message);
	}

	firePtyStreamClosed(cause: UniverseAgentSessionStreamCloseCause): void {
		this._ptyStreamGate?.finish(cause);
	}

	healthCheckCalls = 0;
	healthCheckResult: UniverseAgentHealthCheckResult = {
		status: '',
		version: '',
		activeSessions: 0,
		uptimeMs: 0,
	};

	async healthCheck(): Promise<UniverseAgentHealthCheckResult> {
		this.healthCheckCalls++;
		return this.healthCheckResult;
	}

	doctorCalls = 0;
	doctorResult: UniverseAgentDoctorResult = {
		checks: [],
		allPassed: false,
	};

	async doctor(): Promise<UniverseAgentDoctorResult> {
		this.doctorCalls++;
		return this.doctorResult;
	}

	listDevicesCalls = 0;
	listDevicesResult: UniverseAgentListDevicesResult = {
		devices: [],
	};

	async listDevices(): Promise<UniverseAgentListDevicesResult> {
		this.listDevicesCalls++;
		return this.listDevicesResult;
	}

	readonly pairApproveCalls: UniverseAgentPairApproveRequest[] = [];
	pairApproveResult: UniverseAgentPairApproveResult = {
		success: false,
		deviceId: '',
		message: '',
	};

	async pairApprove(request: UniverseAgentPairApproveRequest): Promise<UniverseAgentPairApproveResult> {
		this.pairApproveCalls.push(request);
		return this.pairApproveResult;
	}

	readonly pairRejectCalls: UniverseAgentPairRejectRequest[] = [];
	pairRejectResult: UniverseAgentPairRejectResult = {
		success: false,
		message: '',
	};

	async pairReject(request: UniverseAgentPairRejectRequest): Promise<UniverseAgentPairRejectResult> {
		this.pairRejectCalls.push(request);
		return this.pairRejectResult;
	}

	readonly revokeCalls: UniverseAgentRevokeRequest[] = [];
	revokeResult: UniverseAgentRevokeResult = {
		success: false,
		message: '',
	};

	async revoke(request: UniverseAgentRevokeRequest): Promise<UniverseAgentRevokeResult> {
		this.revokeCalls.push(request);
		return this.revokeResult;
	}

	readonly rotateTokenCalls: UniverseAgentRotateTokenRequest[] = [];
	rotateTokenResult: UniverseAgentRotateTokenResult = {
		success: false,
		message: '',
	};

	async rotateToken(request: UniverseAgentRotateTokenRequest): Promise<UniverseAgentRotateTokenResult> {
		this.rotateTokenCalls.push(request);
		return this.rotateTokenResult;
	}

	listPendingCalls = 0;
	listPendingResult: UniverseAgentListPendingResult = {
		pending: [],
	};

	async listPending(): Promise<UniverseAgentListPendingResult> {
		this.listPendingCalls++;
		return this.listPendingResult;
	}

	readonly listTriggersCalls: UniverseAgentListTriggersRequest[] = [];
	listTriggersResult: UniverseAgentListTriggersResult = {
		triggers: [],
	};

	async listTriggers(request: UniverseAgentListTriggersRequest): Promise<UniverseAgentListTriggersResult> {
		this.listTriggersCalls.push(request);
		return this.listTriggersResult;
	}

	readonly upsertTriggerCalls: UniverseAgentUpsertTriggerRequest[] = [];
	upsertTriggerResult: UniverseAgentUpsertTriggerResult = {
		trigger: {
			triggerId: '',
			name: '',
			type: '',
			promptTemplate: '',
			enabled: false,
			pauseReason: '',
			target: { kind: 'unspecified' },
			intervalMs: 0,
			cronExpression: '',
			runAtEpochMs: 0,
		},
	};

	async upsertTrigger(request: UniverseAgentUpsertTriggerRequest): Promise<UniverseAgentUpsertTriggerResult> {
		this.upsertTriggerCalls.push(request);
		return this.upsertTriggerResult;
	}

	readonly deleteTriggerCalls: UniverseAgentDeleteTriggerRequest[] = [];
	deleteTriggerResult: UniverseAgentDeleteTriggerResult = {};

	async deleteTrigger(request: UniverseAgentDeleteTriggerRequest): Promise<UniverseAgentDeleteTriggerResult> {
		this.deleteTriggerCalls.push(request);
		return this.deleteTriggerResult;
	}

	readonly setTriggerEnabledCalls: UniverseAgentSetTriggerEnabledRequest[] = [];
	setTriggerEnabledResult: UniverseAgentSetTriggerEnabledResult = {
		trigger: {
			triggerId: '',
			name: '',
			type: '',
			promptTemplate: '',
			enabled: false,
			pauseReason: '',
			target: { kind: 'unspecified' },
			intervalMs: 0,
			cronExpression: '',
			runAtEpochMs: 0,
		},
	};

	async setTriggerEnabled(request: UniverseAgentSetTriggerEnabledRequest): Promise<UniverseAgentSetTriggerEnabledResult> {
		this.setTriggerEnabledCalls.push(request);
		return this.setTriggerEnabledResult;
	}

	readonly fireTriggerCalls: UniverseAgentFireTriggerRequest[] = [];
	fireTriggerResult: UniverseAgentFireTriggerResult = { status: '', eventId: '', reason: '' };

	async fireTrigger(request: UniverseAgentFireTriggerRequest): Promise<UniverseAgentFireTriggerResult> {
		this.fireTriggerCalls.push(request);
		return this.fireTriggerResult;
	}

	async listModels() {
		const ownedOperation = this.recordOwnedOperation('listModels');
		if (ownedOperation) { await ownedOperation; }
		return { models: [] };
	}

	readonly getConfigCalls: UniverseAgentGetConfigRequest[] = [];
	getConfigResult: UniverseAgentGetConfigResult = { values: {}, scope: '' };

	async getConfig(request: UniverseAgentGetConfigRequest): Promise<UniverseAgentGetConfigResult> {
		this.getConfigCalls.push(request);
		return this.getConfigResult;
	}

	readonly getModelPreferencesCalls: UniverseAgentGetModelPreferencesRequest[] = [];
	getModelPreferencesResult: UniverseAgentGetModelPreferencesResult = {
		minLevel: 0,
		maxCost: '',
		minSpeed: '',
		strategy: '',
	};

	async getModelPreferences(request: UniverseAgentGetModelPreferencesRequest): Promise<UniverseAgentGetModelPreferencesResult> {
		this.getModelPreferencesCalls.push(request);
		return this.getModelPreferencesResult;
	}

	async fetchAgentTree(sessionId: string) {
		if (this.handlers.fetchAgentTree) {
			return this.handlers.fetchAgentTree(sessionId);
		}
		return undefined;
	}

	async fetchToolDetail(request: UniverseAgentFetchToolDetailRequest) {
		if (this.handlers.fetchToolDetail) {
			return this.handlers.fetchToolDetail(request);
		}
		return { success: false, content: '', truncated: false };
	}

	async memberStatus() {
		return [];
	}

	async taskList() {
		return [];
	}

	async teamInfo() {
		return undefined;
	}

	async listProviderStatus() {
		const ownedOperation = this.recordOwnedOperation('listProviderStatus');
		if (ownedOperation) { await ownedOperation; }
		return this.handlers.listProviderStatus?.() ?? { providers: [] };
	}

	readonly providerWriteIds: string[] = [];
	async upsertProviderCredentials(request: UniverseAgentUpsertProviderCredentialsRequest): Promise<UniverseAgentProviderStatus> {
		const ownedOperation = this.recordOwnedOperation('upsertProviderCredentials', request);
		if (ownedOperation) { await ownedOperation; }
		this.providerWriteIds.push(request.providerId);
		return this.handlers.upsertProviderCredentials?.(request)
			?? { providerId: '', brand: '', protocol: '', configured: false, credentialSource: 'NONE', hasBaseUrl: false, enabled: false };
	}

	async clearProviderCredentials(request: UniverseAgentClearProviderCredentialsRequest) {
		const ownedOperation = this.recordOwnedOperation('clearProviderCredentials', request);
		if (ownedOperation) { await ownedOperation; }
		return { providerId: '', brand: '', protocol: '', configured: false, credentialSource: 'NONE', hasBaseUrl: false, enabled: false };
	}

	readonly modelWriteIds: string[] = [];
	async upsertModel(request: UniverseAgentUpsertModelRequest): Promise<UniverseAgentModelEntry> {
		const ownedOperation = this.recordOwnedOperation('upsertModel', request);
		if (ownedOperation) { await ownedOperation; }
		this.modelWriteIds.push(request.id);
		return this.handlers.upsertModel?.(request) ?? { id: '', type: '', enabled: false, level: 0, provider: '', modelId: '' };
	}

	async deleteModel(request: UniverseAgentDeleteModelRequest) {
		const ownedOperation = this.recordOwnedOperation('deleteModel', request);
		if (ownedOperation) { await ownedOperation; }
		return { deleted: false };
	}

	async setModelEnabled(request: UniverseAgentSetModelEnabledRequest) {
		const ownedOperation = this.recordOwnedOperation('setModelEnabled', request);
		if (ownedOperation) { await ownedOperation; }
		return { id: '', type: '', enabled: false, level: 0, provider: '', modelId: '' };
	}

	readonly ownedCalls: { readonly method: string; readonly request?: object }[] = [];
	private recordOwnedOperation(method: string, request?: object): Promise<void> | undefined {
		this.ownedCalls.push({ method, ...(request ? { request } : {}) });
		return this.handlers.ownedOperation?.(method);
	}

	async listProjectRules() {
		return { rules: [] };
	}

	async upsertProjectRule() {
		return { id: '', title: '', enabled: false, priority: 0 as const, body: '', scope: 0 as const, globs: [], appliesTo: [] };
	}

	async deleteProjectRule() {
		return { deleted: false };
	}

	async listHookPoints() {
		return { points: [], catalogRevision: '' };
	}

	async listTeams() {
		return { teams: [] };
	}
}


const PLAIN_FIXTURE_PROFILE_ID = 'plain-fixture';

const fixtureLocalTarget: LocalEngineTarget = { kind: 'uds', path: '/tmp/ua-elr14-fixture.sock' };

function plainFixtureIdentity(): IClientIdentityStore {
	const identity = {
		clientIdentityId: 'b'.repeat(64),
		clientPublicKey: new Uint8Array(32),
		privateKeyPkcs8: new Uint8Array(32),
	};
	return {
		getState: async () => ({ kind: 'ready', identity }),
		getOrCreateIdentity: async () => ({ kind: 'ready', identity }),
		createSigner: async () => undefined,
	};
}

function plainFixtureResolver(): ConnectionResolver {
	return {
		resolve: async () => ({
			ok: true as const,
			allowRelayFallback: false as const,
			endpoint: {
				attemptId: 'plain-fixture',
				authority: '127.0.0.1:9',
				port: 9,
				resolvedIp: '127.0.0.1',
				servername: '127.0.0.1',
				relayTicketId: null,
				tls: null,
				expiresAtMs: Date.now() + 60_000,
				path: 'direct' as const,
			},
		}),
		consumeRelayTicket: () => { },
	} as unknown as ConnectionResolver;
}

async function connectPlainFixture(service: UniverseAgentConnectionService): Promise<void> {
	const result = await service.connectProfile(PLAIN_FIXTURE_PROFILE_ID);
	if (!result.ok) {
		throw new Error(`${result.code}: ${result.reason}`);
	}
}

function localEngineFixtureOptions(
	transport: MockUniverseAgentGrpcTransport,
	override: Partial<UniverseAgentConnectionServiceOptions> = {},
): UniverseAgentConnectionServiceOptions {
	return {
		autoConnectLocalEngine: true,
		storageReady: Promise.resolve(),
		findLocalEngine: async () => fixtureLocalTarget,
		openLocalEngineTransport: () => transport as unknown as GrpcUniverseAgentClient,
		setTimeoutFn: callback => {
			queueMicrotask(callback);
			return 0 as unknown as ReturnType<typeof setTimeout>;
		},
		clearTimeoutFn: () => { },
		reconnectJitterRatio: 0,
		...override,
	};
}

async function settleLocalTurns(): Promise<void> {
	for (let i = 0; i < 30; i++) {
		await new Promise(resolve => setImmediate(resolve));
	}
}

async function waitForLocalFixture(service: UniverseAgentConnectionService): Promise<void> {
	for (let i = 0; i < 40; i++) {
		await new Promise(resolve => setImmediate(resolve));
		if (service.getConnectionPhase().kind === 'connected') {
			return;
		}
	}
	throw new Error(`local fixture did not connect: ${service.getConnectionPhase().kind}`);
}

suite('UniverseAgentConnectionService', () => {

	const store = ensureNoDisposablesAreLeakedInTestSuite();

	const importDrafts = [
		{ providerId: 'fixture-alpha', label: 'Alpha', source: 'test', protocol: 'openai', apiKey: 'fixture-alpha-secret', baseUrl: '', models: [{ modelId: 'one' }, { modelId: 'two' }] },
		{ providerId: 'fixture-beta', label: 'Beta', source: 'test', protocol: 'openai', apiKey: 'fixture-beta-secret', baseUrl: '', models: [{ modelId: 'three' }] },
	];
	const importedProvider: UniverseAgentProviderStatus = { providerId: 'fixture-alpha', brand: 'Alpha', protocol: 'openai', configured: true, credentialSource: 'FILE', hasBaseUrl: false, enabled: true };
	const importedModel: UniverseAgentModelEntry = { id: 'fixture-alpha:one', type: 'general', enabled: true, level: 0, provider: 'fixture-alpha', modelId: 'one' };

	class OwnedTestTransport extends MockUniverseAgentGrpcTransport {
		readonly leafDer: Uint8Array;
		readonly trust: ReturnType<typeof createEngineTrustRecord>;
		constructor(readonly engineIdentityId: string, handlers: ConstructorParameters<typeof MockUniverseAgentGrpcTransport>[0] = {}, private readonly advertiseSave = true) {
			super(handlers);
			this.leafDer = new Uint8Array([engineIdentityId === 'engine-a' ? 9 : 10]);
			this.trust = createEngineTrustRecord({ leafDer: this.leafDer, engineIdentityId, establishedAt: 1 });
		}
		override async getAuthNonce(): Promise<UniverseAgentAuthNonceResult> {
			return { authNonce: new Uint8Array(32).fill(7), engineIdentityId: this.engineIdentityId, engineCertFingerprint: this.trust.leafSha256Hex };
		}
		override async connectWithDeviceAuth(): Promise<UniverseAgentConnectResult> {
			return { sessionToken: `token-${this.engineIdentityId}`, methods: ['AgentService.*', 'ConfigService.*', this.advertiseSave ? 'ToolService.*' : 'ToolService.ListSkills'], events: [] };
		}
		override close(): void {
			// Tests may reconnect the same wrapper. The test store owns its emitters.
		}
		dispose(): void {
			super.close();
		}
	}

	function createOwnedFixture(transport: OwnedTestTransport) {
		const clock = createReconnectClock();
		let nextTransport = transport;
		let readerCalls = 0;
		const profile: ConnectionProfile = {
			profileId: 'owner-fixture', displayName: 'Owner fixture',
			target: { kind: 'directAddress', host: '203.0.113.10', port: 7443 },
			trust: transport.trust, state: 'active', allowPrivateNetwork: true,
		};
		const profiles = new PairingTestProfileStore(profile);
		const service = store.add(new UniverseAgentConnectionService({
			createPinnedTransport: () => nextTransport,
			connectionResolver: {
				resolve: async () => ({
					ok: true as const, allowRelayFallback: false as const,
					endpoint: {
						attemptId: 'owner-fixture', authority: '203.0.113.10:7443', port: 7443,
						resolvedIp: '203.0.113.10', servername: 'engine.example', relayTicketId: null,
						tls: { trustAnchorLeafDer: nextTransport.leafDer, expectedLeafSha256Hex: nextTransport.trust.leafSha256Hex, hostnameVerification: 'replaced-by-pin' as const },
						expiresAtMs: Date.now() + 60_000, path: 'direct' as const,
					},
				}),
				consumeRelayTicket: () => { },
			} as unknown as ConnectionResolver,
			connectionProfileStore: profiles,
			pairingOrchestrator: awaitingSasOrchestrator(),
			clientIdentityStore: { ...plainFixtureIdentity(), createSigner: async () => () => new Uint8Array(64) },
			readHarnessProviderDrafts: () => { readerCalls++; return [{ ...importDrafts[0], models: [importDrafts[0].models[0]] }]; },
			setTimeoutFn: clock.setTimeoutFn, clearTimeoutFn: clock.clearTimeoutFn,
		}));
		return {
			service, clock, readerCalls: () => readerCalls,
			enterPairing: async () => {
				profiles.put({ ...profile, trust: null, state: 'pairingPending' });
				await service.connectProfile(profile.profileId);
				assert.strictEqual(service.getConnectionSnapshot().pairingPending, true);
			},
			connect: async (target = transport) => {
				nextTransport = target;
				profiles.put({ ...profile, trust: target.trust });
				const result = await service.connectProfile(profile.profileId);
				assert.strictEqual(result.ok, true);
			},
		};
	}

	function publishedOwner(service: IUniverseAgentConnection): UniverseAgentExpectedOwner {
		const { engineIdentityId, linkId } = service.getConnectionSnapshot();
		assert.ok(typeof engineIdentityId === 'string' && typeof linkId === 'number');
		return { engineIdentityId, linkId };
	}

	const ownedCases: readonly {
		readonly method: string;
		readonly invoke: (connection: IUniverseAgentConnection, owner?: UniverseAgentExpectedOwner) => Promise<unknown>;
		readonly wireCalls: readonly { readonly method: string; readonly request?: object }[];
	}[] = [
		{ method: 'upsertProviderCredentials', invoke: (connection, owner) => connection.upsertProviderCredentials!({ providerId: 'p', apiKey: 'fixture-secret' }, owner), wireCalls: [{ method: 'upsertProviderCredentials', request: { providerId: 'p', apiKey: 'fixture-secret' } }] },
		{ method: 'clearProviderCredentials', invoke: (connection, owner) => connection.clearProviderCredentials!({ providerId: 'p' }, owner), wireCalls: [{ method: 'clearProviderCredentials', request: { providerId: 'p' } }] },
		{ method: 'upsertModel', invoke: (connection, owner) => connection.upsertModel!(importedModel, owner), wireCalls: [{ method: 'upsertModel', request: importedModel }] },
		{ method: 'deleteModel', invoke: (connection, owner) => connection.deleteModel!({ id: 'm' }, owner), wireCalls: [{ method: 'deleteModel', request: { id: 'm' } }] },
		{ method: 'setModelEnabled', invoke: (connection, owner) => connection.setModelEnabled!({ id: 'm', enabled: false }, owner), wireCalls: [{ method: 'setModelEnabled', request: { id: 'm', enabled: false } }] },
		{ method: 'testModelProfile', invoke: (connection, owner) => connection.testModelProfile!({ providerId: 'p', modelId: 'm', apiKey: '', baseUrl: '', protocol: '', params: {} }, owner), wireCalls: [{ method: 'testModelProfile', request: { providerId: 'p', modelId: 'm', apiKey: '', baseUrl: '', protocol: '', params: {} } }] },
		{ method: 'importHarnessProviders', invoke: (connection, owner) => connection.importHarnessProviders!({ providerIds: ['fixture-alpha'] }, owner), wireCalls: [{ method: 'listProviderStatus' }, { method: 'upsertProviderCredentials', request: { providerId: 'fixture-alpha', apiKey: 'fixture-alpha-secret', baseUrl: '', protocol: 'openai' } }, { method: 'upsertModel', request: { id: 'fixture-alpha:one', type: 'general', enabled: true, level: 0, description: '', cost: '', speed: '', provider: 'fixture-alpha', modelId: 'one' } }] },
		{ method: 'listProviderStatus', invoke: (connection, owner) => connection.listProviderStatus!(owner), wireCalls: [{ method: 'listProviderStatus' }] },
		{ method: 'listModels', invoke: (connection, owner) => connection.listModels(owner), wireCalls: [{ method: 'listModels' }] },
		{ method: 'setSkillEnabled', invoke: (connection, owner) => connection.setSkillEnabled({ skillName: 'skill', enabled: true }, owner), wireCalls: [{ method: 'setSkillEnabled', request: { skillName: 'skill', enabled: true } }] },
		{ method: 'saveSkillContent', invoke: (connection, owner) => connection.saveSkillContent!({ skillName: 'skill', content: '# Draft', create: false, expectedSource: 'project', expectedContent: '# Baseline' }, owner), wireCalls: [{ method: 'saveSkillContent', request: { skillName: 'skill', content: '# Draft', create: false, expectedSource: 'project', expectedContent: '# Baseline' } }] },
		{ method: 'listSkills', invoke: (connection, owner) => connection.listSkills(owner), wireCalls: [{ method: 'listSkills' }] },
		{ method: 'getSkillInfo', invoke: (connection, owner) => connection.getSkillInfo({ skillName: 'skill' }, owner), wireCalls: [{ method: 'getSkillInfo', request: { skillName: 'skill' } }] },
	];

	class OwnerProtocol extends Disposable implements IMessagePassingProtocol {
		other!: OwnerProtocol;
		private buffers: VSBuffer[] = [];
		private buffering = true;
		private readonly emitter = this._register(new Emitter<VSBuffer>({
			onDidAddFirstListener: () => {
				this.buffering = false;
				for (const buffer of this.buffers.splice(0)) { this.emitter.fire(buffer); }
			},
			onDidRemoveLastListener: () => { this.buffering = true; },
		}));
		readonly onMessage = this.emitter.event;
		send(buffer: VSBuffer): void {
			if (this.other.buffering) { this.other.buffers.push(buffer); } else { this.other.emitter.fire(buffer); }
		}
	}

	async function openOwnedByteClient(service: UniverseAgentConnectionService) {
		const clientProtocol = store.add(new OwnerProtocol());
		const serverProtocol = store.add(new OwnerProtocol());
		clientProtocol.other = serverProtocol;
		serverProtocol.other = clientProtocol;
		const client = store.add(new ChannelClient(clientProtocol));
		const server = store.add(new ChannelServer(serverProtocol, 'owner-byte-fixture'));
		const inner = ProxyChannel.fromService<string>(service, store.add(new DisposableStore()));
		let holdSnapshots = false;
		server.registerChannel('owner', new UniverseAgentConnectionIpcChannel(service, {
			call: <T>(ctx: string, command: string, arg?: unknown, token?: CancellationToken) => inner.call<T>(ctx, command, arg, token),
			listen: <T>(ctx: string, event: string, arg?: unknown) => Event.filter(inner.listen<T>(ctx, event, arg), () => event !== 'onDidChangeConnection' || !holdSnapshots),
		}));
		const renderer = store.add(new UniverseAgentConnectionChannelClient(client.getChannel('owner')));
		const hydrated = new DeferredPromise<void>();
		store.add(renderer.onDidChangeConnection(() => { void hydrated.complete(); }));
		await hydrated.p;
		return { renderer, holdSnapshots: () => { holdSnapshots = true; } };
	}

	for (const entry of ownedCases) {
		test(`expected owner node: ${entry.method} never treats an explicit malformed owner as legacy omission`, async () => {
			const transport = store.add(new OwnedTestTransport('engine-a'));
			const fixture = createOwnedFixture(transport);
			await fixture.connect();
			const error = await entry.invoke(fixture.service, null as unknown as UniverseAgentExpectedOwner).then(() => undefined, error => error);
			assert.deepStrictEqual({ calls: transport.ownedCalls, cancelled: isCancellationError(error), readerCalls: fixture.readerCalls() }, { calls: [], cancelled: true, readerCalls: 0 });
		});

		test(`expected owner node: ${entry.method} rejects a stale initial owner before any replacement RPC`, async () => {
			const original = store.add(new OwnedTestTransport('engine-a'));
			const replacement = store.add(new OwnedTestTransport('engine-b'));
			const fixture = createOwnedFixture(original);
			await fixture.connect();
			const owner = publishedOwner(fixture.service);
			await fixture.connect(replacement);
			const readerCalls = fixture.readerCalls();
			const error = await entry.invoke(fixture.service, owner).then(() => undefined, error => error);
			assert.deepStrictEqual({ calls: replacement.ownedCalls, cancelled: isCancellationError(error), readerCalls: fixture.readerCalls() - readerCalls }, { calls: [], cancelled: true, readerCalls: 0 });
		});

		test(`expected owner node: ${entry.method} keeps current and legacy wire payloads unchanged`, async () => {
			const transport = store.add(new OwnedTestTransport('engine-a'));
			const fixture = createOwnedFixture(transport);
			await fixture.connect();
			await entry.invoke(fixture.service, publishedOwner(fixture.service));
			assert.deepStrictEqual(transport.ownedCalls, entry.wireCalls);
			transport.ownedCalls.length = 0;
			await entry.invoke(fixture.service);
			assert.deepStrictEqual(transport.ownedCalls, entry.wireCalls);
		});

		for (const outcome of ['success', 'unavailable'] as const) {
			test(`expected owner node: ${entry.method} cancels stale ${outcome} on a reused transport link`, async () => {
				const entered = new DeferredPromise<void>();
				const release = new DeferredPromise<void>();
				let pause = true;
				const transport = store.add(new OwnedTestTransport('engine-a', { ownedOperation: async () => {
					if (!pause) { return; }
					pause = false;
					await entered.complete();
					await release.p;
					if (outcome === 'unavailable') { throw new UniverseAgentTransportError(GrpcStatusCode.UNAVAILABLE, 'old fixture-secret unavailable'); }
				} }));
				const fixture = createOwnedFixture(transport);
				await fixture.connect();
				const owner = publishedOwner(fixture.service);
				const pending = entry.invoke(fixture.service, owner).then(() => undefined, error => error);
				await entered.p;
				await fixture.connect();
				assert.notStrictEqual(publishedOwner(fixture.service).linkId, owner.linkId);
				await release.complete();
				const error = await pending;
				assert.deepStrictEqual({
					cancelled: isCancellationError(error), message: error instanceof Error ? error.message : undefined,
					calls: transport.ownedCalls.map(call => call.method), transport: fixture.service.getTransportState(),
					phase: fixture.service.getConnectionPhase().kind, reconnects: fixture.clock.delays,
				}, { cancelled: true, message: 'Canceled', calls: [entry.wireCalls[0].method], transport: 'ok', phase: 'connected', reconnects: [] });
				transport.ownedCalls.length = 0;
				await entry.invoke(fixture.service, publishedOwner(fixture.service));
				assert.deepStrictEqual(transport.ownedCalls, entry.wireCalls);
			});
		}

		test(`expected owner byte IPC: ${entry.method} rejects main B while renderer still caches A`, async () => {
			const original = store.add(new OwnedTestTransport('engine-a'));
			const replacement = store.add(new OwnedTestTransport('engine-b'));
			const fixture = createOwnedFixture(original);
			await fixture.connect();
			const { renderer, holdSnapshots } = await openOwnedByteClient(fixture.service);
			const owner = publishedOwner(renderer);
			await entry.invoke(renderer, owner);
			assert.deepStrictEqual(original.ownedCalls, entry.wireCalls, 'the byte path must preserve the explicit owner and keep it out of engine requests');
			holdSnapshots();
			await fixture.connect(replacement);
			assert.deepStrictEqual({ renderer: publishedOwner(renderer), mainIdentity: publishedOwner(fixture.service).engineIdentityId }, { renderer: owner, mainIdentity: 'engine-b' });
			const error = await entry.invoke(renderer, owner).then(() => undefined, error => error);
			assert.deepStrictEqual({
				calls: replacement.ownedCalls, error: error instanceof Error,
				originalClass: error instanceof CancellationError, cancelled: isCancellationError(error),
				name: error instanceof Error ? error.name : undefined, message: error instanceof Error ? error.message : undefined,
			}, { calls: [], error: true, originalClass: false, cancelled: true, name: 'Canceled', message: 'Canceled' });
		});
	}

	test('expected owner byte IPC: stale save is cancelled before lookup when the new engine has no binding', async () => {
		const original = store.add(new OwnedTestTransport('engine-a'));
		const replacement = store.add(new OwnedTestTransport('engine-b', {}, false));
		const fixture = createOwnedFixture(original);
		await fixture.connect();
		const { renderer, holdSnapshots } = await openOwnedByteClient(fixture.service);
		const owner = publishedOwner(renderer);
		holdSnapshots();
		await fixture.connect(replacement);
		assert.strictEqual((fixture.service as IUniverseAgentConnection).saveSkillContent, undefined);
		const error = await renderer.saveSkillContent!({ skillName: 'skill', content: '# Draft', create: true }, owner).then(() => undefined, error => error);
		assert.deepStrictEqual({ cancelled: isCancellationError(error), message: error instanceof Error ? error.message : undefined, calls: replacement.ownedCalls }, { cancelled: true, message: 'Canceled', calls: [] });
	});

	for (const ownerSupplied of [true, false]) {
		test(`expected owner skill binding: old UNIMPLEMENTED preserves the new link (owner supplied: ${ownerSupplied})`, async () => {
			const entered = new DeferredPromise<void>();
			const release = new DeferredPromise<void>();
			let saves = 0;
			const transport = store.add(new OwnedTestTransport('engine-a', { saveSkillContent: async () => {
				if (++saves === 1) {
					await entered.complete();
					await release.p;
					throw new UniverseAgentTransportError(GrpcStatusCode.UNIMPLEMENTED, 'old fixture-secret not implemented');
				}
				return { ok: true };
			} }));
			const fixture = createOwnedFixture(transport);
			await fixture.connect();
			const connection: IUniverseAgentConnection = fixture.service;
			const pending = connection.saveSkillContent!({ skillName: 'skill', content: '# Draft', create: true }, ownerSupplied ? publishedOwner(connection) : undefined).then(result => result, error => error);
			await entered.p;
			await fixture.connect();
			await release.complete();
			const result = await pending;
			if (ownerSupplied) {
				assert.deepStrictEqual({ cancelled: isCancellationError(result), binding: typeof connection.saveSkillContent, transport: connection.getTransportState() }, { cancelled: true, binding: 'function', transport: 'ok' });
			} else {
				assert.deepStrictEqual({
					originalError: result instanceof UniverseAgentTransportError,
					code: result instanceof UniverseAgentTransportError ? result.code : undefined,
					cancelled: isCancellationError(result), binding: typeof connection.saveSkillContent,
					transport: connection.getTransportState(), reconnects: fixture.clock.delays,
				}, { originalError: true, code: GrpcStatusCode.UNIMPLEMENTED, cancelled: false, binding: 'function', transport: 'ok', reconnects: [] });
			}
			assert.deepStrictEqual(await connection.saveSkillContent!({ skillName: 'skill', content: '# New', create: true }, publishedOwner(connection)), { ok: true });
		});
	}

	for (const outcome of ['success', 'unavailable'] as const) {
		test(`expected owner skill legacy: late ${outcome} on a reused link keeps new health`, async () => {
			const entered = new DeferredPromise<void>();
			const release = new DeferredPromise<void>();
			const originalError = new UniverseAgentTransportError(GrpcStatusCode.UNAVAILABLE, 'old unavailable');
			const transport = store.add(new OwnedTestTransport('engine-a', {
				saveSkillContent: async () => {
					await entered.complete();
					await release.p;
					if (outcome === 'unavailable') { throw originalError; }
					return { ok: true };
				},
				listSessions: async () => { throw new UniverseAgentTransportError(GrpcStatusCode.UNAVAILABLE, 'new link unavailable'); },
			}));
			const fixture = createOwnedFixture(transport);
			await fixture.connect();
			const connection: IUniverseAgentConnection = fixture.service;
			const pending = connection.saveSkillContent!({ skillName: 'skill', content: '# Draft', create: true }).then(result => result, error => error);
			await entered.p;
			await fixture.connect();
			if (outcome === 'success') {
				await assert.rejects(() => connection.listSessions({}));
			}
			const before = { transport: connection.getTransportState(), phase: connection.getConnectionPhase(), reconnects: [...fixture.clock.delays] };
			await release.complete();
			const result = await pending;
			if (outcome === 'success') {
				assert.deepStrictEqual(result, { ok: true });
			} else {
				assert.strictEqual(result, originalError);
			}
			assert.deepStrictEqual({ transport: connection.getTransportState(), phase: connection.getConnectionPhase(), reconnects: fixture.clock.delays, binding: typeof connection.saveSkillContent }, { ...before, binding: 'function' });
		});
	}

	for (const omitOwner of [true, false]) {
		test(`expected owner skill legacy: current UNIMPLEMENTED keeps old semantics (omitted: ${omitOwner})`, async () => {
			const transport = store.add(new OwnedTestTransport('engine-a', { saveSkillContent: async () => { throw new UniverseAgentTransportError(GrpcStatusCode.UNIMPLEMENTED, 'current unsupported'); } }));
			const fixture = createOwnedFixture(transport);
			await fixture.connect();
			const connection: IUniverseAgentConnection = fixture.service;
			const request = { skillName: 'skill', content: '# Draft', create: true };
			const result = omitOwner ? await connection.saveSkillContent!(request) : await connection.saveSkillContent!(request, undefined);
			assert.deepStrictEqual({ result, binding: typeof connection.saveSkillContent, transport: connection.getTransportState() }, { result: { ok: false, reason: 'UNIMPLEMENTED' }, binding: 'undefined', transport: 'ok' });
		});
	}

	test('expected owner skill: current business rejection UNIMPLEMENTED and original errors stay distinct', async () => {
		const businessError = new Error('current business error');
		let saves = 0;
		const transport = store.add(new OwnedTestTransport('engine-a', { saveSkillContent: async () => {
			saves++;
			if (saves === 1) { return { ok: false, reason: 'CONTENT_CHANGED' }; }
			if (saves === 2) { throw businessError; }
			throw new UniverseAgentTransportError(GrpcStatusCode.UNIMPLEMENTED, 'current unsupported');
		} }));
		const fixture = createOwnedFixture(transport);
		await fixture.connect();
		const connection: IUniverseAgentConnection = fixture.service;
		const request = { skillName: 'skill', content: '# Draft', create: false, expectedSource: 'project' as const, expectedContent: '# Baseline' };
		const owner = publishedOwner(connection);
		assert.deepStrictEqual(await connection.saveSkillContent!(request, owner), { ok: false, reason: 'CONTENT_CHANGED' });
		const error = await connection.saveSkillContent!(request, owner).then(() => undefined, error => error);
		assert.strictEqual(error, businessError);
		assert.deepStrictEqual(await connection.saveSkillContent!(request, owner), { ok: false, reason: 'UNIMPLEMENTED' });
		assert.deepStrictEqual({ binding: typeof connection.saveSkillContent, transport: connection.getTransportState() }, { binding: 'undefined', transport: 'ok' });
	});

	for (const method of ['setSkillEnabled', 'saveSkillContent'] as const) {
		for (const changeMain of [false, true]) {
			test(`expected owner capture: mutating ${method} input cannot change captured main ownership (main changes: ${changeMain})`, async () => {
				const entered = new DeferredPromise<void>();
				const release = new DeferredPromise<void>();
				const transport = store.add(new OwnedTestTransport('engine-a', { ownedOperation: async () => { await entered.complete(); await release.p; } }));
				const fixture = createOwnedFixture(transport);
				await fixture.connect();
				const owner = { ...publishedOwner(fixture.service) };
				const entry = ownedCases.find(entry => entry.method === method)!;
				const pending = entry.invoke(fixture.service, owner).then(() => undefined, error => error);
				await entered.p;
				owner.engineIdentityId = 'changed-by-caller';
				owner.linkId = 99;
				if (changeMain) { await fixture.connect(); }
				await release.complete();
				const error = await pending;
				assert.deepStrictEqual({ calls: transport.ownedCalls.map(call => call.method), cancelled: isCancellationError(error), success: error === undefined }, { calls: [method], cancelled: changeMain, success: !changeMain });
			});
		}
	}

	for (const method of ['listSkills', 'saveSkillContent'] as const) {
		for (const invalidation of ['disconnect', 'pairing', 'dispose'] as const) {
			test(`expected owner node: ${method} cancels pending and captured calls after ${invalidation}`, async () => {
				const entered = new DeferredPromise<void>();
				const release = new DeferredPromise<void>();
				const transport = store.add(new OwnedTestTransport('engine-a', { ownedOperation: async () => { await entered.complete(); await release.p; } }));
				const fixture = createOwnedFixture(transport);
				await fixture.connect();
				const connection: IUniverseAgentConnection = fixture.service;
				const owner = publishedOwner(connection);
				const save = connection.saveSkillContent!;
				const invoke = () => method === 'listSkills' ? connection.listSkills(owner) : save({ skillName: 'skill', content: '# Draft', create: true }, owner);
				const pending = invoke().then(() => undefined, error => error);
				await entered.p;
				if (invalidation === 'disconnect') { await connection.disconnect(); }
				else if (invalidation === 'pairing') { await fixture.enterPairing(); }
				else { fixture.service.dispose(); }
				const beforeCallError = await invoke().then(() => undefined, error => error);
				await release.complete();
				const afterCallError = await pending;
				assert.deepStrictEqual({ calls: transport.ownedCalls.map(call => call.method), beforeCancelled: isCancellationError(beforeCallError), afterCancelled: isCancellationError(afterCallError), reconnects: fixture.clock.delays }, { calls: [method], beforeCancelled: true, afterCancelled: true, reconnects: [] });
			});
		}
	}

	for (const boundary of ['list', 'provider', 'model'] as const) {
		for (const invalidation of ['engine', 'link', 'dispose'] as const) {
			test(`import write ownership: ${boundary} stops remaining writes after ${invalidation}`, async () => {
				const entered = new DeferredPromise<void>();
				const release = new DeferredPromise<void>();
				const stopAtBoundary = async (stage: typeof boundary): Promise<void> => {
					if (stage === boundary) {
						await entered.complete();
						await release.p;
					}
				};
				const original = new MockUniverseAgentGrpcTransport({
					listProviderStatus: async () => { await stopAtBoundary('list'); return { providers: [] }; },
					upsertProviderCredentials: async () => { await stopAtBoundary('provider'); return importedProvider; },
					upsertModel: async () => { await stopAtBoundary('model'); return importedModel; },
				});
				const replacement = new MockUniverseAgentGrpcTransport();
				let transportIndex = 0;
				const service = store.add(new UniverseAgentConnectionService({
					connectionResolver: plainFixtureResolver(),
					clientIdentityStore: plainFixtureIdentity(),
					createTransport: () => transportIndex++ === 0 ? original : replacement,
					readHarnessProviderDrafts: () => importDrafts,
				}));
				await connectPlainFixture(service);
				const previousLink = service.getConnectionSnapshot().linkId;
				const pending = service.importHarnessProviders({ providerIds: importDrafts.map(draft => draft.providerId) });
				const cancelled = assert.rejects(pending, { name: 'Canceled', message: 'Canceled' });
				await entered.p;
				if (invalidation === 'dispose') {
					service.dispose();
				} else {
					const result = await service.connectProfile(invalidation === 'link' ? PLAIN_FIXTURE_PROFILE_ID : 'replacement-fixture');
					assert.strictEqual(result.ok, true);
					assert.notStrictEqual(service.getConnectionSnapshot().linkId, previousLink);
				}
				await release.complete();
				await cancelled;
				assert.deepStrictEqual({
					originalProviders: original.providerWriteIds,
					originalModels: original.modelWriteIds,
					replacementProviders: replacement.providerWriteIds,
					replacementModels: replacement.modelWriteIds,
				}, {
					originalProviders: boundary === 'list' ? [] : ['fixture-alpha'],
					originalModels: boundary === 'model' ? ['fixture-alpha:one'] : [],
					replacementProviders: [],
					replacementModels: [],
				});
				if (invalidation !== 'dispose') {
					assert.strictEqual(service.getTransportState(), 'ok');
				}
			});
		}
	}

	test('import write ownership: stale underlying rejection becomes a fixed secret-free cancellation', async () => {
		const entered = new DeferredPromise<void>();
		const release = new DeferredPromise<void>();
		const original = new MockUniverseAgentGrpcTransport({
			upsertProviderCredentials: async () => { await entered.complete(); await release.p; throw new Error('Rejected fixture-alpha-secret'); },
		});
		const replacement = new MockUniverseAgentGrpcTransport();
		let transportIndex = 0;
		const service = store.add(new UniverseAgentConnectionService({
			connectionResolver: plainFixtureResolver(), clientIdentityStore: plainFixtureIdentity(),
			createTransport: () => transportIndex++ === 0 ? original : replacement,
			readHarnessProviderDrafts: () => importDrafts,
		}));
		await connectPlainFixture(service);
		const pending = service.importHarnessProviders({ providerIds: importDrafts.map(draft => draft.providerId) });
		const cancelled = assert.rejects(pending, { name: 'Canceled', message: 'Canceled' });
		await entered.p;
		assert.strictEqual((await service.connectProfile('replacement-fixture')).ok, true);
		await release.complete();
		await cancelled;
		assert.deepStrictEqual({ providers: replacement.providerWriteIds, models: replacement.modelWriteIds, transport: service.getTransportState() }, { providers: [], models: [], transport: 'ok' });
	});

	test('import write ownership: a new published link on the same transport ignores stale failure diagnostics', async () => {
		const entered = new DeferredPromise<void>();
		const release = new DeferredPromise<void>();
		const clock = createReconnectClock();
		let providerCalls = 0;
		const transport = store.add(new class extends MockUniverseAgentGrpcTransport {
			override close(): void {
				// The factory reuses this transport wrapper across published links.
				// Its underlying event sources are owned by the test store.
			}
			dispose(): void {
				super.close();
			}
		}({
			upsertProviderCredentials: async () => {
				if (++providerCalls === 1) {
					await entered.complete();
					await release.p;
					throw new UniverseAgentTransportError(GrpcStatusCode.UNAVAILABLE, 'old fixture-alpha-secret unavailable');
				}
				return importedProvider;
			},
		}));
		const service = store.add(new UniverseAgentConnectionService({
			connectionResolver: plainFixtureResolver(), clientIdentityStore: plainFixtureIdentity(),
			createTransport: () => transport, readHarnessProviderDrafts: () => importDrafts,
			setTimeoutFn: clock.setTimeoutFn, clearTimeoutFn: clock.clearTimeoutFn,
		}));
		await connectPlainFixture(service);
		const originalLink = service.getConnectionSnapshot().linkId;
		const pending = service.importHarnessProviders({ providerIds: importDrafts.map(draft => draft.providerId) });
		const cancelled = assert.rejects(pending, { name: 'Canceled', message: 'Canceled' });
		await entered.p;
		await connectPlainFixture(service);
		assert.notStrictEqual(service.getConnectionSnapshot().linkId, originalLink, 'the public reconnect must publish a new serial on the reused object');
		await release.complete();
		await cancelled;
		assert.deepStrictEqual({
			providers: transport.providerWriteIds, models: transport.modelWriteIds,
			transport: service.getTransportState(), phase: service.getConnectionPhase().kind,
			reconnectDelays: clock.delays,
		}, { providers: ['fixture-alpha'], models: [], transport: 'ok', phase: 'connected', reconnectDelays: [] });
		assert.deepStrictEqual(await service.importHarnessProviders({ providerIds: importDrafts.map(draft => draft.providerId) }), { imported: 2, updated: 0, skipped: 0, modelWrites: 3, errors: [] });
	});

	test('import write ownership: current-link business failures retain counters, continue, and redact keys', async () => {
		const transport = new MockUniverseAgentGrpcTransport({
			listProviderStatus: async () => ({ providers: [importedProvider] }),
			upsertProviderCredentials: async request => {
				if (request.providerId === 'fixture-beta') { throw new Error('Rejected fixture-beta-secret'); }
				return importedProvider;
			},
			upsertModel: async request => {
				if (request.modelId === 'one') { throw new Error('Rejected fixture-alpha-secret'); }
				return importedModel;
			},
		});
		const service = store.add(new UniverseAgentConnectionService({
			connectionResolver: plainFixtureResolver(), clientIdentityStore: plainFixtureIdentity(),
			createTransport: () => transport, readHarnessProviderDrafts: () => importDrafts,
		}));
		await connectPlainFixture(service);
		const result = await service.importHarnessProviders({ providerIds: [...importDrafts.map(draft => draft.providerId), 'missing'] });
		assert.deepStrictEqual(result, { imported: 0, updated: 1, skipped: 1, modelWrites: 1, errors: ['fixture-alpha:one: Rejected [redacted]', 'fixture-beta: Rejected [redacted]'] });
		assert.deepStrictEqual(transport.modelWriteIds, ['fixture-alpha:one', 'fixture-alpha:two']);
	});

	test('import write ownership: current-link import completes all providers and models', async () => {
		const transport = new MockUniverseAgentGrpcTransport();
		const service = store.add(new UniverseAgentConnectionService({
			connectionResolver: plainFixtureResolver(), clientIdentityStore: plainFixtureIdentity(),
			createTransport: () => transport, readHarnessProviderDrafts: () => importDrafts,
		}));
		await connectPlainFixture(service);
		const preview = await service.previewHarnessProviderImport();
		assert.ok(!JSON.stringify(preview).includes('secret'));
		assert.deepStrictEqual(await service.importHarnessProviders({ providerIds: importDrafts.map(draft => draft.providerId) }), { imported: 2, updated: 0, skipped: 0, modelWrites: 3, errors: [] });
		assert.deepStrictEqual({ providers: transport.providerWriteIds, models: transport.modelWriteIds }, { providers: ['fixture-alpha', 'fixture-beta'], models: ['fixture-alpha:one', 'fixture-alpha:two', 'fixture-beta:three'] });
	});

	test('token + live channel => isEngineConnected === true', async () => {
		const transport = new MockUniverseAgentGrpcTransport();
		const service = new UniverseAgentConnectionService({
			connectionResolver: plainFixtureResolver(),
			clientIdentityStore: plainFixtureIdentity(),
			createTransport: () => transport,
		});

		await connectPlainFixture(service);

		assert.strictEqual(service.isEngineConnected(), true);
		assert.strictEqual(service.getTransportState(), 'ok');
		assert.strictEqual((service as unknown as { _sessionToken?: string })._sessionToken, 'token-1');
		assert.strictEqual(service.getConnectionSnapshot().authenticated, true);
		assert.strictEqual(Object.hasOwn(service.getConnectionSnapshot(), 'sessionToken'), false);
		service.dispose();
	});

	test('a stale AgentService.Tree result does not write the new transport\'s probe state', async () => {
		const treeNodeA = {
			agentId: 'a-root',
			name: 'Root A',
			type: 'AGENT_TYPE_ROOT',
			status: 'AGENT_STATUS_IDLE',
			model: '',
			turnCount: 0,
			createdAt: 0,
			children: [],
		};
		let releaseA!: () => void;
		const treeOnA = new Promise<typeof treeNodeA>(resolve => { releaseA = () => resolve(treeNodeA); });
		const transportA = new MockUniverseAgentGrpcTransport({
			connect: async () => ({
				sessionToken: 'token-a',
				methods: ['AgentService.Tree'],
				events: [],
			}),
			probeRpc: async () => GrpcStatusCode.OK,
			fetchAgentTree: async () => treeOnA,
		});
		const transportB = new MockUniverseAgentGrpcTransport({
			connect: async () => ({
				sessionToken: 'token-b',
				methods: ['AgentService.Tree'],
				events: [],
			}),
			probeRpc: async () => GrpcStatusCode.OK,
			fetchAgentTree: async () => undefined,
		});

		let transportIndex = 0;
		const transports = [transportA, transportB];
		const service = new UniverseAgentConnectionService({
			connectionResolver: {
				resolve: async (profileId: string) => ({
					ok: true as const,
					allowRelayFallback: false as const,
					endpoint: {
						attemptId: `endpoint-${profileId}`,
						authority: '127.0.0.1:9',
						port: 9,
						resolvedIp: '127.0.0.1',
						servername: '127.0.0.1',
						relayTicketId: null,
						tls: null,
						expiresAtMs: Date.now() + 60_000,
						path: 'direct' as const,
					},
				}),
				consumeRelayTicket: () => { },
			} as unknown as ConnectionResolver,
			clientIdentityStore: plainFixtureIdentity(),
			createTransport: () => transports[transportIndex++],
		});

		assert.strictEqual((await service.connectProfile('profile-a')).ok, true);
		const pendingA = service.fetchAgentTree('s1');
		// Let A's call reach the transport before switching links.
		await Promise.resolve();
		assert.strictEqual((await service.connectProfile('profile-b')).ok, true);
		const capabilityOnB = service.getCapabilitySnapshot().agentTree.support;

		releaseA();
		assert.strictEqual(await pendingA, undefined, 'a stale tree must not be returned to the caller');
		assert.strictEqual(service.isAgentTreeUnsupported(), false);
		assert.strictEqual(service.isAgentTreeFetchFailed(), false);
		assert.strictEqual(service.getCapabilitySnapshot().agentTree.support, capabilityOnB);

		service.dispose();
	});

	test('successful unary after DEADLINE_EXCEEDED restores connected phase', async () => {
		let failOnce = true;
		const transport = new MockUniverseAgentGrpcTransport({
			listSessions: async () => {
				if (failOnce) {
					failOnce = false;
					throw new UniverseAgentTransportError(GrpcStatusCode.DEADLINE_EXCEEDED, 'deadline');
				}
				return { sessions: [], totalCount: 0 };
			},
		});
		const service = new UniverseAgentConnectionService({
			connectionResolver: plainFixtureResolver(),
			clientIdentityStore: plainFixtureIdentity(),
			createTransport: () => transport,
		});
		await connectPlainFixture(service);
		(service as unknown as { _activeProfileId: string })._activeProfileId = 'p1';
		await assert.rejects(() => service.listSessions({}));
		assert.strictEqual(service.getConnectionPhase().kind, 'connecting');
		assert.strictEqual((service.getConnectionPhase() as { reason?: string }).reason, 'transport_lost');
		await service.listSessions({});
		assert.strictEqual(service.getConnectionPhase().kind, 'connected');
		service.dispose();
	});

	test('subscribeSessionEventStream forwards transport onClosed', async () => {
		const transport = new MockUniverseAgentGrpcTransport();
		const service = new UniverseAgentConnectionService({
			connectionResolver: plainFixtureResolver(),
			clientIdentityStore: plainFixtureIdentity(),
			createTransport: () => transport,
		});
		await connectPlainFixture(service);

		const seen: UniverseAgentSessionStreamCloseCause[] = [];
		service.subscribeSessionEventStream('sess-1', () => { }, cause => seen.push(cause));
		transport.fireSessionStreamClosed({ kind: 'remote' });
		transport.fireSessionStreamClosed({ kind: 'error', message: 'late' });
		assert.deepStrictEqual(seen, [{ kind: 'remote' }]);
		service.dispose();
	});

	test('subscribeSessionEventStream dispose silences later onClosed', async () => {
		const transport = new MockUniverseAgentGrpcTransport();
		const service = new UniverseAgentConnectionService({
			connectionResolver: plainFixtureResolver(),
			clientIdentityStore: plainFixtureIdentity(),
			createTransport: () => transport,
		});
		await connectPlainFixture(service);

		const seen: UniverseAgentSessionStreamCloseCause[] = [];
		const sub = service.subscribeSessionEventStream('sess-1', () => { }, cause => seen.push(cause));
		sub.dispose();
		transport.fireSessionStreamClosed({ kind: 'error', message: 'CANCELLED' });
		assert.deepStrictEqual(seen, []);
		service.dispose();
	});

	test('UniverseAgentGrpcServices lists Agent.ContinueGeneration', () => {
		assert.strictEqual(UniverseAgentGrpcServices.Agent.ContinueGeneration, 'ContinueGeneration');
		assert.strictEqual(UniverseAgentGrpcServices.Agent.service, 'agentservice.AgentService');
	});

	test('UniverseAgentGrpcServices lists Agent.Regenerate', () => {
		assert.strictEqual(UniverseAgentGrpcServices.Agent.Regenerate, 'Regenerate');
		assert.strictEqual(UniverseAgentGrpcServices.Agent.service, 'agentservice.AgentService');
	});

	test('UniverseAgentGrpcServices lists Agent.Rename', () => {
		assert.strictEqual(UniverseAgentGrpcServices.Agent.Rename, 'Rename');
		assert.strictEqual(UniverseAgentGrpcServices.Agent.service, 'agentservice.AgentService');
	});

	test('UniverseAgentGrpcServices lists Agent.Cancel', () => {
		assert.strictEqual(UniverseAgentGrpcServices.Agent.Cancel, 'Cancel');
		assert.strictEqual(UniverseAgentGrpcServices.Agent.service, 'agentservice.AgentService');
	});

	test('UniverseAgentGrpcServices lists Agent.CancelToolCall', () => {
		assert.strictEqual(UniverseAgentGrpcServices.Agent.CancelToolCall, 'CancelToolCall');
		assert.strictEqual(UniverseAgentGrpcServices.Agent.service, 'agentservice.AgentService');
	});

	test('UniverseAgentGrpcServices lists Agent.RunToolInBackground', () => {
		assert.strictEqual(UniverseAgentGrpcServices.Agent.RunToolInBackground, 'RunToolInBackground');
		assert.strictEqual(UniverseAgentGrpcServices.Agent.service, 'agentservice.AgentService');
	});

	test('UniverseAgentGrpcServices lists Agent.StopShellTask', () => {
		assert.strictEqual(UniverseAgentGrpcServices.Agent.StopShellTask, 'StopShellTask');
		assert.strictEqual(UniverseAgentGrpcServices.Agent.service, 'agentservice.AgentService');
	});

	test('UniverseAgentGrpcServices lists Agent.SendShellSessionClientControl', () => {
		assert.strictEqual(UniverseAgentGrpcServices.Agent.SendShellSessionClientControl, 'SendShellSessionClientControl');
		assert.strictEqual(UniverseAgentGrpcServices.Agent.service, 'agentservice.AgentService');
	});

	test('UniverseAgentGrpcServices lists Agent.FetchToolUsageDetail', () => {
		assert.strictEqual(UniverseAgentGrpcServices.Agent.FetchToolUsageDetail, 'FetchToolUsageDetail');
		assert.strictEqual(UniverseAgentGrpcServices.Agent.service, 'agentservice.AgentService');
	});

	test('UniverseAgentGrpcServices lists Agent.FireTriggerWebhook', () => {
		assert.strictEqual(UniverseAgentGrpcServices.Agent.FireTriggerWebhook, 'FireTriggerWebhook');
		assert.strictEqual(UniverseAgentGrpcServices.Agent.service, 'agentservice.AgentService');
	});

	test('UniverseAgentGrpcServices lists Agent.InstallSessionDemoFake', () => {
		assert.strictEqual(UniverseAgentGrpcServices.Agent.InstallSessionDemoFake, 'InstallSessionDemoFake');
		assert.strictEqual(UniverseAgentGrpcServices.Agent.service, 'agentservice.AgentService');
	});

	test('UniverseAgentGrpcServices lists Agent.ClearSessionDemoFake', () => {
		assert.strictEqual(UniverseAgentGrpcServices.Agent.ClearSessionDemoFake, 'ClearSessionDemoFake');
		assert.strictEqual(UniverseAgentGrpcServices.Agent.service, 'agentservice.AgentService');
	});

	test('UniverseAgentGrpcServices lists Agent.SwitchWorkDir', () => {
		assert.strictEqual(UniverseAgentGrpcServices.Agent.SwitchWorkDir, 'SwitchWorkDir');
	});

	test('UniverseAgentGrpcServices lists Agent.TestModelProfile', () => {
		assert.strictEqual(UniverseAgentGrpcServices.Agent.TestModelProfile, 'TestModelProfile');
		assert.strictEqual(UniverseAgentGrpcServices.Agent.service, 'agentservice.AgentService');
	});

	test('UniverseAgentGrpcServices lists Config.Set', () => {
		assert.strictEqual(UniverseAgentGrpcServices.Config.Set, 'Set');
		assert.strictEqual(UniverseAgentGrpcServices.Config.service, 'agentservice.ConfigService');
	});

	test('UniverseAgentGrpcServices lists Config.SetModelPreferences', () => {
		assert.strictEqual(UniverseAgentGrpcServices.Config.SetModelPreferences, 'SetModelPreferences');
		assert.strictEqual(UniverseAgentGrpcServices.Config.service, 'agentservice.ConfigService');
	});

	test('UniverseAgentGrpcServices lists Agent.SubscribeToolDetail', () => {
		assert.strictEqual(UniverseAgentGrpcServices.Agent.SubscribeToolDetail, 'SubscribeToolDetail');
		assert.strictEqual(UniverseAgentGrpcServices.Agent.service, 'agentservice.AgentService');
	});

	test('UniverseAgentGrpcServices lists Permission.SetSessionGoal', () => {
		assert.strictEqual(UniverseAgentGrpcServices.Permission.SetSessionGoal, 'SetSessionGoal');
		assert.strictEqual(UniverseAgentGrpcServices.Permission.CancelSessionGoal, 'CancelSessionGoal');
		assert.strictEqual(UniverseAgentGrpcServices.Permission.service, 'agentservice.PermissionService');
	});

	test('UniverseAgentGrpcServices lists Permission.Respond', () => {
		assert.strictEqual(UniverseAgentGrpcServices.Permission.Respond, 'Respond');
		assert.strictEqual(UniverseAgentGrpcServices.Permission.service, 'agentservice.PermissionService');
	});

	test('UniverseAgentGrpcServices lists Permission.SyncPermissionRule', () => {
		assert.strictEqual(UniverseAgentGrpcServices.Permission.SyncPermissionRule, 'SyncPermissionRule');
		assert.strictEqual(UniverseAgentGrpcServices.Permission.service, 'agentservice.PermissionService');
	});

	test('UniverseAgentGrpcServices lists Permission.PromotePermissionRule', () => {
		assert.strictEqual(UniverseAgentGrpcServices.Permission.PromotePermissionRule, 'PromotePermissionRule');
		assert.strictEqual(UniverseAgentGrpcServices.Permission.service, 'agentservice.PermissionService');
	});

	test('UniverseAgentGrpcServices lists Permission.GetSessionRules', () => {
		assert.strictEqual(UniverseAgentGrpcServices.Permission.GetSessionRules, 'GetSessionRules');
		assert.strictEqual(UniverseAgentGrpcServices.Permission.service, 'agentservice.PermissionService');
	});

	test('UniverseAgentGrpcServices lists Permission.SetPermissionMode', () => {
		assert.strictEqual(UniverseAgentGrpcServices.Permission.SetPermissionMode, 'SetPermissionMode');
		assert.strictEqual(UniverseAgentGrpcServices.Permission.service, 'agentservice.PermissionService');
	});

	test('UniverseAgentGrpcServices lists Team.TaskUpdate', () => {
		assert.strictEqual(UniverseAgentGrpcServices.Team.TaskUpdate, 'TaskUpdate');
		assert.strictEqual(UniverseAgentGrpcServices.Team.service, 'agentservice.TeamService');
	});

	test('UniverseAgentGrpcServices lists Team.TaskCancel', () => {
		assert.strictEqual(UniverseAgentGrpcServices.Team.TaskCancel, 'TaskCancel');
		assert.strictEqual(UniverseAgentGrpcServices.Team.service, 'agentservice.TeamService');
	});

	test('UniverseAgentGrpcServices lists Team.MessageMember', () => {
		assert.strictEqual(UniverseAgentGrpcServices.Team.MessageMember, 'MessageMember');
		assert.strictEqual(UniverseAgentGrpcServices.Team.service, 'agentservice.TeamService');
	});

	test('UniverseAgentGrpcServices lists Team.CreateTeam', () => {
		assert.strictEqual(UniverseAgentGrpcServices.Team.CreateTeam, 'CreateTeam');
		assert.strictEqual(UniverseAgentGrpcServices.Team.service, 'agentservice.TeamService');
	});

	test('UniverseAgentGrpcServices lists Team.StartMember', () => {
		assert.strictEqual(UniverseAgentGrpcServices.Team.StartMember, 'StartMember');
		assert.strictEqual(UniverseAgentGrpcServices.Team.service, 'agentservice.TeamService');
	});

	test('UniverseAgentGrpcServices lists Team.KillMember', () => {
		assert.strictEqual(UniverseAgentGrpcServices.Team.KillMember, 'KillMember');
		assert.strictEqual(UniverseAgentGrpcServices.Team.service, 'agentservice.TeamService');
	});

	test('UniverseAgentGrpcServices lists Team.Abort', () => {
		assert.strictEqual(UniverseAgentGrpcServices.Team.Abort, 'Abort');
		assert.strictEqual(UniverseAgentGrpcServices.Team.service, 'agentservice.TeamService');
	});

	test('UniverseAgentGrpcServices lists Config.Get', () => {
		assert.strictEqual(UniverseAgentGrpcServices.Config.Get, 'Get');
		assert.strictEqual(UniverseAgentGrpcServices.Config.service, 'agentservice.ConfigService');
	});

	test('UniverseAgentGrpcServices lists Config.SwitchModel', () => {
		assert.strictEqual(UniverseAgentGrpcServices.Config.SwitchModel, 'SwitchModel');
		assert.strictEqual(UniverseAgentGrpcServices.Config.service, 'agentservice.ConfigService');
	});

	test('UniverseAgentGrpcServices lists Config.ResolveModel', () => {
		assert.strictEqual(UniverseAgentGrpcServices.Config.ResolveModel, 'ResolveModel');
		assert.strictEqual(UniverseAgentGrpcServices.Config.service, 'agentservice.ConfigService');
	});

	test('UniverseAgentGrpcServices lists Config.Watch', () => {
		assert.strictEqual(UniverseAgentGrpcServices.Config.Watch, 'Watch');
		assert.strictEqual(UniverseAgentGrpcServices.Config.service, 'agentservice.ConfigService');
	});

	test('UniverseAgentGrpcServices lists Config.SetPermissionPolicy', () => {
		assert.strictEqual(UniverseAgentGrpcServices.Config.SetPermissionPolicy, 'SetPermissionPolicy');
		assert.strictEqual(UniverseAgentGrpcServices.Config.service, 'agentservice.ConfigService');
	});

	test('UniverseAgentGrpcServices lists Config.GetModelPreferences', () => {
		assert.strictEqual(UniverseAgentGrpcServices.Config.GetModelPreferences, 'GetModelPreferences');
		assert.strictEqual(UniverseAgentGrpcServices.Config.service, 'agentservice.ConfigService');
	});

	test('UniverseAgentGrpcServices lists Agent.InsertQueueItem', () => {
		assert.strictEqual(UniverseAgentGrpcServices.Agent.InsertQueueItem, 'InsertQueueItem');
		assert.strictEqual(UniverseAgentGrpcServices.Agent.service, 'agentservice.AgentService');
	});

	test('UniverseAgentGrpcServices lists Agent.ReorderQueue', () => {
		assert.strictEqual(UniverseAgentGrpcServices.Agent.ReorderQueue, 'ReorderQueue');
		assert.strictEqual(UniverseAgentGrpcServices.Agent.service, 'agentservice.AgentService');
	});

	test('UniverseAgentGrpcServices lists Agent.DeleteQueueItem', () => {
		assert.strictEqual(UniverseAgentGrpcServices.Agent.DeleteQueueItem, 'DeleteQueueItem');
		assert.strictEqual(UniverseAgentGrpcServices.Agent.service, 'agentservice.AgentService');
	});

	test('UniverseAgentGrpcServices lists Agent.RetryQueueItem', () => {
		assert.strictEqual(UniverseAgentGrpcServices.Agent.RetryQueueItem, 'RetryQueueItem');
		assert.strictEqual(UniverseAgentGrpcServices.Agent.service, 'agentservice.AgentService');
	});

	test('UniverseAgentGrpcServices lists Agent.RetryAllFailed', () => {
		assert.strictEqual(UniverseAgentGrpcServices.Agent.RetryAllFailed, 'RetryAllFailed');
		assert.strictEqual(UniverseAgentGrpcServices.Agent.service, 'agentservice.AgentService');
	});

	test('UniverseAgentGrpcServices lists Agent.RetryQueueItemUpload', () => {
		assert.strictEqual(UniverseAgentGrpcServices.Agent.RetryQueueItemUpload, 'RetryQueueItemUpload');
		assert.strictEqual(UniverseAgentGrpcServices.Agent.service, 'agentservice.AgentService');
	});

	test('UniverseAgentGrpcServices lists Agent.PinQueueItem', () => {
		assert.strictEqual(UniverseAgentGrpcServices.Agent.PinQueueItem, 'PinQueueItem');
		assert.strictEqual(UniverseAgentGrpcServices.Agent.service, 'agentservice.AgentService');
	});

	test('UniverseAgentGrpcServices lists Agent.SetQueueItemLocked', () => {
		assert.strictEqual(UniverseAgentGrpcServices.Agent.SetQueueItemLocked, 'SetQueueItemLocked');
		assert.strictEqual(UniverseAgentGrpcServices.Agent.service, 'agentservice.AgentService');
	});

	test('UniverseAgentGrpcServices lists Agent.InjectQueueItem', () => {
		assert.strictEqual(UniverseAgentGrpcServices.Agent.InjectQueueItem, 'InjectQueueItem');
		assert.strictEqual(UniverseAgentGrpcServices.Agent.service, 'agentservice.AgentService');
	});

	test('UniverseAgentGrpcServices lists Agent.SetQueueItemForkAnchor', () => {
		assert.strictEqual(UniverseAgentGrpcServices.Agent.SetQueueItemForkAnchor, 'SetQueueItemForkAnchor');
		assert.strictEqual(UniverseAgentGrpcServices.Agent.service, 'agentservice.AgentService');
	});

	test('UniverseAgentGrpcServices lists Agent.ChatSync', () => {
		assert.strictEqual(UniverseAgentGrpcServices.Agent.ChatSync, 'ChatSync');
		assert.strictEqual(UniverseAgentGrpcServices.Agent.service, 'agentservice.AgentService');
	});

	test('UniverseAgentGrpcServices lists Agent.SyncInputDelivery', () => {
		assert.strictEqual(UniverseAgentGrpcServices.Agent.SyncInputDelivery, 'SyncInputDelivery');
		assert.strictEqual(UniverseAgentGrpcServices.Agent.service, 'agentservice.AgentService');
	});

	test('UniverseAgentGrpcServices lists Agent queue mutation family', () => {
		assert.strictEqual(UniverseAgentGrpcServices.Agent.EnqueueQueueItem, 'EnqueueQueueItem');
		assert.strictEqual(UniverseAgentGrpcServices.Agent.PauseQueue, 'PauseQueue');
		assert.strictEqual(UniverseAgentGrpcServices.Agent.ResumeQueue, 'ResumeQueue');
		assert.strictEqual(UniverseAgentGrpcServices.Agent.ClearQueue, 'ClearQueue');
		assert.strictEqual(UniverseAgentGrpcServices.Agent.HoldQueueItem, 'HoldQueueItem');
		assert.strictEqual(UniverseAgentGrpcServices.Agent.ReleaseQueueItemHold, 'ReleaseQueueItemHold');
		assert.strictEqual(UniverseAgentGrpcServices.Agent.EditQueueItem, 'EditQueueItem');
		assert.strictEqual(UniverseAgentGrpcServices.Agent.service, 'agentservice.AgentService');
	});

	test('UniverseAgentGrpcServices lists Agent.Fork', () => {
		assert.strictEqual(UniverseAgentGrpcServices.Agent.Fork, 'Fork');
		assert.strictEqual(UniverseAgentGrpcServices.Agent.service, 'agentservice.AgentService');
	});

	test('UniverseAgentGrpcServices lists Tool.ToolInfo', () => {
		assert.strictEqual(UniverseAgentGrpcServices.Tool.ToolInfo, 'ToolInfo');
		assert.strictEqual(UniverseAgentGrpcServices.Tool.service, 'agentservice.ToolService');
	});

	test('UniverseAgentGrpcServices lists Tool.ListCommands', () => {
		assert.strictEqual(UniverseAgentGrpcServices.Tool.ListCommands, 'ListCommands');
		assert.strictEqual(UniverseAgentGrpcServices.Tool.service, 'agentservice.ToolService');
	});

	test('UniverseAgentGrpcServices lists Tool.GetCommandDef', () => {
		assert.strictEqual(UniverseAgentGrpcServices.Tool.GetCommandDef, 'GetCommandDef');
		assert.strictEqual(UniverseAgentGrpcServices.Tool.service, 'agentservice.ToolService');
	});

	test('UniverseAgentGrpcServices lists File.ListFiles', () => {
		assert.strictEqual(UniverseAgentGrpcServices.File.ListFiles, 'ListFiles');
		assert.strictEqual(UniverseAgentGrpcServices.File.service, 'agentservice.FileService');
	});

	test('UniverseAgentGrpcServices lists File.ReadFile', () => {
		assert.strictEqual(UniverseAgentGrpcServices.File.ReadFile, 'ReadFile');
		assert.strictEqual(UniverseAgentGrpcServices.File.service, 'agentservice.FileService');
	});

	test('UniverseAgentGrpcServices lists File.GetFileInfo', () => {
		assert.strictEqual(UniverseAgentGrpcServices.File.GetFileInfo, 'GetFileInfo');
		assert.strictEqual(UniverseAgentGrpcServices.File.service, 'agentservice.FileService');
	});

	test('UniverseAgentGrpcServices lists File.WriteFile', () => {
		assert.strictEqual(UniverseAgentGrpcServices.File.WriteFile, 'WriteFile');
		assert.strictEqual(UniverseAgentGrpcServices.File.service, 'agentservice.FileService');
	});

	test('UniverseAgentGrpcServices lists File.ForceWriteFile', () => {
		assert.strictEqual(UniverseAgentGrpcServices.File.ForceWriteFile, 'ForceWriteFile');
		assert.strictEqual(UniverseAgentGrpcServices.File.service, 'agentservice.FileService');
	});

	test('UniverseAgentGrpcServices lists File.AgentMerge', () => {
		assert.strictEqual(UniverseAgentGrpcServices.File.AgentMerge, 'AgentMerge');
		assert.strictEqual(UniverseAgentGrpcServices.File.service, 'agentservice.FileService');
	});

	test('UniverseAgentGrpcServices lists Git.ReadGitSummary', () => {
		assert.strictEqual(UniverseAgentGrpcServices.Git.ReadGitSummary, 'ReadGitSummary');
		assert.strictEqual(UniverseAgentGrpcServices.Git.service, 'agentservice.GitService');
	});

	test('UniverseAgentGrpcServices lists Git.ReadGitChanges', () => {
		assert.strictEqual(UniverseAgentGrpcServices.Git.ReadGitChanges, 'ReadGitChanges');
		assert.strictEqual(UniverseAgentGrpcServices.Git.service, 'agentservice.GitService');
	});

	test('UniverseAgentGrpcServices lists Git.ReadGitFileDiff', () => {
		assert.strictEqual(UniverseAgentGrpcServices.Git.ReadGitFileDiff, 'ReadGitFileDiff');
		assert.strictEqual(UniverseAgentGrpcServices.Git.service, 'agentservice.GitService');
	});

	test('UniverseAgentGrpcServices lists Git.WriteGitStagePaths', () => {
		assert.strictEqual(UniverseAgentGrpcServices.Git.WriteGitStagePaths, 'WriteGitStagePaths');
		assert.strictEqual(UniverseAgentGrpcServices.Git.service, 'agentservice.GitService');
	});

	test('UniverseAgentGrpcServices lists Git.WriteGitCommit', () => {
		assert.strictEqual(UniverseAgentGrpcServices.Git.WriteGitCommit, 'WriteGitCommit');
		assert.strictEqual(UniverseAgentGrpcServices.Git.service, 'agentservice.GitService');
	});

	test('UniverseAgentGrpcServices lists Git.WriteGitApplyHunks', () => {
		assert.strictEqual(UniverseAgentGrpcServices.Git.WriteGitApplyHunks, 'WriteGitApplyHunks');
		assert.strictEqual(UniverseAgentGrpcServices.Git.service, 'agentservice.GitService');
	});

	test('UniverseAgentGrpcServices lists TokenUsage.GetSessionUsage', () => {
		assert.strictEqual(UniverseAgentGrpcServices.TokenUsage.GetSessionUsage, 'GetSessionUsage');
		assert.strictEqual(UniverseAgentGrpcServices.TokenUsage.service, 'agentservice.TokenUsageService');
	});

	test('UniverseAgentGrpcServices lists TokenUsage.GetGlobalUsage', () => {
		assert.strictEqual(UniverseAgentGrpcServices.TokenUsage.GetGlobalUsage, 'GetGlobalUsage');
		assert.strictEqual(UniverseAgentGrpcServices.TokenUsage.service, 'agentservice.TokenUsageService');
	});

	test('UniverseAgentGrpcServices lists Memory.Save', () => {
		assert.strictEqual(UniverseAgentGrpcServices.Memory.Save, 'Save');
		assert.strictEqual(UniverseAgentGrpcServices.Memory.service, 'agentservice.MemoryService');
	});

	test('UniverseAgentGrpcServices lists Memory.Search', () => {
		assert.strictEqual(UniverseAgentGrpcServices.Memory.Search, 'Search');
		assert.strictEqual(UniverseAgentGrpcServices.Memory.service, 'agentservice.MemoryService');
	});

	test('UniverseAgentGrpcServices lists Memory.SearchDeep', () => {
		assert.strictEqual(UniverseAgentGrpcServices.Memory.SearchDeep, 'SearchDeep');
		assert.strictEqual(UniverseAgentGrpcServices.Memory.service, 'agentservice.MemoryService');
	});

	test('UniverseAgentGrpcServices lists Memory.Read', () => {
		assert.strictEqual(UniverseAgentGrpcServices.Memory.Read, 'Read');
		assert.strictEqual(UniverseAgentGrpcServices.Memory.service, 'agentservice.MemoryService');
	});

	test('UniverseAgentGrpcServices lists Memory.List', () => {
		assert.strictEqual(UniverseAgentGrpcServices.Memory.List, 'List');
		assert.strictEqual(UniverseAgentGrpcServices.Memory.service, 'agentservice.MemoryService');
	});

	test('UniverseAgentGrpcServices lists Memory.Delete', () => {
		assert.strictEqual(UniverseAgentGrpcServices.Memory.Delete, 'Delete');
		assert.strictEqual(UniverseAgentGrpcServices.Memory.service, 'agentservice.MemoryService');
	});

	test('UniverseAgentGrpcServices lists Memory.Reflect', () => {
		assert.strictEqual(UniverseAgentGrpcServices.Memory.Reflect, 'Reflect');
		assert.strictEqual(UniverseAgentGrpcServices.Memory.service, 'agentservice.MemoryService');
	});

	test('UniverseAgentGrpcServices lists Memory.Rebuild', () => {
		assert.strictEqual(UniverseAgentGrpcServices.Memory.Rebuild, 'Rebuild');
		assert.strictEqual(UniverseAgentGrpcServices.Memory.service, 'agentservice.MemoryService');
	});

	test('UniverseAgentGrpcServices lists Memory.Revert', () => {
		assert.strictEqual(UniverseAgentGrpcServices.Memory.Revert, 'Revert');
		assert.strictEqual(UniverseAgentGrpcServices.Memory.service, 'agentservice.MemoryService');
	});

	test('UniverseAgentGrpcServices lists Memory.History', () => {
		assert.strictEqual(UniverseAgentGrpcServices.Memory.History, 'History');
		assert.strictEqual(UniverseAgentGrpcServices.Memory.service, 'agentservice.MemoryService');
	});

	test('UniverseAgentGrpcServices lists ContextVariable.List', () => {
		assert.strictEqual(UniverseAgentGrpcServices.ContextVariable.List, 'List');
		assert.strictEqual(UniverseAgentGrpcServices.ContextVariable.service, 'agentservice.ContextVariableService');
	});

	test('UniverseAgentGrpcServices lists ContextVariable.Read', () => {
		assert.strictEqual(UniverseAgentGrpcServices.ContextVariable.Read, 'Read');
		assert.strictEqual(UniverseAgentGrpcServices.ContextVariable.service, 'agentservice.ContextVariableService');
	});

	test('UniverseAgentGrpcServices lists RemoteAgent.ListNodes', () => {
		assert.strictEqual(UniverseAgentGrpcServices.RemoteAgent.ListNodes, 'ListNodes');
		assert.strictEqual(UniverseAgentGrpcServices.RemoteAgent.service, 'agentservice.RemoteAgentService');
	});

	test('UniverseAgentGrpcServices lists RemoteAgent.GetNode', () => {
		assert.strictEqual(UniverseAgentGrpcServices.RemoteAgent.GetNode, 'GetNode');
		assert.strictEqual(UniverseAgentGrpcServices.RemoteAgent.service, 'agentservice.RemoteAgentService');
	});

	test('UniverseAgentGrpcServices lists RemoteAgent.CheckConnection', () => {
		assert.strictEqual(UniverseAgentGrpcServices.RemoteAgent.CheckConnection, 'CheckConnection');
		assert.strictEqual(UniverseAgentGrpcServices.RemoteAgent.service, 'agentservice.RemoteAgentService');
	});

	test('UniverseAgentGrpcServices lists RemoteAgent.SetMaintenance', () => {
		assert.strictEqual(UniverseAgentGrpcServices.RemoteAgent.SetMaintenance, 'SetMaintenance');
		assert.strictEqual(UniverseAgentGrpcServices.RemoteAgent.service, 'agentservice.RemoteAgentService');
	});

	test('UniverseAgentGrpcServices lists RemoteAgent.ExitMaintenance', () => {
		assert.strictEqual(UniverseAgentGrpcServices.RemoteAgent.ExitMaintenance, 'ExitMaintenance');
		assert.strictEqual(UniverseAgentGrpcServices.RemoteAgent.service, 'agentservice.RemoteAgentService');
	});

	test('UniverseAgentGrpcServices lists RemoteAgent.ListConfigs', () => {
		assert.strictEqual(UniverseAgentGrpcServices.RemoteAgent.ListConfigs, 'ListConfigs');
		assert.strictEqual(UniverseAgentGrpcServices.RemoteAgent.service, 'agentservice.RemoteAgentService');
	});

	test('UniverseAgentGrpcServices lists RemoteAgent.GetConfig', () => {
		assert.strictEqual(UniverseAgentGrpcServices.RemoteAgent.GetConfig, 'GetConfig');
		assert.strictEqual(UniverseAgentGrpcServices.RemoteAgent.service, 'agentservice.RemoteAgentService');
	});

	test('UniverseAgentGrpcServices lists RemoteAgent.SaveConfig', () => {
		assert.strictEqual(UniverseAgentGrpcServices.RemoteAgent.SaveConfig, 'SaveConfig');
		assert.strictEqual(UniverseAgentGrpcServices.RemoteAgent.service, 'agentservice.RemoteAgentService');
	});

	test('UniverseAgentGrpcServices lists RemoteAgent.ResetError', () => {
		assert.strictEqual(UniverseAgentGrpcServices.RemoteAgent.ResetError, 'ResetError');
		assert.strictEqual(UniverseAgentGrpcServices.RemoteAgent.service, 'agentservice.RemoteAgentService');
	});
	test('UniverseAgentGrpcServices lists RemoteAgent.DeleteConfig', () => {
		assert.strictEqual(UniverseAgentGrpcServices.RemoteAgent.DeleteConfig, 'DeleteConfig');
		assert.strictEqual(UniverseAgentGrpcServices.RemoteAgent.service, 'agentservice.RemoteAgentService');
	});

	test('UniverseAgentGrpcServices lists RemoteAgent.Reload', () => {
		assert.strictEqual(UniverseAgentGrpcServices.RemoteAgent.Reload, 'Reload');
		assert.strictEqual(UniverseAgentGrpcServices.RemoteAgent.service, 'agentservice.RemoteAgentService');
	});

	test('UniverseAgentGrpcServices lists RemoteAgent.RemoteChat', () => {
		assert.strictEqual(UniverseAgentGrpcServices.RemoteAgent.RemoteChat, 'RemoteChat');
		assert.strictEqual(UniverseAgentGrpcServices.RemoteAgent.service, 'agentservice.RemoteAgentService');
	});

	test('UniverseAgentGrpcServices lists RemoteAgent.CreateRemoteSession', () => {
		assert.strictEqual(UniverseAgentGrpcServices.RemoteAgent.CreateRemoteSession, 'CreateRemoteSession');
		assert.strictEqual(UniverseAgentGrpcServices.RemoteAgent.service, 'agentservice.RemoteAgentService');
	});

	test('UniverseAgentGrpcServices lists RemoteAgent.DestroyRemoteSession', () => {
		assert.strictEqual(UniverseAgentGrpcServices.RemoteAgent.DestroyRemoteSession, 'DestroyRemoteSession');
		assert.strictEqual(UniverseAgentGrpcServices.RemoteAgent.service, 'agentservice.RemoteAgentService');
	});
	test('UniverseAgentGrpcServices lists RemoteAgent.GetRemoteSessionStatus', () => {
		assert.strictEqual(UniverseAgentGrpcServices.RemoteAgent.GetRemoteSessionStatus, 'GetRemoteSessionStatus');
		assert.strictEqual(UniverseAgentGrpcServices.RemoteAgent.service, 'agentservice.RemoteAgentService');
	});

	test('UniverseAgentGrpcServices lists RemoteAgent.GetRemoteSessionHistory', () => {
		assert.strictEqual(UniverseAgentGrpcServices.RemoteAgent.GetRemoteSessionHistory, 'GetRemoteSessionHistory');
		assert.strictEqual(UniverseAgentGrpcServices.RemoteAgent.service, 'agentservice.RemoteAgentService');
	});

	test('UniverseAgentGrpcServices lists RemoteAgent.ResumeRemoteSession', () => {
		assert.strictEqual(UniverseAgentGrpcServices.RemoteAgent.ResumeRemoteSession, 'ResumeRemoteSession');
		assert.strictEqual(UniverseAgentGrpcServices.RemoteAgent.service, 'agentservice.RemoteAgentService');
	});
	test('UniverseAgentGrpcServices lists RemoteAgent.CancelRemoteSession', () => {
		assert.strictEqual(UniverseAgentGrpcServices.RemoteAgent.CancelRemoteSession, 'CancelRemoteSession');
		assert.strictEqual(UniverseAgentGrpcServices.RemoteAgent.service, 'agentservice.RemoteAgentService');
	});
	test('UniverseAgentGrpcServices lists FileTransfer.GetUploadProgress', () => {
		assert.strictEqual(UniverseAgentGrpcServices.FileTransfer.GetUploadProgress, 'GetUploadProgress');
		assert.strictEqual(UniverseAgentGrpcServices.FileTransfer.service, 'agentservice.FileTransferService');
	});

	test('UniverseAgentGrpcServices lists FileTransfer.UploadAttachment', () => {
		assert.strictEqual(UniverseAgentGrpcServices.FileTransfer.UploadAttachment, 'UploadAttachment');
		assert.strictEqual(UniverseAgentGrpcServices.FileTransfer.service, 'agentservice.FileTransferService');
	});

	test('UniverseAgentGrpcServices lists FileTransfer.DownloadAttachment', () => {
		assert.strictEqual(UniverseAgentGrpcServices.FileTransfer.DownloadAttachment, 'DownloadAttachment');
		assert.strictEqual(UniverseAgentGrpcServices.FileTransfer.service, 'agentservice.FileTransferService');
	});

	test('UniverseAgentGrpcServices lists Pty.PtyStream', () => {
		assert.strictEqual(UniverseAgentGrpcServices.Pty.PtyStream, 'PtyStream');
		assert.strictEqual(UniverseAgentGrpcServices.Pty.service, 'agentservice.PtyService');
	});

	test('UniverseAgentGrpcServices lists System.HealthCheck', () => {
		assert.strictEqual(UniverseAgentGrpcServices.System.HealthCheck, 'HealthCheck');
		assert.strictEqual(UniverseAgentGrpcServices.System.service, 'agentservice.SystemService');
	});

	test('UniverseAgentGrpcServices lists System.Doctor', () => {
		assert.strictEqual(UniverseAgentGrpcServices.System.Doctor, 'Doctor');
		assert.strictEqual(UniverseAgentGrpcServices.System.service, 'agentservice.SystemService');
	});

	test('UniverseAgentGrpcServices lists System.Shutdown', () => {
		assert.strictEqual(UniverseAgentGrpcServices.System.Shutdown, 'Shutdown');
		assert.strictEqual(UniverseAgentGrpcServices.System.service, 'agentservice.SystemService');
	});

	test('UniverseAgentGrpcServices lists Device.ListDevices', () => {
		assert.strictEqual(UniverseAgentGrpcServices.Device.ListDevices, 'ListDevices');
		assert.strictEqual(UniverseAgentGrpcServices.Device.service, 'agentservice.DeviceService');
	});

	test('UniverseAgentGrpcServices lists Device.PairApprove', () => {
		assert.strictEqual(UniverseAgentGrpcServices.Device.PairApprove, 'PairApprove');
		assert.strictEqual(UniverseAgentGrpcServices.Device.service, 'agentservice.DeviceService');
	});

	test('UniverseAgentGrpcServices lists Device.PairReject', () => {
		assert.strictEqual(UniverseAgentGrpcServices.Device.PairReject, 'PairReject');
		assert.strictEqual(UniverseAgentGrpcServices.Device.service, 'agentservice.DeviceService');
	});

	test('UniverseAgentGrpcServices lists Device.Revoke', () => {
		assert.strictEqual(UniverseAgentGrpcServices.Device.Revoke, 'Revoke');
		assert.strictEqual(UniverseAgentGrpcServices.Device.service, 'agentservice.DeviceService');
	});

	test('UniverseAgentGrpcServices lists Device.RotateToken', () => {
		assert.strictEqual(UniverseAgentGrpcServices.Device.RotateToken, 'RotateToken');
		assert.strictEqual(UniverseAgentGrpcServices.Device.service, 'agentservice.DeviceService');
	});

	test('UniverseAgentGrpcServices lists Device.ListPending', () => {
		assert.strictEqual(UniverseAgentGrpcServices.Device.ListPending, 'ListPending');
		assert.strictEqual(UniverseAgentGrpcServices.Device.service, 'agentservice.DeviceService');
	});

	test('UniverseAgentGrpcServices lists Trigger.ListTriggers', () => {
		assert.strictEqual(UniverseAgentGrpcServices.Trigger.ListTriggers, 'ListTriggers');
		assert.strictEqual(UniverseAgentGrpcServices.Trigger.service, 'agentservice.TriggerService');
	});

	test('UniverseAgentGrpcServices lists Trigger.UpsertTrigger', () => {
		assert.strictEqual(UniverseAgentGrpcServices.Trigger.UpsertTrigger, 'UpsertTrigger');
		assert.strictEqual(UniverseAgentGrpcServices.Trigger.service, 'agentservice.TriggerService');
	});

	test('UniverseAgentGrpcServices lists Trigger.DeleteTrigger', () => {
		assert.strictEqual(UniverseAgentGrpcServices.Trigger.DeleteTrigger, 'DeleteTrigger');
		assert.strictEqual(UniverseAgentGrpcServices.Trigger.service, 'agentservice.TriggerService');
	});

	test('UniverseAgentGrpcServices lists Trigger.SetTriggerEnabled', () => {
		assert.strictEqual(UniverseAgentGrpcServices.Trigger.SetTriggerEnabled, 'SetTriggerEnabled');
		assert.strictEqual(UniverseAgentGrpcServices.Trigger.service, 'agentservice.TriggerService');
	});

	test('UniverseAgentGrpcServices lists Trigger.FireTrigger', () => {
		assert.strictEqual(UniverseAgentGrpcServices.Trigger.FireTrigger, 'FireTrigger');
		assert.strictEqual(UniverseAgentGrpcServices.Trigger.service, 'agentservice.TriggerService');
	});

	test('UniverseAgentGrpcServices lists Clipboard.Write', () => {
		assert.strictEqual(UniverseAgentGrpcServices.Clipboard.Write, 'Write');
		assert.strictEqual(UniverseAgentGrpcServices.Clipboard.service, 'agentservice.ClipboardService');
	});

	test('UniverseAgentGrpcServices lists Clipboard.Read', () => {
		assert.strictEqual(UniverseAgentGrpcServices.Clipboard.Read, 'Read');
		assert.strictEqual(UniverseAgentGrpcServices.Clipboard.service, 'agentservice.ClipboardService');
	});

	test('UniverseAgentGrpcServices lists Clipboard.List', () => {
		assert.strictEqual(UniverseAgentGrpcServices.Clipboard.List, 'List');
		assert.strictEqual(UniverseAgentGrpcServices.Clipboard.service, 'agentservice.ClipboardService');
	});

	test('UniverseAgentGrpcServices lists Clipboard.Clear', () => {
		assert.strictEqual(UniverseAgentGrpcServices.Clipboard.Clear, 'Clear');
		assert.strictEqual(UniverseAgentGrpcServices.Clipboard.service, 'agentservice.ClipboardService');
	});

	test('UniverseAgentGrpcServices lists Agent.Kill', () => {
		assert.strictEqual(UniverseAgentGrpcServices.Agent.Kill, 'Kill');
		assert.strictEqual(UniverseAgentGrpcServices.Agent.service, 'agentservice.AgentService');
	});

	test('UniverseAgentGrpcServices lists Agent.DeleteMessage', () => {
		assert.strictEqual(UniverseAgentGrpcServices.Agent.DeleteMessage, 'DeleteMessage');
	});

	test('UniverseAgentGrpcServices lists Agent.EditMessage', () => {
		assert.strictEqual(UniverseAgentGrpcServices.Agent.EditMessage, 'EditMessage');
	});

	test('UniverseAgentGrpcServices lists Agent.RespondQuestion', () => {
		assert.strictEqual(UniverseAgentGrpcServices.Agent.RespondQuestion, 'RespondQuestion');
		assert.strictEqual(UniverseAgentGrpcServices.Agent.service, 'agentservice.AgentService');
	});

	test('UniverseAgentGrpcServices lists Agent.SendClientToolResponse', () => {
		assert.strictEqual(UniverseAgentGrpcServices.Agent.SendClientToolResponse, 'SendClientToolResponse');
		assert.strictEqual(UniverseAgentGrpcServices.Agent.service, 'agentservice.AgentService');
	});

	test('UniverseAgentGrpcServices lists Agent.ListSnapshots', () => {
		assert.strictEqual(UniverseAgentGrpcServices.Agent.ListSnapshots, 'ListSnapshots');
		assert.strictEqual(UniverseAgentGrpcServices.Agent.service, 'agentservice.AgentService');
	});

	test('UniverseAgentGrpcServices lists Agent.ListLoopSnapshots', () => {
		assert.strictEqual(UniverseAgentGrpcServices.Agent.ListLoopSnapshots, 'ListLoopSnapshots');
		assert.strictEqual(UniverseAgentGrpcServices.Agent.service, 'agentservice.AgentService');
	});

	test('UniverseAgentGrpcServices lists Agent.CreateSnapshot', () => {
		assert.strictEqual(UniverseAgentGrpcServices.Agent.CreateSnapshot, 'CreateSnapshot');
		assert.strictEqual(UniverseAgentGrpcServices.Agent.service, 'agentservice.AgentService');
	});

	test('UniverseAgentGrpcServices lists Agent.RestoreSnapshot', () => {
		assert.strictEqual(UniverseAgentGrpcServices.Agent.RestoreSnapshot, 'RestoreSnapshot');
		assert.strictEqual(UniverseAgentGrpcServices.Agent.service, 'agentservice.AgentService');
	});

	test('UniverseAgentGrpcServices lists Agent.DeleteSnapshot', () => {
		assert.strictEqual(UniverseAgentGrpcServices.Agent.DeleteSnapshot, 'DeleteSnapshot');
		assert.strictEqual(UniverseAgentGrpcServices.Agent.service, 'agentservice.AgentService');
	});

	test('UniverseAgentGrpcServices lists Session.Info', () => {
		assert.strictEqual(UniverseAgentGrpcServices.Session.Info, 'Info');
		assert.strictEqual(UniverseAgentGrpcServices.Session.service, 'agentservice.SessionService');
	});

	test('UniverseAgentGrpcServices lists Session.Resume', () => {
		assert.strictEqual(UniverseAgentGrpcServices.Session.Resume, 'Resume');
		assert.strictEqual(UniverseAgentGrpcServices.Session.service, 'agentservice.SessionService');
	});

	test('UniverseAgentGrpcServices lists Session.Prewarm', () => {
		assert.strictEqual(UniverseAgentGrpcServices.Session.Prewarm, 'Prewarm');
		assert.strictEqual(UniverseAgentGrpcServices.Session.service, 'agentservice.SessionService');
	});

	test('UniverseAgentGrpcServices lists Session.Shelve', () => {
		assert.strictEqual(UniverseAgentGrpcServices.Session.Shelve, 'Shelve');
		assert.strictEqual(UniverseAgentGrpcServices.Session.service, 'agentservice.SessionService');
	});

	test('UniverseAgentGrpcServices lists Session.Unshelve', () => {
		assert.strictEqual(UniverseAgentGrpcServices.Session.Unshelve, 'Unshelve');
		assert.strictEqual(UniverseAgentGrpcServices.Session.service, 'agentservice.SessionService');
	});

	test('UniverseAgentGrpcServices lists Session.Export', () => {
		assert.strictEqual(UniverseAgentGrpcServices.Session.Export, 'Export');
		assert.strictEqual(UniverseAgentGrpcServices.Session.service, 'agentservice.SessionService');
	});

	test('UniverseAgentGrpcServices lists Session.ResolveTurn', () => {
		assert.strictEqual(UniverseAgentGrpcServices.Session.ResolveTurn, 'ResolveTurn');
		assert.strictEqual(UniverseAgentGrpcServices.Session.service, 'agentservice.SessionService');
	});

	test('UniverseAgentGrpcServices lists Agent.Status', () => {
		assert.strictEqual(UniverseAgentGrpcServices.Agent.Status, 'Status');
		assert.strictEqual(UniverseAgentGrpcServices.Agent.service, 'agentservice.AgentService');
	});

	test('UniverseAgentGrpcServices lists Session.Purge', () => {
		assert.strictEqual(UniverseAgentGrpcServices.Session.Purge, 'Purge');
		assert.strictEqual(UniverseAgentGrpcServices.Session.service, 'agentservice.SessionService');
	});

	test('UniverseAgentGrpcServices lists Agent.Todo', () => {
		assert.strictEqual(UniverseAgentGrpcServices.Agent.Todo, 'Todo');
		assert.strictEqual(UniverseAgentGrpcServices.Agent.service, 'agentservice.AgentService');
	});

	test('UniverseAgentGrpcServices lists Agent.Compact', () => {
		assert.strictEqual(UniverseAgentGrpcServices.Agent.Compact, 'Compact');
		assert.strictEqual(UniverseAgentGrpcServices.Agent.service, 'agentservice.AgentService');
	});

	test('UniverseAgentGrpcServices lists Session.ResolveAnchor', () => {
		assert.strictEqual(UniverseAgentGrpcServices.Session.ResolveAnchor, 'ResolveAnchor');
		assert.strictEqual(UniverseAgentGrpcServices.Session.service, 'agentservice.SessionService');
	});

	test('UniverseAgentGrpcServices lists Agent.Usage', () => {
		assert.strictEqual(UniverseAgentGrpcServices.Agent.Usage, 'Usage');
		assert.strictEqual(UniverseAgentGrpcServices.Agent.service, 'agentservice.AgentService');
	});

	test('UniverseAgentGrpcServices lists Agent.List', () => {
		assert.strictEqual(UniverseAgentGrpcServices.Agent.List, 'List');
		assert.strictEqual(UniverseAgentGrpcServices.Agent.service, 'agentservice.AgentService');
	});

	test('UniverseAgentGrpcServices lists Agent.History', () => {
		assert.strictEqual(UniverseAgentGrpcServices.Agent.History, 'History');
		assert.strictEqual(UniverseAgentGrpcServices.Agent.service, 'agentservice.AgentService');
	});

	test('UniverseAgentGrpcServices lists Agent.Pause', () => {
		assert.strictEqual(UniverseAgentGrpcServices.Agent.Pause, 'Pause');
		assert.strictEqual(UniverseAgentGrpcServices.Agent.service, 'agentservice.AgentService');
	});

	test('UniverseAgentGrpcServices lists Agent.Resume', () => {
		assert.strictEqual(UniverseAgentGrpcServices.Agent.Resume, 'Resume');
		assert.strictEqual(UniverseAgentGrpcServices.Agent.service, 'agentservice.AgentService');
	});

	test('UniverseAgentGrpcServices lists Agent.Back', () => {
		assert.strictEqual(UniverseAgentGrpcServices.Agent.Back, 'Back');
		assert.strictEqual(UniverseAgentGrpcServices.Agent.service, 'agentservice.AgentService');
	});

	test('UniverseAgentGrpcServices lists Agent.Prune', () => {
		assert.strictEqual(UniverseAgentGrpcServices.Agent.Prune, 'Prune');
		assert.strictEqual(UniverseAgentGrpcServices.Agent.service, 'agentservice.AgentService');
	});

	test('UniverseAgentGrpcServices lists Agent.SuspendLoop', () => {
		assert.strictEqual(UniverseAgentGrpcServices.Agent.SuspendLoop, 'SuspendLoop');
		assert.strictEqual(UniverseAgentGrpcServices.Agent.service, 'agentservice.AgentService');
	});

	test('UniverseAgentGrpcServices lists Agent.ResumeLoop', () => {
		assert.strictEqual(UniverseAgentGrpcServices.Agent.ResumeLoop, 'ResumeLoop');
		assert.strictEqual(UniverseAgentGrpcServices.Agent.service, 'agentservice.AgentService');
	});

	test('UniverseAgentGrpcServices lists Agent.StopLoop', () => {
		assert.strictEqual(UniverseAgentGrpcServices.Agent.StopLoop, 'StopLoop');
		assert.strictEqual(UniverseAgentGrpcServices.Agent.service, 'agentservice.AgentService');
	});

	test('UniverseAgentGrpcServices lists Agent.Reset', () => {
		assert.strictEqual(UniverseAgentGrpcServices.Agent.Reset, 'Reset');
		assert.strictEqual(UniverseAgentGrpcServices.Agent.service, 'agentservice.AgentService');
	});

	test('UniverseAgentGrpcServices lists Agent.Branch', () => {
		assert.strictEqual(UniverseAgentGrpcServices.Agent.Branch, 'Branch');
		assert.strictEqual(UniverseAgentGrpcServices.Agent.service, 'agentservice.AgentService');
	});

	test('renameSession forwards request and maps result', async () => {
		const transport = new MockUniverseAgentGrpcTransport();
		const service = new UniverseAgentConnectionService({
			connectionResolver: plainFixtureResolver(),
			clientIdentityStore: plainFixtureIdentity(),
			createTransport: () => transport,
		});
		await connectPlainFixture(service);

		const result = await service.renameSession({ sessionId: 'sess-1', title: 'New title' });
		assert.deepStrictEqual(transport.renameCalls, [{ sessionId: 'sess-1', title: 'New title' }]);
		assert.deepStrictEqual(result, { ok: true });

		transport.renameResult = { ok: false, message: 'not found' };
		const failed = await service.renameSession({ sessionId: 'sess-1', title: '' });
		assert.deepStrictEqual(failed, { ok: false, message: 'not found' });
		assert.strictEqual(transport.renameCalls[1]?.title, '');
		service.dispose();
	});

	test('cancelGeneration forwards request and maps result', async () => {
		const transport = new MockUniverseAgentGrpcTransport();
		const service = new UniverseAgentConnectionService({
			connectionResolver: plainFixtureResolver(),
			clientIdentityStore: plainFixtureIdentity(),
			createTransport: () => transport,
		});
		await connectPlainFixture(service);

		const result = await service.cancelGeneration({ sessionId: 'sess-1', agentId: 'root' });
		assert.deepStrictEqual(transport.cancelCalls, [{ sessionId: 'sess-1', agentId: 'root' }]);
		assert.deepStrictEqual(result, { ok: true });

		transport.cancelResult = { ok: false, message: 'not running' };
		const failed = await service.cancelGeneration({ sessionId: 'sess-1', agentId: 'sub:a' });
		assert.deepStrictEqual(failed, { ok: false, message: 'not running' });
		assert.strictEqual(transport.cancelCalls[1]?.agentId, 'sub:a');
		service.dispose();
	});

	test('cancelToolCall forwards request and maps result', async () => {
		const transport = new MockUniverseAgentGrpcTransport();
		const service = new UniverseAgentConnectionService({
			connectionResolver: plainFixtureResolver(),
			clientIdentityStore: plainFixtureIdentity(),
			createTransport: () => transport,
		});
		await connectPlainFixture(service);

		const result = await service.cancelToolCall({ sessionId: 'sess-1', toolCallId: 'tc-1' });
		assert.deepStrictEqual(transport.cancelToolCallCalls, [{ sessionId: 'sess-1', toolCallId: 'tc-1' }]);
		assert.deepStrictEqual(result, { ok: true });

		transport.cancelToolCallResult = { ok: false, message: 'not in flight' };
		const failed = await service.cancelToolCall({ sessionId: 'sess-1', agentId: 'sub:a', toolCallId: 'tc-2' });
		assert.deepStrictEqual(failed, { ok: false, message: 'not in flight' });
		assert.strictEqual(transport.cancelToolCallCalls[1]?.agentId, 'sub:a');
		assert.strictEqual(transport.cancelToolCallCalls[1]?.toolCallId, 'tc-2');
		service.dispose();
	});

	test('runToolInBackground forwards request and maps result', async () => {
		const transport = new MockUniverseAgentGrpcTransport();
		const service = new UniverseAgentConnectionService({
			connectionResolver: plainFixtureResolver(),
			clientIdentityStore: plainFixtureIdentity(),
			createTransport: () => transport,
		});
		await connectPlainFixture(service);

		transport.runToolInBackgroundResult = { ok: true, message: 'detached', reasonCode: '' };
		const result = await service.runToolInBackground({ sessionId: 'sess-1', agentId: 'root', toolCallId: 'tc-1' });
		assert.deepStrictEqual(transport.runToolInBackgroundCalls, [{ sessionId: 'sess-1', agentId: 'root', toolCallId: 'tc-1' }]);
		assert.deepStrictEqual(result, transport.runToolInBackgroundResult);

		transport.runToolInBackgroundResult = { ok: false, message: 'not in flight', reasonCode: 'NOT_IN_FLIGHT' };
		const empty = await service.runToolInBackground({ sessionId: '', agentId: '', toolCallId: '' });
		assert.deepStrictEqual(empty, transport.runToolInBackgroundResult);
		assert.strictEqual(transport.runToolInBackgroundCalls[1]?.sessionId, '');
		assert.strictEqual(transport.runToolInBackgroundCalls[1]?.agentId, '');
		assert.strictEqual(transport.runToolInBackgroundCalls[1]?.toolCallId, '');
		service.dispose();
	});

	test('stopShellTask forwards request and maps result', async () => {
		const transport = new MockUniverseAgentGrpcTransport();
		const service = new UniverseAgentConnectionService({
			connectionResolver: plainFixtureResolver(),
			clientIdentityStore: plainFixtureIdentity(),
			createTransport: () => transport,
		});
		await connectPlainFixture(service);

		transport.stopShellTaskResult = { ok: true, message: 'stopped' };
		const result = await service.stopShellTask({ sessionId: 'sess-1', taskId: 'task-1' });
		assert.deepStrictEqual(transport.stopShellTaskCalls, [{ sessionId: 'sess-1', taskId: 'task-1' }]);
		assert.deepStrictEqual(result, transport.stopShellTaskResult);

		transport.stopShellTaskResult = { ok: false, message: 'not found' };
		const empty = await service.stopShellTask({ sessionId: '', taskId: '' });
		assert.deepStrictEqual(empty, transport.stopShellTaskResult);
		assert.strictEqual(transport.stopShellTaskCalls[1]?.sessionId, '');
		assert.strictEqual(transport.stopShellTaskCalls[1]?.taskId, '');
		service.dispose();
	});

	test('sendShellSessionClientControl forwards request and maps result', async () => {
		const transport = new MockUniverseAgentGrpcTransport();
		const service = new UniverseAgentConnectionService({
			connectionResolver: plainFixtureResolver(),
			clientIdentityStore: plainFixtureIdentity(),
			createTransport: () => transport,
		});
		await connectPlainFixture(service);

		transport.sendShellSessionClientControlResult = {
			ok: true,
			message: '',
			errorCode: '',
			debounced: false,
			deliveredToSubscribe: true,
		};
		const result = await service.sendShellSessionClientControl({
			sessionId: 'sess-1',
			toolCallId: 'tc-1',
			refId: 'shell-1',
			controlPayloadJson: '{"op":"resize"}',
		});
		assert.deepStrictEqual(transport.sendShellSessionClientControlCalls, [{
			sessionId: 'sess-1',
			toolCallId: 'tc-1',
			refId: 'shell-1',
			controlPayloadJson: '{"op":"resize"}',
		}]);
		assert.deepStrictEqual(result, transport.sendShellSessionClientControlResult);

		transport.sendShellSessionClientControlResult = {
			ok: false,
			message: 'no subscribe',
			errorCode: 'NO_SUBSCRIBE',
			debounced: false,
			deliveredToSubscribe: false,
		};
		const empty = await service.sendShellSessionClientControl({
			sessionId: '',
			toolCallId: '',
			refId: '',
			controlPayloadJson: '',
		});
		assert.deepStrictEqual(empty, transport.sendShellSessionClientControlResult);
		assert.strictEqual(transport.sendShellSessionClientControlCalls[1]?.sessionId, '');
		assert.strictEqual(transport.sendShellSessionClientControlCalls[1]?.toolCallId, '');
		assert.strictEqual(transport.sendShellSessionClientControlCalls[1]?.refId, '');
		assert.strictEqual(transport.sendShellSessionClientControlCalls[1]?.controlPayloadJson, '');
		service.dispose();
	});

	test('fetchToolUsageDetail forwards request and maps result', async () => {
		const transport = new MockUniverseAgentGrpcTransport();
		const service = new UniverseAgentConnectionService({
			connectionResolver: plainFixtureResolver(),
			clientIdentityStore: plainFixtureIdentity(),
			createTransport: () => transport,
		});
		await connectPlainFixture(service);

		transport.fetchToolUsageDetailResult = {
			ok: true,
			toolCallId: 'tc-1',
			contextSources: [{
				sourceType: 'CONTEXT_SOURCE_TYPE_SELF_HISTORY',
				sourceAgentId: 'root',
				estimatedTokens: 12,
			}],
			message: '',
		};
		const usageResult = await service.fetchToolUsageDetail({ sessionId: 'sess-1', toolCallId: 'tc-1' });
		assert.deepStrictEqual(transport.fetchToolUsageDetailCalls, [{ sessionId: 'sess-1', toolCallId: 'tc-1' }]);
		assert.deepStrictEqual(usageResult, transport.fetchToolUsageDetailResult);

		transport.fetchToolUsageDetailResult = { ok: false, toolCallId: '', contextSources: [], message: 'not found' };
		const usageEmpty = await service.fetchToolUsageDetail({ sessionId: '', toolCallId: '' });
		assert.deepStrictEqual(usageEmpty, transport.fetchToolUsageDetailResult);
		assert.strictEqual(transport.fetchToolUsageDetailCalls[1]?.sessionId, '');
		assert.strictEqual(transport.fetchToolUsageDetailCalls[1]?.toolCallId, '');
		service.dispose();
	});

	test('fireTriggerWebhook forwards request and maps result', async () => {
		const transport = new MockUniverseAgentGrpcTransport();
		const service = new UniverseAgentConnectionService({
			connectionResolver: plainFixtureResolver(),
			clientIdentityStore: plainFixtureIdentity(),
			createTransport: () => transport,
		});
		await connectPlainFixture(service);

		transport.fireTriggerWebhookResult = {
			status: 'FIRE_TRIGGER_WEBHOOK_STATUS_QUEUED',
			eventId: 'evt-1',
			reason: '',
		};
		const result = await service.fireTriggerWebhook({
			sessionId: 'sess-1',
			triggerId: 'trig-1',
			payloadJson: '{"k":1}',
		});
		assert.deepStrictEqual(transport.fireTriggerWebhookCalls, [{
			sessionId: 'sess-1',
			triggerId: 'trig-1',
			payloadJson: '{"k":1}',
		}]);
		assert.deepStrictEqual(result, transport.fireTriggerWebhookResult);

		transport.fireTriggerWebhookResult = {
			status: 'FIRE_TRIGGER_WEBHOOK_STATUS_REJECTED',
			eventId: '',
			reason: 'not armed',
		};
		const empty = await service.fireTriggerWebhook({
			sessionId: '',
			triggerId: '',
			payloadJson: '',
		});
		assert.deepStrictEqual(empty, transport.fireTriggerWebhookResult);
		assert.strictEqual(transport.fireTriggerWebhookCalls[1]?.sessionId, '');
		assert.strictEqual(transport.fireTriggerWebhookCalls[1]?.triggerId, '');
		assert.strictEqual(transport.fireTriggerWebhookCalls[1]?.payloadJson, '');
		service.dispose();
	});

	test('switchWorkDir forwards request and maps result', async () => {
		const transport = new MockUniverseAgentGrpcTransport();
		const service = new UniverseAgentConnectionService({
			connectionResolver: plainFixtureResolver(),
			clientIdentityStore: plainFixtureIdentity(),
			createTransport: () => transport,
		});
		await connectPlainFixture(service);

		transport.switchWorkDirResult = {
			ok: true,
			previousWorkDir: '/old',
			currentWorkDir: '/new',
			message: 'switched',
		};
		const result = await service.switchWorkDir({
			sessionId: 'sess-1',
			agentId: 'root',
			newWorkDir: '/new',
		});
		assert.deepStrictEqual(transport.switchWorkDirCalls, [{
			sessionId: 'sess-1',
			agentId: 'root',
			newWorkDir: '/new',
		}]);
		assert.deepStrictEqual(result, transport.switchWorkDirResult);

		transport.switchWorkDirResult = {
			ok: false,
			previousWorkDir: '',
			currentWorkDir: '',
			message: 'empty',
		};
		const empty = await service.switchWorkDir({
			sessionId: '',
			agentId: '',
			newWorkDir: '',
		});
		assert.deepStrictEqual(empty, transport.switchWorkDirResult);
		assert.strictEqual(transport.switchWorkDirCalls[1]?.sessionId, '');
		assert.strictEqual(transport.switchWorkDirCalls[1]?.agentId, '');
		assert.strictEqual(transport.switchWorkDirCalls[1]?.newWorkDir, '');
		service.dispose();
	});

	test('testModelProfile forwards request and maps result', async () => {
		const transport = new MockUniverseAgentGrpcTransport();
		const service = new UniverseAgentConnectionService({
			connectionResolver: plainFixtureResolver(),
			clientIdentityStore: plainFixtureIdentity(),
			createTransport: () => transport,
		});
		await connectPlainFixture(service);

		transport.testModelProfileResult = { ok: true, message: '' };
		const result = await service.testModelProfile({
			providerId: 'openai',
			modelId: 'gpt-4',
			apiKey: 'sk-test',
			baseUrl: 'https://api.example',
			protocol: 'openai',
			params: { temperature: '0' },
		});
		assert.deepStrictEqual(transport.testModelProfileCalls, [{
			providerId: 'openai',
			modelId: 'gpt-4',
			apiKey: 'sk-test',
			baseUrl: 'https://api.example',
			protocol: 'openai',
			params: { temperature: '0' },
		}]);
		assert.deepStrictEqual(result, transport.testModelProfileResult);

		transport.testModelProfileResult = { ok: false, message: 'refused' };
		const empty = await service.testModelProfile({
			providerId: '',
			modelId: '',
			apiKey: '',
			baseUrl: '',
			protocol: '',
			params: {},
		});
		assert.deepStrictEqual(empty, transport.testModelProfileResult);
		assert.strictEqual(transport.testModelProfileCalls[1]?.providerId, '');
		assert.strictEqual(transport.testModelProfileCalls[1]?.modelId, '');
		assert.strictEqual(transport.testModelProfileCalls[1]?.apiKey, '');
		assert.strictEqual(transport.testModelProfileCalls[1]?.baseUrl, '');
		assert.strictEqual(transport.testModelProfileCalls[1]?.protocol, '');
		assert.deepStrictEqual(transport.testModelProfileCalls[1]?.params, {});
		service.dispose();
	});

	test('setConfig forwards request and maps result', async () => {
		const transport = new MockUniverseAgentGrpcTransport();
		const service = new UniverseAgentConnectionService({
			connectionResolver: plainFixtureResolver(),
			clientIdentityStore: plainFixtureIdentity(),
			createTransport: () => transport,
		});
		await connectPlainFixture(service);

		transport.setConfigResult = { ok: true, message: '' };
		const result = await service.setConfig({
			key: 'theme',
			value: 'dark',
			scope: 'session',
			sessionId: 'sess-1',
		});
		assert.deepStrictEqual(transport.setConfigCalls, [{
			key: 'theme',
			value: 'dark',
			scope: 'session',
			sessionId: 'sess-1',
		}]);
		assert.deepStrictEqual(result, transport.setConfigResult);

		transport.setConfigResult = { ok: false, message: 'refused' };
		const empty = await service.setConfig({
			key: '',
			value: '',
			scope: '',
			sessionId: '',
		});
		assert.deepStrictEqual(empty, transport.setConfigResult);
		assert.strictEqual(transport.setConfigCalls[1]?.key, '');
		assert.strictEqual(transport.setConfigCalls[1]?.value, '');
		assert.strictEqual(transport.setConfigCalls[1]?.scope, '');
		assert.strictEqual(transport.setConfigCalls[1]?.sessionId, '');
		service.dispose();
	});

	test('setModelPreferences forwards request and maps result', async () => {
		const transport = new MockUniverseAgentGrpcTransport();
		const service = new UniverseAgentConnectionService({
			connectionResolver: plainFixtureResolver(),
			clientIdentityStore: plainFixtureIdentity(),
			createTransport: () => transport,
		});
		await connectPlainFixture(service);

		transport.setModelPreferencesResult = { minLevel: 5, maxCost: 'middle', minSpeed: 'fast', strategy: 'level' };
		const result = await service.setModelPreferences({
			sessionId: 'sess-1',
			minLevel: 5,
			maxCost: 'middle',
			minSpeed: 'fast',
			strategy: 'level',
		});
		assert.deepStrictEqual(transport.setModelPreferencesCalls, [{
			sessionId: 'sess-1',
			minLevel: 5,
			maxCost: 'middle',
			minSpeed: 'fast',
			strategy: 'level',
		}]);
		assert.deepStrictEqual(result, transport.setModelPreferencesResult);

		transport.setModelPreferencesResult = { minLevel: 0, maxCost: '', minSpeed: '', strategy: '' };
		const empty = await service.setModelPreferences({
			sessionId: '',
			minLevel: 0,
			maxCost: '',
			minSpeed: '',
			strategy: '',
		});
		assert.deepStrictEqual(empty, transport.setModelPreferencesResult);
		assert.strictEqual(transport.setModelPreferencesCalls[1]?.sessionId, '');
		assert.strictEqual(transport.setModelPreferencesCalls[1]?.minLevel, 0);
		assert.strictEqual(transport.setModelPreferencesCalls[1]?.maxCost, '');
		assert.strictEqual(transport.setModelPreferencesCalls[1]?.minSpeed, '');
		assert.strictEqual(transport.setModelPreferencesCalls[1]?.strategy, '');
		service.dispose();
	});


	test('setSessionGoal forwards request and maps result', async () => {
		const transport = new MockUniverseAgentGrpcTransport();
		const service = new UniverseAgentConnectionService({
			connectionResolver: plainFixtureResolver(),
			clientIdentityStore: plainFixtureIdentity(),
			createTransport: () => transport,
		});
		await connectPlainFixture(service);

		const result = await service.setSessionGoal({ sessionId: 'sess-1', goal: 'Ship the slice' });
		assert.deepStrictEqual(transport.setGoalCalls, [{ sessionId: 'sess-1', goal: 'Ship the slice' }]);
		assert.deepStrictEqual(result, { ok: true });

		transport.setGoalResult = { ok: false, message: 'empty goal' };
		const failed = await service.setSessionGoal({ sessionId: 'sess-1', goal: '' });
		assert.deepStrictEqual(failed, { ok: false, message: 'empty goal' });
		assert.strictEqual(transport.setGoalCalls[1]?.goal, '');
		service.dispose();
	});

	test('cancelSessionGoal forwards request and maps result', async () => {
		const transport = new MockUniverseAgentGrpcTransport();
		const service = new UniverseAgentConnectionService({
			connectionResolver: plainFixtureResolver(),
			clientIdentityStore: plainFixtureIdentity(),
			createTransport: () => transport,
		});
		await connectPlainFixture(service);

		const result = await service.cancelSessionGoal({ sessionId: 'sess-1' });
		assert.deepStrictEqual(transport.cancelGoalCalls, [{ sessionId: 'sess-1' }]);
		assert.deepStrictEqual(result, { ok: true });

		transport.cancelGoalResult = { ok: false, message: 'no goal' };
		const failed = await service.cancelSessionGoal({ sessionId: 'sess-2' });
		assert.deepStrictEqual(failed, { ok: false, message: 'no goal' });
		assert.strictEqual(transport.cancelGoalCalls[1]?.sessionId, 'sess-2');
		service.dispose();
	});

	test('respondPermission forwards request and maps result', async () => {
		const transport = new MockUniverseAgentGrpcTransport();
		const service = new UniverseAgentConnectionService({
			connectionResolver: plainFixtureResolver(),
			clientIdentityStore: plainFixtureIdentity(),
			createTransport: () => transport,
		});
		await connectPlainFixture(service);

		const result = await service.respondPermission({ sessionId: 'sess-1', requestId: 'req-1', granted: true });
		assert.deepStrictEqual(transport.respondPermissionCalls, [{ sessionId: 'sess-1', requestId: 'req-1', granted: true }]);
		assert.deepStrictEqual(result, { ok: true });

		transport.respondPermissionResult = { ok: false, message: 'expired' };
		const failed = await service.respondPermission({ sessionId: 'sess-1', requestId: 'req-2', granted: false, metadataJson: '{"note":"deny"}' });
		assert.deepStrictEqual(failed, { ok: false, message: 'expired' });
		assert.strictEqual(transport.respondPermissionCalls[1]?.granted, false);
		assert.strictEqual(transport.respondPermissionCalls[1]?.metadataJson, '{"note":"deny"}');
		service.dispose();
	});

	test('syncPermissionRule forwards request and maps result', async () => {
		const transport = new MockUniverseAgentGrpcTransport();
		const service = new UniverseAgentConnectionService({
			connectionResolver: plainFixtureResolver(),
			clientIdentityStore: plainFixtureIdentity(),
			createTransport: () => transport,
		});
		await connectPlainFixture(service);

		transport.syncPermissionRuleResult = { ok: true, ruleId: 'rule-1' };
		const result = await service.syncPermissionRule({
			sessionId: 'sess-1',
			toolName: 'shell',
			scope: 'workdir',
			action: 'ALLOW',
			reason: 'ok',
		});
		assert.deepStrictEqual(transport.syncPermissionRuleCalls, [{
			sessionId: 'sess-1',
			toolName: 'shell',
			scope: 'workdir',
			action: 'ALLOW',
			reason: 'ok',
		}]);
		assert.deepStrictEqual(result, { ok: true, ruleId: 'rule-1' });

		const bash = await service.syncPermissionRule({
			sessionId: 'sess-1',
			toolName: 'bash',
			scope: 'session',
			action: 'ALLOW',
			reason: 'trusted',
		});
		assert.deepStrictEqual(transport.syncPermissionRuleCalls[1], {
			sessionId: 'sess-1',
			toolName: 'bash',
			scope: 'session',
			action: 'ALLOW',
			reason: 'trusted',
		});
		assert.deepStrictEqual(bash, { ok: true, ruleId: 'rule-1' });

		transport.syncPermissionRuleResult = { ok: false, ruleId: '' };
		const empty = await service.syncPermissionRule({
			sessionId: '',
			toolName: '',
			scope: '',
			action: 'RULE_ACTION_UNSPECIFIED',
			reason: '',
		});
		assert.deepStrictEqual(empty, { ok: false, ruleId: '' });
		assert.strictEqual(transport.syncPermissionRuleCalls[2]?.sessionId, '');
		assert.strictEqual(transport.syncPermissionRuleCalls[2]?.toolName, '');
		assert.strictEqual(transport.syncPermissionRuleCalls[2]?.scope, '');
		assert.strictEqual(transport.syncPermissionRuleCalls[2]?.reason, '');
		service.dispose();
	});

	test('promotePermissionRule forwards request and maps result', async () => {
		const transport = new MockUniverseAgentGrpcTransport();
		const service = new UniverseAgentConnectionService({
			connectionResolver: plainFixtureResolver(),
			clientIdentityStore: plainFixtureIdentity(),
			createTransport: () => transport,
		});
		await connectPlainFixture(service);

		transport.promotePermissionRuleResult = { ok: true };
		const promoteResult = await service.promotePermissionRule({
			toolName: 'shell',
			scope: 'workdir',
			action: 'ALLOW',
		});
		assert.deepStrictEqual(transport.promotePermissionRuleCalls, [{
			toolName: 'shell',
			scope: 'workdir',
			action: 'ALLOW',
		}]);
		assert.deepStrictEqual(promoteResult, { ok: true });

		transport.promotePermissionRuleResult = { ok: false };
		const promoteEmpty = await service.promotePermissionRule({
			toolName: '',
			scope: '',
			action: 'RULE_ACTION_UNSPECIFIED',
		});
		assert.deepStrictEqual(promoteEmpty, { ok: false });
		assert.strictEqual(transport.promotePermissionRuleCalls[1]?.toolName, '');
		assert.strictEqual(transport.promotePermissionRuleCalls[1]?.scope, '');
		assert.strictEqual(transport.promotePermissionRuleCalls[1]?.action, 'RULE_ACTION_UNSPECIFIED');
		service.dispose();
	});

	test('respondQuestion forwards request and maps result', async () => {
		const transport = new MockUniverseAgentGrpcTransport();
		const service = new UniverseAgentConnectionService({
			connectionResolver: plainFixtureResolver(),
			clientIdentityStore: plainFixtureIdentity(),
			createTransport: () => transport,
		});
		await connectPlainFixture(service);

		const result = await service.respondQuestion({
			sessionId: 'sess-1',
			questionId: 'q-1',
			answers: { q_0: { selectedLabels: ['A'] } },
		});
		assert.strictEqual(transport.respondQuestionCalls.length, 1);
		assert.deepStrictEqual(transport.respondQuestionCalls[0], {
			sessionId: 'sess-1',
			questionId: 'q-1',
			answers: { q_0: { selectedLabels: ['A'] } },
		});
		assert.deepStrictEqual(result, { ok: true });

		transport.respondQuestionResult = { ok: false, message: 'expired' };
		const failed = await service.respondQuestion({
			sessionId: 'sess-1',
			questionId: '',
			customText: 'other',
		});
		assert.deepStrictEqual(failed, { ok: false, message: 'expired' });
		assert.strictEqual(transport.respondQuestionCalls[1]?.questionId, '');
		assert.strictEqual(transport.respondQuestionCalls[1]?.customText, 'other');
		service.dispose();
	});

	test('queue mutations forward request and map result', async () => {
		const transport = new MockUniverseAgentGrpcTransport();
		const service = new UniverseAgentConnectionService({
			connectionResolver: plainFixtureResolver(),
			clientIdentityStore: plainFixtureIdentity(),
			createTransport: () => transport,
		});
		await connectPlainFixture(service);

		const enqueued = await service.enqueueQueueItem({ sessionId: 'sess-1', text: 'later', priority: 'HIGH', opId: 'op-1' });
		assert.deepStrictEqual(transport.enqueueCalls, [{ sessionId: 'sess-1', text: 'later', priority: 'HIGH', opId: 'op-1' }]);
		assert.deepStrictEqual(enqueued, { ok: true });

		await service.pauseQueue({ sessionId: 'sess-1' });
		await service.resumeQueue({ sessionId: 'sess-1' });
		await service.clearQueue({ sessionId: 'sess-1' });
		await service.holdQueueItem({ sessionId: 'sess-1', itemId: 'q-1', reason: 'EDITING' });
		await service.releaseQueueItemHold({ sessionId: 'sess-1', itemId: 'q-1' });
		await service.editQueueItem({ sessionId: 'sess-1', itemId: 'q-1', text: 'edited' });
		assert.deepStrictEqual(transport.pauseCalls, [{ sessionId: 'sess-1' }]);
		assert.deepStrictEqual(transport.resumeCalls, [{ sessionId: 'sess-1' }]);
		assert.deepStrictEqual(transport.clearCalls, [{ sessionId: 'sess-1' }]);
		assert.deepStrictEqual(transport.holdCalls, [{ sessionId: 'sess-1', itemId: 'q-1', reason: 'EDITING' }]);
		assert.deepStrictEqual(transport.releaseHoldCalls, [{ sessionId: 'sess-1', itemId: 'q-1' }]);
		assert.deepStrictEqual(transport.editCalls, [{ sessionId: 'sess-1', itemId: 'q-1', text: 'edited' }]);

		transport.queueResult = { ok: false, error: 'busy' };
		const failed = await service.pauseQueue({ sessionId: 'sess-1' });
		assert.deepStrictEqual(failed, { ok: false, error: 'busy' });
		service.dispose();
	});

	test('insertQueueItem forwards request and maps result', async () => {
		const transport = new MockUniverseAgentGrpcTransport();
		const service = new UniverseAgentConnectionService({
			connectionResolver: plainFixtureResolver(),
			clientIdentityStore: plainFixtureIdentity(),
			createTransport: () => transport,
		});
		await connectPlainFixture(service);

		transport.queueResult = { ok: true, opId: 'op-1', itemId: 'q-new' };
		const result = await service.insertQueueItem({
			sessionId: 'sess-1',
			opId: 'op-1',
			clientMessageId: 'c-1',
			text: 'insert me',
			priority: 'HIGH',
			beforeItemId: 'q-2',
		});
		assert.deepStrictEqual(transport.insertCalls, [{
			sessionId: 'sess-1',
			opId: 'op-1',
			clientMessageId: 'c-1',
			text: 'insert me',
			priority: 'HIGH',
			beforeItemId: 'q-2',
		}]);
		assert.deepStrictEqual(result, transport.queueResult);

		transport.queueResult = { ok: false, error: 'empty' };
		const empty = await service.insertQueueItem({
			sessionId: '',
			opId: '',
			clientMessageId: '',
			text: '',
			beforeItemId: '',
		});
		assert.deepStrictEqual(empty, transport.queueResult);
		assert.strictEqual(transport.insertCalls[1]?.sessionId, '');
		assert.strictEqual(transport.insertCalls[1]?.opId, '');
		assert.strictEqual(transport.insertCalls[1]?.clientMessageId, '');
		assert.strictEqual(transport.insertCalls[1]?.beforeItemId, '');
		service.dispose();
	});

	test('reorderQueue forwards request and maps result', async () => {
		const transport = new MockUniverseAgentGrpcTransport();
		const service = new UniverseAgentConnectionService({
			connectionResolver: plainFixtureResolver(),
			clientIdentityStore: plainFixtureIdentity(),
			createTransport: () => transport,
		});
		await connectPlainFixture(service);

		transport.queueResult = { ok: true, opId: 'op-1', itemId: 'q-2' };
		const result = await service.reorderQueue({
			sessionId: 'sess-1',
			opId: 'op-1',
			itemIds: ['q-2', 'q-1'],
		});
		assert.deepStrictEqual(transport.reorderCalls, [{
			sessionId: 'sess-1',
			opId: 'op-1',
			itemIds: ['q-2', 'q-1'],
		}]);
		assert.deepStrictEqual(result, transport.queueResult);

		transport.queueResult = { ok: false, error: 'empty' };
		const empty = await service.reorderQueue({
			sessionId: '',
			opId: '',
			itemIds: ['', ''],
		});
		assert.deepStrictEqual(empty, transport.queueResult);
		assert.strictEqual(transport.reorderCalls[1]?.sessionId, '');
		assert.strictEqual(transport.reorderCalls[1]?.opId, '');
		assert.deepStrictEqual(transport.reorderCalls[1]?.itemIds, ['', '']);
		service.dispose();
	});

	test('deleteQueueItem forwards request and maps result', async () => {
		const transport = new MockUniverseAgentGrpcTransport();
		const service = new UniverseAgentConnectionService({
			connectionResolver: plainFixtureResolver(),
			clientIdentityStore: plainFixtureIdentity(),
			createTransport: () => transport,
		});
		await connectPlainFixture(service);

		transport.queueResult = { ok: true, opId: 'op-1', itemId: 'q-1' };
		const result = await service.deleteQueueItem({
			sessionId: 'sess-1',
			itemId: 'q-1',
			opId: 'op-1',
		});
		assert.deepStrictEqual(transport.deleteCalls, [{
			sessionId: 'sess-1',
			itemId: 'q-1',
			opId: 'op-1',
		}]);
		assert.deepStrictEqual(result, transport.queueResult);

		transport.queueResult = { ok: false, error: 'empty' };
		const empty = await service.deleteQueueItem({
			sessionId: '',
			itemId: '',
			opId: '',
		});
		assert.deepStrictEqual(empty, transport.queueResult);
		assert.strictEqual(transport.deleteCalls[1]?.sessionId, '');
		assert.strictEqual(transport.deleteCalls[1]?.itemId, '');
		assert.strictEqual(transport.deleteCalls[1]?.opId, '');
		service.dispose();
	});

	test('retryQueueItem forwards request and maps result', async () => {
		const transport = new MockUniverseAgentGrpcTransport();
		const service = new UniverseAgentConnectionService({
			connectionResolver: plainFixtureResolver(),
			clientIdentityStore: plainFixtureIdentity(),
			createTransport: () => transport,
		});
		await connectPlainFixture(service);

		transport.queueResult = { ok: true, opId: 'op-1', itemId: 'q-1' };
		const result = await service.retryQueueItem({
			sessionId: 'sess-1',
			itemId: 'q-1',
			opId: 'op-1',
		});
		assert.deepStrictEqual(transport.retryCalls, [{
			sessionId: 'sess-1',
			itemId: 'q-1',
			opId: 'op-1',
		}]);
		assert.deepStrictEqual(result, transport.queueResult);

		transport.queueResult = { ok: false, error: 'empty' };
		const empty = await service.retryQueueItem({
			sessionId: '',
			itemId: '',
			opId: '',
		});
		assert.deepStrictEqual(empty, transport.queueResult);
		assert.strictEqual(transport.retryCalls[1]?.sessionId, '');
		assert.strictEqual(transport.retryCalls[1]?.itemId, '');
		assert.strictEqual(transport.retryCalls[1]?.opId, '');
		service.dispose();
	});

	test('retryAllFailed forwards request and maps result', async () => {
		const transport = new MockUniverseAgentGrpcTransport();
		const service = new UniverseAgentConnectionService({
			connectionResolver: plainFixtureResolver(),
			clientIdentityStore: plainFixtureIdentity(),
			createTransport: () => transport,
		});
		await connectPlainFixture(service);

		transport.queueResult = { ok: true, opId: 'op-1' };
		const result = await service.retryAllFailed({
			sessionId: 'sess-1',
			opId: 'op-1',
		});
		assert.deepStrictEqual(transport.retryAllFailedCalls, [{
			sessionId: 'sess-1',
			opId: 'op-1',
		}]);
		assert.deepStrictEqual(result, transport.queueResult);

		transport.queueResult = { ok: false, error: 'empty' };
		const empty = await service.retryAllFailed({
			sessionId: '',
			opId: '',
		});
		assert.deepStrictEqual(empty, transport.queueResult);
		assert.strictEqual(transport.retryAllFailedCalls[1]?.sessionId, '');
		assert.strictEqual(transport.retryAllFailedCalls[1]?.opId, '');
		service.dispose();
	});

	test('retryQueueItemUpload forwards request and maps result', async () => {
		const transport = new MockUniverseAgentGrpcTransport();
		const service = new UniverseAgentConnectionService({
			connectionResolver: plainFixtureResolver(),
			clientIdentityStore: plainFixtureIdentity(),
			createTransport: () => transport,
		});
		await connectPlainFixture(service);

		transport.queueResult = { ok: true, opId: 'op-1', itemId: 'q-1' };
		const result = await service.retryQueueItemUpload({
			sessionId: 'sess-1',
			itemId: 'q-1',
			opId: 'op-1',
		});
		assert.deepStrictEqual(transport.retryQueueItemUploadCalls, [{
			sessionId: 'sess-1',
			itemId: 'q-1',
			opId: 'op-1',
		}]);
		assert.deepStrictEqual(result, transport.queueResult);

		transport.queueResult = { ok: false, error: 'empty' };
		const empty = await service.retryQueueItemUpload({
			sessionId: '',
			itemId: '',
			opId: '',
		});
		assert.deepStrictEqual(empty, transport.queueResult);
		assert.strictEqual(transport.retryQueueItemUploadCalls[1]?.sessionId, '');
		assert.strictEqual(transport.retryQueueItemUploadCalls[1]?.itemId, '');
		assert.strictEqual(transport.retryQueueItemUploadCalls[1]?.opId, '');
		service.dispose();
	});

	test('pinQueueItem forwards request and maps result', async () => {
		const transport = new MockUniverseAgentGrpcTransport();
		const service = new UniverseAgentConnectionService({
			connectionResolver: plainFixtureResolver(),
			clientIdentityStore: plainFixtureIdentity(),
			createTransport: () => transport,
		});
		await connectPlainFixture(service);

		transport.queueResult = { ok: true, opId: 'op-1', itemId: 'q-1' };
		const result = await service.pinQueueItem({
			sessionId: 'sess-1',
			itemId: 'q-1',
			opId: 'op-1',
		});
		assert.deepStrictEqual(transport.pinCalls, [{
			sessionId: 'sess-1',
			itemId: 'q-1',
			opId: 'op-1',
		}]);
		assert.deepStrictEqual(result, transport.queueResult);

		transport.queueResult = { ok: false, error: 'empty' };
		const empty = await service.pinQueueItem({
			sessionId: '',
			itemId: '',
			opId: '',
		});
		assert.deepStrictEqual(empty, transport.queueResult);
		assert.strictEqual(transport.pinCalls[1]?.sessionId, '');
		assert.strictEqual(transport.pinCalls[1]?.itemId, '');
		assert.strictEqual(transport.pinCalls[1]?.opId, '');
		service.dispose();
	});

	test('setQueueItemLocked forwards request and maps result', async () => {
		const transport = new MockUniverseAgentGrpcTransport();
		const service = new UniverseAgentConnectionService({
			connectionResolver: plainFixtureResolver(),
			clientIdentityStore: plainFixtureIdentity(),
			createTransport: () => transport,
		});
		await connectPlainFixture(service);

		transport.queueResult = { ok: true, opId: 'op-1', itemId: 'q-1' };
		const result = await service.setQueueItemLocked({
			sessionId: 'sess-1',
			itemId: 'q-1',
			opId: 'op-1',
			locked: true,
		});
		assert.deepStrictEqual(transport.setQueueItemLockedCalls, [{
			sessionId: 'sess-1',
			itemId: 'q-1',
			opId: 'op-1',
			locked: true,
		}]);
		assert.deepStrictEqual(result, transport.queueResult);

		transport.queueResult = { ok: false, error: 'empty' };
		const empty = await service.setQueueItemLocked({
			sessionId: '',
			itemId: '',
			opId: '',
			locked: false,
		});
		assert.deepStrictEqual(empty, transport.queueResult);
		assert.strictEqual(transport.setQueueItemLockedCalls[1]?.sessionId, '');
		assert.strictEqual(transport.setQueueItemLockedCalls[1]?.itemId, '');
		assert.strictEqual(transport.setQueueItemLockedCalls[1]?.opId, '');
		assert.strictEqual(transport.setQueueItemLockedCalls[1]?.locked, false);
		service.dispose();
	});

	test('injectQueueItem forwards request and maps result', async () => {
		const transport = new MockUniverseAgentGrpcTransport();
		const service = new UniverseAgentConnectionService({
			connectionResolver: plainFixtureResolver(),
			clientIdentityStore: plainFixtureIdentity(),
			createTransport: () => transport,
		});
		await connectPlainFixture(service);

		transport.queueResult = { ok: true, opId: 'op-1', itemId: 'q-1' };
		const result = await service.injectQueueItem({
			sessionId: 'sess-1',
			itemId: 'q-1',
			opId: 'op-1',
		});
		assert.deepStrictEqual(transport.injectCalls, [{
			sessionId: 'sess-1',
			itemId: 'q-1',
			opId: 'op-1',
		}]);
		assert.deepStrictEqual(result, transport.queueResult);

		transport.queueResult = { ok: false, error: 'empty' };
		const empty = await service.injectQueueItem({
			sessionId: '',
			itemId: '',
			opId: '',
		});
		assert.deepStrictEqual(empty, transport.queueResult);
		assert.strictEqual(transport.injectCalls[1]?.sessionId, '');
		assert.strictEqual(transport.injectCalls[1]?.itemId, '');
		assert.strictEqual(transport.injectCalls[1]?.opId, '');
		service.dispose();
	});

	test('setQueueItemForkAnchor forwards request and maps result', async () => {
		const transport = new MockUniverseAgentGrpcTransport();
		const service = new UniverseAgentConnectionService({
			connectionResolver: plainFixtureResolver(),
			clientIdentityStore: plainFixtureIdentity(),
			createTransport: () => transport,
		});
		await connectPlainFixture(service);

		transport.queueResult = { ok: true, opId: 'op-1', itemId: 'q-1' };
		const result = await service.setQueueItemForkAnchor({
			sessionId: 'sess-1',
			itemId: 'q-1',
			opId: 'op-1',
			forkFromTurnId: 'turn-1',
			forkFromPreview: 'hello',
		});
		assert.deepStrictEqual(transport.setQueueItemForkAnchorCalls, [{
			sessionId: 'sess-1',
			itemId: 'q-1',
			opId: 'op-1',
			forkFromTurnId: 'turn-1',
			forkFromPreview: 'hello',
		}]);
		assert.deepStrictEqual(result, transport.queueResult);

		transport.queueResult = { ok: false, error: 'empty' };
		const empty = await service.setQueueItemForkAnchor({
			sessionId: '',
			itemId: '',
			opId: '',
			forkFromTurnId: '',
			forkFromPreview: '',
		});
		assert.deepStrictEqual(empty, transport.queueResult);
		assert.strictEqual(transport.setQueueItemForkAnchorCalls[1]?.sessionId, '');
		assert.strictEqual(transport.setQueueItemForkAnchorCalls[1]?.itemId, '');
		assert.strictEqual(transport.setQueueItemForkAnchorCalls[1]?.opId, '');
		assert.strictEqual(transport.setQueueItemForkAnchorCalls[1]?.forkFromTurnId, '');
		assert.strictEqual(transport.setQueueItemForkAnchorCalls[1]?.forkFromPreview, '');
		service.dispose();
	});

	test('chatSync forwards request and maps result', async () => {
		const transport = new MockUniverseAgentGrpcTransport();
		const service = new UniverseAgentConnectionService({
			connectionResolver: plainFixtureResolver(),
			clientIdentityStore: plainFixtureIdentity(),
			createTransport: () => transport,
		});
		await connectPlainFixture(service);

		transport.chatSyncResult = {
			sessionId: 'sess-1',
			agentId: 'root',
			text: 'ok',
			stopReason: 'end',
			inputTokens: 1,
			outputTokens: 2,
			turnCount: 1,
			toolResults: [],
			error: '',
			inputDeliveryEvents: [],
		};
		const result = await service.chatSync({
			sessionId: 'sess-1',
			agentId: 'root',
			idempotencyKey: 'idemp-1',
			lastKnownMessageIds: ['m-1'],
			sessionInput: { messageId: 'm-new', text: 'hi' },
		});
		assert.deepStrictEqual(transport.chatSyncCalls, [{
			sessionId: 'sess-1',
			agentId: 'root',
			idempotencyKey: 'idemp-1',
			lastKnownMessageIds: ['m-1'],
			sessionInput: { messageId: 'm-new', text: 'hi' },
		}]);
		assert.deepStrictEqual(result, transport.chatSyncResult);

		transport.chatSyncResult = {
			sessionId: '',
			agentId: '',
			text: '',
			stopReason: '',
			inputTokens: 0,
			outputTokens: 0,
			turnCount: 0,
			toolResults: [],
			error: 'empty',
			inputDeliveryEvents: [],
		};
		const empty = await service.chatSync({
			sessionId: '',
			agentId: '',
			idempotencyKey: '',
			lastKnownMessageIds: [''],
			sessionInput: { messageId: '', text: '' },
		});
		assert.deepStrictEqual(empty, transport.chatSyncResult);
		assert.strictEqual(transport.chatSyncCalls[1]?.sessionId, '');
		assert.strictEqual(transport.chatSyncCalls[1]?.agentId, '');
		assert.strictEqual(transport.chatSyncCalls[1]?.idempotencyKey, '');
		assert.deepStrictEqual(transport.chatSyncCalls[1]?.lastKnownMessageIds, ['']);
		assert.strictEqual(transport.chatSyncCalls[1]?.sessionInput?.messageId, '');
		service.dispose();
	});

	test('syncInputDelivery forwards request and maps result', async () => {
		const transport = new MockUniverseAgentGrpcTransport();
		const service = new UniverseAgentConnectionService({
			connectionResolver: plainFixtureResolver(),
			clientIdentityStore: plainFixtureIdentity(),
			createTransport: () => transport,
		});
		await connectPlainFixture(service);

		transport.syncInputDeliveryResult = {
			inputDeliveryEvents: [{
				messageId: 'm-1',
				status: 1,
				errorCode: '',
				errorMessage: '',
			}],
		};
		const result = await service.syncInputDelivery({
			sessionId: 'sess-1',
			lastKnownMessageIds: ['m-1'],
		});
		assert.deepStrictEqual(transport.syncInputDeliveryCalls, [{
			sessionId: 'sess-1',
			lastKnownMessageIds: ['m-1'],
		}]);
		assert.deepStrictEqual(result, transport.syncInputDeliveryResult);

		transport.syncInputDeliveryResult = {
			inputDeliveryEvents: [],
		};
		const empty = await service.syncInputDelivery({
			sessionId: '',
			lastKnownMessageIds: [''],
		});
		assert.deepStrictEqual(empty, transport.syncInputDeliveryResult);
		assert.strictEqual(transport.syncInputDeliveryCalls[1]?.sessionId, '');
		assert.deepStrictEqual(transport.syncInputDeliveryCalls[1]?.lastKnownMessageIds, ['']);
		service.dispose();
	});

	test('installSessionDemoFake forwards request and maps result', async () => {
		const transport = new MockUniverseAgentGrpcTransport();
		const service = new UniverseAgentConnectionService({
			connectionResolver: plainFixtureResolver(),
			clientIdentityStore: plainFixtureIdentity(),
			createTransport: () => transport,
		});
		await connectPlainFixture(service);

		transport.installSessionDemoFakeResult = { ok: true, message: 'ok', reasonCode: 'OK' };
		const queuesPayload = new Uint8Array([1, 2, 3]);
		const result = await service.installSessionDemoFake({
			sessionId: 'sess-1',
			queuesPayload,
			contentType: 'application/vnd.universe.scripted-queues.v1+json',
			playbookId: 'pb-1',
		});
		assert.deepStrictEqual(transport.installSessionDemoFakeCalls, [{
			sessionId: 'sess-1',
			queuesPayload,
			contentType: 'application/vnd.universe.scripted-queues.v1+json',
			playbookId: 'pb-1',
		}]);
		assert.deepStrictEqual(result, transport.installSessionDemoFakeResult);

		transport.installSessionDemoFakeResult = { ok: false, message: 'empty', reasonCode: 'INVALID_PAYLOAD' };
		const emptyPayload = new Uint8Array(0);
		const empty = await service.installSessionDemoFake({
			sessionId: '',
			queuesPayload: emptyPayload,
			contentType: '',
			playbookId: '',
		});
		assert.deepStrictEqual(empty, transport.installSessionDemoFakeResult);
		assert.strictEqual(transport.installSessionDemoFakeCalls[1]?.sessionId, '');
		assert.deepStrictEqual(transport.installSessionDemoFakeCalls[1]?.queuesPayload, emptyPayload);
		assert.strictEqual(transport.installSessionDemoFakeCalls[1]?.contentType, '');
		assert.strictEqual(transport.installSessionDemoFakeCalls[1]?.playbookId, '');
		service.dispose();
	});

	test('clearSessionDemoFake forwards request and maps result', async () => {
		const transport = new MockUniverseAgentGrpcTransport();
		const service = new UniverseAgentConnectionService({
			connectionResolver: plainFixtureResolver(),
			clientIdentityStore: plainFixtureIdentity(),
			createTransport: () => transport,
		});
		await connectPlainFixture(service);

		transport.clearSessionDemoFakeResult = { ok: true, message: 'ok', reasonCode: 'OK' };
		const result = await service.clearSessionDemoFake({
			sessionId: 'sess-1',
		});
		assert.deepStrictEqual(transport.clearSessionDemoFakeCalls, [{
			sessionId: 'sess-1',
		}]);
		assert.deepStrictEqual(result, transport.clearSessionDemoFakeResult);

		transport.clearSessionDemoFakeResult = { ok: false, message: 'empty', reasonCode: 'NOT_INSTALLED' };
		const empty = await service.clearSessionDemoFake({
			sessionId: '',
		});
		assert.deepStrictEqual(empty, transport.clearSessionDemoFakeResult);
		assert.strictEqual(transport.clearSessionDemoFakeCalls[1]?.sessionId, '');
		service.dispose();
	});

	test('forkAgent forwards request and maps result', async () => {
		const transport = new MockUniverseAgentGrpcTransport();
		const service = new UniverseAgentConnectionService({
			connectionResolver: plainFixtureResolver(),
			clientIdentityStore: plainFixtureIdentity(),
			createTransport: () => transport,
		});
		await connectPlainFixture(service);

		const result = await service.forkAgent({ sessionId: 'sess-1', name: 'reviewer', task: 'Review the diff' });
		assert.deepStrictEqual(transport.forkCalls, [{ sessionId: 'sess-1', name: 'reviewer', task: 'Review the diff' }]);
		assert.deepStrictEqual(result, { ok: true, agentId: 'sub:reviewer' });

		transport.forkResult = { ok: false };
		const failedFork = await service.forkAgent({ sessionId: 'sess-2', parentAgentId: 'sub:a' });
		assert.deepStrictEqual(failedFork, { ok: false });
		assert.strictEqual((transport.forkCalls as readonly UniverseAgentForkAgentRequest[])[1]?.parentAgentId, 'sub:a');
		service.dispose();
	});

	test('getToolInfo forwards request and maps result', async () => {
		const transport = new MockUniverseAgentGrpcTransport();
		const service = new UniverseAgentConnectionService({
			connectionResolver: plainFixtureResolver(),
			clientIdentityStore: plainFixtureIdentity(),
			createTransport: () => transport,
		});
		await connectPlainFixture(service);

		const result = await service.getToolInfo({ toolName: 'bash' });
		assert.deepStrictEqual(transport.toolInfoCalls, [{ toolName: 'bash' }]);
		assert.deepStrictEqual(result, {
			name: 'bash',
			description: 'Run a command',
			category: 'shell',
			inputSchemaJson: '{"type":"object"}',
			destructive: true,
			requiresPermission: true,
			aliases: ['sh'],
		});

		transport.toolInfoResult = { name: '', aliases: [] };
		const missing = await service.getToolInfo({ toolName: 'missing' });
		assert.deepStrictEqual(missing, { name: '', aliases: [] });
		assert.strictEqual(transport.toolInfoCalls[1]?.toolName, 'missing');
		service.dispose();
	});

	test('killAgent forwards request and maps result', async () => {
		const transport = new MockUniverseAgentGrpcTransport();
		const service = new UniverseAgentConnectionService({
			connectionResolver: plainFixtureResolver(),
			clientIdentityStore: plainFixtureIdentity(),
			createTransport: () => transport,
		});
		await connectPlainFixture(service);

		const result = await service.killAgent({ sessionId: 'sess-1', agentId: 'sub:reviewer', force: true });
		assert.deepStrictEqual(transport.killCalls, [{ sessionId: 'sess-1', agentId: 'sub:reviewer', force: true }]);
		assert.deepStrictEqual(result, { ok: true });

		transport.killResult = { ok: false, message: 'not found' };
		const failedKill = await service.killAgent({ sessionId: 'sess-2', agentId: '' });
		assert.deepStrictEqual(failedKill, { ok: false, message: 'not found' });
		assert.strictEqual(transport.killCalls[1]?.agentId, '');
		service.dispose();
	});

	test('deleteMessage forwards request and maps result', async () => {
		const transport = new MockUniverseAgentGrpcTransport();
		const service = new UniverseAgentConnectionService({
			connectionResolver: plainFixtureResolver(),
			clientIdentityStore: plainFixtureIdentity(),
			createTransport: () => transport,
		});
		await connectPlainFixture(service);

		const result = await service.deleteMessage({ sessionId: 'sess-1', turnId: 'turn-1', agentId: 'sub:a' });
		assert.deepStrictEqual(transport.deleteMessageCalls, [{ sessionId: 'sess-1', turnId: 'turn-1', agentId: 'sub:a' }]);
		assert.deepStrictEqual(result, { ok: true });

		transport.deleteMessageResult = { ok: false, message: 'not found' };
		const failed = await service.deleteMessage({ sessionId: 'sess-2', turnId: 'turn-2' });
		assert.deepStrictEqual(failed, { ok: false, message: 'not found' });
		assert.strictEqual(transport.deleteMessageCalls[1]?.turnId, 'turn-2');
		service.dispose();
	});

	test('editMessage forwards request and maps result', async () => {
		const transport = new MockUniverseAgentGrpcTransport();
		const service = new UniverseAgentConnectionService({
			connectionResolver: plainFixtureResolver(),
			clientIdentityStore: plainFixtureIdentity(),
			createTransport: () => transport,
		});
		await connectPlainFixture(service);

		const result = await service.editMessage({ sessionId: 'sess-1', turnId: 'turn-1', newContent: 'later', agentId: 'sub:a' });
		assert.deepStrictEqual(transport.editMessageCalls, [{ sessionId: 'sess-1', turnId: 'turn-1', newContent: 'later', agentId: 'sub:a' }]);
		assert.deepStrictEqual(result, { ok: true });

		transport.editMessageResult = { ok: false, message: 'not found' };
		const failed = await service.editMessage({ sessionId: 'sess-2', turnId: 'turn-2', newContent: 'nope' });
		assert.deepStrictEqual(failed, { ok: false, message: 'not found' });
		assert.strictEqual(transport.editMessageCalls[1]?.turnId, 'turn-2');
		service.dispose();
	});

	test('sendClientToolResponse forwards request and maps result', async () => {
		const transport = new MockUniverseAgentGrpcTransport();
		const service = new UniverseAgentConnectionService({
			connectionResolver: plainFixtureResolver(),
			clientIdentityStore: plainFixtureIdentity(),
			createTransport: () => transport,
		});
		await connectPlainFixture(service);

		const result = await service.sendClientToolResponse({
			sessionId: 'sess-1',
			callId: 'call-1',
			content: '{"ok":true}',
		});
		assert.deepStrictEqual([...transport.sendClientToolResponseCalls], [{
			sessionId: 'sess-1',
			callId: 'call-1',
			content: '{"ok":true}',
		}]);
		assert.deepStrictEqual(result, { ok: true });

		transport.sendClientToolResponseResult = { ok: false, message: 'expired' };
		const failed = await service.sendClientToolResponse({
			sessionId: 'sess-1',
			callId: '',
			isError: true,
			metadataJson: '{"note":"fail"}',
			canvasRefs: [{ canvasId: 'c1', revisionId: 'r1', title: 'Board' }],
		});
		assert.deepStrictEqual(failed, { ok: false, message: 'expired' });
		const second: UniverseAgentSendClientToolResponseRequest | undefined = transport.sendClientToolResponseCalls[1];
		assert.strictEqual(second?.callId, '');
		assert.strictEqual(second?.isError, true);
		assert.strictEqual(second?.metadataJson, '{"note":"fail"}');
		assert.deepStrictEqual(second?.canvasRefs, [{ canvasId: 'c1', revisionId: 'r1', title: 'Board' }]);
		service.dispose();
	});

	test('listSnapshots forwards request and maps result', async () => {
		const transport = new MockUniverseAgentGrpcTransport();
		const service = new UniverseAgentConnectionService({
			connectionResolver: plainFixtureResolver(),
			clientIdentityStore: plainFixtureIdentity(),
			createTransport: () => transport,
		});
		await connectPlainFixture(service);

		transport.listSnapshotsResult = {
			snapshots: [{ id: 'snap-1', sessionId: 'sess-1', title: 'Before refactor', turnCount: 3 }],
		};
		const result = await service.listSnapshots({ sessionId: 'sess-1' });
		assert.deepStrictEqual(transport.listSnapshotsCalls, [{ sessionId: 'sess-1' }]);
		assert.deepStrictEqual(result, {
			snapshots: [{ id: 'snap-1', sessionId: 'sess-1', title: 'Before refactor', turnCount: 3 }],
		});

		transport.listSnapshotsResult = { snapshots: [] };
		const empty = await service.listSnapshots({ sessionId: '' });
		assert.deepStrictEqual(empty, { snapshots: [] });
		assert.strictEqual(transport.listSnapshotsCalls[1]?.sessionId, '');
		service.dispose();
	});

	test('listLoopSnapshots forwards request and maps result', async () => {
		const transport = new MockUniverseAgentGrpcTransport();
		const service = new UniverseAgentConnectionService({
			connectionResolver: plainFixtureResolver(),
			clientIdentityStore: plainFixtureIdentity(),
			createTransport: () => transport,
		});
		await connectPlainFixture(service);

		transport.listLoopSnapshotsResult = {
			snapshots: [{
				timestamp: 1_700_000_000,
				turnId: 'turn-1',
				loopId: 'loop-1',
				iteration: 2,
				maxIterations: 8,
				goal: 'finish',
				exitCondition: 'done',
				tmpFileRelativePath: 'tmp/loop.md',
				isExit: false,
			}],
		};
		const result = await service.listLoopSnapshots({ sessionId: 'sess-1', loopId: 'loop-1' });
		assert.deepStrictEqual(transport.listLoopSnapshotsCalls, [{ sessionId: 'sess-1', loopId: 'loop-1' }]);
		assert.deepStrictEqual(result, {
			snapshots: [{
				timestamp: 1_700_000_000,
				turnId: 'turn-1',
				loopId: 'loop-1',
				iteration: 2,
				maxIterations: 8,
				goal: 'finish',
				exitCondition: 'done',
				tmpFileRelativePath: 'tmp/loop.md',
				isExit: false,
			}],
		});

		transport.listLoopSnapshotsResult = { snapshots: [] };
		const empty = await service.listLoopSnapshots({ sessionId: '', loopId: '' });
		assert.deepStrictEqual(empty, { snapshots: [] });
		assert.strictEqual(transport.listLoopSnapshotsCalls[1]?.sessionId, '');
		assert.strictEqual(transport.listLoopSnapshotsCalls[1]?.loopId, '');
		service.dispose();
	});

	test('createSnapshot forwards request and maps result', async () => {
		const transport = new MockUniverseAgentGrpcTransport();
		const service = new UniverseAgentConnectionService({
			connectionResolver: plainFixtureResolver(),
			clientIdentityStore: plainFixtureIdentity(),
			createTransport: () => transport,
		});
		await connectPlainFixture(service);

		transport.createSnapshotResult = {
			ok: true,
			snapshot: { id: 'snap-1', sessionId: 'sess-1', title: 'Before refactor', description: 'note' },
		};
		const result = await service.createSnapshot({
			sessionId: 'sess-1',
			title: 'Before refactor',
			description: 'note',
		});
		assert.deepStrictEqual(transport.createSnapshotCalls, [{
			sessionId: 'sess-1',
			title: 'Before refactor',
			description: 'note',
		}]);
		assert.deepStrictEqual(result, {
			ok: true,
			snapshot: { id: 'snap-1', sessionId: 'sess-1', title: 'Before refactor', description: 'note' },
		});

		transport.createSnapshotResult = { ok: false, message: 'denied' };
		const failed = await service.createSnapshot({ sessionId: '', title: '' });
		assert.deepStrictEqual(failed, { ok: false, message: 'denied' });
		assert.strictEqual(transport.createSnapshotCalls[1]?.sessionId, '');
		assert.strictEqual(transport.createSnapshotCalls[1]?.title, '');
		service.dispose();
	});

	test('createSnapshot forwards turnCount snapshot and empty-title failure', async () => {
		const transport = new MockUniverseAgentGrpcTransport();
		const service = new UniverseAgentConnectionService({
			connectionResolver: plainFixtureResolver(),
			clientIdentityStore: plainFixtureIdentity(),
			createTransport: () => transport,
		});
		await connectPlainFixture(service);

		transport.createSnapshotResult = {
			ok: true,
			snapshot: { id: 'snap-1', sessionId: 'sess-1', title: 'Before refactor', turnCount: 3 },
		};
		const result = await service.createSnapshot({ sessionId: 'sess-1', title: 'Before refactor', description: 'checkpoint' });
		assert.deepStrictEqual(transport.createSnapshotCalls, [{ sessionId: 'sess-1', title: 'Before refactor', description: 'checkpoint' }]);
		assert.deepStrictEqual(result, {
			ok: true,
			snapshot: { id: 'snap-1', sessionId: 'sess-1', title: 'Before refactor', turnCount: 3 },
		});

		transport.createSnapshotResult = { ok: false, message: 'empty title' };
		const failed = await service.createSnapshot({ sessionId: '', title: '' });
		assert.deepStrictEqual(failed, { ok: false, message: 'empty title' });
		assert.strictEqual(transport.createSnapshotCalls[1]?.sessionId, '');
		assert.strictEqual(transport.createSnapshotCalls[1]?.title, '');
		service.dispose();
	});

	test('restoreSnapshot forwards request and maps result', async () => {
		const transport = new MockUniverseAgentGrpcTransport();
		const service = new UniverseAgentConnectionService({
			connectionResolver: plainFixtureResolver(),
			clientIdentityStore: plainFixtureIdentity(),
			createTransport: () => transport,
		});
		await connectPlainFixture(service);

		transport.restoreSnapshotResult = { ok: true };
		const result = await service.restoreSnapshot({ sessionId: 'sess-1', snapshotId: 'snap-1' });
		assert.deepStrictEqual(transport.restoreSnapshotCalls, [{ sessionId: 'sess-1', snapshotId: 'snap-1' }]);
		assert.deepStrictEqual(result, { ok: true });

		transport.restoreSnapshotResult = { ok: false, message: 'denied' };
		const failed = await service.restoreSnapshot({ sessionId: '', snapshotId: '' });
		assert.deepStrictEqual(failed, { ok: false, message: 'denied' });
		assert.strictEqual(transport.restoreSnapshotCalls[1]?.sessionId, '');
		assert.strictEqual(transport.restoreSnapshotCalls[1]?.snapshotId, '');
		service.dispose();
	});

	test('getSessionInfo forwards request and maps result', async () => {
		const transport = new MockUniverseAgentGrpcTransport();
		const service = new UniverseAgentConnectionService({
			connectionResolver: plainFixtureResolver(),
			clientIdentityStore: plainFixtureIdentity(),
			createTransport: () => transport,
		});
		await connectPlainFixture(service);

		transport.getSessionInfoResult = {
			sessionId: 'sess-1',
			rootAgent: {
				agentId: 'root',
				name: 'Root',
				type: 'AGENT_TYPE_UNKNOWN',
				status: 'AGENT_STATUS_UNKNOWN',
				model: 'gpt',
				turnCount: 2,
				createdAt: 10,
				children: [],
			},
			createdAt: 100,
			lastAccessedAt: 200,
			provider: 'openai',
			model: 'gpt',
		};
		const result = await service.getSessionInfo({ sessionId: 'sess-1' });
		assert.deepStrictEqual(transport.getSessionInfoCalls, [{ sessionId: 'sess-1' }]);
		assert.deepStrictEqual(result, transport.getSessionInfoResult);

		transport.getSessionInfoResult = {
			sessionId: '',
			createdAt: 0,
			lastAccessedAt: 0,
			provider: '',
			model: '',
		};
		const empty = await service.getSessionInfo({ sessionId: '' });
		assert.deepStrictEqual(empty, transport.getSessionInfoResult);
		assert.strictEqual(transport.getSessionInfoCalls[1]?.sessionId, '');
		service.dispose();
	});

	test('getSessionRules forwards request and maps result', async () => {
		const transport = new MockUniverseAgentGrpcTransport();
		const service = new UniverseAgentConnectionService({
			connectionResolver: plainFixtureResolver(),
			clientIdentityStore: plainFixtureIdentity(),
			createTransport: () => transport,
		});
		await connectPlainFixture(service);

		transport.getSessionRulesResult = {
			rules: [{
				id: 'rule-1',
				toolName: 'bash',
				scope: 'session',
				action: 'ALLOW',
				reason: 'user',
				createdAt: 1,
				expiresAt: 2,
				source: 'USER_INTERACTIVE',
			}],
		};
		const result = await service.getSessionRules({ sessionId: 'sess-1' });
		assert.deepStrictEqual(transport.getSessionRulesCalls, [{ sessionId: 'sess-1' }]);
		assert.deepStrictEqual(result, transport.getSessionRulesResult);

		transport.getSessionRulesResult = { rules: [] };
		const empty = await service.getSessionRules({ sessionId: '' });
		assert.deepStrictEqual(empty, { rules: [] });
		assert.strictEqual(transport.getSessionRulesCalls[1]?.sessionId, '');
		service.dispose();
	});

	test('session tool profile and engine trigger forward exact requests and preserve responses', async () => {
		const transport = new MockUniverseAgentGrpcTransport();
		const service = new UniverseAgentConnectionService({
			connectionResolver: plainFixtureResolver(),
			clientIdentityStore: plainFixtureIdentity(),
			createTransport: () => transport,
		});
		try {
			await connectPlainFixture(service);
			const profile = { sessionId: 's', profile: 'CLIENT_TOOL_PROFILE_NONE' as const };
			const trigger = { sessionId: 's', name: 'Watch', type: 'file_changed' as const, promptTemplate: 'Changed', watchPaths: ['src'], dedupeKeyField: '' };
			assert.deepStrictEqual(await service.setClientToolProfile(profile), { ok: false, error: 'Session not found' });
			assert.strictEqual(await service.registerSessionEngineTrigger(trigger), transport.upsertTriggerResult);
			assert.deepStrictEqual(transport.setClientToolProfileCalls, [profile]);
			assert.deepStrictEqual(transport.registerSessionEngineTriggerCalls, [trigger]);
		} finally {
			service.dispose();
		}
	});

	test('setPermissionMode forwards request and maps result', async () => {
		const transport = new MockUniverseAgentGrpcTransport();
		const service = new UniverseAgentConnectionService({
			connectionResolver: plainFixtureResolver(),
			clientIdentityStore: plainFixtureIdentity(),
			createTransport: () => transport,
		});
		await connectPlainFixture(service);

		transport.setPermissionModeResult = { ok: true };
		const result = await service.setPermissionMode({
			sessionId: 'sess-1',
			mode: 'SESSION_TOOL_PERMISSION_MODE_ASK',
		});
		assert.deepStrictEqual(transport.setPermissionModeCalls, [{
			sessionId: 'sess-1',
			mode: 'SESSION_TOOL_PERMISSION_MODE_ASK',
		}]);
		assert.deepStrictEqual(result, { ok: true });

		transport.setPermissionModeResult = { ok: false, message: 'denied' };
		const empty = await service.setPermissionMode({
			sessionId: '',
			mode: 'SESSION_TOOL_PERMISSION_MODE_UNSPECIFIED',
		});
		assert.deepStrictEqual(empty, { ok: false, message: 'denied' });
		assert.strictEqual(transport.setPermissionModeCalls[1]?.sessionId, '');
		assert.strictEqual(transport.setPermissionModeCalls[1]?.mode, 'SESSION_TOOL_PERMISSION_MODE_UNSPECIFIED');
		service.dispose();
	});

	test('taskUpdate forwards request and maps result', async () => {
		const transport = new MockUniverseAgentGrpcTransport();
		const service = new UniverseAgentConnectionService({
			connectionResolver: plainFixtureResolver(),
			clientIdentityStore: plainFixtureIdentity(),
			createTransport: () => transport,
		});
		await connectPlainFixture(service);

		transport.taskUpdateResult = { ok: true, message: 'updated' };
		const result = await service.taskUpdate({
			sessionId: 'sess-1',
			agentId: 'agent-1',
			taskId: 'task-1',
			newStatus: 'COMPLETED',
			message: 'done',
		});
		assert.deepStrictEqual(transport.taskUpdateCalls, [{
			sessionId: 'sess-1',
			agentId: 'agent-1',
			taskId: 'task-1',
			newStatus: 'COMPLETED',
			message: 'done',
		}]);
		assert.deepStrictEqual(result, { ok: true, message: 'updated' });

		transport.taskUpdateResult = { ok: false, message: '' };
		const empty = await service.taskUpdate({
			sessionId: '',
			agentId: '',
			taskId: '',
			newStatus: '',
			message: '',
		});
		assert.deepStrictEqual(empty, { ok: false, message: '' });
		assert.strictEqual(transport.taskUpdateCalls[1]?.sessionId, '');
		assert.strictEqual(transport.taskUpdateCalls[1]?.agentId, '');
		assert.strictEqual(transport.taskUpdateCalls[1]?.taskId, '');
		assert.strictEqual(transport.taskUpdateCalls[1]?.newStatus, '');
		assert.strictEqual(transport.taskUpdateCalls[1]?.message, '');
		service.dispose();
	});

	test('taskCancel forwards request and maps result', async () => {
		const transport = new MockUniverseAgentGrpcTransport();
		const service = new UniverseAgentConnectionService({
			connectionResolver: plainFixtureResolver(),
			clientIdentityStore: plainFixtureIdentity(),
			createTransport: () => transport,
		});
		await connectPlainFixture(service);

		transport.taskCancelResult = { ok: true, message: 'cancelled' };
		const result = await service.taskCancel({
			sessionId: 'sess-1',
			agentId: 'agent-1',
			taskId: 'task-1',
		});
		assert.deepStrictEqual(transport.taskCancelCalls, [{
			sessionId: 'sess-1',
			agentId: 'agent-1',
			taskId: 'task-1',
		}]);
		assert.deepStrictEqual(result, { ok: true, message: 'cancelled' });

		transport.taskCancelResult = { ok: false, message: '' };
		const empty = await service.taskCancel({
			sessionId: '',
			agentId: '',
			taskId: '',
		});
		assert.deepStrictEqual(empty, { ok: false, message: '' });
		assert.strictEqual(transport.taskCancelCalls[1]?.sessionId, '');
		assert.strictEqual(transport.taskCancelCalls[1]?.agentId, '');
		assert.strictEqual(transport.taskCancelCalls[1]?.taskId, '');
		service.dispose();
	});

	test('messageMember forwards request and maps result', async () => {
		const transport = new MockUniverseAgentGrpcTransport();
		const service = new UniverseAgentConnectionService({
			connectionResolver: plainFixtureResolver(),
			clientIdentityStore: plainFixtureIdentity(),
			createTransport: () => transport,
		});
		await connectPlainFixture(service);

		transport.messageMemberResult = { ok: true, message: 'delivered' };
		const result = await service.messageMember({
			sessionId: 'sess-1',
			agentId: 'agent-1',
			memberName: 'worker',
			content: 'hello',
		});
		assert.deepStrictEqual(transport.messageMemberCalls, [{
			sessionId: 'sess-1',
			agentId: 'agent-1',
			memberName: 'worker',
			content: 'hello',
		}]);
		assert.deepStrictEqual(result, { ok: true, message: 'delivered' });

		transport.messageMemberResult = { ok: false, message: '' };
		const empty = await service.messageMember({
			sessionId: '',
			agentId: '',
			memberName: '',
			content: '',
		});
		assert.deepStrictEqual(empty, { ok: false, message: '' });
		assert.strictEqual(transport.messageMemberCalls[1]?.sessionId, '');
		assert.strictEqual(transport.messageMemberCalls[1]?.agentId, '');
		assert.strictEqual(transport.messageMemberCalls[1]?.memberName, '');
		assert.strictEqual(transport.messageMemberCalls[1]?.content, '');
		service.dispose();
	});

	test('createTeam forwards request and maps result', async () => {
		const transport = new MockUniverseAgentGrpcTransport();
		const service = new UniverseAgentConnectionService({
			connectionResolver: plainFixtureResolver(),
			clientIdentityStore: plainFixtureIdentity(),
			createTransport: () => transport,
		});
		await connectPlainFixture(service);

		transport.createTeamResult = { teamId: 7, memberCount: 3 };
		const result = await service.createTeam({
			sessionId: 'sess-1',
			agentId: 'agent-1',
			taskDescriptions: ['write tests', 'review'],
		});
		assert.deepStrictEqual(transport.createTeamCalls, [{
			sessionId: 'sess-1',
			agentId: 'agent-1',
			taskDescriptions: ['write tests', 'review'],
		}]);
		assert.deepStrictEqual(result, { teamId: 7, memberCount: 3 });

		transport.createTeamResult = { teamId: 0, memberCount: 0 };
		const empty = await service.createTeam({
			sessionId: '',
			agentId: '',
			taskDescriptions: ['', ''],
		});
		assert.deepStrictEqual(empty, { teamId: 0, memberCount: 0 });
		assert.strictEqual(transport.createTeamCalls[1]?.sessionId, '');
		assert.strictEqual(transport.createTeamCalls[1]?.agentId, '');
		assert.deepStrictEqual(transport.createTeamCalls[1]?.taskDescriptions, ['', '']);
		service.dispose();
	});

	test('getConfig forwards request and maps result', async () => {
		const transport = new MockUniverseAgentGrpcTransport();
		const service = new UniverseAgentConnectionService({
			connectionResolver: plainFixtureResolver(),
			clientIdentityStore: plainFixtureIdentity(),
			createTransport: () => transport,
		});
		await connectPlainFixture(service);

		transport.getConfigResult = { values: { 'model.id': 'fast' }, scope: 'session' };
		const result = await service.getConfig({
			key: 'model.id',
			scope: 'session',
			sessionId: 'sess-1',
		});
		assert.deepStrictEqual(transport.getConfigCalls, [{
			key: 'model.id',
			scope: 'session',
			sessionId: 'sess-1',
		}]);
		assert.deepStrictEqual(result, { values: { 'model.id': 'fast' }, scope: 'session' });

		transport.getConfigResult = { values: {}, scope: '' };
		const empty = await service.getConfig({
			key: '',
			scope: '',
			sessionId: '',
		});
		assert.deepStrictEqual(empty, { values: {}, scope: '' });
		assert.strictEqual(transport.getConfigCalls[1]?.key, '');
		assert.strictEqual(transport.getConfigCalls[1]?.scope, '');
		assert.strictEqual(transport.getConfigCalls[1]?.sessionId, '');
		service.dispose();
	});

	test('getModelPreferences forwards request and maps result', async () => {
		const transport = new MockUniverseAgentGrpcTransport();
		const service = new UniverseAgentConnectionService({
			connectionResolver: plainFixtureResolver(),
			clientIdentityStore: plainFixtureIdentity(),
			createTransport: () => transport,
		});
		await connectPlainFixture(service);

		transport.getModelPreferencesResult = {
			minLevel: 5,
			maxCost: 'middle',
			minSpeed: 'low',
			strategy: 'level',
		};
		const result = await service.getModelPreferences({
			sessionId: 'sess-1',
		});
		assert.deepStrictEqual(transport.getModelPreferencesCalls, [{
			sessionId: 'sess-1',
		}]);
		assert.deepStrictEqual(result, transport.getModelPreferencesResult);

		transport.getModelPreferencesResult = {
			minLevel: 0,
			maxCost: '',
			minSpeed: '',
			strategy: '',
		};
		const empty = await service.getModelPreferences({
			sessionId: '',
		});
		assert.deepStrictEqual(empty, transport.getModelPreferencesResult);
		assert.strictEqual(transport.getModelPreferencesCalls[1]?.sessionId, '');
		service.dispose();
	});

	test('startMember forwards request and maps result', async () => {
		const transport = new MockUniverseAgentGrpcTransport();
		const service = new UniverseAgentConnectionService({
			connectionResolver: plainFixtureResolver(),
			clientIdentityStore: plainFixtureIdentity(),
			createTransport: () => transport,
		});
		await connectPlainFixture(service);

		transport.startMemberResult = { memberAgentId: 'member-1', memberName: 'worker', dynamic: true };
		const result = await service.startMember({
			sessionId: 'sess-1',
			agentId: 'agent-1',
			memberName: 'worker',
			presetId: 'preset-1',
			systemPrompt: 'do work',
			modelType: 'fast',
			dynamic: true,
		});
		assert.deepStrictEqual(transport.startMemberCalls, [{
			sessionId: 'sess-1',
			agentId: 'agent-1',
			memberName: 'worker',
			presetId: 'preset-1',
			systemPrompt: 'do work',
			modelType: 'fast',
			dynamic: true,
		}]);
		assert.deepStrictEqual(result, { memberAgentId: 'member-1', memberName: 'worker', dynamic: true });

		transport.startMemberResult = { memberAgentId: '', memberName: '', dynamic: false };
		const empty = await service.startMember({
			sessionId: '',
			agentId: '',
			memberName: '',
			presetId: '',
			systemPrompt: '',
			modelType: '',
			dynamic: false,
		});
		assert.deepStrictEqual(empty, { memberAgentId: '', memberName: '', dynamic: false });
		assert.strictEqual(transport.startMemberCalls[1]?.sessionId, '');
		assert.strictEqual(transport.startMemberCalls[1]?.agentId, '');
		assert.strictEqual(transport.startMemberCalls[1]?.memberName, '');
		assert.strictEqual(transport.startMemberCalls[1]?.presetId, '');
		assert.strictEqual(transport.startMemberCalls[1]?.systemPrompt, '');
		assert.strictEqual(transport.startMemberCalls[1]?.modelType, '');
		assert.strictEqual(transport.startMemberCalls[1]?.dynamic, false);
		service.dispose();
	});

	test('killMember forwards request and maps result', async () => {
		const transport = new MockUniverseAgentGrpcTransport();
		const service = new UniverseAgentConnectionService({
			connectionResolver: plainFixtureResolver(),
			clientIdentityStore: plainFixtureIdentity(),
			createTransport: () => transport,
		});
		await connectPlainFixture(service);

		transport.killMemberResult = { ok: true, message: 'stopped' };
		const result = await service.killMember({
			sessionId: 'sess-1',
			agentId: 'agent-1',
			memberName: 'worker',
		});
		assert.deepStrictEqual(transport.killMemberCalls, [{
			sessionId: 'sess-1',
			agentId: 'agent-1',
			memberName: 'worker',
		}]);
		assert.deepStrictEqual(result, { ok: true, message: 'stopped' });

		transport.killMemberResult = { ok: false, message: '' };
		const empty = await service.killMember({
			sessionId: '',
			agentId: '',
			memberName: '',
		});
		assert.deepStrictEqual(empty, { ok: false, message: '' });
		assert.strictEqual(transport.killMemberCalls[1]?.sessionId, '');
		assert.strictEqual(transport.killMemberCalls[1]?.agentId, '');
		assert.strictEqual(transport.killMemberCalls[1]?.memberName, '');
		service.dispose();
	});

	test('abort forwards request and maps result', async () => {
		const transport = new MockUniverseAgentGrpcTransport();
		const service = new UniverseAgentConnectionService({
			connectionResolver: plainFixtureResolver(),
			clientIdentityStore: plainFixtureIdentity(),
			createTransport: () => transport,
		});
		await connectPlainFixture(service);

		transport.abortResult = { ok: true, message: 'aborted', stoppedMembers: ['worker'] };
		const result = await service.abort({
			sessionId: 'sess-1',
			agentId: 'agent-1',
			teamId: 7,
			reason: 'stop',
		});
		assert.deepStrictEqual(transport.abortCalls, [{
			sessionId: 'sess-1',
			agentId: 'agent-1',
			teamId: 7,
			reason: 'stop',
		}]);
		assert.deepStrictEqual(result, { ok: true, message: 'aborted', stoppedMembers: ['worker'] });

		transport.abortResult = { ok: false, message: '', stoppedMembers: [] };
		const empty = await service.abort({
			sessionId: '',
			agentId: '',
			teamId: 0,
			reason: '',
		});
		assert.deepStrictEqual(empty, { ok: false, message: '', stoppedMembers: [] });
		assert.strictEqual(transport.abortCalls[1]?.sessionId, '');
		assert.strictEqual(transport.abortCalls[1]?.agentId, '');
		assert.strictEqual(transport.abortCalls[1]?.teamId, 0);
		assert.strictEqual(transport.abortCalls[1]?.reason, '');
		service.dispose();
	});

	test('switchModel forwards request and maps result', async () => {
		const transport = new MockUniverseAgentGrpcTransport();
		const service = new UniverseAgentConnectionService({
			connectionResolver: plainFixtureResolver(),
			clientIdentityStore: plainFixtureIdentity(),
			createTransport: () => transport,
		});
		await connectPlainFixture(service);

		transport.switchModelResult = {
			resolvedModelId: 'claude-sonnet',
			provider: 'anthropic',
			level: 7,
			cost: 'middle',
			speed: 'fast',
		};
		const result = await service.switchModel({
			sessionId: 'sess-1',
			agentId: 'root',
			modelType: 'quality',
			modelId: '',
		});
		assert.deepStrictEqual(transport.switchModelCalls, [{
			sessionId: 'sess-1',
			agentId: 'root',
			modelType: 'quality',
			modelId: '',
		}]);
		assert.deepStrictEqual(result, {
			resolvedModelId: 'claude-sonnet',
			provider: 'anthropic',
			level: 7,
			cost: 'middle',
			speed: 'fast',
		});

		transport.switchModelResult = {
			resolvedModelId: '',
			provider: '',
			level: 0,
			cost: '',
			speed: '',
		};
		const empty = await service.switchModel({
			sessionId: '',
			agentId: '',
			modelType: '',
			modelId: '',
		});
		assert.deepStrictEqual(empty, {
			resolvedModelId: '',
			provider: '',
			level: 0,
			cost: '',
			speed: '',
		});
		assert.strictEqual(transport.switchModelCalls[1]?.sessionId, '');
		assert.strictEqual(transport.switchModelCalls[1]?.agentId, '');
		assert.strictEqual(transport.switchModelCalls[1]?.modelType, '');
		assert.strictEqual(transport.switchModelCalls[1]?.modelId, '');
		service.dispose();
	});

	test('resolveModel forwards request and maps result', async () => {
		const transport = new MockUniverseAgentGrpcTransport();
		const service = new UniverseAgentConnectionService({
			connectionResolver: plainFixtureResolver(),
			clientIdentityStore: plainFixtureIdentity(),
			createTransport: () => transport,
		});
		await connectPlainFixture(service);

		transport.resolveModelResult = {
			selected: {
				id: 'claude-sonnet',
				type: 'quality',
				enabled: true,
				level: 7,
				provider: 'anthropic',
				modelId: 'claude-sonnet-4',
			},
			candidates: [{
				id: 'claude-sonnet',
				type: 'quality',
				enabled: true,
				level: 7,
				provider: 'anthropic',
				modelId: 'claude-sonnet-4',
			}],
			filtered: [{
				id: 'haiku',
				type: 'fast',
				enabled: true,
				level: 3,
				provider: 'anthropic',
				modelId: 'claude-haiku',
			}],
		};
		const result = await service.resolveModel({
			sessionId: 'sess-1',
			type: 'quality',
		});
		assert.deepStrictEqual(transport.resolveModelCalls, [{
			sessionId: 'sess-1',
			type: 'quality',
		}]);
		assert.deepStrictEqual(result, transport.resolveModelResult);

		transport.resolveModelResult = { candidates: [], filtered: [] };
		const empty = await service.resolveModel({
			sessionId: '',
			type: '',
		});
		assert.deepStrictEqual(empty, { candidates: [], filtered: [] });
		assert.strictEqual(transport.resolveModelCalls[1]?.sessionId, '');
		assert.strictEqual(transport.resolveModelCalls[1]?.type, '');
		service.dispose();
	});

	test('listCommands forwards request and maps result', async () => {
		const transport = new MockUniverseAgentGrpcTransport();
		const service = new UniverseAgentConnectionService({
			connectionResolver: plainFixtureResolver(),
			clientIdentityStore: plainFixtureIdentity(),
			createTransport: () => transport,
		});
		await connectPlainFixture(service);

		transport.listCommandsResult = {
			commands: [{
				name: 'review',
				description: 'Review the diff',
				source: 'SLASH_COMMAND_SOURCE_SKILL',
				slashEnabled: true,
				agent: 'code',
				model: 'default',
				subtask: false,
				skillSource: 'user',
			}],
			total: 1,
		};
		const result = await service.listCommands();
		assert.strictEqual(transport.listCommandsCalls, 1);
		assert.deepStrictEqual(result, transport.listCommandsResult);

		transport.listCommandsResult = {
			commands: [{
				name: '',
				description: '',
				source: '',
				slashEnabled: false,
				agent: '',
				model: '',
				subtask: false,
				skillSource: '',
			}],
			total: 0,
		};
		const empty = await service.listCommands();
		assert.strictEqual(transport.listCommandsCalls, 2);
		assert.strictEqual(empty.commands[0]?.name, '');
		assert.strictEqual(empty.commands[0]?.agent, '');
		assert.strictEqual(empty.commands[0]?.model, '');
		assert.strictEqual(empty.commands[0]?.skillSource, '');
		assert.strictEqual(empty.commands[0]?.source, '');
		assert.strictEqual(empty.total, 0);
		service.dispose();
	});

	test('getCommandDef forwards request and maps result', async () => {
		const transport = new MockUniverseAgentGrpcTransport();
		const service = new UniverseAgentConnectionService({
			connectionResolver: plainFixtureResolver(),
			clientIdentityStore: plainFixtureIdentity(),
			createTransport: () => transport,
		});
		await connectPlainFixture(service);

		transport.getCommandDefResult = {
			name: 'review',
			description: 'Review the diff',
			source: 'SLASH_COMMAND_SOURCE_SKILL',
			template: 'Review $ARGUMENTS',
			agent: 'code',
			model: 'default',
			subtask: false,
			mcpServerId: 'mcp-1',
			mcpPromptName: 'review',
			mcpArgumentNames: ['path'],
			skillSource: 'user',
		};
		const result = await service.getCommandDef({ commandName: 'review' });
		assert.deepStrictEqual(transport.getCommandDefCalls, [{ commandName: 'review' }]);
		assert.deepStrictEqual(result, transport.getCommandDefResult);

		transport.getCommandDefResult = {
			name: '',
			description: '',
			source: '',
			template: '',
			agent: '',
			model: '',
			subtask: false,
			mcpServerId: '',
			mcpPromptName: '',
			mcpArgumentNames: [],
			skillSource: '',
		};
		const empty = await service.getCommandDef({ commandName: '' });
		assert.strictEqual(transport.getCommandDefCalls[1]?.commandName, '');
		assert.strictEqual(empty.name, '');
		assert.strictEqual(empty.agent, '');
		assert.strictEqual(empty.model, '');
		assert.strictEqual(empty.template, '');
		assert.strictEqual(empty.mcpServerId, '');
		assert.strictEqual(empty.mcpPromptName, '');
		assert.strictEqual(empty.skillSource, '');
		assert.strictEqual(empty.source, '');
		assert.deepStrictEqual(empty.mcpArgumentNames, []);
		service.dispose();
	});

	test('listFiles forwards request and maps result', async () => {
		const transport = new MockUniverseAgentGrpcTransport();
		const service = new UniverseAgentConnectionService({
			connectionResolver: plainFixtureResolver(),
			clientIdentityStore: plainFixtureIdentity(),
			createTransport: () => transport,
		});
		await connectPlainFixture(service);

		transport.listFilesResult = {
			entries: [{
				name: 'readme.md',
				path: 'docs/readme.md',
				isDirectory: false,
				size: 128,
				lastModified: 1_700_000_000,
				mimeType: 'text/markdown',
			}],
			total: 1,
		};
		const result = await service.listFiles({
			path: 'docs',
			sessionId: 's1',
			recursive: true,
			pattern: '*.md',
			maxResults: 50,
		});
		assert.deepStrictEqual(transport.listFilesCalls, [{
			path: 'docs',
			sessionId: 's1',
			recursive: true,
			pattern: '*.md',
			maxResults: 50,
		}]);
		assert.deepStrictEqual(result, transport.listFilesResult);

		transport.listFilesResult = {
			entries: [{
				name: '',
				path: '',
				isDirectory: false,
				size: 0,
				lastModified: 0,
				mimeType: '',
			}],
			total: 0,
		};
		const empty = await service.listFiles({
			path: '',
			sessionId: '',
			recursive: false,
			pattern: '',
			maxResults: 0,
		});
		assert.strictEqual(transport.listFilesCalls[1]?.path, '');
		assert.strictEqual(transport.listFilesCalls[1]?.sessionId, '');
		assert.strictEqual(transport.listFilesCalls[1]?.pattern, '');
		assert.strictEqual(transport.listFilesCalls[1]?.recursive, false);
		assert.strictEqual(transport.listFilesCalls[1]?.maxResults, 0);
		assert.strictEqual(empty.entries[0]?.name, '');
		assert.strictEqual(empty.entries[0]?.path, '');
		assert.strictEqual(empty.entries[0]?.mimeType, '');
		assert.strictEqual(empty.total, 0);
		service.dispose();
	});

	test('readFile forwards request and maps result', async () => {
		const transport = new MockUniverseAgentGrpcTransport();
		const service = new UniverseAgentConnectionService({
			connectionResolver: plainFixtureResolver(),
			clientIdentityStore: plainFixtureIdentity(),
			createTransport: () => transport,
		});
		await connectPlainFixture(service);

		transport.readFileResult = {
			content: new Uint8Array([97, 98, 99]),
			totalSize: 3,
			mimeType: 'text/plain',
			lineCount: 1,
			contentHash: 'abc',
		};
		const request = { path: 'src/foo.ts', sessionId: 'sess-1', startLine: 1, endLine: 10, maxBytes: 1024 };
		const result = await service.readFile(request);
		assert.deepStrictEqual(transport.readFileCalls, [request]);
		assert.deepStrictEqual(result, transport.readFileResult);

		transport.readFileResult = {
			content: new Uint8Array(0),
			totalSize: 0,
			mimeType: '',
			lineCount: 0,
			contentHash: '',
		};
		const emptyRequest = { path: '', sessionId: '', startLine: 0, endLine: 0, maxBytes: 0 };
		const empty = await service.readFile(emptyRequest);
		assert.strictEqual(transport.readFileCalls[1]?.path, '');
		assert.strictEqual(transport.readFileCalls[1]?.sessionId, '');
		assert.strictEqual(transport.readFileCalls[1]?.startLine, 0);
		assert.strictEqual(transport.readFileCalls[1]?.endLine, 0);
		assert.strictEqual(transport.readFileCalls[1]?.maxBytes, 0);
		assert.deepStrictEqual(empty.content, new Uint8Array(0));
		assert.strictEqual(empty.mimeType, '');
		assert.strictEqual(empty.contentHash, '');
		service.dispose();
	});

	test('getFileInfo forwards request and maps result', async () => {
		const transport = new MockUniverseAgentGrpcTransport();
		const service = new UniverseAgentConnectionService({
			connectionResolver: plainFixtureResolver(),
			clientIdentityStore: plainFixtureIdentity(),
			createTransport: () => transport,
		});
		await connectPlainFixture(service);

		transport.getFileInfoResult = {
			file: {
				name: 'readme.md',
				path: 'docs/readme.md',
				isDirectory: false,
				size: 128,
				lastModified: 1_700_000_000,
				mimeType: 'text/markdown',
			},
		};
		const request = { path: 'docs/readme.md', sessionId: 'sess-1' };
		const result = await service.getFileInfo(request);
		assert.deepStrictEqual(transport.getFileInfoCalls, [request]);
		assert.deepStrictEqual(result, transport.getFileInfoResult);

		transport.getFileInfoResult = {
			file: {
				name: '',
				path: '',
				isDirectory: false,
				size: 0,
				lastModified: 0,
				mimeType: '',
			},
		};
		const emptyRequest = { path: '', sessionId: '' };
		const empty = await service.getFileInfo(emptyRequest);
		assert.strictEqual(transport.getFileInfoCalls[1]?.path, '');
		assert.strictEqual(transport.getFileInfoCalls[1]?.sessionId, '');
		assert.strictEqual(empty.file.name, '');
		assert.strictEqual(empty.file.path, '');
		assert.strictEqual(empty.file.mimeType, '');
		assert.strictEqual(empty.file.isDirectory, false);
		assert.strictEqual(empty.file.size, 0);
		assert.strictEqual(empty.file.lastModified, 0);
		service.dispose();
	});

	test('writeFile forwards request and maps result', async () => {
		const transport = new MockUniverseAgentGrpcTransport();
		const service = new UniverseAgentConnectionService({
			connectionResolver: plainFixtureResolver(),
			clientIdentityStore: plainFixtureIdentity(),
			createTransport: () => transport,
		});
		await connectPlainFixture(service);

		transport.writeFileResult = {
			status: 'SAVED',
			newHash: 'hash-1',
			size: 3,
			modifiedAt: 100,
			currentContent: new Uint8Array([97, 98, 99]),
			currentHash: 'hash-1',
			mergedContent: new Uint8Array(0),
		};
		const writeRequest = {
			path: 'src/foo.ts',
			content: new Uint8Array([97, 98, 99]),
			baseHash: 'base-1',
			sessionId: 'sess-1',
			baseContent: new Uint8Array([97]),
		};
		const writeResult = await service.writeFile(writeRequest);
		assert.deepStrictEqual(transport.writeFileCalls, [writeRequest]);
		assert.deepStrictEqual(writeResult, transport.writeFileResult);

		transport.writeFileResult = {
			status: 'SAVED',
			newHash: '',
			size: 0,
			modifiedAt: 0,
			currentContent: new Uint8Array(0),
			currentHash: '',
			mergedContent: new Uint8Array(0),
		};
		const writeEmptyRequest = {
			path: '',
			content: new Uint8Array(0),
			baseHash: '',
			sessionId: '',
			baseContent: new Uint8Array(0),
		};
		const writeEmpty = await service.writeFile(writeEmptyRequest);
		assert.strictEqual(transport.writeFileCalls[1]?.path, '');
		assert.strictEqual(transport.writeFileCalls[1]?.sessionId, '');
		assert.strictEqual(transport.writeFileCalls[1]?.baseHash, '');
		assert.deepStrictEqual(transport.writeFileCalls[1]?.content, new Uint8Array(0));
		assert.deepStrictEqual(transport.writeFileCalls[1]?.baseContent, new Uint8Array(0));
		assert.strictEqual(writeEmpty.status, 'SAVED');
		assert.strictEqual(writeEmpty.newHash, '');
		assert.strictEqual(writeEmpty.currentHash, '');
		assert.deepStrictEqual(writeEmpty.currentContent, new Uint8Array(0));
		assert.deepStrictEqual(writeEmpty.mergedContent, new Uint8Array(0));
		service.dispose();
	});

	test('forceWriteFile forwards request and maps result', async () => {
		const transport = new MockUniverseAgentGrpcTransport();
		const service = new UniverseAgentConnectionService({
			connectionResolver: plainFixtureResolver(),
			clientIdentityStore: plainFixtureIdentity(),
			createTransport: () => transport,
		});
		await connectPlainFixture(service);

		transport.forceWriteFileResult = {
			status: 'SAVED',
			newHash: 'hash-1',
			size: 3,
			modifiedAt: 100,
			currentContent: new Uint8Array([97, 98, 99]),
			currentHash: 'hash-1',
			mergedContent: new Uint8Array(0),
		};
		const forceRequest = {
			path: 'src/foo.ts',
			content: new Uint8Array([97, 98, 99]),
			sessionId: 'sess-1',
		};
		const forceResult = await service.forceWriteFile(forceRequest);
		assert.deepStrictEqual(transport.forceWriteFileCalls, [forceRequest]);
		assert.deepStrictEqual(forceResult, transport.forceWriteFileResult);

		transport.forceWriteFileResult = {
			status: 'SAVED',
			newHash: '',
			size: 0,
			modifiedAt: 0,
			currentContent: new Uint8Array(0),
			currentHash: '',
			mergedContent: new Uint8Array(0),
		};
		const forceEmptyRequest = {
			path: '',
			content: new Uint8Array(0),
			sessionId: '',
		};
		const forceEmpty = await service.forceWriteFile(forceEmptyRequest);
		assert.strictEqual(transport.forceWriteFileCalls[1]?.path, '');
		assert.strictEqual(transport.forceWriteFileCalls[1]?.sessionId, '');
		assert.deepStrictEqual(transport.forceWriteFileCalls[1]?.content, new Uint8Array(0));
		assert.strictEqual(forceEmpty.status, 'SAVED');
		assert.strictEqual(forceEmpty.newHash, '');
		assert.strictEqual(forceEmpty.currentHash, '');
		assert.deepStrictEqual(forceEmpty.currentContent, new Uint8Array(0));
		assert.deepStrictEqual(forceEmpty.mergedContent, new Uint8Array(0));
		service.dispose();
	});

	test('agentMerge forwards request and maps result', async () => {
		const transport = new MockUniverseAgentGrpcTransport();
		const service = new UniverseAgentConnectionService({
			connectionResolver: plainFixtureResolver(),
			clientIdentityStore: plainFixtureIdentity(),
			createTransport: () => transport,
		});
		await connectPlainFixture(service);

		transport.agentMergeResult = { accepted: true };
		const mergeRequest = {
			sessionId: 'sess-1',
			path: 'src/foo.ts',
			baseContent: new Uint8Array([97]),
			currentContent: new Uint8Array([98]),
			userContent: new Uint8Array([99]),
		};
		const mergeResult = await service.agentMerge(mergeRequest);
		assert.deepStrictEqual(transport.agentMergeCalls, [mergeRequest]);
		assert.deepStrictEqual(mergeResult, transport.agentMergeResult);

		transport.agentMergeResult = { accepted: false };
		const mergeEmptyRequest = {
			sessionId: '',
			path: '',
			baseContent: new Uint8Array(0),
			currentContent: new Uint8Array(0),
			userContent: new Uint8Array(0),
		};
		const mergeEmpty = await service.agentMerge(mergeEmptyRequest);
		assert.strictEqual(transport.agentMergeCalls[1]?.sessionId, '');
		assert.strictEqual(transport.agentMergeCalls[1]?.path, '');
		assert.deepStrictEqual(transport.agentMergeCalls[1]?.baseContent, new Uint8Array(0));
		assert.deepStrictEqual(transport.agentMergeCalls[1]?.currentContent, new Uint8Array(0));
		assert.deepStrictEqual(transport.agentMergeCalls[1]?.userContent, new Uint8Array(0));
		assert.strictEqual(mergeEmpty.accepted, false);
		service.dispose();
	});

	test('readGitSummary forwards request and maps result', async () => {
		const transport = new MockUniverseAgentGrpcTransport();
		const service = new UniverseAgentConnectionService({
			connectionResolver: plainFixtureResolver(),
			clientIdentityStore: plainFixtureIdentity(),
			createTransport: () => transport,
		});
		await connectPlainFixture(service);

		transport.readGitSummaryResult = {
			supported: true,
			reason: '',
			branch: 'loop/A',
			changeCount: 3,
		};
		const request = { sessionId: 'sess-1' };
		const result = await service.readGitSummary(request);
		assert.deepStrictEqual(transport.readGitSummaryCalls, [request]);
		assert.deepStrictEqual(result, transport.readGitSummaryResult);

		transport.readGitSummaryResult = {
			supported: false,
			reason: '',
			branch: '',
			changeCount: 0,
		};
		const emptyRequest = { sessionId: '' };
		const empty = await service.readGitSummary(emptyRequest);
		assert.strictEqual(transport.readGitSummaryCalls[1]?.sessionId, '');
		assert.strictEqual(empty.supported, false);
		assert.strictEqual(empty.reason, '');
		assert.strictEqual(empty.branch, '');
		assert.strictEqual(empty.changeCount, 0);
		service.dispose();
	});

	test('readGitChanges forwards request and maps result', async () => {
		const transport = new MockUniverseAgentGrpcTransport();
		const service = new UniverseAgentConnectionService({
			connectionResolver: plainFixtureResolver(),
			clientIdentityStore: plainFixtureIdentity(),
			createTransport: () => transport,
		});
		await connectPlainFixture(service);

		transport.readGitChangesResult = {
			supported: true,
			reason: '',
			branch: 'main',
			entries: [{
				path: 'src/foo.ts',
				oldPath: '',
				kind: 'modified',
				indexState: 'unstaged',
			}],
		};
		const changesRequest = { sessionId: 'sess-1' };
		const changesResult = await service.readGitChanges(changesRequest);
		assert.deepStrictEqual(transport.readGitChangesCalls, [changesRequest]);
		assert.deepStrictEqual(changesResult, transport.readGitChangesResult);

		transport.readGitChangesResult = {
			supported: false,
			reason: '',
			branch: '',
			entries: [{
				path: '',
				oldPath: '',
				kind: '',
				indexState: '',
			}],
		};
		const changesEmptyRequest = { sessionId: '' };
		const changesEmpty = await service.readGitChanges(changesEmptyRequest);
		assert.strictEqual(transport.readGitChangesCalls[1]?.sessionId, '');
		assert.strictEqual(changesEmpty.supported, false);
		assert.strictEqual(changesEmpty.reason, '');
		assert.strictEqual(changesEmpty.branch, '');
		assert.strictEqual(changesEmpty.entries[0]?.path, '');
		assert.strictEqual(changesEmpty.entries[0]?.oldPath, '');
		assert.strictEqual(changesEmpty.entries[0]?.kind, '');
		assert.strictEqual(changesEmpty.entries[0]?.indexState, '');
		service.dispose();
	});

	test('readGitFileDiff forwards request and maps result', async () => {
		const transport = new MockUniverseAgentGrpcTransport();
		const service = new UniverseAgentConnectionService({
			connectionResolver: plainFixtureResolver(),
			clientIdentityStore: plainFixtureIdentity(),
			createTransport: () => transport,
		});
		await connectPlainFixture(service);

		transport.readGitFileDiffResult = {
			supported: true,
			reason: '',
			path: 'src/foo.ts',
			unifiedDiff: 'diff --git a/src/foo.ts b/src/foo.ts\n',
		};
		const request = { sessionId: 'sess-1', path: 'src/foo.ts', indexState: 'unstaged' };
		const result = await service.readGitFileDiff(request);
		assert.deepStrictEqual(transport.readGitFileDiffCalls, [request]);
		assert.deepStrictEqual(result, transport.readGitFileDiffResult);

		transport.readGitFileDiffResult = {
			supported: false,
			reason: '',
			path: '',
			unifiedDiff: '',
		};
		const emptyRequest = { sessionId: '', path: '', indexState: '' };
		const empty = await service.readGitFileDiff(emptyRequest);
		assert.strictEqual(transport.readGitFileDiffCalls[1]?.sessionId, '');
		assert.strictEqual(transport.readGitFileDiffCalls[1]?.path, '');
		assert.strictEqual(transport.readGitFileDiffCalls[1]?.indexState, '');
		assert.strictEqual(empty.supported, false);
		assert.strictEqual(empty.reason, '');
		assert.strictEqual(empty.path, '');
		assert.strictEqual(empty.unifiedDiff, '');
		service.dispose();
	});

	test('writeGitStagePaths forwards request and maps result', async () => {
		const transport = new MockUniverseAgentGrpcTransport();
		const service = new UniverseAgentConnectionService({
			connectionResolver: plainFixtureResolver(),
			clientIdentityStore: plainFixtureIdentity(),
			createTransport: () => transport,
		});
		await connectPlainFixture(service);

		transport.writeGitStagePathsResult = {
			supported: true,
			reason: '',
			success: true,
			errorMessage: '',
			exitCode: 0,
			stdout: 'staged',
		};
		const request = {
			sessionId: 'sess-1',
			commands: [{ argv: ['add', 'src/foo.ts'] }],
		};
		const result = await service.writeGitStagePaths(request);
		assert.deepStrictEqual(transport.writeGitStagePathsCalls, [request]);
		assert.deepStrictEqual(result, transport.writeGitStagePathsResult);

		transport.writeGitStagePathsResult = {
			supported: false,
			reason: '',
			success: false,
			errorMessage: '',
			exitCode: 0,
			stdout: '',
		};
		const emptyRequest = {
			sessionId: '',
			commands: [{ argv: [] }],
		};
		const empty = await service.writeGitStagePaths(emptyRequest);
		assert.strictEqual(transport.writeGitStagePathsCalls[1]?.sessionId, '');
		assert.deepStrictEqual(transport.writeGitStagePathsCalls[1]?.commands, [{ argv: [] }]);
		assert.strictEqual(empty.supported, false);
		assert.strictEqual(empty.reason, '');
		assert.strictEqual(empty.success, false);
		assert.strictEqual(empty.errorMessage, '');
		assert.strictEqual(empty.exitCode, 0);
		assert.strictEqual(empty.stdout, '');

		const emptyCommandsRequest = {
			sessionId: '',
			commands: [],
		};
		await service.writeGitStagePaths(emptyCommandsRequest);
		assert.strictEqual(transport.writeGitStagePathsCalls[2]?.sessionId, '');
		assert.deepStrictEqual(transport.writeGitStagePathsCalls[2]?.commands, []);
		service.dispose();
	});

	test('writeGitCommit forwards request and maps result', async () => {
		const transport = new MockUniverseAgentGrpcTransport();
		const service = new UniverseAgentConnectionService({
			connectionResolver: plainFixtureResolver(),
			clientIdentityStore: plainFixtureIdentity(),
			createTransport: () => transport,
		});
		await connectPlainFixture(service);

		transport.writeGitCommitResult = {
			supported: true,
			reason: '',
			success: true,
			errorMessage: '',
			exitCode: 0,
			stdout: 'committed',
		};
		const request = {
			sessionId: 'sess-1',
			message: 'fix: wire write',
			signOff: true,
			amend: false,
		};
		const result = await service.writeGitCommit(request);
		assert.deepStrictEqual(transport.writeGitCommitCalls, [request]);
		assert.deepStrictEqual(result, transport.writeGitCommitResult);

		transport.writeGitCommitResult = {
			supported: false,
			reason: '',
			success: false,
			errorMessage: '',
			exitCode: 0,
			stdout: '',
		};
		const emptyRequest = {
			sessionId: '',
			message: '',
			signOff: false,
			amend: false,
		};
		const empty = await service.writeGitCommit(emptyRequest);
		assert.strictEqual(transport.writeGitCommitCalls[1]?.sessionId, '');
		assert.strictEqual(transport.writeGitCommitCalls[1]?.message, '');
		assert.strictEqual(transport.writeGitCommitCalls[1]?.signOff, false);
		assert.strictEqual(transport.writeGitCommitCalls[1]?.amend, false);
		assert.strictEqual(empty.supported, false);
		assert.strictEqual(empty.reason, '');
		assert.strictEqual(empty.success, false);
		assert.strictEqual(empty.errorMessage, '');
		assert.strictEqual(empty.exitCode, 0);
		assert.strictEqual(empty.stdout, '');
		service.dispose();
	});

	test('writeGitApplyHunks forwards request and maps result', async () => {
		const transport = new MockUniverseAgentGrpcTransport();
		const service = new UniverseAgentConnectionService({
			connectionResolver: plainFixtureResolver(),
			clientIdentityStore: plainFixtureIdentity(),
			createTransport: () => transport,
		});
		await connectPlainFixture(service);

		transport.writeGitApplyHunksResult = {
			supported: true,
			reason: '',
			success: true,
			errorMessage: '',
			exitCode: 0,
			stdout: 'applied',
		};
		const request = {
			sessionId: 'sess-1',
			argv: ['apply', '--cached'],
			patches: ['diff --git a/src/foo.ts b/src/foo.ts\n'],
		};
		const result = await service.writeGitApplyHunks(request);
		assert.deepStrictEqual(transport.writeGitApplyHunksCalls, [request]);
		assert.deepStrictEqual(result, transport.writeGitApplyHunksResult);

		transport.writeGitApplyHunksResult = {
			supported: false,
			reason: '',
			success: false,
			errorMessage: '',
			exitCode: 0,
			stdout: '',
		};
		const emptyRequest = {
			sessionId: '',
			argv: [''],
			patches: [''],
		};
		const empty = await service.writeGitApplyHunks(emptyRequest);
		assert.strictEqual(transport.writeGitApplyHunksCalls[1]?.sessionId, '');
		assert.deepStrictEqual(transport.writeGitApplyHunksCalls[1]?.argv, ['']);
		assert.deepStrictEqual(transport.writeGitApplyHunksCalls[1]?.patches, ['']);
		assert.strictEqual(empty.supported, false);
		assert.strictEqual(empty.reason, '');
		assert.strictEqual(empty.success, false);
		assert.strictEqual(empty.errorMessage, '');
		assert.strictEqual(empty.exitCode, 0);
		assert.strictEqual(empty.stdout, '');

		const emptyListsRequest = {
			sessionId: '',
			argv: [],
			patches: [],
		};
		await service.writeGitApplyHunks(emptyListsRequest);
		assert.strictEqual(transport.writeGitApplyHunksCalls[2]?.sessionId, '');
		assert.deepStrictEqual(transport.writeGitApplyHunksCalls[2]?.argv, []);
		assert.deepStrictEqual(transport.writeGitApplyHunksCalls[2]?.patches, []);
		service.dispose();
	});

	test('getSessionUsage forwards request and maps result', async () => {
		const transport = new MockUniverseAgentGrpcTransport();
		const service = new UniverseAgentConnectionService({
			connectionResolver: plainFixtureResolver(),
			clientIdentityStore: plainFixtureIdentity(),
			createTransport: () => transport,
		});
		await connectPlainFixture(service);

		transport.getSessionUsageResult = {
			usage: {
				inputTokens: 12,
				outputTokens: 34,
				thinkingTokens: 5,
				cacheReadTokens: 6,
				cacheWriteTokens: 7,
				totalCostMicros: 890,
				currency: 'USD',
				requestCount: 3,
			},
		};
		const request = { sessionId: 'sess-1' };
		const result = await service.getSessionUsage(request);
		assert.deepStrictEqual(transport.getSessionUsageCalls, [request]);
		assert.deepStrictEqual(result, transport.getSessionUsageResult);

		transport.getSessionUsageResult = {
			usage: {
				inputTokens: 0,
				outputTokens: 0,
				thinkingTokens: 0,
				cacheReadTokens: 0,
				cacheWriteTokens: 0,
				totalCostMicros: 0,
				currency: '',
				requestCount: 0,
			},
		};
		const emptyRequest = { sessionId: '' };
		const empty = await service.getSessionUsage(emptyRequest);
		assert.strictEqual(transport.getSessionUsageCalls[1]?.sessionId, '');
		assert.strictEqual(empty.usage.inputTokens, 0);
		assert.strictEqual(empty.usage.outputTokens, 0);
		assert.strictEqual(empty.usage.thinkingTokens, 0);
		assert.strictEqual(empty.usage.cacheReadTokens, 0);
		assert.strictEqual(empty.usage.cacheWriteTokens, 0);
		assert.strictEqual(empty.usage.totalCostMicros, 0);
		assert.strictEqual(empty.usage.currency, '');
		assert.strictEqual(empty.usage.requestCount, 0);
		service.dispose();
	});

	test('getGlobalUsage forwards empty request and maps result', async () => {
		const transport = new MockUniverseAgentGrpcTransport();
		const service = new UniverseAgentConnectionService({
			connectionResolver: plainFixtureResolver(),
			clientIdentityStore: plainFixtureIdentity(),
			createTransport: () => transport,
		});
		await connectPlainFixture(service);

		transport.getGlobalUsageResult = {
			usage: {
				inputTokens: 11,
				outputTokens: 22,
				thinkingTokens: 3,
				cacheReadTokens: 4,
				cacheWriteTokens: 5,
				totalCostMicros: 600,
				currency: 'USD',
				requestCount: 7,
			},
		};
		const result = await service.getGlobalUsage();
		assert.strictEqual(transport.getGlobalUsageCalls, 1);
		assert.deepStrictEqual(result, transport.getGlobalUsageResult);

		transport.getGlobalUsageResult = {
			usage: {
				inputTokens: 0,
				outputTokens: 0,
				thinkingTokens: 0,
				cacheReadTokens: 0,
				cacheWriteTokens: 0,
				totalCostMicros: 0,
				currency: '',
				requestCount: 0,
			},
		};
		const empty = await service.getGlobalUsage();
		assert.strictEqual(transport.getGlobalUsageCalls, 2);
		assert.strictEqual(empty.usage.currency, '');
		assert.strictEqual(empty.usage.inputTokens, 0);
		assert.strictEqual(empty.usage.requestCount, 0);
		service.dispose();
	});

	test('saveMemory forwards request and maps result', async () => {
		const transport = new MockUniverseAgentGrpcTransport();
		const service = new UniverseAgentConnectionService({
			connectionResolver: plainFixtureResolver(),
			clientIdentityStore: plainFixtureIdentity(),
			createTransport: () => transport,
		});
		await connectPlainFixture(service);

		transport.saveMemoryResult = {
			success: true,
			message: 'saved',
			filePath: 'project/notes.md',
		};
		const request = {
			scope: 'project',
			content: 'remember this',
			category: 'notes',
		};
		const result = await service.saveMemory(request);
		assert.deepStrictEqual(transport.saveMemoryCalls, [request]);
		assert.deepStrictEqual(result, transport.saveMemoryResult);

		transport.saveMemoryResult = {
			success: false,
			message: '',
			filePath: '',
		};
		const emptyRequest = {
			scope: '',
			content: '',
			category: '',
		};
		const empty = await service.saveMemory(emptyRequest);
		assert.strictEqual(transport.saveMemoryCalls[1]?.scope, '');
		assert.strictEqual(transport.saveMemoryCalls[1]?.content, '');
		assert.strictEqual(transport.saveMemoryCalls[1]?.category, '');
		assert.strictEqual(empty.success, false);
		assert.strictEqual(empty.message, '');
		assert.strictEqual(empty.filePath, '');
		service.dispose();
	});

	test('searchMemory forwards request and maps result', async () => {
		const transport = new MockUniverseAgentGrpcTransport();
		const service = new UniverseAgentConnectionService({
			connectionResolver: plainFixtureResolver(),
			clientIdentityStore: plainFixtureIdentity(),
			createTransport: () => transport,
		});
		await connectPlainFixture(service);

		transport.searchMemoryResult = {
			results: [{
				category: 'facts',
				filename: 'note.md',
				title: 'Note',
				score: 0.8,
				snippet: 'hit',
				forgot: false,
				scope: 'project',
			}],
		};
		const request = {
			scope: 'project',
			query: 'note',
			keywords: ['alpha'],
			limit: 10,
		};
		const result = await service.searchMemory(request);
		assert.deepStrictEqual(transport.searchMemoryCalls, [request]);
		assert.deepStrictEqual(result, transport.searchMemoryResult);

		transport.searchMemoryResult = {
			results: [{
				category: '',
				filename: '',
				title: '',
				score: 0,
				snippet: '',
				forgot: false,
				scope: '',
			}],
		};
		const emptyRequest = {
			scope: '',
			query: '',
			keywords: [''],
			limit: 0,
		};
		const empty = await service.searchMemory(emptyRequest);
		assert.strictEqual(transport.searchMemoryCalls[1]?.scope, '');
		assert.strictEqual(transport.searchMemoryCalls[1]?.query, '');
		assert.deepStrictEqual(transport.searchMemoryCalls[1]?.keywords, ['']);
		assert.strictEqual(transport.searchMemoryCalls[1]?.limit, 0);
		assert.strictEqual(empty.results[0]?.category, '');
		assert.strictEqual(empty.results[0]?.filename, '');
		assert.strictEqual(empty.results[0]?.title, '');
		assert.strictEqual(empty.results[0]?.score, 0);
		assert.strictEqual(empty.results[0]?.snippet, '');
		assert.strictEqual(empty.results[0]?.forgot, false);
		assert.strictEqual(empty.results[0]?.scope, '');

		const emptyListsRequest = {
			scope: '',
			query: '',
			keywords: [],
			limit: 0,
		};
		transport.searchMemoryResult = { results: [] };
		const emptyLists = await service.searchMemory(emptyListsRequest);
		assert.strictEqual(transport.searchMemoryCalls[2]?.scope, '');
		assert.deepStrictEqual(transport.searchMemoryCalls[2]?.keywords, []);
		assert.deepStrictEqual(emptyLists.results, []);
		service.dispose();
	});

	test('searchDeepMemory forwards request and maps result', async () => {
		const transport = new MockUniverseAgentGrpcTransport();
		const service = new UniverseAgentConnectionService({
			connectionResolver: plainFixtureResolver(),
			clientIdentityStore: plainFixtureIdentity(),
			createTransport: () => transport,
		});
		await connectPlainFixture(service);

		transport.searchDeepMemoryResult = {
			results: [{
				category: 'facts',
				filename: 'note.md',
				title: 'Note',
				score: 0.8,
				snippet: 'hit',
				forgot: false,
				scope: 'project',
			}],
			searchedCategories: ['facts'],
		};
		const request = {
			scope: 'project',
			query: 'note',
			keywords: ['alpha'],
			categories: ['facts'],
			limit: 10,
			includeContent: true,
		};
		const result = await service.searchDeepMemory(request);
		assert.deepStrictEqual(transport.searchDeepMemoryCalls, [request]);
		assert.deepStrictEqual(result, transport.searchDeepMemoryResult);

		transport.searchDeepMemoryResult = {
			results: [{
				category: '',
				filename: '',
				title: '',
				score: 0,
				snippet: '',
				forgot: false,
				scope: '',
			}],
			searchedCategories: [''],
		};
		const emptyRequest = {
			scope: '',
			query: '',
			keywords: [''],
			categories: [''],
			limit: 0,
			includeContent: false,
		};
		const empty = await service.searchDeepMemory(emptyRequest);
		assert.strictEqual(transport.searchDeepMemoryCalls[1]?.scope, '');
		assert.strictEqual(transport.searchDeepMemoryCalls[1]?.query, '');
		assert.deepStrictEqual(transport.searchDeepMemoryCalls[1]?.keywords, ['']);
		assert.deepStrictEqual(transport.searchDeepMemoryCalls[1]?.categories, ['']);
		assert.strictEqual(transport.searchDeepMemoryCalls[1]?.limit, 0);
		assert.strictEqual(transport.searchDeepMemoryCalls[1]?.includeContent, false);
		assert.strictEqual(empty.results[0]?.category, '');
		assert.strictEqual(empty.results[0]?.filename, '');
		assert.strictEqual(empty.results[0]?.title, '');
		assert.strictEqual(empty.results[0]?.score, 0);
		assert.strictEqual(empty.results[0]?.snippet, '');
		assert.strictEqual(empty.results[0]?.forgot, false);
		assert.strictEqual(empty.results[0]?.scope, '');
		assert.deepStrictEqual(empty.searchedCategories, ['']);

		const emptyListsRequest = {
			scope: '',
			query: '',
			keywords: [],
			categories: [],
			limit: 0,
			includeContent: false,
		};
		transport.searchDeepMemoryResult = { results: [], searchedCategories: [] };
		const emptyLists = await service.searchDeepMemory(emptyListsRequest);
		assert.strictEqual(transport.searchDeepMemoryCalls[2]?.scope, '');
		assert.deepStrictEqual(transport.searchDeepMemoryCalls[2]?.keywords, []);
		assert.deepStrictEqual(transport.searchDeepMemoryCalls[2]?.categories, []);
		assert.strictEqual(transport.searchDeepMemoryCalls[2]?.includeContent, false);
		assert.deepStrictEqual(emptyLists.results, []);
		assert.deepStrictEqual(emptyLists.searchedCategories, []);
		service.dispose();
	});

	test('readMemory forwards request and maps result', async () => {
		const transport = new MockUniverseAgentGrpcTransport();
		const service = new UniverseAgentConnectionService({
			connectionResolver: plainFixtureResolver(),
			clientIdentityStore: plainFixtureIdentity(),
			createTransport: () => transport,
		});
		await connectPlainFixture(service);

		transport.readMemoryResult = {
			content: '# notes',
			metadata: {
				category: 'notes',
				filename: 'project.md',
				title: 'Project',
				tags: ['keep'],
				createdAt: 10,
				updatedAt: 20,
				version: 2,
			},
		};
		const request = {
			scope: 'project',
			category: 'notes',
			filename: 'project.md',
			section: 'intro',
			mode: 'full',
			forgot: true,
		};
		const result = await service.readMemory(request);
		assert.deepStrictEqual(transport.readMemoryCalls, [request]);
		assert.deepStrictEqual(result, transport.readMemoryResult);

		transport.readMemoryResult = {
			content: '',
			metadata: {
				category: '',
				filename: '',
				title: '',
				tags: [],
				createdAt: 0,
				updatedAt: 0,
				version: 0,
			},
		};
		const emptyRequest = {
			scope: '',
			category: '',
			filename: '',
			section: '',
			mode: '',
			forgot: false,
		};
		const empty = await service.readMemory(emptyRequest);
		assert.strictEqual(transport.readMemoryCalls[1]?.scope, '');
		assert.strictEqual(transport.readMemoryCalls[1]?.category, '');
		assert.strictEqual(transport.readMemoryCalls[1]?.filename, '');
		assert.strictEqual(transport.readMemoryCalls[1]?.section, '');
		assert.strictEqual(transport.readMemoryCalls[1]?.mode, '');
		assert.strictEqual(transport.readMemoryCalls[1]?.forgot, false);
		assert.strictEqual(empty.content, '');
		assert.strictEqual(empty.metadata.category, '');
		assert.strictEqual(empty.metadata.filename, '');
		assert.strictEqual(empty.metadata.title, '');
		assert.deepStrictEqual(empty.metadata.tags, []);
		assert.strictEqual(empty.metadata.createdAt, 0);
		assert.strictEqual(empty.metadata.updatedAt, 0);
		assert.strictEqual(empty.metadata.version, 0);
		service.dispose();
	});

	test('listMemory forwards request and maps result', async () => {
		const transport = new MockUniverseAgentGrpcTransport();
		const service = new UniverseAgentConnectionService({
			connectionResolver: plainFixtureResolver(),
			clientIdentityStore: plainFixtureIdentity(),
			createTransport: () => transport,
		});
		await connectPlainFixture(service);

		transport.listMemoryResult = {
			categories: [{
				category: 'notes',
				files: [{
					filename: 'note.md',
					title: 'Note',
					updatedAt: 1,
				}],
				fileCount: 1,
			}],
		};
		const request = {
			scope: 'project',
			category: 'notes',
		};
		const result = await service.listMemory(request);
		assert.deepStrictEqual(transport.listMemoryCalls, [request]);
		assert.deepStrictEqual(result, transport.listMemoryResult);

		transport.listMemoryResult = {
			categories: [{
				category: '',
				files: [{
					filename: '',
					title: '',
					updatedAt: 0,
				}],
				fileCount: 0,
			}],
		};
		const emptyRequest = {
			scope: '',
			category: '',
		};
		const empty = await service.listMemory(emptyRequest);
		assert.strictEqual(transport.listMemoryCalls[1]?.scope, '');
		assert.strictEqual(transport.listMemoryCalls[1]?.category, '');
		assert.strictEqual(empty.categories[0]?.category, '');
		assert.strictEqual(empty.categories[0]?.fileCount, 0);
		assert.strictEqual(empty.categories[0]?.files[0]?.filename, '');
		assert.strictEqual(empty.categories[0]?.files[0]?.title, '');
		assert.strictEqual(empty.categories[0]?.files[0]?.updatedAt, 0);

		transport.listMemoryResult = { categories: [] };
		const emptyLists = await service.listMemory(emptyRequest);
		assert.strictEqual(transport.listMemoryCalls[2]?.scope, '');
		assert.strictEqual(transport.listMemoryCalls[2]?.category, '');
		assert.deepStrictEqual(emptyLists.categories, []);
		service.dispose();
	});

	test('deleteMemory forwards request and maps result', async () => {
		const transport = new MockUniverseAgentGrpcTransport();
		const service = new UniverseAgentConnectionService({
			connectionResolver: plainFixtureResolver(),
			clientIdentityStore: plainFixtureIdentity(),
			createTransport: () => transport,
		});
		await connectPlainFixture(service);

		transport.deleteMemoryResult = {
			success: true,
			message: 'deleted',
		};
		const request = {
			scope: 'project',
			category: 'notes',
			filename: 'note.md',
		};
		const result = await service.deleteMemory(request);
		assert.deepStrictEqual(transport.deleteMemoryCalls, [request]);
		assert.deepStrictEqual(result, transport.deleteMemoryResult);

		transport.deleteMemoryResult = {
			success: false,
			message: '',
		};
		const emptyRequest = {
			scope: '',
			category: '',
			filename: '',
		};
		const empty = await service.deleteMemory(emptyRequest);
		assert.strictEqual(transport.deleteMemoryCalls[1]?.scope, '');
		assert.strictEqual(transport.deleteMemoryCalls[1]?.category, '');
		assert.strictEqual(transport.deleteMemoryCalls[1]?.filename, '');
		assert.strictEqual(empty.success, false);
		assert.strictEqual(empty.message, '');
		service.dispose();
	});

	test('reflectMemory forwards request and maps result', async () => {
		const transport = new MockUniverseAgentGrpcTransport();
		const service = new UniverseAgentConnectionService({
			connectionResolver: plainFixtureResolver(),
			clientIdentityStore: plainFixtureIdentity(),
			createTransport: () => transport,
		});
		await connectPlainFixture(service);

		transport.reflectMemoryResult = {
			diagnoses: [{
				type: 'stale',
				category: 'notes',
				filename: 'old.md',
				description: 'outdated',
				suggestion: 'refresh',
			}],
			summary: 'one stale',
		};
		const request = {
			scope: 'project',
			categories: ['notes'],
		};
		const result = await service.reflectMemory(request);
		assert.deepStrictEqual(transport.reflectMemoryCalls, [request]);
		assert.deepStrictEqual(result, transport.reflectMemoryResult);

		transport.reflectMemoryResult = {
			diagnoses: [{
				type: '',
				category: '',
				filename: '',
				description: '',
				suggestion: '',
			}],
			summary: '',
		};
		const emptyRequest = {
			scope: '',
			categories: [''],
		};
		const empty = await service.reflectMemory(emptyRequest);
		assert.strictEqual(transport.reflectMemoryCalls[1]?.scope, '');
		assert.deepStrictEqual(transport.reflectMemoryCalls[1]?.categories, ['']);
		assert.strictEqual(empty.diagnoses[0]?.type, '');
		assert.strictEqual(empty.diagnoses[0]?.category, '');
		assert.strictEqual(empty.diagnoses[0]?.filename, '');
		assert.strictEqual(empty.diagnoses[0]?.description, '');
		assert.strictEqual(empty.diagnoses[0]?.suggestion, '');
		assert.strictEqual(empty.summary, '');

		const emptyListsRequest = {
			scope: '',
			categories: [],
		};
		transport.reflectMemoryResult = { diagnoses: [], summary: '' };
		const emptyLists = await service.reflectMemory(emptyListsRequest);
		assert.strictEqual(transport.reflectMemoryCalls[2]?.scope, '');
		assert.deepStrictEqual(transport.reflectMemoryCalls[2]?.categories, []);
		assert.deepStrictEqual(emptyLists.diagnoses, []);
		assert.strictEqual(emptyLists.summary, '');
		service.dispose();
	});

	test('revertMemory forwards request and maps result', async () => {
		const transport = new MockUniverseAgentGrpcTransport();
		const service = new UniverseAgentConnectionService({
			connectionResolver: plainFixtureResolver(),
			clientIdentityStore: plainFixtureIdentity(),
			createTransport: () => transport,
		});
		await connectPlainFixture(service);

		transport.revertMemoryResult = {
			success: true,
			message: 'reverted',
			revertedToVersion: 3,
		};
		const request = {
			scope: 'project',
			category: 'notes',
			filename: 'note.md',
			targetVersion: 3,
		};
		const result = await service.revertMemory(request);
		assert.deepStrictEqual(transport.revertMemoryCalls, [request]);
		assert.deepStrictEqual(result, transport.revertMemoryResult);

		transport.revertMemoryResult = {
			success: false,
			message: '',
			revertedToVersion: 0,
		};
		const emptyRequest = {
			scope: '',
			category: '',
			filename: '',
			targetVersion: 0,
		};
		const empty = await service.revertMemory(emptyRequest);
		assert.strictEqual(transport.revertMemoryCalls[1]?.scope, '');
		assert.strictEqual(transport.revertMemoryCalls[1]?.category, '');
		assert.strictEqual(transport.revertMemoryCalls[1]?.filename, '');
		assert.strictEqual(transport.revertMemoryCalls[1]?.targetVersion, 0);
		assert.strictEqual(empty.success, false);
		assert.strictEqual(empty.message, '');
		assert.strictEqual(empty.revertedToVersion, 0);
		service.dispose();
	});

	test('historyMemory forwards request and maps result', async () => {
		const transport = new MockUniverseAgentGrpcTransport();
		const service = new UniverseAgentConnectionService({
			connectionResolver: plainFixtureResolver(),
			clientIdentityStore: plainFixtureIdentity(),
			createTransport: () => transport,
		});
		await connectPlainFixture(service);

		transport.historyMemoryResult = {
			changes: [{
				version: 2,
				changeType: 'updated',
				summary: 'edited note',
				timestamp: 1_700_000_000,
				author: 'agent',
			}],
		};
		const request = {
			scope: 'project',
			category: 'notes',
			filename: 'note.md',
			limit: 20,
		};
		const result = await service.historyMemory(request);
		assert.deepStrictEqual(transport.historyMemoryCalls, [request]);
		assert.deepStrictEqual(result, transport.historyMemoryResult);

		transport.historyMemoryResult = {
			changes: [{
				version: 0,
				changeType: '',
				summary: '',
				timestamp: 0,
				author: '',
			}],
		};
		const emptyRequest = {
			scope: '',
			category: '',
			filename: '',
			limit: 0,
		};
		const empty = await service.historyMemory(emptyRequest);
		assert.strictEqual(transport.historyMemoryCalls[1]?.scope, '');
		assert.strictEqual(transport.historyMemoryCalls[1]?.category, '');
		assert.strictEqual(transport.historyMemoryCalls[1]?.filename, '');
		assert.strictEqual(transport.historyMemoryCalls[1]?.limit, 0);
		assert.strictEqual(empty.changes[0]?.version, 0);
		assert.strictEqual(empty.changes[0]?.changeType, '');
		assert.strictEqual(empty.changes[0]?.summary, '');
		assert.strictEqual(empty.changes[0]?.timestamp, 0);
		assert.strictEqual(empty.changes[0]?.author, '');

		transport.historyMemoryResult = { changes: [] };
		const emptyList = await service.historyMemory(emptyRequest);
		assert.deepStrictEqual(emptyList.changes, []);
		service.dispose();
	});

	test('listContextVariable forwards request and maps result', async () => {
		const transport = new MockUniverseAgentGrpcTransport();
		const service = new UniverseAgentConnectionService({
			connectionResolver: plainFixtureResolver(),
			clientIdentityStore: plainFixtureIdentity(),
			createTransport: () => transport,
		});
		await connectPlainFixture(service);

		transport.listContextVariableResult = {
			current: [{
				name: 'cwd',
				scope: 'VARIABLE_LOCAL',
				updatedBy: 'root',
				updatedAt: 1_700_000_000,
				contentPreview: '/tmp',
			}],
			inherited: [{
				name: 'lang',
				scope: 'VARIABLE_GLOBAL',
				updatedBy: 'parent',
				updatedAt: 1_600_000_000,
				contentPreview: 'en',
			}],
		};
		const request = {
			sessionId: 'sess-1',
			agentId: 'agent-1',
		};
		const result = await service.listContextVariable(request);
		assert.deepStrictEqual(transport.listContextVariableCalls, [request]);
		assert.deepStrictEqual(result, transport.listContextVariableResult);

		transport.listContextVariableResult = {
			current: [{
				name: '',
				scope: 'VARIABLE_GLOBAL',
				updatedBy: '',
				updatedAt: 0,
				contentPreview: '',
			}],
			inherited: [{
				name: '',
				scope: 'VARIABLE_LOCAL',
				updatedBy: '',
				updatedAt: 0,
				contentPreview: '',
			}],
		};
		const emptyRequest = {
			sessionId: '',
			agentId: '',
		};
		const empty = await service.listContextVariable(emptyRequest);
		assert.strictEqual(transport.listContextVariableCalls[1]?.sessionId, '');
		assert.strictEqual(transport.listContextVariableCalls[1]?.agentId, '');
		assert.strictEqual(empty.current[0]?.name, '');
		assert.strictEqual(empty.current[0]?.scope, 'VARIABLE_GLOBAL');
		assert.strictEqual(empty.current[0]?.updatedBy, '');
		assert.strictEqual(empty.current[0]?.updatedAt, 0);
		assert.strictEqual(empty.current[0]?.contentPreview, '');
		assert.strictEqual(empty.inherited[0]?.name, '');
		assert.strictEqual(empty.inherited[0]?.scope, 'VARIABLE_LOCAL');
		assert.strictEqual(empty.inherited[0]?.updatedBy, '');
		assert.strictEqual(empty.inherited[0]?.updatedAt, 0);
		assert.strictEqual(empty.inherited[0]?.contentPreview, '');

		transport.listContextVariableResult = { current: [], inherited: [] };
		const emptyLists = await service.listContextVariable(emptyRequest);
		assert.deepStrictEqual(emptyLists.current, []);
		assert.deepStrictEqual(emptyLists.inherited, []);
		service.dispose();
	});

	test('readContextVariable forwards request and maps result', async () => {
		const transport = new MockUniverseAgentGrpcTransport();
		const service = new UniverseAgentConnectionService({
			connectionResolver: plainFixtureResolver(),
			clientIdentityStore: plainFixtureIdentity(),
			createTransport: () => transport,
		});
		await connectPlainFixture(service);

		transport.readContextVariableResult = {
			entry: {
				name: 'cwd',
				content: '/tmp',
				scope: 'VARIABLE_LOCAL',
				updatedBy: 'root',
				updatedAt: 1_700_000_000,
			},
		};
		const request = {
			sessionId: 'sess-1',
			name: 'cwd',
			agentId: 'agent-1',
		};
		const result = await service.readContextVariable(request);
		assert.deepStrictEqual(transport.readContextVariableCalls, [request]);
		assert.deepStrictEqual(result, transport.readContextVariableResult);

		transport.readContextVariableResult = {
			entry: {
				name: '',
				content: '',
				scope: 'VARIABLE_GLOBAL',
				updatedBy: '',
				updatedAt: 0,
			},
		};
		const emptyRequest = {
			sessionId: '',
			name: '',
			agentId: '',
		};
		const empty = await service.readContextVariable(emptyRequest);
		assert.strictEqual(transport.readContextVariableCalls[1]?.sessionId, '');
		assert.strictEqual(transport.readContextVariableCalls[1]?.name, '');
		assert.strictEqual(transport.readContextVariableCalls[1]?.agentId, '');
		assert.strictEqual(empty.entry.name, '');
		assert.strictEqual(empty.entry.content, '');
		assert.strictEqual(empty.entry.scope, 'VARIABLE_GLOBAL');
		assert.strictEqual(empty.entry.updatedBy, '');
		assert.strictEqual(empty.entry.updatedAt, 0);
		service.dispose();
	});

	test('listNodes forwards request and maps result', async () => {
		const transport = new MockUniverseAgentGrpcTransport();
		const service = new UniverseAgentConnectionService({
			connectionResolver: plainFixtureResolver(),
			clientIdentityStore: plainFixtureIdentity(),
			createTransport: () => transport,
		});
		await connectPlainFixture(service);

		transport.listNodesResult = {
			nodes: [{
				id: 'node-1',
				name: 'galaxy',
				description: 'remote',
				status: 'ONLINE',
				endpoint: '127.0.0.1:50061',
				tags: ['prod'],
				capabilities: {
					models: [{
						id: 'gpt',
						name: 'GPT',
						provider: 'openai',
						maxTokens: 8192,
						enabled: true,
					}],
					tools: ['read'],
					modes: ['agent'],
					serverVersion: '1.0',
					protocolVersion: 'v1',
					properties: { region: 'cn' },
				},
				load: {
					activeSessions: 2,
					queueDepth: 1,
					cpuPercent: 10,
					memoryUsedMb: 256,
				},
				lastHeartbeatAt: 1_700_000_000,
			}],
			total: 1,
			onlineCount: 1,
		};
		const request = {
			filterStatus: ['ONLINE'],
			filterTags: ['prod'],
		};
		const result = await service.listNodes(request);
		assert.deepStrictEqual(transport.listNodesCalls, [request]);
		assert.deepStrictEqual(result, transport.listNodesResult);

		transport.listNodesResult = {
			nodes: [{
				id: '',
				name: '',
				description: '',
				status: '',
				endpoint: '',
				tags: [''],
				capabilities: {
					models: [{
						id: '',
						name: '',
						provider: '',
						maxTokens: 0,
						enabled: false,
					}],
					tools: [''],
					modes: [''],
					serverVersion: '',
					protocolVersion: '',
					properties: { '': '' },
				},
				load: {
					activeSessions: 0,
					queueDepth: 0,
					cpuPercent: 0,
					memoryUsedMb: 0,
				},
				lastHeartbeatAt: 0,
			}],
			total: 0,
			onlineCount: 0,
		};
		const emptyRequest = {
			filterStatus: [''],
			filterTags: [''],
		};
		const empty = await service.listNodes(emptyRequest);
		assert.deepStrictEqual(transport.listNodesCalls[1]?.filterStatus, ['']);
		assert.deepStrictEqual(transport.listNodesCalls[1]?.filterTags, ['']);
		assert.strictEqual(empty.nodes[0]?.id, '');
		assert.strictEqual(empty.nodes[0]?.name, '');
		assert.strictEqual(empty.nodes[0]?.description, '');
		assert.strictEqual(empty.nodes[0]?.status, '');
		assert.strictEqual(empty.nodes[0]?.endpoint, '');
		assert.deepStrictEqual(empty.nodes[0]?.tags, ['']);
		assert.strictEqual(empty.nodes[0]?.capabilities.models[0]?.id, '');
		assert.strictEqual(empty.nodes[0]?.capabilities.models[0]?.enabled, false);
		assert.strictEqual(empty.nodes[0]?.capabilities.serverVersion, '');
		assert.strictEqual(empty.nodes[0]?.capabilities.properties[''], '');
		assert.strictEqual(empty.nodes[0]?.load.activeSessions, 0);
		assert.strictEqual(empty.nodes[0]?.lastHeartbeatAt, 0);
		assert.strictEqual(empty.total, 0);
		assert.strictEqual(empty.onlineCount, 0);

		transport.listNodesResult = {
			nodes: [],
			total: 0,
			onlineCount: 0,
		};
		const emptyFilters = await service.listNodes({ filterStatus: [], filterTags: [] });
		assert.deepStrictEqual(transport.listNodesCalls[2]?.filterStatus, []);
		assert.deepStrictEqual(transport.listNodesCalls[2]?.filterTags, []);
		assert.deepStrictEqual(emptyFilters.nodes, []);		service.dispose();
	});

	test('getNode forwards request and maps result', async () => {
		const transport = new MockUniverseAgentGrpcTransport();
		const service = new UniverseAgentConnectionService({
			connectionResolver: plainFixtureResolver(),
			clientIdentityStore: plainFixtureIdentity(),
			createTransport: () => transport,
		});
		await connectPlainFixture(service);

		transport.getNodeResult = {
			id: 'node-1',
			name: 'galaxy',
			description: 'remote',
			status: 'ONLINE',
			endpoint: '127.0.0.1:50061',
			tags: ['prod'],
			capabilities: {
				models: [{
					id: 'gpt',
					name: 'GPT',
					provider: 'openai',
					maxTokens: 8192,
					enabled: true,
				}],
				tools: ['read'],
				modes: ['agent'],
				serverVersion: '1.0',
				protocolVersion: 'v1',
				properties: { region: 'cn' },
			},
			load: {
				activeSessions: 2,
				queueDepth: 1,
				cpuPercent: 10,
				memoryUsedMb: 256,
			},
			lastHeartbeatAt: 1_700_000_000,
		};
		const request = {
			nodeId: 'node-1',
		};
		const result = await service.getNode(request);
		assert.deepStrictEqual(transport.getNodeCalls, [request]);
		assert.deepStrictEqual(result, transport.getNodeResult);

		transport.getNodeResult = {
			id: '',
			name: '',
			description: '',
			status: '',
			endpoint: '',
			tags: [''],
			capabilities: {
				models: [{
					id: '',
					name: '',
					provider: '',
					maxTokens: 0,
					enabled: false,
				}],
				tools: [''],
				modes: [''],
				serverVersion: '',
				protocolVersion: '',
				properties: { '': '' },
			},
			load: {
				activeSessions: 0,
				queueDepth: 0,
				cpuPercent: 0,
				memoryUsedMb: 0,
			},
			lastHeartbeatAt: 0,
		};
		const emptyRequest = {
			nodeId: '',
		};
		const empty = await service.getNode(emptyRequest);
		assert.strictEqual(transport.getNodeCalls[1]?.nodeId, '');
		assert.strictEqual(empty.id, '');
		assert.strictEqual(empty.name, '');
		assert.strictEqual(empty.description, '');
		assert.strictEqual(empty.status, '');
		assert.strictEqual(empty.endpoint, '');
		assert.deepStrictEqual(empty.tags, ['']);
		assert.strictEqual(empty.capabilities.models[0]?.id, '');
		assert.strictEqual(empty.capabilities.models[0]?.enabled, false);
		assert.strictEqual(empty.capabilities.serverVersion, '');
		assert.strictEqual(empty.capabilities.properties[''], '');
		assert.strictEqual(empty.load.activeSessions, 0);
		assert.strictEqual(empty.lastHeartbeatAt, 0);
		service.dispose();
	});

	test('checkConnection forwards request and maps result', async () => {
		const transport = new MockUniverseAgentGrpcTransport();
		const service = new UniverseAgentConnectionService({
			connectionResolver: plainFixtureResolver(),
			clientIdentityStore: plainFixtureIdentity(),
			createTransport: () => transport,
		});
		await connectPlainFixture(service);

		transport.checkConnectionResult = {
			reachable: true,
			authenticated: true,
			canCreateSession: true,
			latencyMs: 42,
			capabilities: {
				models: [{
					id: 'gpt',
					name: 'GPT',
					provider: 'openai',
					maxTokens: 8192,
					enabled: true,
				}],
				tools: ['read'],
				modes: ['agent'],
				serverVersion: '1.0',
				protocolVersion: 'v1',
				properties: { region: 'cn' },
			},
			errors: [{
				code: 'CONNECT_TIMEOUT',
				field: 'endpoint',
				message: 'timeout',
				suggestion: 'retry',
			}],
			load: {
				activeSessions: 2,
				queueDepth: 1,
				cpuPercent: 10,
				memoryUsedMb: 256,
			},
		};
		const request = {
			nodeId: 'node-1',
			sessionParams: {
				preferredModel: 'gpt',
				requiredTools: ['read'],
				mode: 'agent',
				maxTokens: 4096,
				maxTurns: 8,
				systemPromptSuffix: 'be brief',
				maxExecutionTimeMs: 30_000,
			},
		};
		const result = await service.checkConnection(request);
		assert.deepStrictEqual(transport.checkConnectionCalls, [request]);
		assert.deepStrictEqual(result, transport.checkConnectionResult);

		transport.checkConnectionResult = {
			reachable: false,
			authenticated: false,
			canCreateSession: false,
			latencyMs: 0,
			capabilities: {
				models: [{
					id: '',
					name: '',
					provider: '',
					maxTokens: 0,
					enabled: false,
				}],
				tools: [''],
				modes: [''],
				serverVersion: '',
				protocolVersion: '',
				properties: { '': '' },
			},
			errors: [{
				code: 'ERROR_CODE_UNSPECIFIED',
				field: '',
				message: '',
				suggestion: '',
			}],
			load: {
				activeSessions: 0,
				queueDepth: 0,
				cpuPercent: 0,
				memoryUsedMb: 0,
			},
		};
		const emptyRequest = {
			nodeId: '',
			sessionParams: {
				preferredModel: '',
				requiredTools: [''],
				mode: '',
				maxTokens: 0,
				maxTurns: 0,
				systemPromptSuffix: '',
				maxExecutionTimeMs: 0,
			},
		};
		const empty = await service.checkConnection(emptyRequest);
		assert.strictEqual(transport.checkConnectionCalls[1]?.nodeId, '');
		assert.strictEqual(transport.checkConnectionCalls[1]?.sessionParams.preferredModel, '');
		assert.deepStrictEqual(transport.checkConnectionCalls[1]?.sessionParams.requiredTools, ['']);
		assert.strictEqual(transport.checkConnectionCalls[1]?.sessionParams.mode, '');
		assert.strictEqual(transport.checkConnectionCalls[1]?.sessionParams.maxTokens, 0);
		assert.strictEqual(transport.checkConnectionCalls[1]?.sessionParams.maxTurns, 0);
		assert.strictEqual(transport.checkConnectionCalls[1]?.sessionParams.systemPromptSuffix, '');
		assert.strictEqual(transport.checkConnectionCalls[1]?.sessionParams.maxExecutionTimeMs, 0);
		assert.strictEqual(empty.reachable, false);
		assert.strictEqual(empty.authenticated, false);
		assert.strictEqual(empty.canCreateSession, false);
		assert.strictEqual(empty.latencyMs, 0);
		assert.strictEqual(empty.capabilities.models[0]?.id, '');
		assert.strictEqual(empty.capabilities.models[0]?.enabled, false);
		assert.strictEqual(empty.capabilities.serverVersion, '');
		assert.strictEqual(empty.capabilities.properties[''], '');
		assert.strictEqual(empty.errors[0]?.code, 'ERROR_CODE_UNSPECIFIED');
		assert.strictEqual(empty.errors[0]?.field, '');
		assert.strictEqual(empty.load.activeSessions, 0);
		service.dispose();
	});

	test('setMaintenance forwards request and maps result', async () => {
		const transport = new MockUniverseAgentGrpcTransport();
		const service = new UniverseAgentConnectionService({
			connectionResolver: plainFixtureResolver(),
			clientIdentityStore: plainFixtureIdentity(),
			createTransport: () => transport,
		});
		await connectPlainFixture(service);

		transport.setMaintenanceResult = {
			success: true,
		};
		const request = {
			nodeId: 'node-1',
		};
		const result = await service.setMaintenance(request);
		assert.deepStrictEqual(transport.setMaintenanceCalls, [request]);
		assert.deepStrictEqual(result, transport.setMaintenanceResult);

		transport.setMaintenanceResult = {
			success: false,
		};
		const emptyRequest = {
			nodeId: '',
		};
		const empty = await service.setMaintenance(emptyRequest);
		assert.strictEqual(transport.setMaintenanceCalls[1]?.nodeId, '');
		assert.strictEqual(empty.success, false);
		service.dispose();
	});

	test('exitMaintenance forwards request and maps result', async () => {
		const transport = new MockUniverseAgentGrpcTransport();
		const service = new UniverseAgentConnectionService({
			connectionResolver: plainFixtureResolver(),
			clientIdentityStore: plainFixtureIdentity(),
			createTransport: () => transport,
		});
		await connectPlainFixture(service);

		transport.exitMaintenanceResult = {
			success: true,
		};
		const request = {
			nodeId: 'node-1',
		};
		const result = await service.exitMaintenance(request);
		assert.deepStrictEqual(transport.exitMaintenanceCalls, [request]);
		assert.deepStrictEqual(result, transport.exitMaintenanceResult);

		transport.exitMaintenanceResult = {
			success: false,
		};
		const emptyRequest = {
			nodeId: '',
		};
		const empty = await service.exitMaintenance(emptyRequest);
		assert.strictEqual(transport.exitMaintenanceCalls[1]?.nodeId, '');
		assert.strictEqual(empty.success, false);
		service.dispose();
	});

	test('listConfigs forwards empty request and maps result', async () => {
		const transport = new MockUniverseAgentGrpcTransport();
		const service = new UniverseAgentConnectionService({
			connectionResolver: plainFixtureResolver(),
			clientIdentityStore: plainFixtureIdentity(),
			createTransport: () => transport,
		});
		await connectPlainFixture(service);

		transport.listConfigsResult = {
			configs: [{
				id: 'node-1',
				name: 'galaxy',
				description: 'remote',
				enabled: true,
				endpoint: {
					host: '127.0.0.1',
					port: 50061,
					tls: true,
					tlsCertPath: '/certs/ca.pem',
				},
				auth: {
					type: 'API_KEY',
					apiKeyRef: '${API_KEY}',
					tokenRef: 'keyring://tok',
				},
				tags: ['prod'],
				maxConcurrentSessions: 4,
				sessionLifecycle: 'POOLED',
				defaultPermissionDelegate: {
					mode: 'WHITELIST_VERIFIED',
					whitelist: [{
						toolName: 'read',
						argConditions: [{
							field: 'path',
							operator: 'starts_with',
							value: '/tmp',
						}],
					}],
					budget: {
						maxToolCalls: 10,
						maxTokens: 1000,
						timeoutMs: 5000,
						windowMs: 60000,
						maxBubbleToUserPerDay: 3,
					},
					timeoutPolicy: 'DENY',
					fallback: 'DENY_ALL',
					bubbleTarget: 'USER',
				},
				healthCheck: {
					intervalMs: 30000,
					timeoutMs: 2000,
					unhealthyThreshold: 3,
					healthyThreshold: 2,
					useWatch: true,
					degradedErrorRateThreshold: 0.2,
					degradedP99LatencyMs: 800,
				},
			}],
		};
		const result = await service.listConfigs();
		assert.strictEqual(transport.listConfigsCalls, 1);
		assert.deepStrictEqual(result, transport.listConfigsResult);

		transport.listConfigsResult = {
			configs: [{
				id: '',
				name: '',
				description: '',
				enabled: false,
				endpoint: {
					host: '',
					port: 0,
					tls: false,
					tlsCertPath: '',
				},
				auth: {
					type: '',
					apiKeyRef: '',
					tokenRef: '',
				},
				tags: [''],
				maxConcurrentSessions: 0,
				sessionLifecycle: '',
				defaultPermissionDelegate: {
					mode: '',
					whitelist: [{
						toolName: '',
						argConditions: [{
							field: '',
							operator: '',
							value: '',
						}],
					}],
					budget: {
						maxToolCalls: 0,
						maxTokens: 0,
						timeoutMs: 0,
						windowMs: 0,
						maxBubbleToUserPerDay: 0,
					},
					timeoutPolicy: '',
					fallback: '',
					bubbleTarget: '',
				},
				healthCheck: {
					intervalMs: 0,
					timeoutMs: 0,
					unhealthyThreshold: 0,
					healthyThreshold: 0,
					useWatch: false,
					degradedErrorRateThreshold: 0,
					degradedP99LatencyMs: 0,
				},
			}],
		};
		const empty = await service.listConfigs();
		assert.strictEqual(transport.listConfigsCalls, 2);
		assert.strictEqual(empty.configs[0]?.id, '');
		assert.strictEqual(empty.configs[0]?.name, '');
		assert.strictEqual(empty.configs[0]?.description, '');
		assert.strictEqual(empty.configs[0]?.enabled, false);
		assert.strictEqual(empty.configs[0]?.endpoint.host, '');
		assert.strictEqual(empty.configs[0]?.endpoint.port, 0);
		assert.strictEqual(empty.configs[0]?.endpoint.tls, false);
		assert.strictEqual(empty.configs[0]?.endpoint.tlsCertPath, '');
		assert.strictEqual(empty.configs[0]?.auth.type, '');
		assert.strictEqual(empty.configs[0]?.auth.apiKeyRef, '');
		assert.strictEqual(empty.configs[0]?.auth.tokenRef, '');
		assert.deepStrictEqual(empty.configs[0]?.tags, ['']);
		assert.strictEqual(empty.configs[0]?.maxConcurrentSessions, 0);
		assert.strictEqual(empty.configs[0]?.sessionLifecycle, '');
		assert.strictEqual(empty.configs[0]?.defaultPermissionDelegate.mode, '');
		assert.strictEqual(empty.configs[0]?.defaultPermissionDelegate.whitelist[0]?.toolName, '');
		assert.strictEqual(empty.configs[0]?.defaultPermissionDelegate.whitelist[0]?.argConditions[0]?.field, '');
		assert.strictEqual(empty.configs[0]?.defaultPermissionDelegate.budget.maxToolCalls, 0);
		assert.strictEqual(empty.configs[0]?.healthCheck.intervalMs, 0);
		assert.strictEqual(empty.configs[0]?.healthCheck.useWatch, false);
		assert.strictEqual(empty.configs[0]?.healthCheck.degradedErrorRateThreshold, 0);

		transport.listConfigsResult = {
			configs: [],
		};
		const emptyList = await service.listConfigs();
		assert.strictEqual(transport.listConfigsCalls, 3);
		assert.deepStrictEqual(emptyList.configs, []);
		service.dispose();
	});

	test('getRemoteAgentConfig forwards request and maps result', async () => {
		const transport = new MockUniverseAgentGrpcTransport();
		const service = new UniverseAgentConnectionService({
			connectionResolver: plainFixtureResolver(),
			clientIdentityStore: plainFixtureIdentity(),
			createTransport: () => transport,
		});
		await connectPlainFixture(service);

		transport.getRemoteAgentConfigResult = {
			id: 'node-1',
			name: 'galaxy',
			description: 'remote',
			enabled: true,
			endpoint: {
				host: '127.0.0.1',
				port: 50061,
				tls: true,
				tlsCertPath: '/certs/ca.pem',
			},
			auth: {
				type: 'API_KEY',
				apiKeyRef: '${UA_KEY}',
				tokenRef: 'keyring://ua',
			},
			tags: ['prod'],
			maxConcurrentSessions: 4,
			sessionLifecycle: 'POOLED',
			defaultPermissionDelegate: {
				mode: 'WHITELIST_VERIFIED',
				whitelist: [{
					toolName: 'read',
					argConditions: [{
						field: 'path',
						operator: 'starts_with',
						value: '/tmp',
					}],
				}],
				budget: {
					maxToolCalls: 10,
					maxTokens: 1000,
					timeoutMs: 5000,
					windowMs: 60_000,
					maxBubbleToUserPerDay: 3,
				},
				timeoutPolicy: 'DENY',
				fallback: 'DENY_ALL',
				bubbleTarget: 'USER',
			},
			healthCheck: {
				intervalMs: 15_000,
				timeoutMs: 2000,
				unhealthyThreshold: 3,
				healthyThreshold: 2,
				useWatch: true,
				degradedErrorRateThreshold: 0.2,
				degradedP99LatencyMs: 800,
			},
		};
		const request = {
			nodeId: 'node-1',
		};
		const result = await service.getRemoteAgentConfig(request);
		assert.deepStrictEqual(transport.getRemoteAgentConfigCalls, [request]);
		assert.deepStrictEqual(result, transport.getRemoteAgentConfigResult);

		transport.getRemoteAgentConfigResult = {
			id: '',
			name: '',
			description: '',
			enabled: false,
			endpoint: {
				host: '',
				port: 0,
				tls: false,
				tlsCertPath: '',
			},
			auth: {
				type: '',
				apiKeyRef: '',
				tokenRef: '',
			},
			tags: [''],
			maxConcurrentSessions: 0,
			sessionLifecycle: '',
			defaultPermissionDelegate: {
				mode: '',
				whitelist: [{
					toolName: '',
					argConditions: [{
						field: '',
						operator: '',
						value: '',
					}],
				}],
				budget: {
					maxToolCalls: 0,
					maxTokens: 0,
					timeoutMs: 0,
					windowMs: 0,
					maxBubbleToUserPerDay: 0,
				},
				timeoutPolicy: '',
				fallback: '',
				bubbleTarget: '',
			},
			healthCheck: {
				intervalMs: 0,
				timeoutMs: 0,
				unhealthyThreshold: 0,
				healthyThreshold: 0,
				useWatch: false,
				degradedErrorRateThreshold: 0,
				degradedP99LatencyMs: 0,
			},
		};
		const emptyRequest = {
			nodeId: '',
		};
		const empty = await service.getRemoteAgentConfig(emptyRequest);
		assert.strictEqual(transport.getRemoteAgentConfigCalls[1]?.nodeId, '');
		assert.strictEqual(empty.id, '');
		assert.strictEqual(empty.name, '');
		assert.strictEqual(empty.description, '');
		assert.strictEqual(empty.enabled, false);
		assert.strictEqual(empty.endpoint.host, '');
		assert.strictEqual(empty.endpoint.port, 0);
		assert.strictEqual(empty.endpoint.tls, false);
		assert.strictEqual(empty.endpoint.tlsCertPath, '');
		assert.strictEqual(empty.auth.type, '');
		assert.strictEqual(empty.auth.apiKeyRef, '');
		assert.strictEqual(empty.auth.tokenRef, '');
		assert.deepStrictEqual(empty.tags, ['']);
		assert.strictEqual(empty.maxConcurrentSessions, 0);
		assert.strictEqual(empty.sessionLifecycle, '');
		assert.strictEqual(empty.defaultPermissionDelegate.mode, '');
		assert.strictEqual(empty.defaultPermissionDelegate.whitelist[0]?.toolName, '');
		assert.strictEqual(empty.defaultPermissionDelegate.whitelist[0]?.argConditions[0]?.field, '');
		assert.strictEqual(empty.defaultPermissionDelegate.budget.maxToolCalls, 0);
		assert.strictEqual(empty.defaultPermissionDelegate.timeoutPolicy, '');
		assert.strictEqual(empty.healthCheck.intervalMs, 0);
		assert.strictEqual(empty.healthCheck.useWatch, false);
		assert.strictEqual(empty.healthCheck.degradedErrorRateThreshold, 0);
		service.dispose();
	});

	test('saveRemoteAgentConfig forwards request and maps result', async () => {
		const transport = new MockUniverseAgentGrpcTransport();
		const service = new UniverseAgentConnectionService({
			connectionResolver: plainFixtureResolver(),
			clientIdentityStore: plainFixtureIdentity(),
			createTransport: () => transport,
		});
		await connectPlainFixture(service);

		const config: UniverseAgentRemoteAgentConfig = {
			id: 'node-1',
			name: 'galaxy',
			description: 'remote',
			enabled: true,
			endpoint: {
				host: '127.0.0.1',
				port: 50061,
				tls: true,
				tlsCertPath: '/certs/ca.pem',
			},
			auth: {
				type: 'API_KEY',
				apiKeyRef: '${UA_KEY}',
				tokenRef: 'keyring://ua',
			},
			tags: ['prod'],
			maxConcurrentSessions: 4,
			sessionLifecycle: 'POOLED',
			defaultPermissionDelegate: {
				mode: 'WHITELIST_VERIFIED',
				whitelist: [{
					toolName: 'read',
					argConditions: [{
						field: 'path',
						operator: 'starts_with',
						value: '/tmp',
					}],
				}],
				budget: {
					maxToolCalls: 10,
					maxTokens: 1000,
					timeoutMs: 5000,
					windowMs: 60_000,
					maxBubbleToUserPerDay: 3,
				},
				timeoutPolicy: 'DENY',
				fallback: 'DENY_ALL',
				bubbleTarget: 'USER',
			},
			healthCheck: {
				intervalMs: 15_000,
				timeoutMs: 2000,
				unhealthyThreshold: 3,
				healthyThreshold: 2,
				useWatch: true,
				degradedErrorRateThreshold: 0.2,
				degradedP99LatencyMs: 800,
			},
		};
		transport.saveRemoteAgentConfigResult = {
			success: true,
			message: 'saved',
			connectionTest: {
				reachable: true,
				authenticated: true,
				canCreateSession: true,
				latencyMs: 12,
				capabilities: {
					models: [{
						id: 'm1',
						name: 'model',
						provider: 'local',
						maxTokens: 8192,
						enabled: true,
					}],
					tools: ['read'],
					modes: ['agent'],
					serverVersion: '1.0',
					protocolVersion: 'v1',
					properties: { region: 'dev' },
				},
				errors: [{
					code: 'PARAM_INVALID',
					field: 'host',
					message: 'bad',
					suggestion: 'fix',
				}],
				load: {
					activeSessions: 1,
					queueDepth: 2,
					cpuPercent: 3,
					memoryUsedMb: 4,
				},
			},
			asyncTestId: 'async-1',
		};
		const request = {
			config,
			skipConnectionTest: true,
			asyncTest: true,
		};
		const result = await service.saveRemoteAgentConfig(request);
		assert.deepStrictEqual(transport.saveRemoteAgentConfigCalls, [request]);
		assert.deepStrictEqual(result, transport.saveRemoteAgentConfigResult);

		const emptyConfig: UniverseAgentRemoteAgentConfig = {
			id: '',
			name: '',
			description: '',
			enabled: false,
			endpoint: {
				host: '',
				port: 0,
				tls: false,
				tlsCertPath: '',
			},
			auth: {
				type: '',
				apiKeyRef: '',
				tokenRef: '',
			},
			tags: [''],
			maxConcurrentSessions: 0,
			sessionLifecycle: '',
			defaultPermissionDelegate: {
				mode: '',
				whitelist: [{
					toolName: '',
					argConditions: [{
						field: '',
						operator: '',
						value: '',
					}],
				}],
				budget: {
					maxToolCalls: 0,
					maxTokens: 0,
					timeoutMs: 0,
					windowMs: 0,
					maxBubbleToUserPerDay: 0,
				},
				timeoutPolicy: '',
				fallback: '',
				bubbleTarget: '',
			},
			healthCheck: {
				intervalMs: 0,
				timeoutMs: 0,
				unhealthyThreshold: 0,
				healthyThreshold: 0,
				useWatch: false,
				degradedErrorRateThreshold: 0,
				degradedP99LatencyMs: 0,
			},
		};
		transport.saveRemoteAgentConfigResult = {
			success: false,
			message: '',
			connectionTest: {
				reachable: false,
				authenticated: false,
				canCreateSession: false,
				latencyMs: 0,
				capabilities: {
					models: [{
						id: '',
						name: '',
						provider: '',
						maxTokens: 0,
						enabled: false,
					}],
					tools: [''],
					modes: [''],
					serverVersion: '',
					protocolVersion: '',
					properties: { '': '' },
				},
				errors: [{
					code: 'ERROR_CODE_UNSPECIFIED',
					field: '',
					message: '',
					suggestion: '',
				}],
				load: {
					activeSessions: 0,
					queueDepth: 0,
					cpuPercent: 0,
					memoryUsedMb: 0,
				},
			},
			asyncTestId: '',
		};
		const emptyRequest = {
			config: emptyConfig,
			skipConnectionTest: false,
			asyncTest: false,
		};
		const empty = await service.saveRemoteAgentConfig(emptyRequest);
		assert.strictEqual(transport.saveRemoteAgentConfigCalls[1]?.config.id, '');
		assert.strictEqual(transport.saveRemoteAgentConfigCalls[1]?.config.name, '');
		assert.strictEqual(transport.saveRemoteAgentConfigCalls[1]?.skipConnectionTest, false);
		assert.strictEqual(transport.saveRemoteAgentConfigCalls[1]?.asyncTest, false);
		assert.strictEqual(empty.success, false);
		assert.strictEqual(empty.message, '');
		assert.strictEqual(empty.asyncTestId, '');
		assert.strictEqual(empty.connectionTest.reachable, false);
		assert.strictEqual(empty.connectionTest.authenticated, false);
		assert.strictEqual(empty.connectionTest.canCreateSession, false);
		assert.strictEqual(empty.connectionTest.latencyMs, 0);
		assert.strictEqual(empty.connectionTest.capabilities.models[0]?.id, '');
		assert.strictEqual(empty.connectionTest.capabilities.serverVersion, '');
		assert.strictEqual(empty.connectionTest.errors[0]?.code, 'ERROR_CODE_UNSPECIFIED');
		assert.strictEqual(empty.connectionTest.errors[0]?.field, '');
		assert.strictEqual(empty.connectionTest.errors[0]?.message, '');
		assert.strictEqual(empty.connectionTest.load.activeSessions, 0);
		service.dispose();
	});

	test('resetError forwards request and maps result', async () => {
		const transport = new MockUniverseAgentGrpcTransport();
		const service = new UniverseAgentConnectionService({
			connectionResolver: plainFixtureResolver(),
			clientIdentityStore: plainFixtureIdentity(),
			createTransport: () => transport,
		});
		await connectPlainFixture(service);

		transport.resetErrorResult = {
			success: true,
		};
		const request = {
			nodeId: 'node-1',
		};
		const result = await service.resetError(request);
		assert.deepStrictEqual(transport.resetErrorCalls, [request]);
		assert.deepStrictEqual(result, transport.resetErrorResult);

		transport.resetErrorResult = {
			success: false,
		};
		const emptyRequest = {
			nodeId: '',
		};
		const empty = await service.resetError(emptyRequest);
		assert.strictEqual(transport.resetErrorCalls[1]?.nodeId, '');
		assert.strictEqual(empty.success, false);
		service.dispose();
	});

	test('deleteRemoteAgentConfig forwards request and maps result', async () => {
		const transport = new MockUniverseAgentGrpcTransport();
		const service = new UniverseAgentConnectionService({
			connectionResolver: plainFixtureResolver(),
			clientIdentityStore: plainFixtureIdentity(),
			createTransport: () => transport,
		});
		await connectPlainFixture(service);

		transport.deleteRemoteAgentConfigResult = {
			success: true,
		};
		const request = {
			nodeId: 'node-1',
		};
		const result = await service.deleteRemoteAgentConfig(request);
		assert.deepStrictEqual(transport.deleteRemoteAgentConfigCalls, [request]);
		assert.deepStrictEqual(result, transport.deleteRemoteAgentConfigResult);

		transport.deleteRemoteAgentConfigResult = {
			success: false,
		};
		const emptyRequest = {
			nodeId: '',
		};
		const empty = await service.deleteRemoteAgentConfig(emptyRequest);
		assert.strictEqual(transport.deleteRemoteAgentConfigCalls[1]?.nodeId, '');
		assert.strictEqual(empty.success, false);
		service.dispose();
	});

	test('reloadRemoteAgents forwards empty request and maps result', async () => {
		const transport = new MockUniverseAgentGrpcTransport();
		const service = new UniverseAgentConnectionService({
			connectionResolver: plainFixtureResolver(),
			clientIdentityStore: plainFixtureIdentity(),
			createTransport: () => transport,
		});
		await connectPlainFixture(service);

		transport.reloadRemoteAgentsResult = {
			success: true,
			added: ['node-a'],
			removed: ['node-b'],
			changed: ['node-c'],
			errors: ['node-d failed'],
			durationMs: 42,
		};
		const result = await service.reloadRemoteAgents();
		assert.strictEqual(transport.reloadRemoteAgentsCalls, 1);
		assert.deepStrictEqual(result, transport.reloadRemoteAgentsResult);

		transport.reloadRemoteAgentsResult = {
			success: false,
			added: [''],
			removed: [''],
			changed: [''],
			errors: [''],
			durationMs: 0,
		};
		const empty = await service.reloadRemoteAgents();
		assert.strictEqual(transport.reloadRemoteAgentsCalls, 2);
		assert.strictEqual(empty.success, false);
		assert.deepStrictEqual(empty.added, ['']);
		assert.deepStrictEqual(empty.removed, ['']);
		assert.deepStrictEqual(empty.changed, ['']);
		assert.deepStrictEqual(empty.errors, ['']);
		assert.strictEqual(empty.durationMs, 0);

		transport.reloadRemoteAgentsResult = {
			success: false,
			added: [],
			removed: [],
			changed: [],
			errors: [],
			durationMs: 0,
		};
		const emptyLists = await service.reloadRemoteAgents();
		assert.strictEqual(transport.reloadRemoteAgentsCalls, 3);
		assert.deepStrictEqual(emptyLists.added, []);
		assert.deepStrictEqual(emptyLists.removed, []);
		assert.deepStrictEqual(emptyLists.changed, []);
		assert.deepStrictEqual(emptyLists.errors, []);
		service.dispose();
	});

	test('createRemoteSession forwards request and maps result', async () => {
		const transport = new MockUniverseAgentGrpcTransport();
		const service = new UniverseAgentConnectionService({
			connectionResolver: plainFixtureResolver(),
			clientIdentityStore: plainFixtureIdentity(),
			createTransport: () => transport,
		});
		await connectPlainFixture(service);

		transport.createRemoteSessionResult = {
			callId: 'call-1',
			status: 'created',
			createdAt: 1_700_000_000_000,
			expiresAt: 1_700_003_600_000,
		};
		const request = {
			nodeId: 'node-1',
			mode: 'polling',
			sessionParams: {
				preferredModel: 'gpt',
				requiredTools: ['read'],
				mode: 'agent',
				maxTokens: 4096,
				maxTurns: 8,
				systemPromptSuffix: 'be brief',
				maxExecutionTimeMs: 30_000,
			},
		};
		const result = await service.createRemoteSession(request);
		assert.deepStrictEqual(transport.createRemoteSessionCalls, [request]);
		assert.deepStrictEqual(result, transport.createRemoteSessionResult);

		transport.createRemoteSessionResult = {
			callId: '',
			status: '',
			createdAt: 0,
			expiresAt: 0,
		};
		const emptyRequest = {
			nodeId: '',
			mode: '',
			sessionParams: {
				preferredModel: '',
				requiredTools: [''],
				mode: '',
				maxTokens: 0,
				maxTurns: 0,
				systemPromptSuffix: '',
				maxExecutionTimeMs: 0,
			},
		};
		const empty = await service.createRemoteSession(emptyRequest);
		assert.strictEqual(transport.createRemoteSessionCalls[1]?.nodeId, '');
		assert.strictEqual(transport.createRemoteSessionCalls[1]?.mode, '');
		assert.strictEqual(transport.createRemoteSessionCalls[1]?.sessionParams.preferredModel, '');
		assert.strictEqual(transport.createRemoteSessionCalls[1]?.sessionParams.requiredTools[0], '');
		assert.strictEqual(transport.createRemoteSessionCalls[1]?.sessionParams.mode, '');
		assert.strictEqual(transport.createRemoteSessionCalls[1]?.sessionParams.systemPromptSuffix, '');
		assert.strictEqual(transport.createRemoteSessionCalls[1]?.sessionParams.maxTokens, 0);
		assert.strictEqual(transport.createRemoteSessionCalls[1]?.sessionParams.maxTurns, 0);
		assert.strictEqual(transport.createRemoteSessionCalls[1]?.sessionParams.maxExecutionTimeMs, 0);
		assert.strictEqual(empty.callId, '');
		assert.strictEqual(empty.status, '');
		assert.strictEqual(empty.createdAt, 0);
		assert.strictEqual(empty.expiresAt, 0);
		service.dispose();
	});

	test('destroyRemoteSession forwards request and maps result', async () => {
		const transport = new MockUniverseAgentGrpcTransport();
		const service = new UniverseAgentConnectionService({
			connectionResolver: plainFixtureResolver(),
			clientIdentityStore: plainFixtureIdentity(),
			createTransport: () => transport,
		});
		await connectPlainFixture(service);

		transport.destroyRemoteSessionResult = {
			success: true,
			message: 'destroyed',
		};
		const request = {
			callId: 'call-1',
		};
		const result = await service.destroyRemoteSession(request);
		assert.deepStrictEqual(transport.destroyRemoteSessionCalls, [request]);
		assert.deepStrictEqual(result, transport.destroyRemoteSessionResult);

		transport.destroyRemoteSessionResult = {
			success: false,
			message: '',
		};
		const emptyRequest = {
			callId: '',
		};
		const empty = await service.destroyRemoteSession(emptyRequest);
		assert.strictEqual(transport.destroyRemoteSessionCalls[1]?.callId, '');
		assert.strictEqual(empty.success, false);
		assert.strictEqual(empty.message, '');
		service.dispose();
	});

	test('getRemoteSessionStatus forwards request and maps result', async () => {
		const transport = new MockUniverseAgentGrpcTransport();
		const service = new UniverseAgentConnectionService({
			connectionResolver: plainFixtureResolver(),
			clientIdentityStore: plainFixtureIdentity(),
			createTransport: () => transport,
		});
		await connectPlainFixture(service);

		transport.getRemoteSessionStatusResult = {
			status: 'running',
			callId: 'call-1',
			progress: 'step 1',
			elapsedMs: 42,
			expiresAt: 99,
			pendingPermissions: [{
				requestId: 'perm-1',
				toolName: 'bash',
				path: '/tmp',
				command: 'ls',
				argumentsJson: '{"cmd":"ls"}',
				dangerLevel: 'LOW',
				bubbleTarget: 'USER',
			}],
			pendingQuestions: [{
				questionId: 'q-1',
				questionsJson: '[]',
			}],
		};
		const request = {
			callId: 'call-1',
		};
		const result = await service.getRemoteSessionStatus(request);
		assert.deepStrictEqual(transport.getRemoteSessionStatusCalls, [request]);
		assert.deepStrictEqual(result, transport.getRemoteSessionStatusResult);

		transport.getRemoteSessionStatusResult = {
			status: '',
			callId: '',
			progress: '',
			elapsedMs: 0,
			expiresAt: 0,
			pendingPermissions: [{
				requestId: '',
				toolName: '',
				path: '',
				command: '',
				argumentsJson: '',
				dangerLevel: '',
				bubbleTarget: '',
			}],
			pendingQuestions: [{
				questionId: '',
				questionsJson: '',
			}],
		};
		const emptyRequest = {
			callId: '',
		};
		const empty = await service.getRemoteSessionStatus(emptyRequest);
		assert.strictEqual(transport.getRemoteSessionStatusCalls[1]?.callId, '');
		assert.strictEqual(empty.status, '');
		assert.strictEqual(empty.callId, '');
		assert.strictEqual(empty.progress, '');
		assert.strictEqual(empty.elapsedMs, 0);
		assert.strictEqual(empty.expiresAt, 0);
		assert.strictEqual(empty.pendingPermissions[0]?.requestId, '');
		assert.strictEqual(empty.pendingQuestions[0]?.questionId, '');

		transport.getRemoteSessionStatusResult = {
			status: '',
			callId: '',
			progress: '',
			elapsedMs: 0,
			expiresAt: 0,
			pendingPermissions: [],
			pendingQuestions: [],
		};
		const emptyLists = await service.getRemoteSessionStatus(emptyRequest);
		assert.strictEqual(transport.getRemoteSessionStatusCalls[2]?.callId, '');
		assert.deepStrictEqual(emptyLists.pendingPermissions, []);
		assert.deepStrictEqual(emptyLists.pendingQuestions, []);
		service.dispose();
	});

	test('getRemoteSessionHistory forwards request and maps result', async () => {
		const transport = new MockUniverseAgentGrpcTransport();
		const service = new UniverseAgentConnectionService({
			connectionResolver: plainFixtureResolver(),
			clientIdentityStore: plainFixtureIdentity(),
			createTransport: () => transport,
		});
		await connectPlainFixture(service);

		transport.getRemoteSessionHistoryResult = {
			messages: [
				{ system: { content: 'sys' } },
				{ user: { content: 'hi' } },
				{ assistant: { content: 'ok', toolCalls: [{ id: 'tc-1', name: 'read', arguments: '{}' }] } },
				{ toolResult: { toolCallId: 'tc-1', toolName: 'read', content: 'done', isError: false } },
			],
			version: 7,
			hasMore: true,
		};
		const request = {
			callId: 'call-1',
			sinceVersion: 3,
			pageSize: 20,
		};
		const result = await service.getRemoteSessionHistory(request);
		assert.deepStrictEqual(transport.getRemoteSessionHistoryCalls, [request]);
		assert.deepStrictEqual(result, transport.getRemoteSessionHistoryResult);

		transport.getRemoteSessionHistoryResult = {
			messages: [
				{ system: { content: '' } },
				{ user: { content: '' } },
				{ assistant: { content: '', toolCalls: [{ id: '', name: '', arguments: '' }] } },
				{ toolResult: { toolCallId: '', toolName: '', content: '', isError: false } },
			],
			version: 0,
			hasMore: false,
		};
		const emptyRequest = {
			callId: '',
			sinceVersion: 0,
			pageSize: 0,
		};
		const empty = await service.getRemoteSessionHistory(emptyRequest);
		assert.strictEqual(transport.getRemoteSessionHistoryCalls[1]?.callId, '');
		assert.strictEqual(transport.getRemoteSessionHistoryCalls[1]?.sinceVersion, 0);
		assert.strictEqual(transport.getRemoteSessionHistoryCalls[1]?.pageSize, 0);
		assert.strictEqual(empty.messages[0]?.system?.content, '');
		assert.strictEqual(empty.messages[1]?.user?.content, '');
		assert.strictEqual(empty.messages[2]?.assistant?.content, '');
		assert.strictEqual(empty.messages[2]?.assistant?.toolCalls[0]?.id, '');
		assert.strictEqual(empty.messages[2]?.assistant?.toolCalls[0]?.name, '');
		assert.strictEqual(empty.messages[2]?.assistant?.toolCalls[0]?.arguments, '');
		assert.strictEqual(empty.messages[3]?.toolResult?.toolCallId, '');
		assert.strictEqual(empty.messages[3]?.toolResult?.toolName, '');
		assert.strictEqual(empty.messages[3]?.toolResult?.content, '');
		assert.strictEqual(empty.messages[3]?.toolResult?.isError, false);
		assert.strictEqual(empty.version, 0);
		assert.strictEqual(empty.hasMore, false);

		transport.getRemoteSessionHistoryResult = {
			messages: [],
			version: 0,
			hasMore: false,
		};
		const emptyList = await service.getRemoteSessionHistory(emptyRequest);
		assert.strictEqual(transport.getRemoteSessionHistoryCalls[2]?.callId, '');
		assert.deepStrictEqual(emptyList.messages, []);
		service.dispose();
	});
	test('resumeRemoteSession forwards request and maps result', async () => {
		const transport = new MockUniverseAgentGrpcTransport();
		const service = new UniverseAgentConnectionService({
			connectionResolver: plainFixtureResolver(),
			clientIdentityStore: plainFixtureIdentity(),
			createTransport: () => transport,
		});
		await connectPlainFixture(service);

		transport.resumeRemoteSessionResult = {
			success: true,
			callId: 'call-1',
			status: 'resumed',
			message: 'ok',
			expiresAt: 1_700_003_600_000,
		};
		const request = {
			callId: 'call-1',
			nodeId: 'node-1',
		};
		const result = await service.resumeRemoteSession(request);
		assert.deepStrictEqual(transport.resumeRemoteSessionCalls, [request]);
		assert.deepStrictEqual(result, transport.resumeRemoteSessionResult);

		transport.resumeRemoteSessionResult = {
			success: false,
			callId: '',
			status: '',
			message: '',
			expiresAt: 0,
		};
		const emptyRequest = {
			callId: '',
			nodeId: '',
		};
		const empty = await service.resumeRemoteSession(emptyRequest);
		assert.strictEqual(transport.resumeRemoteSessionCalls[1]?.callId, '');
		assert.strictEqual(transport.resumeRemoteSessionCalls[1]?.nodeId, '');
		assert.strictEqual(empty.success, false);
		assert.strictEqual(empty.callId, '');
		assert.strictEqual(empty.status, '');
		assert.strictEqual(empty.message, '');
		assert.strictEqual(empty.expiresAt, 0);
		service.dispose();
	});
	test('cancelRemoteSession forwards request and maps result', async () => {
		const transport = new MockUniverseAgentGrpcTransport();
		const service = new UniverseAgentConnectionService({
			connectionResolver: plainFixtureResolver(),
			clientIdentityStore: plainFixtureIdentity(),
			createTransport: () => transport,
		});
		await connectPlainFixture(service);

		transport.cancelRemoteSessionResult = {
			success: true,
			callId: 'call-1',
			status: 'cancelled',
			message: 'cancelled',
		};
		const request = {
			callId: 'call-1',
			reason: 'user-stop',
		};
		const result = await service.cancelRemoteSession(request);
		assert.deepStrictEqual(transport.cancelRemoteSessionCalls, [request]);
		assert.deepStrictEqual(result, transport.cancelRemoteSessionResult);

		transport.cancelRemoteSessionResult = {
			success: false,
			callId: '',
			status: '',
			message: '',
		};
		const emptyRequest = {
			callId: '',
			reason: '',
		};
		const empty = await service.cancelRemoteSession(emptyRequest);
		assert.strictEqual(transport.cancelRemoteSessionCalls[1]?.callId, '');
		assert.strictEqual(transport.cancelRemoteSessionCalls[1]?.reason, '');
		assert.strictEqual(empty.success, false);
		assert.strictEqual(empty.callId, '');
		assert.strictEqual(empty.status, '');
		assert.strictEqual(empty.message, '');
		service.dispose();
	});

	test('getUploadProgress forwards request and maps result', async () => {
		const transport = new MockUniverseAgentGrpcTransport();
		const service = new UniverseAgentConnectionService({
			connectionResolver: plainFixtureResolver(),
			clientIdentityStore: plainFixtureIdentity(),
			createTransport: () => transport,
		});
		await connectPlainFixture(service);

		transport.getUploadProgressResult = {
			exists: true,
			bytesReceived: 4096,
			partialPath: 'tmp/upload.bin',
		};
		const request = {
			transferId: 'xfer-1',
			sessionId: 'sess-1',
		};
		const result = await service.getUploadProgress(request);
		assert.deepStrictEqual(transport.getUploadProgressCalls, [request]);
		assert.deepStrictEqual(result, transport.getUploadProgressResult);

		transport.getUploadProgressResult = {
			exists: false,
			bytesReceived: 0,
			partialPath: '',
		};
		const emptyRequest = {
			transferId: '',
			sessionId: '',
		};
		const empty = await service.getUploadProgress(emptyRequest);
		assert.strictEqual(transport.getUploadProgressCalls[1]?.transferId, '');
		assert.strictEqual(transport.getUploadProgressCalls[1]?.sessionId, '');
		assert.strictEqual(empty.exists, false);
		assert.strictEqual(empty.bytesReceived, 0);
		assert.strictEqual(empty.partialPath, '');
		service.dispose();
	});

	test('healthCheck forwards empty request and maps result', async () => {
		const transport = new MockUniverseAgentGrpcTransport();
		const service = new UniverseAgentConnectionService({
			connectionResolver: plainFixtureResolver(),
			clientIdentityStore: plainFixtureIdentity(),
			createTransport: () => transport,
		});
		await connectPlainFixture(service);

		transport.healthCheckResult = {
			status: 'SERVING',
			version: '1.2.3',
			activeSessions: 4,
			uptimeMs: 90000,
		};
		const result = await service.healthCheck();
		assert.strictEqual(transport.healthCheckCalls, 1);
		assert.deepStrictEqual(result, transport.healthCheckResult);

		transport.healthCheckResult = {
			status: '',
			version: '',
			activeSessions: 0,
			uptimeMs: 0,
		};
		const empty = await service.healthCheck();
		assert.strictEqual(transport.healthCheckCalls, 2);
		assert.strictEqual(empty.status, '');
		assert.strictEqual(empty.version, '');
		assert.strictEqual(empty.activeSessions, 0);
		assert.strictEqual(empty.uptimeMs, 0);
		service.dispose();
	});

	test('doctor forwards empty request and maps result', async () => {
		const transport = new MockUniverseAgentGrpcTransport();
		const service = new UniverseAgentConnectionService({
			connectionResolver: plainFixtureResolver(),
			clientIdentityStore: plainFixtureIdentity(),
			createTransport: () => transport,
		});
		await connectPlainFixture(service);

		transport.doctorResult = {
			checks: [{
				name: 'tls',
				passed: true,
				message: 'ok',
				fixHint: 'none',
			}],
			allPassed: true,
		};
		const result = await service.doctor();
		assert.strictEqual(transport.doctorCalls, 1);
		assert.deepStrictEqual(result, transport.doctorResult);

		transport.doctorResult = {
			checks: [{
				name: '',
				passed: false,
				message: '',
				fixHint: '',
			}],
			allPassed: false,
		};
		const empty = await service.doctor();
		assert.strictEqual(transport.doctorCalls, 2);
		assert.strictEqual(empty.checks[0]?.name, '');
		assert.strictEqual(empty.checks[0]?.message, '');
		assert.strictEqual(empty.checks[0]?.fixHint, '');
		assert.strictEqual(empty.checks[0]?.passed, false);
		assert.strictEqual(empty.allPassed, false);
		service.dispose();
	});

	test('shutdown forwards request and maps result', async () => {
		const transport = new MockUniverseAgentGrpcTransport();
		const service = new UniverseAgentConnectionService({
			connectionResolver: plainFixtureResolver(),
			clientIdentityStore: plainFixtureIdentity(),
			createTransport: () => transport,
		});
		await connectPlainFixture(service);

		transport.shutdownResult = {
			accepted: true,
			message: 'shutting down',
		};
		const request = {
			force: true,
			gracePeriodMs: 15000,
		};
		const result = await service.shutdown(request);
		assert.deepStrictEqual(transport.shutdownCalls, [request]);
		assert.deepStrictEqual(result, transport.shutdownResult);

		transport.shutdownResult = {
			accepted: false,
			message: '',
		};
		const emptyRequest = {
			force: false,
			gracePeriodMs: 0,
		};
		const empty = await service.shutdown(emptyRequest);
		assert.strictEqual(transport.shutdownCalls[1]?.force, false);
		assert.strictEqual(transport.shutdownCalls[1]?.gracePeriodMs, 0);
		assert.strictEqual(empty.accepted, false);
		assert.strictEqual(empty.message, '');
		service.dispose();
	});

	test('listDevices forwards empty request and maps result', async () => {
		const transport = new MockUniverseAgentGrpcTransport();
		const service = new UniverseAgentConnectionService({
			connectionResolver: plainFixtureResolver(),
			clientIdentityStore: plainFixtureIdentity(),
			createTransport: () => transport,
		});
		await connectPlainFixture(service);

		transport.listDevicesResult = {
			devices: [{
				deviceId: 'dev-1',
				displayName: 'laptop',
				role: 'operator',
				platform: 'linux',
				pairedAt: 100,
				lastSeenAt: 200,
				active: true,
			}],
		};
		const result = await service.listDevices();
		assert.strictEqual(transport.listDevicesCalls, 1);
		assert.deepStrictEqual(result, transport.listDevicesResult);

		transport.listDevicesResult = {
			devices: [{
				deviceId: '',
				displayName: '',
				role: '',
				platform: '',
				pairedAt: 0,
				lastSeenAt: 0,
				active: false,
			}],
		};
		const empty = await service.listDevices();
		assert.strictEqual(transport.listDevicesCalls, 2);
		assert.strictEqual(empty.devices[0]?.deviceId, '');
		assert.strictEqual(empty.devices[0]?.displayName, '');
		assert.strictEqual(empty.devices[0]?.role, '');
		assert.strictEqual(empty.devices[0]?.platform, '');
		assert.strictEqual(empty.devices[0]?.pairedAt, 0);
		assert.strictEqual(empty.devices[0]?.lastSeenAt, 0);
		assert.strictEqual(empty.devices[0]?.active, false);
		service.dispose();
	});

	test('pairApprove forwards request and maps result', async () => {
		const transport = new MockUniverseAgentGrpcTransport();
		const service = new UniverseAgentConnectionService({
			connectionResolver: plainFixtureResolver(),
			clientIdentityStore: plainFixtureIdentity(),
			createTransport: () => transport,
		});
		await connectPlainFixture(service);

		transport.pairApproveResult = {
			success: true,
			deviceId: 'dev-1',
			message: 'approved',
		};
		const request = {
			pairingCode: '123456',
			displayName: 'laptop',
			role: 'operator',
		};
		const result = await service.pairApprove(request);
		assert.deepStrictEqual(transport.pairApproveCalls, [request]);
		assert.deepStrictEqual(result, transport.pairApproveResult);

		transport.pairApproveResult = {
			success: false,
			deviceId: '',
			message: '',
		};
		const emptyRequest = {
			pairingCode: '',
			displayName: '',
			role: '',
		};
		const empty = await service.pairApprove(emptyRequest);
		assert.strictEqual(transport.pairApproveCalls[1]?.pairingCode, '');
		assert.strictEqual(transport.pairApproveCalls[1]?.displayName, '');
		assert.strictEqual(transport.pairApproveCalls[1]?.role, '');
		assert.strictEqual(empty.success, false);
		assert.strictEqual(empty.deviceId, '');
		assert.strictEqual(empty.message, '');
		service.dispose();
	});

	test('pairReject forwards request and maps result', async () => {
		const transport = new MockUniverseAgentGrpcTransport();
		const service = new UniverseAgentConnectionService({
			connectionResolver: plainFixtureResolver(),
			clientIdentityStore: plainFixtureIdentity(),
			createTransport: () => transport,
		});
		await connectPlainFixture(service);

		transport.pairRejectResult = {
			success: true,
			message: 'rejected',
		};
		const request = {
			pairingCode: '123456',
		};
		const result = await service.pairReject(request);
		assert.deepStrictEqual(transport.pairRejectCalls, [request]);
		assert.deepStrictEqual(result, transport.pairRejectResult);

		transport.pairRejectResult = {
			success: false,
			message: '',
		};
		const emptyRequest = {
			pairingCode: '',
		};
		const empty = await service.pairReject(emptyRequest);
		assert.strictEqual(transport.pairRejectCalls[1]?.pairingCode, '');
		assert.strictEqual(empty.success, false);
		assert.strictEqual(empty.message, '');
		service.dispose();
	});

	test('revoke forwards request and maps result', async () => {
		const transport = new MockUniverseAgentGrpcTransport();
		const service = new UniverseAgentConnectionService({
			connectionResolver: plainFixtureResolver(),
			clientIdentityStore: plainFixtureIdentity(),
			createTransport: () => transport,
		});
		await connectPlainFixture(service);

		transport.revokeResult = {
			success: true,
			message: 'revoked',
		};
		const request = {
			deviceId: 'dev-1',
		};
		const result = await service.revoke(request);
		assert.deepStrictEqual(transport.revokeCalls, [request]);
		assert.deepStrictEqual(result, transport.revokeResult);

		transport.revokeResult = {
			success: false,
			message: '',
		};
		const emptyRequest = {
			deviceId: '',
		};
		const empty = await service.revoke(emptyRequest);
		assert.strictEqual(transport.revokeCalls[1]?.deviceId, '');
		assert.strictEqual(empty.success, false);
		assert.strictEqual(empty.message, '');
		service.dispose();
	});

	test('rotateToken forwards request and maps result', async () => {
		const transport = new MockUniverseAgentGrpcTransport();
		const service = new UniverseAgentConnectionService({
			connectionResolver: plainFixtureResolver(),
			clientIdentityStore: plainFixtureIdentity(),
			createTransport: () => transport,
		});
		await connectPlainFixture(service);

		transport.rotateTokenResult = {
			success: true,
			message: 'rotated',
		};
		const request = {
			deviceId: 'dev-1',
		};
		const result = await service.rotateToken(request);
		assert.deepStrictEqual(transport.rotateTokenCalls, [request]);
		assert.deepStrictEqual(result, transport.rotateTokenResult);

		transport.rotateTokenResult = {
			success: false,
			message: '',
		};
		const emptyRequest = {
			deviceId: '',
		};
		const empty = await service.rotateToken(emptyRequest);
		assert.strictEqual(transport.rotateTokenCalls[1]?.deviceId, '');
		assert.strictEqual(empty.success, false);
		assert.strictEqual(empty.message, '');
		service.dispose();
	});

	test('listPending forwards empty request and maps result', async () => {
		const transport = new MockUniverseAgentGrpcTransport();
		const service = new UniverseAgentConnectionService({
			connectionResolver: plainFixtureResolver(),
			clientIdentityStore: plainFixtureIdentity(),
			createTransport: () => transport,
		});
		await connectPlainFixture(service);

		transport.listPendingResult = {
			pending: [{
				pairingCode: '123456',
				deviceId: 'dev-1',
				displayName: 'phone',
				platform: 'android',
				requestedAt: 100,
				expiresInSeconds: 60,
			}],
		};
		const result = await service.listPending();
		assert.strictEqual(transport.listPendingCalls, 1);
		assert.deepStrictEqual(result, transport.listPendingResult);

		transport.listPendingResult = {
			pending: [{
				pairingCode: '',
				deviceId: '',
				displayName: '',
				platform: '',
				requestedAt: 0,
				expiresInSeconds: 0,
			}],
		};
		const empty = await service.listPending();
		assert.strictEqual(transport.listPendingCalls, 2);
		assert.strictEqual(empty.pending[0]?.pairingCode, '');
		assert.strictEqual(empty.pending[0]?.deviceId, '');
		assert.strictEqual(empty.pending[0]?.displayName, '');
		assert.strictEqual(empty.pending[0]?.platform, '');
		assert.strictEqual(empty.pending[0]?.requestedAt, 0);
		assert.strictEqual(empty.pending[0]?.expiresInSeconds, 0);
		service.dispose();
	});

	test('listTriggers forwards request and maps result', async () => {
		const transport = new MockUniverseAgentGrpcTransport();
		const service = new UniverseAgentConnectionService({
			connectionResolver: plainFixtureResolver(),
			clientIdentityStore: plainFixtureIdentity(),
			createTransport: () => transport,
		});
		await connectPlainFixture(service);

		transport.listTriggersResult = {
			triggers: [{
				triggerId: 'trg-1',
				name: 'nightly',
				type: 'schedule',
				promptTemplate: 'run',
				enabled: true,
				pauseReason: 'paused',
				target: { kind: 'boundSession', sessionId: 'sess-1' },
				intervalMs: 60_000,
				cronExpression: '0 * * * *',
				runAtEpochMs: 1,
			}],
		};
		const request = {
			scope: 'session',
			scopeId: 'sess-1',
			typeFilter: 'schedule',
		};
		const result = await service.listTriggers(request);
		assert.deepStrictEqual(transport.listTriggersCalls, [request]);
		assert.deepStrictEqual(result, transport.listTriggersResult);

		transport.listTriggersResult = {
			triggers: [{
				triggerId: '',
				name: '',
				type: '',
				promptTemplate: '',
				enabled: false,
				pauseReason: '',
				target: { kind: 'newSession', engineProfileId: '' },
				intervalMs: 0,
				cronExpression: '',
				runAtEpochMs: 0,
			}],
		};
		const emptyRequest = {
			scope: '',
			scopeId: '',
			typeFilter: '',
		};
		const empty = await service.listTriggers(emptyRequest);
		assert.strictEqual(transport.listTriggersCalls[1]?.scope, '');
		assert.strictEqual(transport.listTriggersCalls[1]?.scopeId, '');
		assert.strictEqual(transport.listTriggersCalls[1]?.typeFilter, '');
		assert.strictEqual(empty.triggers[0]?.triggerId, '');
		assert.strictEqual(empty.triggers[0]?.name, '');
		assert.strictEqual(empty.triggers[0]?.type, '');
		assert.strictEqual(empty.triggers[0]?.promptTemplate, '');
		assert.strictEqual(empty.triggers[0]?.pauseReason, '');
		assert.strictEqual(empty.triggers[0]?.cronExpression, '');
		assert.strictEqual(empty.triggers[0]?.enabled, false);
		assert.strictEqual(empty.triggers[0]?.intervalMs, 0);
		assert.strictEqual(empty.triggers[0]?.runAtEpochMs, 0);
		assert.deepStrictEqual(empty.triggers[0]?.target, { kind: 'newSession', engineProfileId: '' });

		transport.listTriggersResult = { triggers: [] };
		const emptyLists = await service.listTriggers(emptyRequest);
		assert.strictEqual(transport.listTriggersCalls[2]?.scope, '');
		assert.strictEqual(transport.listTriggersCalls[2]?.scopeId, '');
		assert.strictEqual(transport.listTriggersCalls[2]?.typeFilter, '');
		assert.deepStrictEqual(emptyLists.triggers, []);
		service.dispose();
	});

	test('upsertTrigger forwards request and maps result', async () => {
		const transport = new MockUniverseAgentGrpcTransport();
		const service = new UniverseAgentConnectionService({
			connectionResolver: plainFixtureResolver(),
			clientIdentityStore: plainFixtureIdentity(),
			createTransport: () => transport,
		});
		await connectPlainFixture(service);

		transport.upsertTriggerResult = {
			trigger: {
				triggerId: 'trg-1',
				name: 'nightly',
				type: 'schedule',
				promptTemplate: 'run',
				enabled: true,
				pauseReason: 'paused',
				target: { kind: 'boundSession', sessionId: 'sess-1' },
				intervalMs: 60_000,
				cronExpression: '0 * * * *',
				runAtEpochMs: 1,
			},
		};
		const request = {
			scope: 'session',
			scopeId: 'sess-1',
			trigger: {
				triggerId: 'trg-1',
				name: 'nightly',
				type: 'schedule',
				promptTemplate: 'run',
				enabled: true,
				pauseReason: 'paused',
				target: { kind: 'boundSession' as const, sessionId: 'sess-1' },
				intervalMs: 60_000,
				cronExpression: '0 * * * *',
				runAtEpochMs: 1,
			},
		};
		const result = await service.upsertTrigger(request);
		assert.deepStrictEqual(transport.upsertTriggerCalls, [request]);
		assert.deepStrictEqual(result, transport.upsertTriggerResult);

		transport.upsertTriggerResult = {
			trigger: {
				triggerId: '',
				name: '',
				type: '',
				promptTemplate: '',
				enabled: false,
				pauseReason: '',
				target: { kind: 'newSession', engineProfileId: '' },
				intervalMs: 0,
				cronExpression: '',
				runAtEpochMs: 0,
			},
		};
		const emptyRequest = {
			scope: '',
			scopeId: '',
			trigger: {
				triggerId: '',
				name: '',
				type: '',
				promptTemplate: '',
				enabled: false,
				pauseReason: '',
				target: { kind: 'newSession' as const, engineProfileId: '' },
				intervalMs: 0,
				cronExpression: '',
				runAtEpochMs: 0,
			},
		};
		const empty = await service.upsertTrigger(emptyRequest);
		assert.strictEqual(transport.upsertTriggerCalls[1]?.scope, '');
		assert.strictEqual(transport.upsertTriggerCalls[1]?.scopeId, '');
		assert.strictEqual(transport.upsertTriggerCalls[1]?.trigger.triggerId, '');
		assert.strictEqual(transport.upsertTriggerCalls[1]?.trigger.name, '');
		assert.strictEqual(transport.upsertTriggerCalls[1]?.trigger.type, '');
		assert.strictEqual(transport.upsertTriggerCalls[1]?.trigger.promptTemplate, '');
		assert.strictEqual(transport.upsertTriggerCalls[1]?.trigger.pauseReason, '');
		assert.strictEqual(transport.upsertTriggerCalls[1]?.trigger.cronExpression, '');
		assert.strictEqual(transport.upsertTriggerCalls[1]?.trigger.enabled, false);
		assert.strictEqual(transport.upsertTriggerCalls[1]?.trigger.intervalMs, 0);
		assert.strictEqual(transport.upsertTriggerCalls[1]?.trigger.runAtEpochMs, 0);
		assert.deepStrictEqual(transport.upsertTriggerCalls[1]?.trigger.target, { kind: 'newSession', engineProfileId: '' });
		assert.strictEqual(empty.trigger.triggerId, '');
		assert.strictEqual(empty.trigger.name, '');
		assert.strictEqual(empty.trigger.type, '');
		assert.strictEqual(empty.trigger.promptTemplate, '');
		assert.strictEqual(empty.trigger.pauseReason, '');
		assert.strictEqual(empty.trigger.cronExpression, '');
		assert.strictEqual(empty.trigger.enabled, false);
		assert.strictEqual(empty.trigger.intervalMs, 0);
		assert.strictEqual(empty.trigger.runAtEpochMs, 0);
		assert.deepStrictEqual(empty.trigger.target, { kind: 'newSession', engineProfileId: '' });
		service.dispose();
	});

	test('deleteTrigger forwards request and maps result', async () => {
		const transport = new MockUniverseAgentGrpcTransport();
		const service = new UniverseAgentConnectionService({
			connectionResolver: plainFixtureResolver(),
			clientIdentityStore: plainFixtureIdentity(),
			createTransport: () => transport,
		});
		await connectPlainFixture(service);

		transport.deleteTriggerResult = {};
		const request = {
			scope: 'session',
			scopeId: 'sess-1',
			triggerId: 'trg-1',
		};
		const result = await service.deleteTrigger(request);
		assert.deepStrictEqual(transport.deleteTriggerCalls, [request]);
		assert.deepStrictEqual(result, transport.deleteTriggerResult);

		transport.deleteTriggerResult = {};
		const emptyRequest = {
			scope: '',
			scopeId: '',
			triggerId: '',
		};
		const empty = await service.deleteTrigger(emptyRequest);
		assert.strictEqual(transport.deleteTriggerCalls[1]?.scope, '');
		assert.strictEqual(transport.deleteTriggerCalls[1]?.scopeId, '');
		assert.strictEqual(transport.deleteTriggerCalls[1]?.triggerId, '');
		assert.deepStrictEqual(empty, {});
		service.dispose();
	});

	test('setTriggerEnabled forwards request and maps result', async () => {
		const transport = new MockUniverseAgentGrpcTransport();
		const service = new UniverseAgentConnectionService({
			connectionResolver: plainFixtureResolver(),
			clientIdentityStore: plainFixtureIdentity(),
			createTransport: () => transport,
		});
		await connectPlainFixture(service);

		transport.setTriggerEnabledResult = {
			trigger: {
				triggerId: 'trg-1',
				name: 'nightly',
				type: 'schedule',
				promptTemplate: 'run',
				enabled: true,
				pauseReason: 'paused',
				target: { kind: 'boundSession', sessionId: 'sess-1' },
				intervalMs: 60_000,
				cronExpression: '0 * * * *',
				runAtEpochMs: 1,
			},
		};
		const request = {
			scope: 'session',
			scopeId: 'sess-1',
			triggerId: 'trg-1',
			enabled: true,
		};
		const result = await service.setTriggerEnabled(request);
		assert.deepStrictEqual(transport.setTriggerEnabledCalls, [request]);
		assert.deepStrictEqual(result, transport.setTriggerEnabledResult);

		transport.setTriggerEnabledResult = {
			trigger: {
				triggerId: '',
				name: '',
				type: '',
				promptTemplate: '',
				enabled: false,
				pauseReason: '',
				target: { kind: 'newSession', engineProfileId: '' },
				intervalMs: 0,
				cronExpression: '',
				runAtEpochMs: 0,
			},
		};
		const emptyRequest = {
			scope: '',
			scopeId: '',
			triggerId: '',
			enabled: false,
		};
		const empty = await service.setTriggerEnabled(emptyRequest);
		assert.strictEqual(transport.setTriggerEnabledCalls[1]?.scope, '');
		assert.strictEqual(transport.setTriggerEnabledCalls[1]?.scopeId, '');
		assert.strictEqual(transport.setTriggerEnabledCalls[1]?.triggerId, '');
		assert.strictEqual(transport.setTriggerEnabledCalls[1]?.enabled, false);
		assert.strictEqual(empty.trigger.triggerId, '');
		assert.strictEqual(empty.trigger.name, '');
		assert.strictEqual(empty.trigger.type, '');
		assert.strictEqual(empty.trigger.promptTemplate, '');
		assert.strictEqual(empty.trigger.pauseReason, '');
		assert.strictEqual(empty.trigger.cronExpression, '');
		assert.strictEqual(empty.trigger.enabled, false);
		assert.strictEqual(empty.trigger.intervalMs, 0);
		assert.strictEqual(empty.trigger.runAtEpochMs, 0);
		assert.deepStrictEqual(empty.trigger.target, { kind: 'newSession', engineProfileId: '' });
		service.dispose();
	});

	test('fireTrigger forwards request and maps result', async () => {
		const transport = new MockUniverseAgentGrpcTransport();
		const service = new UniverseAgentConnectionService({
			connectionResolver: plainFixtureResolver(),
			clientIdentityStore: plainFixtureIdentity(),
			createTransport: () => transport,
		});
		await connectPlainFixture(service);

		transport.fireTriggerResult = {
			status: 'queued',
			eventId: 'evt-1',
			reason: '',
		};
		const request = {
			scope: 'session',
			scopeId: 'sess-1',
			triggerId: 'trg-1',
		};
		const result = await service.fireTrigger(request);
		assert.deepStrictEqual(transport.fireTriggerCalls, [request]);
		assert.deepStrictEqual(result, transport.fireTriggerResult);

		transport.fireTriggerResult = {
			status: '',
			eventId: '',
			reason: '',
		};
		const emptyRequest = {
			scope: '',
			scopeId: '',
			triggerId: '',
		};
		const empty = await service.fireTrigger(emptyRequest);
		assert.strictEqual(transport.fireTriggerCalls[1]?.scope, '');
		assert.strictEqual(transport.fireTriggerCalls[1]?.scopeId, '');
		assert.strictEqual(transport.fireTriggerCalls[1]?.triggerId, '');
		assert.strictEqual(empty.status, '');
		assert.strictEqual(empty.eventId, '');
		assert.strictEqual(empty.reason, '');
		service.dispose();
	});

	test('writeClipboard forwards request and maps result', async () => {
		const transport = new MockUniverseAgentGrpcTransport();
		const service = new UniverseAgentConnectionService({
			connectionResolver: plainFixtureResolver(),
			clientIdentityStore: plainFixtureIdentity(),
			createTransport: () => transport,
		});
		await connectPlainFixture(service);

		transport.writeClipboardResult = {
			clipId: 'clip-1',
		};
		const request = {
			sessionId: 'sess-1',
			agentId: 'agent-1',
			label: 'note',
			type: 'CLIPBOARD_TEXT' as const,
			content: 'hello',
			filePath: '',
			url: '',
		};
		const result = await service.writeClipboard(request);
		assert.deepStrictEqual(transport.writeClipboardCalls, [request]);
		assert.deepStrictEqual(result, transport.writeClipboardResult);

		transport.writeClipboardResult = {
			clipId: '',
		};
		const emptyRequest = {
			sessionId: '',
			agentId: '',
			label: '',
			type: 'CLIPBOARD_TEXT' as const,
			content: '',
			filePath: '',
			url: '',
		};
		const empty = await service.writeClipboard(emptyRequest);
		assert.strictEqual(transport.writeClipboardCalls[1]?.sessionId, '');
		assert.strictEqual(transport.writeClipboardCalls[1]?.agentId, '');
		assert.strictEqual(transport.writeClipboardCalls[1]?.label, '');
		assert.strictEqual(transport.writeClipboardCalls[1]?.content, '');
		assert.strictEqual(transport.writeClipboardCalls[1]?.filePath, '');
		assert.strictEqual(transport.writeClipboardCalls[1]?.url, '');
		assert.strictEqual(empty.clipId, '');
		service.dispose();
	});

	test('readClipboard forwards request and maps result', async () => {
		const transport = new MockUniverseAgentGrpcTransport();
		const service = new UniverseAgentConnectionService({
			connectionResolver: plainFixtureResolver(),
			clientIdentityStore: plainFixtureIdentity(),
			createTransport: () => transport,
		});
		await connectPlainFixture(service);

		transport.readClipboardResult = {
			entry: {
				clipId: 'clip-1',
				label: 'note',
				type: 'CLIPBOARD_TEXT',
				content: 'hello',
				createdBy: 'agent-1',
				createdAt: 1,
			},
		};
		const request = {
			sessionId: 'sess-1',
			clipId: 'clip-1',
		};
		const result = await service.readClipboard(request);
		assert.deepStrictEqual(transport.readClipboardCalls, [request]);
		assert.deepStrictEqual(result, transport.readClipboardResult);

		transport.readClipboardResult = {
			entry: {
				clipId: '',
				label: '',
				type: 'CLIPBOARD_TEXT',
				content: '',
				createdBy: '',
				createdAt: 0,
			},
		};
		const emptyRequest = {
			sessionId: '',
			clipId: '',
		};
		const empty = await service.readClipboard(emptyRequest);
		assert.strictEqual(transport.readClipboardCalls[1]?.sessionId, '');
		assert.strictEqual(transport.readClipboardCalls[1]?.clipId, '');
		assert.strictEqual(empty.entry.clipId, '');
		assert.strictEqual(empty.entry.label, '');
		assert.strictEqual(empty.entry.content, '');
		assert.strictEqual(empty.entry.createdBy, '');
		assert.strictEqual(empty.entry.createdAt, 0);
		service.dispose();
	});

	test('listClipboard forwards request and maps result', async () => {
		const transport = new MockUniverseAgentGrpcTransport();
		const service = new UniverseAgentConnectionService({
			connectionResolver: plainFixtureResolver(),
			clientIdentityStore: plainFixtureIdentity(),
			createTransport: () => transport,
		});
		await connectPlainFixture(service);

		transport.listClipboardResult = {
			entries: [{
				clipId: 'clip-1',
				label: 'note',
				type: 'CLIPBOARD_TEXT',
				createdBy: 'agent-1',
				createdAt: 1,
			}],
		};
		const request = {
			sessionId: 'sess-1',
		};
		const result = await service.listClipboard(request);
		assert.deepStrictEqual(transport.listClipboardCalls, [request]);
		assert.deepStrictEqual(result, transport.listClipboardResult);

		transport.listClipboardResult = {
			entries: [{
				clipId: '',
				label: '',
				type: 'CLIPBOARD_TEXT',
				createdBy: '',
				createdAt: 0,
			}],
		};
		const emptyRequest = {
			sessionId: '',
		};
		const empty = await service.listClipboard(emptyRequest);
		assert.strictEqual(transport.listClipboardCalls[1]?.sessionId, '');
		assert.strictEqual(empty.entries[0]?.clipId, '');
		assert.strictEqual(empty.entries[0]?.label, '');
		assert.strictEqual(empty.entries[0]?.createdBy, '');
		assert.strictEqual(empty.entries[0]?.createdAt, 0);

		transport.listClipboardResult = { entries: [] };
		const emptyList = await service.listClipboard(emptyRequest);
		assert.deepStrictEqual(emptyList.entries, []);
		service.dispose();
	});

	test('clearClipboard forwards request and maps result', async () => {
		const transport = new MockUniverseAgentGrpcTransport();
		const service = new UniverseAgentConnectionService({
			connectionResolver: plainFixtureResolver(),
			clientIdentityStore: plainFixtureIdentity(),
			createTransport: () => transport,
		});
		await connectPlainFixture(service);

		transport.clearClipboardResult = {
			removedCount: 3,
		};
		const request = {
			sessionId: 'sess-1',
		};
		const result = await service.clearClipboard(request);
		assert.deepStrictEqual(transport.clearClipboardCalls, [request]);
		assert.deepStrictEqual(result, transport.clearClipboardResult);

		transport.clearClipboardResult = {
			removedCount: 0,
		};
		const emptyRequest = {
			sessionId: '',
		};
		const empty = await service.clearClipboard(emptyRequest);
		assert.strictEqual(transport.clearClipboardCalls[1]?.sessionId, '');
		assert.strictEqual(empty.removedCount, 0);
		service.dispose();
	});

	test('setPermissionPolicy forwards request and maps result', async () => {
		const transport = new MockUniverseAgentGrpcTransport();
		const service = new UniverseAgentConnectionService({
			connectionResolver: plainFixtureResolver(),
			clientIdentityStore: plainFixtureIdentity(),
			createTransport: () => transport,
		});
		await connectPlainFixture(service);

		transport.setPermissionPolicyResult = { ok: true, message: 'applied' };
		const result = await service.setPermissionPolicy({
			sessionId: 'sess-1',
			toolName: 'shell',
			policy: 'PERMISSION_POLICY_ASK',
		});
		assert.deepStrictEqual(transport.setPermissionPolicyCalls, [{
			sessionId: 'sess-1',
			toolName: 'shell',
			policy: 'PERMISSION_POLICY_ASK',
		}]);
		assert.deepStrictEqual(result, { ok: true, message: 'applied' });

		transport.setPermissionPolicyResult = { ok: false, message: '' };
		const empty = await service.setPermissionPolicy({
			sessionId: '',
			toolName: '',
			policy: 'PERMISSION_POLICY_UNSPECIFIED',
		});
		assert.deepStrictEqual(empty, { ok: false, message: '' });
		assert.strictEqual(transport.setPermissionPolicyCalls[1]?.sessionId, '');
		assert.strictEqual(transport.setPermissionPolicyCalls[1]?.toolName, '');
		assert.strictEqual(transport.setPermissionPolicyCalls[1]?.policy, 'PERMISSION_POLICY_UNSPECIFIED');
		service.dispose();
	});

	test('getTodo forwards request and maps result', async () => {
		const transport = new MockUniverseAgentGrpcTransport();
		const service = new UniverseAgentConnectionService({
			connectionResolver: plainFixtureResolver(),
			clientIdentityStore: plainFixtureIdentity(),
			createTransport: () => transport,
		});
		await connectPlainFixture(service);

		transport.getTodoResult = {
			items: [{
				id: 'todo-1',
				content: 'wire catalog',
				status: 'in_progress',
				priority: 1,
				requireConfirm: true,
				blocked: 'need review',
			}],
		};
		const result = await service.getTodo({ sessionId: 'sess-1', agentId: 'root' });
		assert.deepStrictEqual(transport.getTodoCalls, [{ sessionId: 'sess-1', agentId: 'root' }]);
		assert.deepStrictEqual(result, transport.getTodoResult);

		transport.getTodoResult = { items: [] };
		const empty = await service.getTodo({ sessionId: '', agentId: '' });
		assert.deepStrictEqual(empty, { items: [] });
		assert.strictEqual(transport.getTodoCalls[1]?.sessionId, '');
		assert.strictEqual(transport.getTodoCalls[1]?.agentId, '');
		service.dispose();
	});

	test('resolveAnchor forwards request and maps result', async () => {
		const transport = new MockUniverseAgentGrpcTransport();
		const service = new UniverseAgentConnectionService({
			connectionResolver: plainFixtureResolver(),
			clientIdentityStore: plainFixtureIdentity(),
			createTransport: () => transport,
		});
		await connectPlainFixture(service);

		transport.resolveAnchorResult = {
			hit: {
				envelope: { id: 'env-1' },
				presence: 'ENVELOPE_RECORD_PRESENCE_ACTIVE_ON_PATH',
				generation: 2,
			},
		};
		const result = await service.resolveAnchor({
			anchor: { sessionId: 'sess-1', envelopeId: 'env-1', generation: 2 },
			scope: 'ANCHOR_RESOLVE_SCOPE_ACTIVE',
			currentLeafTurnId: 'turn-1',
		});
		assert.deepStrictEqual(transport.resolveAnchorCalls, [{
			anchor: { sessionId: 'sess-1', envelopeId: 'env-1', generation: 2 },
			scope: 'ANCHOR_RESOLVE_SCOPE_ACTIVE',
			currentLeafTurnId: 'turn-1',
		}]);
		assert.deepStrictEqual(result, transport.resolveAnchorResult);

		transport.resolveAnchorResult = {
			expired: { anchor: { sessionId: '', envelopeId: '' } },
		};
		const empty = await service.resolveAnchor({
			anchor: { sessionId: '', envelopeId: '' },
			scope: 'ANCHOR_RESOLVE_SCOPE_UNSPECIFIED',
			currentLeafTurnId: '',
		});
		assert.deepStrictEqual(empty, transport.resolveAnchorResult);
		assert.strictEqual(transport.resolveAnchorCalls[1]?.anchor.sessionId, '');
		assert.strictEqual(transport.resolveAnchorCalls[1]?.anchor.envelopeId, '');
		assert.strictEqual(transport.resolveAnchorCalls[1]?.currentLeafTurnId, '');
		service.dispose();
	});

	test('getUsage forwards request and maps result', async () => {
		const transport = new MockUniverseAgentGrpcTransport();
		const service = new UniverseAgentConnectionService({
			connectionResolver: plainFixtureResolver(),
			clientIdentityStore: plainFixtureIdentity(),
			createTransport: () => transport,
		});
		await connectPlainFixture(service);

		transport.getUsageResult = {
			totalInputTokens: 12,
			totalOutputTokens: 34,
			totalTurns: 2,
			agentUsages: [{
				agentId: 'root',
				inputTokens: 12,
				outputTokens: 34,
				turns: 2,
			}],
			recentRequestSpans: [{
				profileId: 'p1',
				provider: 'openai',
				modelId: 'gpt',
				inputTokens: 8,
				outputTokens: 16,
				prefillMs: 1,
				decodeMs: 2,
				completedAtMs: 3,
				usageKind: 'chat',
			}],
		};
		const result = await service.getUsage({ sessionId: 'sess-1', agentId: 'root' });
		assert.deepStrictEqual(transport.getUsageCalls, [{ sessionId: 'sess-1', agentId: 'root' }]);
		assert.deepStrictEqual(result, transport.getUsageResult);

		transport.getUsageResult = {
			totalInputTokens: 0,
			totalOutputTokens: 0,
			totalTurns: 0,
			agentUsages: [],
			recentRequestSpans: [],
		};
		const empty = await service.getUsage({ sessionId: '', agentId: '' });
		assert.deepStrictEqual(empty, transport.getUsageResult);
		assert.strictEqual(transport.getUsageCalls[1]?.sessionId, '');
		assert.strictEqual(transport.getUsageCalls[1]?.agentId, '');
		service.dispose();
	});

	test('getAgentHistory forwards request and maps result', async () => {
		const transport = new MockUniverseAgentGrpcTransport();
		const service = new UniverseAgentConnectionService({
			connectionResolver: plainFixtureResolver(),
			clientIdentityStore: plainFixtureIdentity(),
			createTransport: () => transport,
		});
		await connectPlainFixture(service);

		transport.getAgentHistoryResult = {
			entries: [{
				role: 'user',
				content: 'hello',
				timestamp: 1,
				agentId: 'root',
			}],
			total: 1,
		};
		const result = await service.getAgentHistory({ sessionId: 'sess-1', agentId: 'root', limit: 20, offset: 0 });
		assert.deepStrictEqual(transport.getAgentHistoryCalls, [{ sessionId: 'sess-1', agentId: 'root', limit: 20, offset: 0 }]);
		assert.deepStrictEqual(result, transport.getAgentHistoryResult);

		transport.getAgentHistoryResult = { entries: [], total: 0 };
		const empty = await service.getAgentHistory({ sessionId: '', agentId: '', limit: 0, offset: 0 });
		assert.deepStrictEqual(empty, transport.getAgentHistoryResult);
		assert.strictEqual(transport.getAgentHistoryCalls[1]?.sessionId, '');
		assert.strictEqual(transport.getAgentHistoryCalls[1]?.agentId, '');
		service.dispose();
	});

	test('prune forwards request and maps result', async () => {
		const transport = new MockUniverseAgentGrpcTransport();
		const service = new UniverseAgentConnectionService({
			connectionResolver: plainFixtureResolver(),
			clientIdentityStore: plainFixtureIdentity(),
			createTransport: () => transport,
		});
		await connectPlainFixture(service);

		transport.pruneResult = { ok: true, message: 'pruned', removedCount: 3 };
		const result = await service.prune({ sessionId: 'sess-1', agentId: 'root' });
		assert.deepStrictEqual(transport.pruneCalls, [{ sessionId: 'sess-1', agentId: 'root' }]);
		assert.deepStrictEqual(result, transport.pruneResult);

		transport.pruneResult = { ok: false, message: 'busy', removedCount: 0 };
		const empty = await service.prune({ sessionId: '', agentId: '' });
		assert.deepStrictEqual(empty, transport.pruneResult);
		assert.strictEqual(transport.pruneCalls[1]?.sessionId, '');
		assert.strictEqual(transport.pruneCalls[1]?.agentId, '');
		service.dispose();
	});

	test('resetAgent forwards request and maps result', async () => {
		const transport = new MockUniverseAgentGrpcTransport();
		const service = new UniverseAgentConnectionService({
			connectionResolver: plainFixtureResolver(),
			clientIdentityStore: plainFixtureIdentity(),
			createTransport: () => transport,
		});
		await connectPlainFixture(service);

		transport.resetAgentResult = { ok: true, message: 'reset' };
		const result = await service.resetAgent({ sessionId: 'sess-1', agentId: 'root', clearProfileOnly: true });
		assert.deepStrictEqual(transport.resetAgentCalls, [{ sessionId: 'sess-1', agentId: 'root', clearProfileOnly: true }]);
		assert.deepStrictEqual(result, transport.resetAgentResult);

		transport.resetAgentResult = { ok: false, message: 'already empty' };
		const empty = await service.resetAgent({ sessionId: '', agentId: '' });
		assert.deepStrictEqual(empty, transport.resetAgentResult);
		assert.strictEqual(transport.resetAgentCalls[1]?.sessionId, '');
		assert.strictEqual(transport.resetAgentCalls[1]?.agentId, '');
		service.dispose();
	});

	test('branch forwards request and maps result', async () => {
		const transport = new MockUniverseAgentGrpcTransport();
		const service = new UniverseAgentConnectionService({
			connectionResolver: plainFixtureResolver(),
			clientIdentityStore: plainFixtureIdentity(),
			createTransport: () => transport,
		});
		await connectPlainFixture(service);

		transport.branchResult = { ok: true, message: 'switched', currentBranch: 2, totalBranches: 3, currentTurnId: 'turn-9' };
		const result = await service.branch({ sessionId: 'sess-1', agentId: 'root', branchIndex: 1, turnId: 'turn-1' });
		assert.deepStrictEqual(transport.branchCalls, [{ sessionId: 'sess-1', agentId: 'root', branchIndex: 1, turnId: 'turn-1' }]);
		assert.deepStrictEqual(result, transport.branchResult);

		transport.branchResult = { ok: false, message: 'no branch', currentBranch: 0, totalBranches: 0 };
		const empty = await service.branch({ sessionId: '', agentId: '', branchIndex: -1, turnId: '' });
		assert.deepStrictEqual(empty, transport.branchResult);
		assert.strictEqual(transport.branchCalls[1]?.sessionId, '');
		assert.strictEqual(transport.branchCalls[1]?.agentId, '');
		assert.strictEqual(transport.branchCalls[1]?.branchIndex, -1);
		assert.strictEqual(transport.branchCalls[1]?.turnId, '');
		service.dispose();
	});

	test('shelveSession forwards request and maps result', async () => {
		const transport = new MockUniverseAgentGrpcTransport();
		const service = new UniverseAgentConnectionService({
			connectionResolver: plainFixtureResolver(),
			clientIdentityStore: plainFixtureIdentity(),
			createTransport: () => transport,
		});
		await connectPlainFixture(service);

		const result = await service.shelveSession({ sessionId: 'sess-1' });
		assert.deepStrictEqual(transport.shelveSessionCalls, [{ sessionId: 'sess-1' }]);
		assert.deepStrictEqual(result, { ok: true });

		transport.shelveSessionResult = { ok: false, message: 'not found' };
		const failed = await service.shelveSession({ sessionId: '' });
		assert.deepStrictEqual(failed, { ok: false, message: 'not found' });
		assert.strictEqual(transport.shelveSessionCalls[1]?.sessionId, '');
		service.dispose();
	});

	test('purgeSession forwards request and maps result', async () => {
		const transport = new MockUniverseAgentGrpcTransport();
		const service = new UniverseAgentConnectionService({
			connectionResolver: plainFixtureResolver(),
			clientIdentityStore: plainFixtureIdentity(),
			createTransport: () => transport,
		});
		await connectPlainFixture(service);

		const result = await service.purgeSession({ sessionId: 'sess-1' });
		assert.deepStrictEqual(transport.purgeSessionCalls, [{ sessionId: 'sess-1' }]);
		assert.deepStrictEqual(result, { ok: true });

		transport.purgeSessionResult = { ok: false, message: 'not found' };
		const failed = await service.purgeSession({ sessionId: '' });
		assert.deepStrictEqual(failed, { ok: false, message: 'not found' });
		assert.strictEqual(transport.purgeSessionCalls[1]?.sessionId, '');
		service.dispose();
	});

	test('deleteSnapshot forwards request and maps result', async () => {
		const transport = new MockUniverseAgentGrpcTransport();
		const service = new UniverseAgentConnectionService({
			connectionResolver: plainFixtureResolver(),
			clientIdentityStore: plainFixtureIdentity(),
			createTransport: () => transport,
		});
		await connectPlainFixture(service);

		transport.deleteSnapshotResult = { ok: true };
		const result = await service.deleteSnapshot({ sessionId: 'sess-1', snapshotId: 'snap-1' });
		assert.deepStrictEqual(transport.deleteSnapshotCalls, [{ sessionId: 'sess-1', snapshotId: 'snap-1' }]);
		assert.deepStrictEqual(result, { ok: true });

		transport.deleteSnapshotResult = { ok: false, message: 'denied' };
		const failed = await service.deleteSnapshot({ sessionId: '', snapshotId: '' });
		assert.deepStrictEqual(failed, { ok: false, message: 'denied' });
		assert.strictEqual(transport.deleteSnapshotCalls[1]?.sessionId, '');
		assert.strictEqual(transport.deleteSnapshotCalls[1]?.snapshotId, '');
		service.dispose();
	});

	test('resumeSession forwards request and maps result', async () => {
		const transport = new MockUniverseAgentGrpcTransport();
		const service = new UniverseAgentConnectionService({
			connectionResolver: plainFixtureResolver(),
			clientIdentityStore: plainFixtureIdentity(),
			createTransport: () => transport,
		});
		await connectPlainFixture(service);

		transport.resumeSessionResult = {
			ok: true,
			rootAgent: {
				agentId: 'root',
				name: 'Root',
				type: 'AGENT_TYPE_UNKNOWN',
				status: 'AGENT_STATUS_UNKNOWN',
				model: 'gpt',
				turnCount: 2,
				createdAt: 10,
				children: [],
			},
		};
		const result = await service.resumeSession({ sessionId: 'sess-1' });
		assert.deepStrictEqual(transport.resumeSessionCalls, [{ sessionId: 'sess-1' }]);
		assert.deepStrictEqual(result, transport.resumeSessionResult);

		transport.resumeSessionResult = { ok: false, message: 'not found' };
		const failed = await service.resumeSession({ sessionId: '' });
		assert.deepStrictEqual(failed, { ok: false, message: 'not found' });
		assert.strictEqual(transport.resumeSessionCalls[1]?.sessionId, '');
		service.dispose();
	});

	test('unshelveSession forwards request and maps result', async () => {
		const transport = new MockUniverseAgentGrpcTransport();
		const service = new UniverseAgentConnectionService({
			connectionResolver: plainFixtureResolver(),
			clientIdentityStore: plainFixtureIdentity(),
			createTransport: () => transport,
		});
		await connectPlainFixture(service);

		const result = await service.unshelveSession({ sessionId: 'sess-1' });
		assert.deepStrictEqual(transport.unshelveSessionCalls, [{ sessionId: 'sess-1' }]);
		assert.deepStrictEqual(result, { ok: true });

		transport.unshelveSessionResult = { ok: false, message: 'not found' };
		const failed = await service.unshelveSession({ sessionId: '' });
		assert.deepStrictEqual(failed, { ok: false, message: 'not found' });
		assert.strictEqual(transport.unshelveSessionCalls[1]?.sessionId, '');
		service.dispose();
	});

	test('prewarmSessions forwards request and maps result', async () => {
		const transport = new MockUniverseAgentGrpcTransport();
		const service = new UniverseAgentConnectionService({
			connectionResolver: plainFixtureResolver(),
			clientIdentityStore: plainFixtureIdentity(),
			createTransport: () => transport,
		});
		await connectPlainFixture(service);

		transport.prewarmSessionsResult = {
			entries: [{ sessionId: 'sess-1', outcome: 'PREWARM_SESSION_OUTCOME_RESTORED', message: 'ok' }],
		};
		const result = await service.prewarmSessions({ sessionIds: ['sess-1'] });
		assert.deepStrictEqual(transport.prewarmSessionsCalls, [{ sessionIds: ['sess-1'] }]);
		assert.deepStrictEqual(result, transport.prewarmSessionsResult);

		transport.prewarmSessionsResult = { entries: [] };
		const empty = await service.prewarmSessions({ sessionIds: [''] });
		assert.deepStrictEqual(empty, transport.prewarmSessionsResult);
		assert.deepStrictEqual(transport.prewarmSessionsCalls[1]?.sessionIds, ['']);
		service.dispose();
	});

	test('exportSession forwards request and maps result', async () => {
		const transport = new MockUniverseAgentGrpcTransport();
		const service = new UniverseAgentConnectionService({
			connectionResolver: plainFixtureResolver(),
			clientIdentityStore: plainFixtureIdentity(),
			createTransport: () => transport,
		});
		await connectPlainFixture(service);

		transport.exportSessionResult = { content: '# sess', format: 'markdown' };
		const result = await service.exportSession({ sessionId: 'sess-1', format: 'markdown' });
		assert.deepStrictEqual(transport.exportSessionCalls, [{ sessionId: 'sess-1', format: 'markdown' }]);
		assert.deepStrictEqual(result, { content: '# sess', format: 'markdown' });

		transport.exportSessionResult = { content: '', format: '' };
		const empty = await service.exportSession({ sessionId: '', format: '' });
		assert.deepStrictEqual(empty, { content: '', format: '' });
		assert.strictEqual(transport.exportSessionCalls[1]?.sessionId, '');
		assert.strictEqual(transport.exportSessionCalls[1]?.format, '');
		service.dispose();
	});

	test('resolveTurn forwards request and maps result', async () => {
		const transport = new MockUniverseAgentGrpcTransport();
		const service = new UniverseAgentConnectionService({
			connectionResolver: plainFixtureResolver(),
			clientIdentityStore: plainFixtureIdentity(),
			createTransport: () => transport,
		});
		await connectPlainFixture(service);

		transport.resolveTurnResult = {
			kind: 'hit',
			envelope: { id: 'env-1' },
			presence: 'ENVELOPE_RECORD_PRESENCE_ACTIVE_OFF_PATH',
			generation: 2,
		};
		const result = await service.resolveTurn({ sessionId: 'sess-1', turnId: 'turn-1', currentLeafTurnId: 'leaf-1' });
		assert.deepStrictEqual(transport.resolveTurnCalls, [{ sessionId: 'sess-1', turnId: 'turn-1', currentLeafTurnId: 'leaf-1' }]);
		assert.deepStrictEqual(result, transport.resolveTurnResult);

		transport.resolveTurnResult = { kind: 'expired', sessionId: '', envelopeId: '' };
		const empty = await service.resolveTurn({ sessionId: '', turnId: '', currentLeafTurnId: '' });
		assert.deepStrictEqual(empty, transport.resolveTurnResult);
		assert.strictEqual(transport.resolveTurnCalls[1]?.sessionId, '');
		assert.strictEqual(transport.resolveTurnCalls[1]?.turnId, '');
		assert.strictEqual(transport.resolveTurnCalls[1]?.currentLeafTurnId, '');
		service.dispose();
	});

	test('getAgentStatus forwards request and maps result', async () => {
		const transport = new MockUniverseAgentGrpcTransport();
		const service = new UniverseAgentConnectionService({
			connectionResolver: plainFixtureResolver(),
			clientIdentityStore: plainFixtureIdentity(),
			createTransport: () => transport,
		});
		await connectPlainFixture(service);

		transport.getAgentStatusResult = {
			agent: {
				agentId: 'root',
				name: 'Root',
				type: 'AGENT_TYPE_UNKNOWN',
				status: 'AGENT_STATUS_IDLE',
				model: 'gpt',
				turnCount: 2,
				createdAt: 10,
				children: [],
			},
		};
		const result = await service.getAgentStatus({ sessionId: 'sess-1', agentId: 'root' });
		assert.deepStrictEqual(transport.getAgentStatusCalls, [{ sessionId: 'sess-1', agentId: 'root' }]);
		assert.deepStrictEqual(result, transport.getAgentStatusResult);

		transport.getAgentStatusResult = {};
		const empty = await service.getAgentStatus({ sessionId: '', agentId: '' });
		assert.deepStrictEqual(empty, transport.getAgentStatusResult);
		assert.strictEqual(transport.getAgentStatusCalls[1]?.sessionId, '');
		assert.strictEqual(transport.getAgentStatusCalls[1]?.agentId, '');
		service.dispose();
	});

	test('compact forwards request and maps result', async () => {
		const transport = new MockUniverseAgentGrpcTransport();
		const service = new UniverseAgentConnectionService({
			connectionResolver: plainFixtureResolver(),
			clientIdentityStore: plainFixtureIdentity(),
			createTransport: () => transport,
		});
		await connectPlainFixture(service);

		transport.compactResult = {
			ok: true,
			message: 'compacted',
			tokensBefore: 1200,
			tokensAfter: 400,
			outcome: 'COMPACT_OUTCOME_SUCCEEDED',
			rejectReason: '',
		};
		const result = await service.compact({ sessionId: 'sess-1', agentId: 'root' });
		assert.deepStrictEqual(transport.compactCalls, [{ sessionId: 'sess-1', agentId: 'root' }]);
		assert.deepStrictEqual(result, transport.compactResult);

		transport.compactResult = { ok: false, message: 'busy', outcome: 'COMPACT_OUTCOME_FAILED', rejectReason: 'ADMISSION_BUSY' };
		const empty = await service.compact({ sessionId: '', agentId: '' });
		assert.deepStrictEqual(empty, transport.compactResult);
		assert.strictEqual(transport.compactCalls[1]?.sessionId, '');
		assert.strictEqual(transport.compactCalls[1]?.agentId, '');
		service.dispose();
	});

	test('listAgents forwards request and maps result', async () => {
		const transport = new MockUniverseAgentGrpcTransport();
		const service = new UniverseAgentConnectionService({
			connectionResolver: plainFixtureResolver(),
			clientIdentityStore: plainFixtureIdentity(),
			createTransport: () => transport,
		});
		await connectPlainFixture(service);

		transport.listAgentsResult = {
			agents: [{
				agentId: 'root',
				name: 'Root',
				type: 'AGENT_TYPE_UNKNOWN',
				status: 'AGENT_STATUS_IDLE',
				model: 'gpt',
				turnCount: 2,
				createdAt: 10,
				children: [],
			}],
		};
		const result = await service.listAgents({ sessionId: 'sess-1' });
		assert.deepStrictEqual(transport.listAgentsCalls, [{ sessionId: 'sess-1' }]);
		assert.deepStrictEqual(result, transport.listAgentsResult);

		transport.listAgentsResult = { agents: [] };
		const empty = await service.listAgents({ sessionId: '' });
		assert.deepStrictEqual(empty, { agents: [] });
		assert.strictEqual(transport.listAgentsCalls[1]?.sessionId, '');
		service.dispose();
	});

	test('pauseAgent forwards request and maps result', async () => {
		const transport = new MockUniverseAgentGrpcTransport();
		const service = new UniverseAgentConnectionService({
			connectionResolver: plainFixtureResolver(),
			clientIdentityStore: plainFixtureIdentity(),
			createTransport: () => transport,
		});
		await connectPlainFixture(service);

		transport.pauseAgentResult = { ok: true, message: 'paused' };
		const result = await service.pauseAgent({ sessionId: 'sess-1', agentId: 'root' });
		assert.deepStrictEqual(transport.pauseAgentCalls, [{ sessionId: 'sess-1', agentId: 'root' }]);
		assert.deepStrictEqual(result, transport.pauseAgentResult);

		transport.pauseAgentResult = { ok: false, message: 'already idle' };
		const empty = await service.pauseAgent({ sessionId: '', agentId: '' });
		assert.deepStrictEqual(empty, transport.pauseAgentResult);
		assert.strictEqual(transport.pauseAgentCalls[1]?.sessionId, '');
		assert.strictEqual(transport.pauseAgentCalls[1]?.agentId, '');
		service.dispose();
	});

	test('suspendLoop forwards request and maps result', async () => {
		const transport = new MockUniverseAgentGrpcTransport();
		const service = new UniverseAgentConnectionService({
			connectionResolver: plainFixtureResolver(),
			clientIdentityStore: plainFixtureIdentity(),
			createTransport: () => transport,
		});
		await connectPlainFixture(service);

		transport.suspendLoopResult = { ok: true, message: 'suspended' };
		const result = await service.suspendLoop({ sessionId: 'sess-1', agentId: 'root' });
		assert.deepStrictEqual(transport.suspendLoopCalls, [{ sessionId: 'sess-1', agentId: 'root' }]);
		assert.deepStrictEqual(result, transport.suspendLoopResult);

		transport.suspendLoopResult = { ok: false, message: 'already suspended' };
		const empty = await service.suspendLoop({ sessionId: '', agentId: '' });
		assert.deepStrictEqual(empty, transport.suspendLoopResult);
		assert.strictEqual(transport.suspendLoopCalls[1]?.sessionId, '');
		assert.strictEqual(transport.suspendLoopCalls[1]?.agentId, '');
		service.dispose();
	});

	test('resumeLoop forwards request and maps result', async () => {
		const transport = new MockUniverseAgentGrpcTransport();
		const service = new UniverseAgentConnectionService({
			connectionResolver: plainFixtureResolver(),
			clientIdentityStore: plainFixtureIdentity(),
			createTransport: () => transport,
		});
		await connectPlainFixture(service);

		transport.resumeLoopResult = { ok: true, message: 'resumed' };
		const result = await service.resumeLoop({ sessionId: 'sess-1', agentId: 'root' });
		assert.deepStrictEqual(transport.resumeLoopCalls, [{ sessionId: 'sess-1', agentId: 'root' }]);
		assert.deepStrictEqual(result, transport.resumeLoopResult);

		transport.resumeLoopResult = { ok: false, message: 'not suspended' };
		const empty = await service.resumeLoop({ sessionId: '', agentId: '' });
		assert.deepStrictEqual(empty, transport.resumeLoopResult);
		assert.strictEqual(transport.resumeLoopCalls[1]?.sessionId, '');
		assert.strictEqual(transport.resumeLoopCalls[1]?.agentId, '');
		service.dispose();
	});

	test('stopLoop forwards request and maps result', async () => {
		const transport = new MockUniverseAgentGrpcTransport();
		const service = new UniverseAgentConnectionService({
			connectionResolver: plainFixtureResolver(),
			clientIdentityStore: plainFixtureIdentity(),
			createTransport: () => transport,
		});
		await connectPlainFixture(service);

		transport.stopLoopResult = { ok: true, message: 'stopped' };
		const result = await service.stopLoop({ sessionId: 'sess-1', agentId: 'root', detail: 'user_stop' });
		assert.deepStrictEqual(transport.stopLoopCalls, [{ sessionId: 'sess-1', agentId: 'root', detail: 'user_stop' }]);
		assert.deepStrictEqual(result, transport.stopLoopResult);

		transport.stopLoopResult = { ok: false, message: 'not in loop' };
		const empty = await service.stopLoop({ sessionId: '', agentId: '', detail: '' });
		assert.deepStrictEqual(empty, transport.stopLoopResult);
		assert.strictEqual(transport.stopLoopCalls[1]?.sessionId, '');
		assert.strictEqual(transport.stopLoopCalls[1]?.agentId, '');
		assert.strictEqual(transport.stopLoopCalls[1]?.detail, '');
		service.dispose();
	});

	test('back forwards request and maps result', async () => {
		const transport = new MockUniverseAgentGrpcTransport();
		const service = new UniverseAgentConnectionService({
			connectionResolver: plainFixtureResolver(),
			clientIdentityStore: plainFixtureIdentity(),
			createTransport: () => transport,
		});
		await connectPlainFixture(service);

		transport.backResult = { ok: true, message: 'backed', currentTurnId: 'turn-parent' };
		const result = await service.back({ sessionId: 'sess-1', agentId: 'root', operationId: 'op-1' });
		assert.deepStrictEqual(transport.backCalls, [{ sessionId: 'sess-1', agentId: 'root', operationId: 'op-1' }]);
		assert.deepStrictEqual(result, transport.backResult);

		transport.backResult = { ok: false, message: 'empty leaf', currentTurnId: '' };
		const empty = await service.back({ sessionId: '', agentId: '', operationId: '' });
		assert.deepStrictEqual(empty, transport.backResult);
		assert.strictEqual(transport.backCalls[1]?.sessionId, '');
		assert.strictEqual(transport.backCalls[1]?.agentId, '');
		assert.strictEqual(transport.backCalls[1]?.operationId, '');
		service.dispose();
	});

	test('openChatStream forwards transport onClosed', async () => {
		const transport = new MockUniverseAgentGrpcTransport();
		const service = new UniverseAgentConnectionService({
			connectionResolver: plainFixtureResolver(),
			clientIdentityStore: plainFixtureIdentity(),
			createTransport: () => transport,
		});
		await connectPlainFixture(service);

		const seen: UniverseAgentSessionStreamCloseCause[] = [];
		const handle = service.openChatStream('sess-1', () => { }, cause => seen.push(cause));
		assert.deepStrictEqual(transport.chatOpens, ['sess-1']);
		transport.fireChatClosed({ kind: 'remote' });
		transport.fireChatClosed({ kind: 'error', message: 'late' });
		assert.deepStrictEqual(seen, [{ kind: 'remote' }]);
		handle.dispose();
		service.dispose();
	});

	test('openChatStream dispose silences later onClosed', async () => {
		const transport = new MockUniverseAgentGrpcTransport();
		const service = new UniverseAgentConnectionService({
			connectionResolver: plainFixtureResolver(),
			clientIdentityStore: plainFixtureIdentity(),
			createTransport: () => transport,
		});
		await connectPlainFixture(service);

		const seen: UniverseAgentSessionStreamCloseCause[] = [];
		const handle = service.openChatStream('sess-1', () => { }, cause => seen.push(cause));
		handle.dispose();
		transport.fireChatClosed({ kind: 'error', message: 'CANCELLED' });
		assert.deepStrictEqual(seen, []);
		service.dispose();
	});

	test('openContinuationStream forwards request and transport onClosed', async () => {
		const transport = new MockUniverseAgentGrpcTransport();
		const service = new UniverseAgentConnectionService({
			connectionResolver: plainFixtureResolver(),
			clientIdentityStore: plainFixtureIdentity(),
			createTransport: () => transport,
		});
		await connectPlainFixture(service);

		const seen: UniverseAgentSessionStreamCloseCause[] = [];
		const handle = service.openContinuationStream({
			sessionId: 'sess-1',
			agentId: 'agent-a',
			turnId: 'turn-9',
			messageId: 'msg-3',
		}, () => { }, cause => seen.push(cause));
		assert.deepStrictEqual(transport.continuationOpens, [{
			sessionId: 'sess-1',
			agentId: 'agent-a',
			turnId: 'turn-9',
			messageId: 'msg-3',
		}]);
		transport.fireContinuationClosed({ kind: 'remote' });
		transport.fireContinuationClosed({ kind: 'error', message: 'late' });
		assert.deepStrictEqual(seen, [{ kind: 'remote' }]);
		handle.dispose();
		service.dispose();
	});

	test('openContinuationStream dispose silences later onClosed', async () => {
		const transport = new MockUniverseAgentGrpcTransport();
		const service = new UniverseAgentConnectionService({
			connectionResolver: plainFixtureResolver(),
			clientIdentityStore: plainFixtureIdentity(),
			createTransport: () => transport,
		});
		await connectPlainFixture(service);

		const seen: UniverseAgentSessionStreamCloseCause[] = [];
		const handle = service.openContinuationStream({
			sessionId: 'sess-1',
			agentId: 'agent-a',
			turnId: 'turn-9',
			messageId: 'msg-3',
		}, () => { }, cause => seen.push(cause));
		handle.dispose();
		transport.fireContinuationClosed({ kind: 'error', message: 'CANCELLED' });
		assert.deepStrictEqual(seen, []);
		service.dispose();
	});

	test('openRegenerateStream forwards request and transport onClosed', async () => {
		const transport = new MockUniverseAgentGrpcTransport();
		const service = new UniverseAgentConnectionService({
			connectionResolver: plainFixtureResolver(),
			clientIdentityStore: plainFixtureIdentity(),
			createTransport: () => transport,
		});
		await connectPlainFixture(service);

		const seen: UniverseAgentSessionStreamCloseCause[] = [];
		const handle = service.openRegenerateStream({
			sessionId: 'sess-1',
			agentId: 'agent-a',
			turnId: 'turn-9',
			messageId: 'msg-3',
		}, () => { }, cause => seen.push(cause));
		assert.deepStrictEqual(transport.regenerateOpens, [{
			sessionId: 'sess-1',
			agentId: 'agent-a',
			turnId: 'turn-9',
			messageId: 'msg-3',
		}]);
		transport.fireRegenerateClosed({ kind: 'remote' });
		transport.fireRegenerateClosed({ kind: 'error', message: 'late' });
		assert.deepStrictEqual(seen, [{ kind: 'remote' }]);

		service.openRegenerateStream({
			sessionId: '',
			agentId: '',
			turnId: '',
			messageId: '',
		}, () => { });
		assert.strictEqual(transport.regenerateOpens[1]?.sessionId, '');
		assert.strictEqual(transport.regenerateOpens[1]?.agentId, '');
		assert.strictEqual(transport.regenerateOpens[1]?.turnId, '');
		assert.strictEqual(transport.regenerateOpens[1]?.messageId, '');
		handle.dispose();
		service.dispose();
	});

	test('openRegenerateStream dispose silences later onClosed', async () => {
		const transport = new MockUniverseAgentGrpcTransport();
		const service = new UniverseAgentConnectionService({
			connectionResolver: plainFixtureResolver(),
			clientIdentityStore: plainFixtureIdentity(),
			createTransport: () => transport,
		});
		await connectPlainFixture(service);

		const seen: UniverseAgentSessionStreamCloseCause[] = [];
		const handle = service.openRegenerateStream({
			sessionId: 'sess-1',
			agentId: 'agent-a',
			turnId: 'turn-9',
			messageId: 'msg-3',
		}, () => { }, cause => seen.push(cause));
		handle.dispose();
		transport.fireRegenerateClosed({ kind: 'error', message: 'CANCELLED' });
		assert.deepStrictEqual(seen, []);
		service.dispose();
	});

	test('openResumeStream forwards request and transport onClosed', async () => {
		const transport = new MockUniverseAgentGrpcTransport();
		const service = new UniverseAgentConnectionService({
			connectionResolver: plainFixtureResolver(),
			clientIdentityStore: plainFixtureIdentity(),
			createTransport: () => transport,
		});
		await connectPlainFixture(service);

		const seen: UniverseAgentSessionStreamCloseCause[] = [];
		const handle = service.openResumeStream({
			sessionId: 'sess-1',
			agentId: 'agent-a',
		}, () => { }, cause => seen.push(cause));
		assert.deepStrictEqual(transport.resumeOpens, [{
			sessionId: 'sess-1',
			agentId: 'agent-a',
		}]);
		transport.fireResumeClosed({ kind: 'remote' });
		transport.fireResumeClosed({ kind: 'error', message: 'late' });
		assert.deepStrictEqual(seen, [{ kind: 'remote' }]);

		service.openResumeStream({
			sessionId: '',
			agentId: '',
		}, () => { });
		assert.strictEqual(transport.resumeOpens[1]?.sessionId, '');
		assert.strictEqual(transport.resumeOpens[1]?.agentId, '');
		handle.dispose();
		service.dispose();
	});

	test('openResumeStream dispose silences later onClosed', async () => {
		const transport = new MockUniverseAgentGrpcTransport();
		const service = new UniverseAgentConnectionService({
			connectionResolver: plainFixtureResolver(),
			clientIdentityStore: plainFixtureIdentity(),
			createTransport: () => transport,
		});
		await connectPlainFixture(service);

		const seen: UniverseAgentSessionStreamCloseCause[] = [];
		const handle = service.openResumeStream({
			sessionId: 'sess-1',
			agentId: 'agent-a',
		}, () => { }, cause => seen.push(cause));
		handle.dispose();
		transport.fireResumeClosed({ kind: 'error', message: 'CANCELLED' });
		assert.deepStrictEqual(seen, []);
		service.dispose();
	});

	test('openSubscribeToolDetailStream forwards request and transport onClosed', async () => {
		const transport = new MockUniverseAgentGrpcTransport();
		const service = new UniverseAgentConnectionService({
			connectionResolver: plainFixtureResolver(),
			clientIdentityStore: plainFixtureIdentity(),
			createTransport: () => transport,
		});
		await connectPlainFixture(service);

		const seen: UniverseAgentSessionStreamCloseCause[] = [];
		const handle = service.openSubscribeToolDetailStream({
			sessionId: 'sess-1',
			toolCallId: 'tc-1',
			detailKind: 2,
			refId: 'ref-9',
			fromRevision: 3,
		}, () => { }, cause => seen.push(cause));
		assert.deepStrictEqual(transport.subscribeToolDetailOpens, [{
			sessionId: 'sess-1',
			toolCallId: 'tc-1',
			detailKind: 2,
			refId: 'ref-9',
			fromRevision: 3,
		}]);
		transport.fireSubscribeToolDetailClosed({ kind: 'remote' });
		transport.fireSubscribeToolDetailClosed({ kind: 'error', message: 'late' });
		assert.deepStrictEqual(seen, [{ kind: 'remote' }]);

		service.openSubscribeToolDetailStream({
			sessionId: '',
			toolCallId: '',
			detailKind: 0,
			refId: '',
			fromRevision: 0,
		}, () => { });
		assert.strictEqual(transport.subscribeToolDetailOpens[1]?.sessionId, '');
		assert.strictEqual(transport.subscribeToolDetailOpens[1]?.toolCallId, '');
		assert.strictEqual(transport.subscribeToolDetailOpens[1]?.refId, '');
		handle.dispose();
		service.dispose();
	});

	test('openSubscribeToolDetailStream dispose silences later onClosed', async () => {
		const transport = new MockUniverseAgentGrpcTransport();
		const service = new UniverseAgentConnectionService({
			connectionResolver: plainFixtureResolver(),
			clientIdentityStore: plainFixtureIdentity(),
			createTransport: () => transport,
		});
		await connectPlainFixture(service);

		const seen: UniverseAgentSessionStreamCloseCause[] = [];
		const handle = service.openSubscribeToolDetailStream({
			sessionId: 'sess-1',
			toolCallId: 'tc-1',
			detailKind: 0,
			refId: 'ref-1',
			fromRevision: 0,
		}, () => { }, cause => seen.push(cause));
		handle.dispose();
		transport.fireSubscribeToolDetailClosed({ kind: 'error', message: 'CANCELLED' });
		assert.deepStrictEqual(seen, []);
		service.dispose();
	});

	test('openRemoteChatStream forwards request and transport onClosed', async () => {
		const transport = new MockUniverseAgentGrpcTransport();
		const service = new UniverseAgentConnectionService({
			connectionResolver: plainFixtureResolver(),
			clientIdentityStore: plainFixtureIdentity(),
			createTransport: () => transport,
		});
		await connectPlainFixture(service);

		const seen: UniverseAgentSessionStreamCloseCause[] = [];
		const handle = service.openRemoteChatStream({
			callId: 'call-1',
			task: 'do work',
			responses: [{
				type: 'permission',
				requestId: 'req-1',
				permission: { decision: 'grant', reason: 'ok' },
			}],
			overridePending: true,
		}, () => { }, cause => seen.push(cause));
		assert.deepStrictEqual(transport.remoteChatOpens, [{
			callId: 'call-1',
			task: 'do work',
			responses: [{
				type: 'permission',
				requestId: 'req-1',
				permission: { decision: 'grant', reason: 'ok' },
			}],
			overridePending: true,
		}] as UniverseAgentRemoteChatRequest[]);
		transport.fireRemoteChatClosed({ kind: 'remote' });
		transport.fireRemoteChatClosed({ kind: 'error', message: 'late' });
		assert.deepStrictEqual(seen, [{ kind: 'remote' }]);

		service.openRemoteChatStream({
			callId: '',
			task: '',
			responses: [{
				type: '',
				requestId: '',
				permission: { decision: '', reason: '' },
				questionAnswersJson: '',
			}],
			overridePending: false,
		}, () => { });
		assert.strictEqual(transport.remoteChatOpens[1]?.callId, '');
		assert.strictEqual(transport.remoteChatOpens[1]?.task, '');
		assert.strictEqual(transport.remoteChatOpens[1]?.overridePending, false);
		assert.strictEqual(transport.remoteChatOpens[1]?.responses[0]?.type, '');
		assert.strictEqual(transport.remoteChatOpens[1]?.responses[0]?.requestId, '');
		assert.strictEqual(transport.remoteChatOpens[1]?.responses[0]?.permission?.decision, '');
		assert.strictEqual(transport.remoteChatOpens[1]?.responses[0]?.permission?.reason, '');
		assert.strictEqual(transport.remoteChatOpens[1]?.responses[0]?.questionAnswersJson, '');
		handle.dispose();
		service.dispose();
	});

	test('openRemoteChatStream dispose silences later onClosed', async () => {
		const transport = new MockUniverseAgentGrpcTransport();
		const service = new UniverseAgentConnectionService({
			connectionResolver: plainFixtureResolver(),
			clientIdentityStore: plainFixtureIdentity(),
			createTransport: () => transport,
		});
		await connectPlainFixture(service);

		const seen: UniverseAgentSessionStreamCloseCause[] = [];
		const handle = service.openRemoteChatStream({
			callId: '',
			task: '',
			responses: [],
			overridePending: false,
		}, () => { }, cause => seen.push(cause));
		handle.dispose();
		transport.fireRemoteChatClosed({ kind: 'error', message: 'CANCELLED' });
		assert.deepStrictEqual(seen, []);
		service.dispose();
	});

	test('openRebuildMemoryStream forwards request and transport onClosed', async () => {
		const transport = new MockUniverseAgentGrpcTransport();
		const service = new UniverseAgentConnectionService({
			connectionResolver: plainFixtureResolver(),
			clientIdentityStore: plainFixtureIdentity(),
			createTransport: () => transport,
		});
		await connectPlainFixture(service);

		const seen: UniverseAgentSessionStreamCloseCause[] = [];
		const handle = service.openRebuildMemoryStream({
			scope: 'project',
			dryRun: true,
		}, () => { }, cause => seen.push(cause));
		assert.deepStrictEqual(transport.rebuildMemoryOpens, [{
			scope: 'project',
			dryRun: true,
		}]);
		transport.fireRebuildMemoryClosed({ kind: 'remote' });
		transport.fireRebuildMemoryClosed({ kind: 'error', message: 'late' });
		assert.deepStrictEqual(seen, [{ kind: 'remote' }]);

		service.openRebuildMemoryStream({
			scope: '',
			dryRun: false,
		}, () => { });
		assert.strictEqual(transport.rebuildMemoryOpens[1]?.scope, '');
		assert.strictEqual(transport.rebuildMemoryOpens[1]?.dryRun, false);
		handle.dispose();
		service.dispose();
	});

	test('openRebuildMemoryStream dispose silences later onClosed', async () => {
		const transport = new MockUniverseAgentGrpcTransport();
		const service = new UniverseAgentConnectionService({
			connectionResolver: plainFixtureResolver(),
			clientIdentityStore: plainFixtureIdentity(),
			createTransport: () => transport,
		});
		await connectPlainFixture(service);

		const seen: UniverseAgentSessionStreamCloseCause[] = [];
		const handle = service.openRebuildMemoryStream({
			scope: '',
			dryRun: false,
		}, () => { }, cause => seen.push(cause));
		handle.dispose();
		transport.fireRebuildMemoryClosed({ kind: 'error', message: 'CANCELLED' });
		assert.deepStrictEqual(seen, []);
		service.dispose();
	});

	test('openWatchConfigStream forwards request and transport onClosed', async () => {
		const transport = new MockUniverseAgentGrpcTransport();
		const service = new UniverseAgentConnectionService({
			connectionResolver: plainFixtureResolver(),
			clientIdentityStore: plainFixtureIdentity(),
			createTransport: () => transport,
		});
		await connectPlainFixture(service);

		const seen: UniverseAgentSessionStreamCloseCause[] = [];
		const handle = service.openWatchConfigStream({
			keys: ['model.id', ''],
		}, () => { }, cause => seen.push(cause));
		assert.deepStrictEqual(transport.watchConfigOpens, [{
			keys: ['model.id', ''],
		}]);
		transport.fireWatchConfigClosed({ kind: 'remote' });
		transport.fireWatchConfigClosed({ kind: 'error', message: 'late' });
		assert.deepStrictEqual(seen, [{ kind: 'remote' }]);

		service.openWatchConfigStream({
			keys: [],
		}, () => { });
		assert.deepStrictEqual(transport.watchConfigOpens[1]?.keys, []);
		handle.dispose();
		service.dispose();
	});

	test('openWatchConfigStream dispose silences later onClosed', async () => {
		const transport = new MockUniverseAgentGrpcTransport();
		const service = new UniverseAgentConnectionService({
			connectionResolver: plainFixtureResolver(),
			clientIdentityStore: plainFixtureIdentity(),
			createTransport: () => transport,
		});
		await connectPlainFixture(service);

		const seen: UniverseAgentSessionStreamCloseCause[] = [];
		const handle = service.openWatchConfigStream({
			keys: [''],
		}, () => { }, cause => seen.push(cause));
		handle.dispose();
		transport.fireWatchConfigClosed({ kind: 'error', message: 'CANCELLED' });
		assert.deepStrictEqual(seen, []);
		service.dispose();
	});

	test('openUploadAttachmentStream forwards writes and transport onClosed', async () => {
		const transport = new MockUniverseAgentGrpcTransport();
		const service = new UniverseAgentConnectionService({
			connectionResolver: plainFixtureResolver(),
			clientIdentityStore: plainFixtureIdentity(),
			createTransport: () => transport,
		});
		await connectPlainFixture(service);

		const seen: UniverseAgentSessionStreamCloseCause[] = [];
		const handle = service.openUploadAttachmentStream(() => { }, cause => seen.push(cause));
		assert.strictEqual(transport.uploadAttachmentOpenCount, 1);
		handle.write({
			header: {
				transferId: 'xfer-1',
				filename: 'a.bin',
				totalSize: 3,
				mimeType: 'application/octet-stream',
				checksumSha256: 'abc',
				isPrecompressed: false,
				sessionId: 'sess-1',
				chunkSize: 2,
				queueItemId: 'q-1',
			},
			offset: 0,
		});
		handle.write({
			chunk: new Uint8Array([1, 2, 3]),
			offset: 0,
		});
		assert.deepStrictEqual(transport.uploadAttachmentWrites, [{
			header: {
				transferId: 'xfer-1',
				filename: 'a.bin',
				totalSize: 3,
				mimeType: 'application/octet-stream',
				checksumSha256: 'abc',
				isPrecompressed: false,
				sessionId: 'sess-1',
				chunkSize: 2,
				queueItemId: 'q-1',
			},
			offset: 0,
		}, {
			chunk: new Uint8Array([1, 2, 3]),
			offset: 0,
		}]);
		transport.fireUploadAttachmentClosed({ kind: 'remote' });
		transport.fireUploadAttachmentClosed({ kind: 'error', message: 'late' });
		assert.deepStrictEqual(seen, [{ kind: 'remote' }]);

		const empty = service.openUploadAttachmentStream(() => { });
		empty.write({
			header: {
				transferId: '',
				filename: '',
				totalSize: 0,
				mimeType: '',
				checksumSha256: '',
				isPrecompressed: false,
				sessionId: '',
				chunkSize: 0,
				queueItemId: '',
			},
			chunk: new Uint8Array(0),
			offset: 0,
		});
		assert.strictEqual(transport.uploadAttachmentWrites[2]?.header?.transferId, '');
		assert.strictEqual(transport.uploadAttachmentWrites[2]?.header?.filename, '');
		assert.strictEqual(transport.uploadAttachmentWrites[2]?.header?.sessionId, '');
		assert.strictEqual(transport.uploadAttachmentWrites[2]?.header?.queueItemId, '');
		assert.deepStrictEqual(transport.uploadAttachmentWrites[2]?.chunk, new Uint8Array(0));
		handle.dispose();
		empty.dispose();
		service.dispose();
	});

	test('openUploadAttachmentStream dispose silences later onClosed', async () => {
		const transport = new MockUniverseAgentGrpcTransport();
		const service = new UniverseAgentConnectionService({
			connectionResolver: plainFixtureResolver(),
			clientIdentityStore: plainFixtureIdentity(),
			createTransport: () => transport,
		});
		await connectPlainFixture(service);

		const seen: UniverseAgentSessionStreamCloseCause[] = [];
		const handle = service.openUploadAttachmentStream(() => { }, cause => seen.push(cause));
		handle.dispose();
		transport.fireUploadAttachmentClosed({ kind: 'error', message: 'CANCELLED' });
		assert.deepStrictEqual(seen, []);
		service.dispose();
	});

	test('openDownloadAttachmentStream forwards request and transport onClosed', async () => {
		const transport = new MockUniverseAgentGrpcTransport();
		const service = new UniverseAgentConnectionService({
			connectionResolver: plainFixtureResolver(),
			clientIdentityStore: plainFixtureIdentity(),
			createTransport: () => transport,
		});
		await connectPlainFixture(service);

		const seen: UniverseAgentSessionStreamCloseCause[] = [];
		const handle = service.openDownloadAttachmentStream({
			filePath: 'att/a.bin',
			offset: 8,
			maxBytes: 64,
			sessionId: 'sess-1',
			artifactId: 'art-1',
		}, () => { }, cause => seen.push(cause));
		assert.deepStrictEqual(transport.downloadAttachmentOpens, [{
			filePath: 'att/a.bin',
			offset: 8,
			maxBytes: 64,
			sessionId: 'sess-1',
			artifactId: 'art-1',
		}]);
		transport.fireDownloadAttachmentClosed({ kind: 'remote' });
		transport.fireDownloadAttachmentClosed({ kind: 'error', message: 'late' });
		assert.deepStrictEqual(seen, [{ kind: 'remote' }]);

		service.openDownloadAttachmentStream({
			filePath: '',
			offset: 0,
			maxBytes: 0,
			sessionId: '',
			artifactId: '',
		}, () => { });
		assert.strictEqual(transport.downloadAttachmentOpens[1]?.filePath, '');
		assert.strictEqual(transport.downloadAttachmentOpens[1]?.offset, 0);
		assert.strictEqual(transport.downloadAttachmentOpens[1]?.maxBytes, 0);
		assert.strictEqual(transport.downloadAttachmentOpens[1]?.sessionId, '');
		assert.strictEqual(transport.downloadAttachmentOpens[1]?.artifactId, '');
		handle.dispose();
		service.dispose();
	});

	test('openDownloadAttachmentStream dispose silences later onClosed', async () => {
		const transport = new MockUniverseAgentGrpcTransport();
		const service = new UniverseAgentConnectionService({
			connectionResolver: plainFixtureResolver(),
			clientIdentityStore: plainFixtureIdentity(),
			createTransport: () => transport,
		});
		await connectPlainFixture(service);

		const seen: UniverseAgentSessionStreamCloseCause[] = [];
		const handle = service.openDownloadAttachmentStream({
			filePath: '',
			offset: 0,
			maxBytes: 0,
			sessionId: '',
			artifactId: '',
		}, () => { }, cause => seen.push(cause));
		handle.dispose();
		transport.fireDownloadAttachmentClosed({ kind: 'error', message: 'CANCELLED' });
		assert.deepStrictEqual(seen, []);
		service.dispose();
	});

	test('openPtyStream forwards writes, server frames, and transport onClosed', async () => {
		const transport = new MockUniverseAgentGrpcTransport();
		const service = new UniverseAgentConnectionService({
			connectionResolver: plainFixtureResolver(),
			clientIdentityStore: plainFixtureIdentity(),
			createTransport: () => transport,
		});
		await connectPlainFixture(service);

		const seen: UniverseAgentSessionStreamCloseCause[] = [];
		const frames: UniverseAgentPtyServerMessage[] = [];
		const handle = service.openPtyStream(frame => frames.push(frame), cause => seen.push(cause));
		assert.strictEqual(transport.ptyStreamOpenCount, 1);
		handle.write({
			openSession: {
				engineSessionId: 'eng-1',
				clientSessionId: 'term-1',
				tabId: 'tab-1',
				workingDirectory: '/tmp',
				shellCommand: '/bin/bash',
				shellArgs: ['-l'],
				environment: { TERM: 'xterm' },
				initialCommand: 'ls',
				columns: 80,
				rows: 24,
			},
		});
		handle.write({
			write: { data: new Uint8Array([1, 2, 3]) },
		});
		assert.deepStrictEqual(transport.ptyStreamWrites, [{
			openSession: {
				engineSessionId: 'eng-1',
				clientSessionId: 'term-1',
				tabId: 'tab-1',
				workingDirectory: '/tmp',
				shellCommand: '/bin/bash',
				shellArgs: ['-l'],
				environment: { TERM: 'xterm' },
				initialCommand: 'ls',
				columns: 80,
				rows: 24,
			},
		}, {
			write: { data: new Uint8Array([1, 2, 3]) },
		}]);
		transport.firePtyStreamMessage({
			openSessionResponse: {
				success: true,
				ptySessionId: 'pty-1',
				failureReason: 'PTY_OPEN_FAILURE_UNSPECIFIED',
			},
		});
		transport.firePtyStreamMessage({
			read: { data: new Uint8Array(0) },
		});
		assert.deepStrictEqual(frames, [{
			openSessionResponse: {
				success: true,
				ptySessionId: 'pty-1',
				failureReason: 'PTY_OPEN_FAILURE_UNSPECIFIED',
			},
		}, {
			read: { data: new Uint8Array(0) },
		}]);
		transport.firePtyStreamClosed({ kind: 'remote' });
		transport.firePtyStreamClosed({ kind: 'error', message: 'late' });
		assert.deepStrictEqual(seen, [{ kind: 'remote' }]);

		const empty = service.openPtyStream(() => { });
		empty.write({
			openSession: {
				engineSessionId: '',
				clientSessionId: '',
				tabId: '',
				workingDirectory: '',
				shellCommand: '',
				shellArgs: [''],
				environment: { '': '' },
				initialCommand: '',
				columns: 0,
				rows: 0,
			},
		});
		empty.write({
			write: { data: new Uint8Array(0) },
		});
		assert.strictEqual(transport.ptyStreamWrites[2]?.openSession?.engineSessionId, '');
		assert.strictEqual(transport.ptyStreamWrites[2]?.openSession?.clientSessionId, '');
		assert.strictEqual(transport.ptyStreamWrites[2]?.openSession?.tabId, '');
		assert.strictEqual(transport.ptyStreamWrites[2]?.openSession?.workingDirectory, '');
		assert.deepStrictEqual(transport.ptyStreamWrites[2]?.openSession?.shellArgs, ['']);
		assert.deepStrictEqual(transport.ptyStreamWrites[2]?.openSession?.environment, { '': '' });
		assert.deepStrictEqual(transport.ptyStreamWrites[3]?.write?.data, new Uint8Array(0));
		handle.dispose();
		empty.dispose();
		service.dispose();
	});

	test('openPtyStream dispose silences later onClosed', async () => {
		const transport = new MockUniverseAgentGrpcTransport();
		const service = new UniverseAgentConnectionService({
			connectionResolver: plainFixtureResolver(),
			clientIdentityStore: plainFixtureIdentity(),
			createTransport: () => transport,
		});
		await connectPlainFixture(service);

		const seen: UniverseAgentSessionStreamCloseCause[] = [];
		const handle = service.openPtyStream(() => { }, cause => seen.push(cause));
		handle.dispose();
		transport.firePtyStreamClosed({ kind: 'error', message: 'CANCELLED' });
		assert.deepStrictEqual(seen, []);
		service.dispose();
	});

	test('pairing-pending => isEngineConnected === false', async () => {
		const service = new UniverseAgentConnectionService({
			connectionProfileStore: new PairingTestProfileStore(directPairingPendingProfile()),
			connectionResolver: pairingRequiredResolver() as unknown as ConnectionResolver,
			pairingOrchestrator: awaitingSasOrchestrator(),
		});

		const result = await service.connectProfile(PAIRING_PROFILE_ID);
		assert.strictEqual(result.ok, true);
		assert.strictEqual(service.isEngineConnected(), false);
		assert.strictEqual(service.getConnectionSnapshot().pairingPending, true);
		service.dispose();
	});

	test('GrpcCapabilityProbe UNIMPLEMENTED on skills => UNSUPPORTED', async () => {
		const transport = new MockUniverseAgentGrpcTransport({
			connect: async () => ({
				sessionToken: 'token-1',
				methods: ['ToolService.ListSkills'],
				events: [],
			}),
			probeRpc: async () => GrpcStatusCode.UNIMPLEMENTED,
		});
		const service = new UniverseAgentConnectionService({
			connectionResolver: plainFixtureResolver(),
			clientIdentityStore: plainFixtureIdentity(),
			createTransport: () => transport,
		});

		await connectPlainFixture(service);

		assert.strictEqual(service.getCapabilitySnapshot().skills.support, 'UNSUPPORTED');
		assert.strictEqual(service.getCapabilitySnapshot().skills.reason, 'UNIMPLEMENTED');
		service.dispose();
	});

	test('SessionService.List advertised + probe OK => sessionList SUPPORTED (not in Overview keys)', async () => {
		const probed: Array<{ service: string; method: string }> = [];
		const transport = new MockUniverseAgentGrpcTransport({
			connect: async () => ({
				sessionToken: 'token-1',
				methods: [UniverseAgentSessionListMethodKey],
				events: [],
			}),
			probeRpc: async (service, method) => {
				probed.push({ service, method });
				return GrpcStatusCode.OK;
			},
		});
		const service = new UniverseAgentConnectionService({
			connectionResolver: plainFixtureResolver(),
			clientIdentityStore: plainFixtureIdentity(),
			createTransport: () => transport,
		});

		await connectPlainFixture(service);

		assert.strictEqual(service.getNavigatorCapability('sessionList'), 'SUPPORTED');
		assert.strictEqual(service.getConnectionSnapshot().sessionListCapability, 'SUPPORTED');
		assert.strictEqual(Object.hasOwn(service.getCapabilitySnapshot(), 'sessionList'), false);
		assert.ok(probed.some(call =>
			call.service === UniverseAgentGrpcServices.Session.service
			&& call.method === UniverseAgentGrpcServices.Session.List));
		await service.disconnect();
		assert.strictEqual(service.getNavigatorCapability('sessionList'), 'UNKNOWN');
		service.dispose();
	});

	test('SessionService.List not advertised => sessionList UNSUPPORTED without List probe', async () => {
		const probed: Array<{ service: string; method: string }> = [];
		const transport = new MockUniverseAgentGrpcTransport({
			connect: async () => ({
				sessionToken: 'token-1',
				methods: ['ToolService.ListSkills'],
				events: [],
			}),
			probeRpc: async (service, method) => {
				probed.push({ service, method });
				return GrpcStatusCode.OK;
			},
		});
		const service = new UniverseAgentConnectionService({
			connectionResolver: plainFixtureResolver(),
			clientIdentityStore: plainFixtureIdentity(),
			createTransport: () => transport,
		});

		await connectPlainFixture(service);

		assert.strictEqual(service.getNavigatorCapability('sessionList'), 'UNSUPPORTED');
		assert.strictEqual(service.getConnectionSnapshot().sessionListCapability, 'UNSUPPORTED');
		assert.ok(!probed.some(call =>
			call.service === UniverseAgentGrpcServices.Session.service
			&& call.method === UniverseAgentGrpcServices.Session.List));
		service.dispose();
	});

	test('git write capability is snapshotted beside sessionList and cleared on disconnect', async () => {
		const probed: string[] = [];
		const transport = new MockUniverseAgentGrpcTransport({
			connect: async () => ({
				sessionToken: 'token-1',
				methods: ['GitService.ReadGitChanges', 'GitService.WriteGitCommit'],
				events: [],
			}),
			probeRpc: async (_service, method) => {
				probed.push(method);
				return GrpcStatusCode.OK;
			},
		});
		const service = new UniverseAgentConnectionService({
			connectionResolver: plainFixtureResolver(),
			clientIdentityStore: plainFixtureIdentity(),
			createTransport: () => transport,
		});

		await connectPlainFixture(service);

		const gitWrite = service.getConnectionSnapshot().gitWriteCapability;
		assert.strictEqual(gitWrite?.writeGitStagePaths, 'UNSUPPORTED');
		assert.strictEqual(gitWrite?.writeGitCommit, 'SUPPORTED');
		assert.strictEqual(gitWrite?.writeGitApplyHunks, 'UNSUPPORTED');
		assert.strictEqual(Object.hasOwn(service.getCapabilitySnapshot(), 'writeGitStagePaths'), false);
		assert.ok(probed.includes(UniverseAgentGrpcServices.Git.WriteGitCommit));
		assert.ok(!probed.includes(UniverseAgentGrpcServices.Git.WriteGitStagePaths));
		await service.disconnect();
		assert.strictEqual(service.getConnectionSnapshot().gitWriteCapability?.writeGitCommit, 'UNKNOWN');
		assert.strictEqual(service.getConnectionSnapshot().gitWriteCapability?.writeGitStagePaths, 'UNKNOWN');
		service.dispose();
	});

	test('conversation entry capability is snapshotted beside git write and cleared on disconnect', async () => {
		const probed: string[] = [];
		const transport = new MockUniverseAgentGrpcTransport({
			connect: async () => ({
				sessionToken: 'token-1',
				methods: ['ClipboardService.List', 'PermissionService.SetPermissionMode'],
				events: [],
			}),
			probeRpc: async (_service, method) => {
				probed.push(method);
				return method === UniverseAgentGrpcServices.Clipboard.List
					? GrpcStatusCode.UNIMPLEMENTED
					: GrpcStatusCode.OK;
			},
		});
		const service = new UniverseAgentConnectionService({
			connectionResolver: plainFixtureResolver(),
			clientIdentityStore: plainFixtureIdentity(),
			createTransport: () => transport,
		});

		await connectPlainFixture(service);

		const entry = service.getConnectionSnapshot().conversationEntryCapability;
		assert.strictEqual(entry?.listClipboard, 'UNSUPPORTED');
		assert.strictEqual(entry?.setPermissionMode, 'SUPPORTED');
		assert.strictEqual(entry?.listTriggers, 'UNSUPPORTED');
		assert.strictEqual(entry?.switchAgent, 'UNSUPPORTED');
		assert.strictEqual(Object.hasOwn(service.getCapabilitySnapshot(), 'listClipboard'), false);
		assert.ok(probed.includes(UniverseAgentGrpcServices.Clipboard.List));
		assert.ok(probed.includes(UniverseAgentGrpcServices.Permission.SetPermissionMode));
		assert.ok(!probed.includes(UniverseAgentGrpcServices.Trigger.ListTriggers));
		await service.disconnect();
		assert.strictEqual(service.getConnectionSnapshot().conversationEntryCapability?.listClipboard, 'UNKNOWN');
		assert.strictEqual(service.getConnectionSnapshot().conversationEntryCapability?.switchAgent, 'UNKNOWN');
		service.dispose();
	});

	test('listFiles capability is snapshotted beside conversation entry and cleared on disconnect', async () => {
		const hiddenProbed: string[] = [];
		const hidden = new UniverseAgentConnectionService({
			connectionResolver: plainFixtureResolver(),
			clientIdentityStore: plainFixtureIdentity(),
			createTransport: () => new MockUniverseAgentGrpcTransport({
				connect: async () => ({
					sessionToken: 'token-1',
					methods: ['GitService.ReadGitChanges'],
					events: [],
				}),
				probeRpc: async (_service, method) => {
					hiddenProbed.push(method);
					return GrpcStatusCode.OK;
				},
			}),
		});
		await connectPlainFixture(hidden);
		assert.strictEqual(hidden.getConnectionSnapshot().listFilesCapability, 'UNSUPPORTED');
		assert.ok(!hiddenProbed.includes(UniverseAgentGrpcServices.File.ListFiles));
		hidden.dispose();

		const probed: string[] = [];
		const service = new UniverseAgentConnectionService({
			connectionResolver: plainFixtureResolver(),
			clientIdentityStore: plainFixtureIdentity(),
			createTransport: () => new MockUniverseAgentGrpcTransport({
				connect: async () => ({
					sessionToken: 'token-1',
					methods: ['FileService.ListFiles'],
					events: [],
				}),
				probeRpc: async (_service, method) => {
					probed.push(method);
					return GrpcStatusCode.OK;
				},
			}),
		});
		await connectPlainFixture(service);
		assert.strictEqual(service.getConnectionSnapshot().listFilesCapability, 'SUPPORTED');
		assert.strictEqual(Object.hasOwn(service.getCapabilitySnapshot(), 'listFiles'), false);
		assert.ok(probed.includes(UniverseAgentGrpcServices.File.ListFiles));
		await service.disconnect();
		assert.strictEqual(service.getConnectionSnapshot().listFilesCapability, 'UNKNOWN');
		service.dispose();
	});

	test('SessionService.List advertised + UNIMPLEMENTED probe => sessionList UNSUPPORTED', async () => {
		const transport = new MockUniverseAgentGrpcTransport({
			connect: async () => ({
				sessionToken: 'token-1',
				methods: [UniverseAgentSessionListMethodKey],
				events: [],
			}),
			probeRpc: async (_service, method) => {
				if (method === UniverseAgentGrpcServices.Session.List) {
					return GrpcStatusCode.UNIMPLEMENTED;
				}
				return GrpcStatusCode.OK;
			},
		});
		const service = new UniverseAgentConnectionService({
			connectionResolver: plainFixtureResolver(),
			clientIdentityStore: plainFixtureIdentity(),
			createTransport: () => transport,
		});

		await connectPlainFixture(service);

		assert.strictEqual(service.getNavigatorCapability('sessionList'), 'UNSUPPORTED');
		assert.strictEqual(service.getConnectionSnapshot().sessionListCapability, 'UNSUPPORTED');
		service.dispose();
	});

	test('transport failure => transport failed rather than empty list', async () => {
		const transport = new MockUniverseAgentGrpcTransport({
			connect: async () => ({
				sessionToken: 'token-1',
				methods: [],
				events: [],
			}),
			listSessions: async () => {
				throw new UniverseAgentTransportError(GrpcStatusCode.UNAVAILABLE, 'engine unavailable');
			},
		});
		const service = new UniverseAgentConnectionService({
			connectionResolver: plainFixtureResolver(),
			clientIdentityStore: plainFixtureIdentity(),
			createTransport: () => transport,
		});

		await connectPlainFixture(service);

		await assert.rejects(
			() => service.listSessions({ limit: 10 }),
			(error: unknown) => error instanceof UniverseAgentTransportError,
		);
		assert.strictEqual(service.getTransportState(), 'failed');
		service.dispose();
	});

	test('onDidFileMutation fires joined records from host', () => {
		const service = new UniverseAgentConnectionService({
			createTransport: () => new MockUniverseAgentGrpcTransport(),
		});
		const records: unknown[] = [];
		store.add(service.onDidFileMutation(r => records.push(r)));
		service.notifyFileMutation({
			sessionId: 's1',
			toolCallId: 'tc',
			turnId: 't1',
			agentId: 'a1',
			path: 'p.ts',
			operation: 'edit',
		});
		assert.strictEqual(records.length, 1);
		service.dispose();
	});

	test('onDidTurnSettle fires from host notifyTurnSettle', () => {
		const service = new UniverseAgentConnectionService({
			createTransport: () => new MockUniverseAgentGrpcTransport(),
		});
		const signals: unknown[] = [];
		store.add(service.onDidTurnSettle(s => signals.push(s)));
		service.notifyTurnSettle({
			sessionId: 's1',
			runtimeTurnId: 'runtime-1',
			assistantTurnId: 'assistant-1',
		});
		assert.deepStrictEqual(signals, [{
			sessionId: 's1',
			runtimeTurnId: 'runtime-1',
			assistantTurnId: 'assistant-1',
		}]);
		service.dispose();
	});

	test('agentTree UNIMPLEMENTED probe → UNSUPPORTED capability', async () => {
		const transport = new MockUniverseAgentGrpcTransport({
			connect: async () => ({
				sessionToken: 'token-1',
				methods: ['AgentService.Tree'],
				events: [],
			}),
			probeRpc: async (_service, method) => {
				if (method === 'Tree') {
					return GrpcStatusCode.UNIMPLEMENTED;
				}
				return GrpcStatusCode.OK;
			},
		});
		const service = new UniverseAgentConnectionService({
			connectionResolver: plainFixtureResolver(),
			clientIdentityStore: plainFixtureIdentity(),
			createTransport: () => transport,
		});

		await connectPlainFixture(service);

		assert.strictEqual(service.getCapabilitySnapshot().agentTree.support, 'UNSUPPORTED');
		service.dispose();
	});

	test('AgentService.Tree non-UNIMPLEMENTED failure sets isAgentTreeFetchFailed (D21)', async () => {
		let treeMode: 'fail' | 'ok' = 'fail';
		const transport = new MockUniverseAgentGrpcTransport({
			connect: async () => ({
				sessionToken: 'token-1',
				methods: ['AgentService.Tree'],
				events: [],
			}),
			probeRpc: async () => GrpcStatusCode.OK,
			fetchAgentTree: async () => {
				if (treeMode === 'fail') {
					throw new UniverseAgentTransportError(13, 'tree boom');
				}
				return {
					agentId: 'root',
					name: 'Root',
					type: 'AGENT_TYPE_ROOT',
					status: 'AGENT_STATUS_IDLE',
					model: '',
					turnCount: 0,
					createdAt: 0,
					children: [],
				};
			},
		});
		const service = new UniverseAgentConnectionService({
			connectionResolver: plainFixtureResolver(),
			clientIdentityStore: plainFixtureIdentity(),
			createTransport: () => transport,
		});
		await connectPlainFixture(service);
		assert.strictEqual(service.isAgentTreeFetchFailed(), false);
		assert.strictEqual(service.getTransportState(), 'ok');

		await assert.rejects(() => service.fetchAgentTree('s1'));
		assert.strictEqual(service.isAgentTreeFetchFailed(), true);
		assert.strictEqual(service.getTransportState(), 'ok');
		assert.strictEqual(service.isEngineConnected(), true);

		treeMode = 'ok';
		const root = await service.fetchAgentTree('s1');
		assert.ok(root);
		assert.strictEqual(service.isAgentTreeFetchFailed(), false);
		service.dispose();
	});

	test('AgentService.Tree UNIMPLEMENTED does not set isAgentTreeFetchFailed', async () => {
		const transport = new MockUniverseAgentGrpcTransport({
			connect: async () => ({
				sessionToken: 'token-1',
				methods: ['AgentService.Tree'],
				events: [],
			}),
			probeRpc: async () => GrpcStatusCode.OK,
			fetchAgentTree: async () => {
				throw new UniverseAgentTransportError(GrpcStatusCode.UNIMPLEMENTED, 'no tree');
			},
		});
		const service = new UniverseAgentConnectionService({
			connectionResolver: plainFixtureResolver(),
			clientIdentityStore: plainFixtureIdentity(),
			createTransport: () => transport,
		});
		await connectPlainFixture(service);
		await assert.rejects(() => service.fetchAgentTree('s1'));
		assert.strictEqual(service.isAgentTreeFetchFailed(), false);
		assert.strictEqual(service.isAgentTreeUnsupported(), true);
		service.dispose();
	});

	test('switching profile after AgentService.Tree UNIMPLEMENTED resets probe flag and allows engine B to fetchAgentTree (B1)', async () => {
		const treeNodeB = {
			agentId: 'b-root',
			name: 'Root B',
			type: 'AGENT_TYPE_ROOT',
			status: 'AGENT_STATUS_IDLE',
			model: '',
			turnCount: 0,
			createdAt: 0,
			children: [],
		};
		let fetchedOnB = false;
		const transportA = new MockUniverseAgentGrpcTransport({
			connect: async () => ({
				sessionToken: 'token-a',
				methods: ['AgentService.Tree'],
				events: [],
			}),
			probeRpc: async () => GrpcStatusCode.OK,
			fetchAgentTree: async () => {
				throw new UniverseAgentTransportError(GrpcStatusCode.UNIMPLEMENTED, 'no tree on A');
			},
		});
		const transportB = new MockUniverseAgentGrpcTransport({
			connect: async () => ({
				sessionToken: 'token-b',
				methods: ['AgentService.Tree'],
				events: [],
			}),
			probeRpc: async () => GrpcStatusCode.OK,
			fetchAgentTree: async () => {
				fetchedOnB = true;
				return treeNodeB;
			},
		});

		let transportIndex = 0;
		const transports = [transportA, transportB];
		const service = new UniverseAgentConnectionService({
			connectionResolver: {
				resolve: async (profileId: string) => ({
					ok: true as const,
					allowRelayFallback: false as const,
					endpoint: {
						attemptId: `endpoint-${profileId}`,
						authority: '127.0.0.1:9',
						port: 9,
						resolvedIp: '127.0.0.1',
						servername: '127.0.0.1',
						relayTicketId: null,
						tls: null,
						expiresAtMs: Date.now() + 60_000,
						path: 'direct' as const,
					},
				}),
				consumeRelayTicket: () => { },
			} as unknown as ConnectionResolver,
			clientIdentityStore: plainFixtureIdentity(),
			createTransport: () => transports[transportIndex++],
		});

		const connectA = await service.connectProfile('profile-a');
		assert.strictEqual(connectA.ok, true);
		await assert.rejects(() => service.fetchAgentTree('s1'));
		assert.strictEqual(service.isAgentTreeUnsupported(), true);

		// Switch profile to profile-b
		const connectB = await service.connectProfile('profile-b');
		assert.strictEqual(connectB.ok, true);
		assert.strictEqual((service as unknown as { _agentTreeProbeUnsupported?: boolean })._agentTreeProbeUnsupported, false);
		assert.strictEqual(service.isAgentTreeUnsupported(), false);

		const rootB = await service.fetchAgentTree('s1');
		assert.strictEqual(fetchedOnB, true);
		assert.deepStrictEqual(rootB, treeNodeB);

		service.dispose();
	});

	test('_dropPublishedTransport resets capabilities and probe flags (B1, G17)', async () => {
		const transport = new MockUniverseAgentGrpcTransport({
			connect: async () => ({
				sessionToken: 'token-1',
				methods: ['AgentService.Tree', 'ToolService.ListSkills'],
				events: [],
			}),
			probeRpc: async () => GrpcStatusCode.OK,
		});
		const service = new UniverseAgentConnectionService({
			connectionResolver: plainFixtureResolver(),
			clientIdentityStore: plainFixtureIdentity(),
			createTransport: () => transport,
		});
		await connectPlainFixture(service);
		assert.strictEqual(service.getConnectionSnapshot().capabilities.agentTree.support, 'SUPPORTED');

		(service as unknown as { _dropPublishedTransport(): void })._dropPublishedTransport();

		const snapshot = service.getConnectionSnapshot();
		assert.strictEqual(snapshot.capabilities.agentTree.support, 'UNKNOWN');
		assert.strictEqual(snapshot.capabilities.skills.support, 'UNKNOWN');
		assert.strictEqual(snapshot.sessionListCapability, 'UNKNOWN');
		assert.strictEqual(snapshot.listFilesCapability, 'UNKNOWN');
		assert.strictEqual(service.getCapabilitySnapshot().agentTree.support, 'UNKNOWN');
		assert.strictEqual(service.isAgentTreeUnsupported(), false);

		service.dispose();
	});

	test('disconnect clears isAgentTreeFetchFailed (D21)', async () => {
		const transport = new MockUniverseAgentGrpcTransport({
			connect: async () => ({
				sessionToken: 'token-1',
				methods: ['AgentService.Tree'],
				events: [],
			}),
			probeRpc: async () => GrpcStatusCode.OK,
			fetchAgentTree: async () => {
				throw new UniverseAgentTransportError(13, 'tree boom');
			},
		});
		const service = new UniverseAgentConnectionService({
			connectionResolver: plainFixtureResolver(),
			clientIdentityStore: plainFixtureIdentity(),
			createTransport: () => transport,
		});
		await connectPlainFixture(service);
		await assert.rejects(() => service.fetchAgentTree('s1'));
		assert.strictEqual(service.isAgentTreeFetchFailed(), true);

		await service.disconnect();
		assert.strictEqual(service.isAgentTreeFetchFailed(), false);
		service.dispose();
	});

	test('isAgentTreeFetchFailed flip fires onDidChangeConnection (D21)', async () => {
		const transport = new MockUniverseAgentGrpcTransport({
			connect: async () => ({
				sessionToken: 'token-1',
				methods: ['AgentService.Tree'],
				events: [],
			}),
			probeRpc: async () => GrpcStatusCode.OK,
			fetchAgentTree: async () => {
				throw new UniverseAgentTransportError(13, 'tree boom');
			},
		});
		const service = new UniverseAgentConnectionService({
			connectionResolver: plainFixtureResolver(),
			clientIdentityStore: plainFixtureIdentity(),
			createTransport: () => transport,
		});
		await connectPlainFixture(service);

		let fires = 0;
		store.add(service.onDidChangeConnection(() => { fires++; }));
		const before = fires;
		await assert.rejects(() => service.fetchAgentTree('s1'));
		assert.strictEqual(service.isAgentTreeFetchFailed(), true);
		assert.ok(fires > before, 'tree-fetch failure must notify connection listeners');
		service.dispose();
	});

	test('idle profile dial broadcasts the connecting phase on the snapshot (ELR-9)', async () => {
		let releaseConnect: () => void = () => { };
		const connectGate = new Promise<void>(resolve => { releaseConnect = resolve; });
		let enteredConnect: () => void = () => { };
		const connectEntered = new Promise<void>(resolve => { enteredConnect = resolve; });
		const transport = new MockUniverseAgentGrpcTransport({
			connect: async () => {
				enteredConnect();
				await connectGate;
				return {
					sessionToken: 'token-1',
					workDir: '/tmp/work',
					methods: ['ToolService.ListSkills'],
					events: [],
				};
			},
		});
		const service = new UniverseAgentConnectionService({
			createTransport: () => transport,
			connectionResolver: plainFixtureResolver(),
			clientIdentityStore: plainFixtureIdentity(),
		});
		const idle = service.getConnectionSnapshot();
		assert.strictEqual(idle.transport, 'idle');
		assert.strictEqual(idle.phase?.kind, 'disconnected');
		assert.strictEqual(idle.agentTreeFetchFailed, false);
		const snapshots: Array<typeof idle> = [];
		store.add(service.onDidChangeConnection(snapshot => { snapshots.push(snapshot); }));
		const pending = connectPlainFixture(service);
		await connectEntered;
		const connecting = snapshots.find(snapshot => snapshot.phase?.kind === 'connecting');
		assert.ok(connecting);
		assert.strictEqual(connecting.transport, 'idle');
		const phase = connecting.phase;
		if (!phase || phase.kind !== 'connecting') {
			assert.fail(`snapshot must carry connecting, got ${phase?.kind}`);
		}
		assert.strictEqual(phase.reason, 'initial');
		assert.strictEqual(connecting.agentTreeFetchFailed, false);
		assert.strictEqual(service.getConnectionPhase().kind, 'connecting');
		releaseConnect();
		await pending;
		assert.strictEqual(service.getConnectionSnapshot().phase?.kind, 'connected');
		service.dispose();
	});

	test('Hub signedIn does not set isEngineConnected (H4a connection-state honesty)', async () => {
		const hubSessionStore = new InMemoryHubSessionStore();
		const service = new UniverseAgentConnectionService({ hubSessionStore });
		await hubSessionStore.applyAuthSession('https://hub.example.com', {
			accessToken: 'token',
			expiresIn: 3600,
			csrfToken: 'csrf',
			mustChangePassword: false,
			user: { id: 'u1', email: 'a@example.com', role: 'user', status: 'active' },
		}, Date.now());
		service.setActiveHubBaseUrl('https://hub.example.com');

		assert.strictEqual(service.getAuthStatus().kind, 'signedIn');
		assert.strictEqual(service.isEngineConnected(), false);
		assert.strictEqual(service.getConnectionPhase().kind, 'disconnected');
		service.dispose();
	});

	test('SaveSkillContent advertised + probe OK => saveSkillContent writes via transport', async () => {
		let saved: UniverseAgentSaveSkillContentRequest | undefined;
		const transport = new MockUniverseAgentGrpcTransport({
			connect: async () => ({
				sessionToken: 'token-1',
				methods: ['ToolService.ListSkills', 'ToolService.SaveSkillContent'],
				events: [],
			}),
			probeRpc: async (_service, method) => {
				if (method === UniverseAgentGrpcServices.Tool.SaveSkillContent) {
					return GrpcStatusCode.OK;
				}
				return GrpcStatusCode.OK;
			},
			saveSkillContent: async (request) => {
				saved = request;
				return { ok: true };
			},
		});
		const service = new UniverseAgentConnectionService({
			connectionResolver: plainFixtureResolver(),
			clientIdentityStore: plainFixtureIdentity(),
			createTransport: () => transport,
		});

		await connectPlainFixture(service);

		const connection: IUniverseAgentConnection = service;
		assert.strictEqual(typeof connection.saveSkillContent, 'function');
		const result = await connection.saveSkillContent!({
			skillName: 'demo-skill',
			content: '# Demo',
			create: true,
		});
		assert.strictEqual(result.ok, true);
		assert.deepStrictEqual(saved, { skillName: 'demo-skill', content: '# Demo', create: true });
		service.dispose();
	});

	test('SaveSkillContent UNIMPLEMENTED probe => saveSkillContent absent', async () => {
		const transport = new MockUniverseAgentGrpcTransport({
			connect: async () => ({
				sessionToken: 'token-1',
				methods: ['ToolService.ListSkills', 'ToolService.SaveSkillContent'],
				events: [],
			}),
			probeRpc: async (_service, method) => {
				if (method === UniverseAgentGrpcServices.Tool.SaveSkillContent) {
					return GrpcStatusCode.UNIMPLEMENTED;
				}
				return GrpcStatusCode.OK;
			},
		});
		const service = new UniverseAgentConnectionService({
			connectionResolver: plainFixtureResolver(),
			clientIdentityStore: plainFixtureIdentity(),
			createTransport: () => transport,
		});

		await connectPlainFixture(service);

		const connection: IUniverseAgentConnection = service;
		assert.strictEqual(connection.saveSkillContent, undefined);
		service.dispose();
	});

	test('ToolService.* wildcard advertises SaveSkillContent and still requires a probe', async () => {
		const transport = new MockUniverseAgentGrpcTransport({
			connect: async () => ({
				sessionToken: 'token-1',
				methods: ['ToolService.*'],
				events: [],
			}),
			probeRpc: async () => GrpcStatusCode.OK,
			saveSkillContent: async () => ({ ok: true }),
		});
		const service = new UniverseAgentConnectionService({
			connectionResolver: plainFixtureResolver(),
			clientIdentityStore: plainFixtureIdentity(),
			createTransport: () => transport,
		});

		await connectPlainFixture(service);

		assert.strictEqual(typeof (service as IUniverseAgentConnection).saveSkillContent, 'function');
		service.dispose();
	});

	test('ToolService.ListSkills alone does not bind saveSkillContent', async () => {
		const transport = new MockUniverseAgentGrpcTransport({
			connect: async () => ({
				sessionToken: 'token-1',
				methods: ['ToolService.ListSkills'],
				events: [],
			}),
			probeRpc: async () => GrpcStatusCode.OK,
		});
		const service = new UniverseAgentConnectionService({
			connectionResolver: plainFixtureResolver(),
			clientIdentityStore: plainFixtureIdentity(),
			createTransport: () => transport,
		});

		await connectPlainFixture(service);

		assert.strictEqual((service as IUniverseAgentConnection).saveSkillContent, undefined);
		service.dispose();
	});

	test('AgentService.* wildcard advertises FetchToolDetail', async () => {
		let calls = 0;
		const transport = new MockUniverseAgentGrpcTransport({
			connect: async () => ({
				sessionToken: 'token-1',
				methods: ['AgentService.*'],
				events: [],
			}),
			probeRpc: async () => GrpcStatusCode.OK,
			fetchToolDetail: async () => {
				calls++;
				return { success: true, content: 'detail', truncated: false };
			},
		});
		const service = new UniverseAgentConnectionService({
			connectionResolver: plainFixtureResolver(),
			clientIdentityStore: plainFixtureIdentity(),
			createTransport: () => transport,
		});

		await connectPlainFixture(service);
		const result = await service.fetchToolDetail({ sessionId: 's1', toolCallId: 'tc-1', detailKind: 0, refId: 'r1' });

		assert.deepStrictEqual(result, { ok: true, content: 'detail', truncated: false });
		assert.strictEqual(calls, 1);
		service.dispose();
	});

	test('fetchToolDetail without an AgentService advertisement is unavailable and does not call the transport', async () => {
		let calls = 0;
		const transport = new MockUniverseAgentGrpcTransport({
			connect: async () => ({
				sessionToken: 'token-1',
				methods: ['AgentService.Tree'],
				events: [],
			}),
			probeRpc: async () => GrpcStatusCode.OK,
			fetchToolDetail: async () => {
				calls++;
				return { success: true, content: 'detail', truncated: false };
			},
		});
		const service = new UniverseAgentConnectionService({
			connectionResolver: plainFixtureResolver(),
			clientIdentityStore: plainFixtureIdentity(),
			createTransport: () => transport,
		});

		await connectPlainFixture(service);
		const result = await service.fetchToolDetail({ sessionId: 's1', toolCallId: 'tc-1', detailKind: 0, refId: 'r1' });

		assert.deepStrictEqual(result, { ok: false, reason: 'unavailable' });
		assert.strictEqual(calls, 0);
		service.dispose();
	});

	test('saveSkillContent runtime UNIMPLEMENTED => ok false without throwing', async () => {
		const transport = new MockUniverseAgentGrpcTransport({
			connect: async () => ({
				sessionToken: 'token-1',
				methods: ['ToolService.ListSkills', 'ToolService.SaveSkillContent'],
				events: [],
			}),
			probeRpc: async (_service, method) => {
				if (method === UniverseAgentGrpcServices.Tool.SaveSkillContent) {
					return GrpcStatusCode.OK;
				}
				return GrpcStatusCode.OK;
			},
			saveSkillContent: async () => {
				throw new UniverseAgentTransportError(GrpcStatusCode.UNIMPLEMENTED, 'SaveSkillContent not implemented');
			},
		});
		const service = new UniverseAgentConnectionService({
			connectionResolver: plainFixtureResolver(),
			clientIdentityStore: plainFixtureIdentity(),
			createTransport: () => transport,
		});

		await connectPlainFixture(service);

		const connection: IUniverseAgentConnection = service;
		const result = await connection.saveSkillContent!({
			skillName: 'demo-skill',
			content: '# Demo',
			create: true,
		});
		assert.strictEqual(result.ok, false);
		assert.strictEqual(result.reason, 'UNIMPLEMENTED');
		assert.strictEqual(connection.saveSkillContent, undefined);
		service.dispose();
	});

	test('probeEngine without transport reports not connected', async () => {
		const service = new UniverseAgentConnectionService({
			createTransport: () => new MockUniverseAgentGrpcTransport(),
		});
		const result = await service.probeEngine();
		assert.deepStrictEqual(result, { ok: false, reason: 'Engine is not connected.' });
		service.dispose();
	});

	test('probeEngine uses GetAuthNonce with client identity', async () => {
		const transport = new MockUniverseAgentGrpcTransport();
		const identityStore: IClientIdentityStore = {
			getState: async () => ({
				kind: 'ready',
				identity: {
					clientIdentityId: 'a'.repeat(64),
					clientPublicKey: new Uint8Array(32),
					privateKeyPkcs8: new Uint8Array(32),
				},
			}),
			getOrCreateIdentity: async () => ({
				kind: 'ready',
				identity: {
					clientIdentityId: 'a'.repeat(64),
					clientPublicKey: new Uint8Array(32),
					privateKeyPkcs8: new Uint8Array(32),
				},
			}),
			createSigner: async () => undefined,
		};
		const service = new UniverseAgentConnectionService({
			connectionResolver: plainFixtureResolver(),
			createTransport: () => transport,
			clientIdentityStore: identityStore,
		});
		await connectPlainFixture(service);
		const result = await service.probeEngine();
		assert.deepStrictEqual(result, { ok: true, engineIdentityId: 'engine-id' });
		service.dispose();
	});
});

suite('UniverseAgentConnectionService probeConnectionProfile (GC-3)', () => {

	ensureNoDisposablesAreLeakedInTestSuite();

	const identityStore: IClientIdentityStore = {
		getState: async () => ({
			kind: 'ready',
			identity: {
				clientIdentityId: 'a'.repeat(64),
				clientPublicKey: new Uint8Array(32),
				privateKeyPkcs8: new Uint8Array(32),
			},
		}),
		getOrCreateIdentity: async () => ({
			kind: 'ready',
			identity: {
				clientIdentityId: 'a'.repeat(64),
				clientPublicKey: new Uint8Array(32),
				privateKeyPkcs8: new Uint8Array(32),
			},
		}),
		createSigner: async () => undefined,
	};

	test('resolver failure code passes through', async () => {
		const mockResolver = {
			resolve: async () => ({
				ok: false as const,
				code: 'hub_device_revoked' as const,
				reason: 'device revoked',
				allowRelayFallback: false,
			}),
			consumeRelayTicket: () => { },
		};
		const service = new UniverseAgentConnectionService({
			connectionResolver: mockResolver as unknown as ConnectionResolver,
			clientIdentityStore: identityStore,
			createTransport: () => new MockUniverseAgentGrpcTransport(),
		});
		const result = await service.probeConnectionProfile('profile-1');
		assert.deepStrictEqual(result, { ok: false, code: 'hub_device_revoked', reason: 'device revoked' });
		service.dispose();
	});

	test('probe pin text is pin_mismatch and a timeout stays transport_failed', async () => {
		const endpoint = {
			attemptId: 'a1',
			authority: '203.0.113.10:7443',
			port: 7443,
			resolvedIp: '203.0.113.10',
			servername: '203.0.113.10',
			relayTicketId: null,
			tls: null,
			expiresAtMs: Date.now() + 60_000,
			path: 'direct' as const,
		};
		class PinProbeTransport extends MockUniverseAgentGrpcTransport {
			override async getAuthNonce(): Promise<UniverseAgentAuthNonceResult> {
				throw new UniverseAgentTransportError(GrpcStatusCode.UNAVAILABLE, '14 UNAVAILABLE: No connection established. Last error: Engine TLS leaf fingerprint does not match pinned trust anchor');
			}
		}
		class TimeoutProbeTransport extends MockUniverseAgentGrpcTransport {
			override async getAuthNonce(): Promise<UniverseAgentAuthNonceResult> {
				throw new Error('probe timed out after 10s');
			}
		}
		const resolver = {
			resolve: async () => ({ ok: true as const, allowRelayFallback: false as const, endpoint }),
			consumeRelayTicket: () => { },
		};
		const pinService = new UniverseAgentConnectionService({
			connectionResolver: resolver as unknown as ConnectionResolver,
			clientIdentityStore: identityStore,
			createTransport: () => new PinProbeTransport(),
		});
		const pin = await pinService.probeConnectionProfile('profile-1');
		assert.strictEqual(pin.ok, false);
		if (!pin.ok) {
			assert.strictEqual(pin.code, 'pin_mismatch');
		}
		pinService.dispose();

		const timeoutService = new UniverseAgentConnectionService({
			connectionResolver: resolver as unknown as ConnectionResolver,
			clientIdentityStore: identityStore,
			createTransport: () => new TimeoutProbeTransport(),
		});
		const timedOut = await timeoutService.probeConnectionProfile('profile-1');
		assert.strictEqual(timedOut.ok, false);
		if (!timedOut.ok) {
			assert.strictEqual(timedOut.code, 'transport_failed');
			assert.strictEqual(timedOut.reason, 'probe timed out after 10s');
		}
		timeoutService.dispose();
	});

	test('getAuthNonce success leaves phase and live transport unchanged', async () => {
		let connectCalls = 0;
		let probeTransportClosed = false;
		class ProbeMockTransport extends MockUniverseAgentGrpcTransport {
			override close(): void {
				probeTransportClosed = true;
				super.close();
			}

			override async connect(): Promise<UniverseAgentConnectResult> {
				connectCalls++;
				return super.connect({ clientId: 'x', protocolVersion: '1' });
			}

			override async connectWithDeviceAuth(): Promise<UniverseAgentConnectResult> {
				connectCalls++;
				return super.connectWithDeviceAuth({
					clientIdentityId: 'a'.repeat(64),
					clientPublicKey: new Uint8Array(32),
					authNonce: new Uint8Array(32),
					signature: new Uint8Array(64),
					protocolVersion: '1',
				});
			}
		}

		const liveTransport = new ProbeMockTransport();
		const mockResolver = {
			resolve: async () => ({
				ok: true as const,
				allowRelayFallback: false,
				endpoint: {
					attemptId: 'a1',
					authority: '203.0.113.10:7443',
					port: 7443,
					resolvedIp: '203.0.113.10',
					servername: '203.0.113.10',
					relayTicketId: null,
					tls: null,
					expiresAtMs: Date.now() + 60_000,
					path: 'direct' as const,
				},
			}),
			consumeRelayTicket: () => { },
		};
		const service = new UniverseAgentConnectionService({
			...localEngineFixtureOptions(liveTransport),
			connectionResolver: mockResolver as unknown as ConnectionResolver,
			clientIdentityStore: identityStore,
			createTransport: address => address === '203.0.113.10:7443' ? new ProbeMockTransport() : liveTransport,
		});

		await waitForLocalFixture(service);
		connectCalls = 0;
		const phaseBefore = service.getConnectionPhase();
		const transportBefore = (service as unknown as { _transport: MockUniverseAgentGrpcTransport })._transport;

		const result = await service.probeConnectionProfile('profile-1');
		assert.strictEqual(result.ok, true);
		if (result.ok) {
			assert.strictEqual(result.path, 'direct');
			assert.strictEqual(result.authority, '203.0.113.10:7443');
			assert.ok(result.latencyMs >= 0);
		}
		assert.strictEqual(connectCalls, 0, 'probe must not invoke Connect');
		assert.strictEqual(probeTransportClosed, true);
		assert.strictEqual(service.getConnectionPhase(), phaseBefore);
		assert.strictEqual((service as unknown as { _transport: MockUniverseAgentGrpcTransport })._transport, transportBefore);
		service.dispose();
	});

	test('probe does not write transport or phase and keeps writes made during the probe', async () => {
		let releaseNonce: () => void = () => { };
		let enteredNonce: () => void = () => { };
		const nonceEntered = new Promise<void>(resolve => { enteredNonce = resolve; });
		const nonceGate = new Promise<void>(resolve => { releaseNonce = resolve; });
		class GatedProbeTransport extends MockUniverseAgentGrpcTransport {
			override async getAuthNonce(): Promise<UniverseAgentAuthNonceResult> {
				enteredNonce();
				await nonceGate;
				return {
					authNonce: new Uint8Array(32),
					engineIdentityId: 'engine-id',
					engineCertFingerprint: 'a'.repeat(64),
				};
			}
		}
		const liveTransport = new MockUniverseAgentGrpcTransport();
		const mockResolver = {
			resolve: async () => ({
				ok: true as const,
				allowRelayFallback: false,
				endpoint: {
					attemptId: 'a1',
					authority: '203.0.113.10:7443',
					port: 7443,
					resolvedIp: '203.0.113.10',
					servername: '203.0.113.10',
					relayTicketId: null,
					tls: null,
					expiresAtMs: Date.now() + 60_000,
					path: 'direct' as const,
				},
			}),
			consumeRelayTicket: () => { },
		};
		const service = new UniverseAgentConnectionService({
			...localEngineFixtureOptions(liveTransport),
			connectionResolver: mockResolver as unknown as ConnectionResolver,
			clientIdentityStore: identityStore,
			createTransport: address => address === '203.0.113.10:7443' ? new GatedProbeTransport() : liveTransport,
		});
		await waitForLocalFixture(service);
		const live = service as unknown as {
			_transport: MockUniverseAgentGrpcTransport | undefined;
			_connectionPhase: { kind: string };
		};
		const phaseBefore = service.getConnectionPhase();
		const transportBefore = live._transport;

		const pending = service.probeConnectionProfile('profile-1');
		await nonceEntered;
		assert.strictEqual(service.getConnectionPhase(), phaseBefore, 'probe must not write connection phase');
		assert.strictEqual(live._transport, transportBefore, 'probe must not write transport');

		const concurrentTransport = new MockUniverseAgentGrpcTransport();
		const concurrentPhase = { kind: 'connecting' as const, reason: 'transport_lost' as const };
		live._transport = concurrentTransport;
		live._connectionPhase = concurrentPhase;
		releaseNonce();

		const result = await pending;
		assert.strictEqual(result.ok, true);
		assert.strictEqual(live._transport, concurrentTransport, 'probe end must not overwrite a transport written during the probe');
		assert.strictEqual(service.getConnectionPhase(), concurrentPhase, 'probe end must not overwrite a phase written during the probe');
		transportBefore?.close();
		service.dispose();
	});

	test('pairing_required formal resolve still probes GetAuthNonce via forPairing', async () => {
		let probeNonce = 0;
		const resolveOptions: Array<{ readonly forPairing?: boolean; readonly useRelayTicketCache?: boolean } | undefined> = [];
		class PairingProbeTransport extends MockUniverseAgentGrpcTransport {
			override async getAuthNonce(): Promise<UniverseAgentAuthNonceResult> {
				probeNonce++;
				return {
					authNonce: new Uint8Array(32).fill(1),
					engineIdentityId: 'e'.repeat(64),
					engineCertFingerprint: 'ab'.repeat(32),
				};
			}
		}
		const mockResolver = {
			resolve: async (_profileId: string, options?: { readonly forPairing?: boolean; readonly useRelayTicketCache?: boolean }) => {
				resolveOptions.push(options);
				if (!options?.forPairing) {
					return {
						ok: false as const,
						code: 'pairing_required' as const,
						reason: 'direct address dial requires pairing orchestrator when trust is missing',
						allowRelayFallback: false,
					};
				}
				return {
					ok: true as const,
					allowRelayFallback: false,
					endpoint: {
						attemptId: 'a1',
						authority: '203.0.113.10:7443',
						port: 7443,
						resolvedIp: '203.0.113.10',
						servername: '203.0.113.10',
						relayTicketId: null,
						tls: null,
						expiresAtMs: Date.now() + 60_000,
						path: 'direct' as const,
					},
				};
			},
			consumeRelayTicket: () => { },
		};
		const service = new UniverseAgentConnectionService({
			connectionResolver: mockResolver as unknown as ConnectionResolver,
			clientIdentityStore: identityStore,
			createTransport: () => new PairingProbeTransport(),
		});
		const result = await service.probeConnectionProfile('profile-1');
		assert.strictEqual(result.ok, true);
		assert.strictEqual(probeNonce, 1);
		assert.deepStrictEqual(resolveOptions, [
			{ useRelayTicketCache: false },
			{ forPairing: true, useRelayTicketCache: false },
		]);
		service.dispose();
	});

	test('probe ticket is not reused by the next resolve without forceNewTicket', async () => {
		let cached: string | undefined = 'ticket-cached';
		let issued = 0;
		let probing = true;
		const probeTickets: string[] = [];
		const resolver = {
			resolve: async (_profileId: string, options?: { readonly forceNewTicket?: boolean; readonly useRelayTicketCache?: boolean }) => {
				if (probing) {
					assert.strictEqual(options?.useRelayTicketCache, false);
				}
				const useCache = options?.useRelayTicketCache !== false;
				let ticketId: string;
				if (useCache && options?.forceNewTicket !== true && cached) {
					ticketId = cached;
				} else {
					issued++;
					ticketId = `ticket-issued-${issued}`;
					if (useCache) {
						cached = ticketId;
					}
				}
				if (probing) {
					probeTickets.push(ticketId);
				}
				return {
					ok: true as const,
					allowRelayFallback: false,
					endpoint: {
						attemptId: 'a1',
						authority: '203.0.113.10:7443',
						port: 7443,
						resolvedIp: '203.0.113.10',
						servername: '203.0.113.10',
						relayTicketId: ticketId,
						tls: null,
						expiresAtMs: Date.now() + 60_000,
						path: 'direct' as const,
					},
				};
			},
			consumeRelayTicket: () => {
				cached = undefined;
			},
		};
		const service = new UniverseAgentConnectionService({
			connectionResolver: resolver as unknown as ConnectionResolver,
			clientIdentityStore: identityStore,
			createTransport: () => new MockUniverseAgentGrpcTransport(),
		});
		const probed = await service.probeConnectionProfile('profile-1');
		assert.strictEqual(probed.ok, true);
		probing = false;
		const follow = await resolver.resolve('profile-1');
		assert.deepStrictEqual(probeTickets, ['ticket-issued-1']);
		assert.strictEqual(follow.endpoint.relayTicketId, 'ticket-cached');
		assert.notStrictEqual(probeTickets[0], follow.endpoint.relayTicketId);
		service.dispose();
	});

	test('pairing_required without a pairing endpoint uses Connect-owned reason', async () => {
		const mockResolver = {
			resolve: async () => ({
				ok: false as const,
				code: 'pairing_required' as const,
				reason: 'direct address dial requires pairing orchestrator when trust is missing',
				allowRelayFallback: false,
			}),
			consumeRelayTicket: () => { },
		};
		const service = new UniverseAgentConnectionService({
			connectionResolver: mockResolver as unknown as ConnectionResolver,
			clientIdentityStore: identityStore,
			createTransport: () => new MockUniverseAgentGrpcTransport(),
		});
		const result = await service.probeConnectionProfile('profile-1');
		assert.strictEqual(result.ok, false);
		if (!result.ok) {
			assert.strictEqual(result.code, 'pairing_required');
			assert.strictEqual(result.reason, PAIRING_REQUIRED_USE_CONNECT_REASON);
			assert.notStrictEqual(result.reason, 'direct address dial requires pairing orchestrator when trust is missing');
		}
		service.dispose();
	});
});

const PAIRING_PROFILE_ID = '11111111-1111-4111-8111-111111111111';

class PairingTestProfileStore implements IConnectionProfileStore {
	constructor(private profile: ConnectionProfile) { }

	list(): ConnectionProfile[] {
		return [this.profile];
	}

	get(profileId: string): ConnectionProfile | undefined {
		return profileId === this.profile.profileId ? this.profile : undefined;
	}

	put(profile: ConnectionProfile): void {
		this.profile = profile;
	}

	remove(_profileId: string): void {
	}

	createDraft(input: {
		readonly displayName: string;
		readonly target: ConnectionProfile['target'];
		readonly allowPrivateNetwork?: boolean;
	}): ConnectionProfile {
		return {
			profileId: PAIRING_PROFILE_ID,
			displayName: input.displayName,
			target: input.target,
			trust: null,
			state: 'pairingPending',
			allowPrivateNetwork: input.allowPrivateNetwork ?? false,
		};
	}
}

function directPairingPendingProfile(profileId = PAIRING_PROFILE_ID): ConnectionProfile {
	return {
		profileId,
		displayName: 'Direct',
		target: { kind: 'directAddress', host: '127.0.0.1', port: 50051 },
		trust: null,
		state: 'pairingPending',
		allowPrivateNetwork: true,
	};
}

function pairingRequiredResolver(onDial?: () => { readonly ok: true; readonly allowRelayFallback: false; readonly endpoint: typeof plainDialEndpoint } | { readonly ok: false; readonly code: 'pairing_required'; readonly reason: string; readonly allowRelayFallback: false }) {
	return {
		resolve: async (_profileId: string, options?: { readonly forPairing?: boolean }) => {
			if (options?.forPairing) {
				return { ok: true as const, allowRelayFallback: false as const, endpoint: plainDialEndpoint };
			}
			if (onDial) {
				return onDial();
			}
			return {
				ok: false as const,
				code: 'pairing_required' as const,
				reason: 'pairing required',
				allowRelayFallback: false as const,
			};
		},
		consumeRelayTicket: () => { },
	};
}

function awaitingSasOrchestrator(): PairingOrchestrator {
	return {
		startPairing: async () => ({
			ok: true as const,
			awaitingUserConfirm: true,
			snapshot: {
				phase: 'awaiting_sas_confirm' as const,
				profileId: PAIRING_PROFILE_ID,
				sasCode: 'ABCD-EFGH',
				engineIdentityId: 'engine-id',
				sessionTokenInstalled: false,
			},
		}),
		confirmSas: async () => ({ ok: false as const, code: 'unused', reason: 'unused' }),
		confirmRecoverTrust: async () => ({ ok: false as const, code: 'unused', reason: 'unused' }),
		getSnapshot: () => undefined,
		abandonRecoverTrust: () => { },
	} as unknown as PairingOrchestrator;
}

const plainDialEndpoint = {
	attemptId: 'a1',
	authority: '127.0.0.1',
	port: 50051,
	resolvedIp: '127.0.0.1',
	servername: '127.0.0.1',
	relayTicketId: null,
	tls: null,
	expiresAtMs: Date.now() + 60_000,
	path: 'direct' as const,
};

function createHubDevicePairingProfile(): ConnectionProfile {
	return {
		profileId: PAIRING_PROFILE_ID,
		displayName: 'Studio',
		target: {
			kind: 'hubDevice',
			hubBaseUrl: 'https://hub.example.com',
			accountId: 'usr_1',
			hubDeviceId: 'dev-1',
		},
		trust: null,
		state: 'pairingPending',
		allowPrivateNetwork: false,
	};
}

suite('UniverseAgentConnectionService pairing (GC-1b)', () => {

	ensureNoDisposablesAreLeakedInTestSuite();

	test('hubDevice without trust returns pairingPending with handshake sasCode', async () => {
		const profile = createHubDevicePairingProfile();
		const profileStore = new PairingTestProfileStore(profile);
		const mockResolver = {
			resolve: async (_profileId: string, options?: { readonly forPairing?: boolean }) => {
				if (options?.forPairing) {
					return {
						ok: true as const,
						allowRelayFallback: true,
						endpoint: {
							attemptId: 'a1',
							authority: 'relay.example.com',
							port: 443,
							resolvedIp: '203.0.113.1',
							servername: 'relay.example.com',
							relayTicketId: 'ticket-1',
							tls: null,
							expiresAtMs: Date.now() + 60_000,
							path: 'hubRelay' as const,
						},
					};
				}
				return {
					ok: false as const,
					code: 'pairing_required' as const,
					reason: 'pairing required',
					allowRelayFallback: true,
				};
			},
			consumeRelayTicket: () => { },
		};
		const mockOrchestrator = {
			startPairing: async () => ({
				ok: true as const,
				awaitingUserConfirm: true,
				snapshot: {
					phase: 'awaiting_sas_confirm' as const,
					profileId: PAIRING_PROFILE_ID,
					sasCode: 'ABCD-EFGH',
					engineIdentityId: 'eng-handshake-id',
					sessionTokenInstalled: false,
				},
			}),
			confirmSas: async () => ({ ok: false as const, code: 'unused', reason: 'unused' }),
			confirmRecoverTrust: async () => ({ ok: false as const, code: 'unused', reason: 'unused' }),
			getSnapshot: () => undefined,
			abandonRecoverTrust: () => { },
		};

		const service = new UniverseAgentConnectionService({
			connectionProfileStore: profileStore,
			connectionResolver: mockResolver as unknown as ConnectionResolver,
			pairingOrchestrator: mockOrchestrator as unknown as PairingOrchestrator,
		});

		const result = await service.connectProfile(PAIRING_PROFILE_ID);
		assert.strictEqual(result.ok, true);
		if (result.ok) {
			assert.strictEqual(result.pairingPending, true);
			assert.strictEqual(result.sasCode, 'ABCD-EFGH');
			assert.strictEqual(result.engineIdentityId, 'eng-handshake-id');
		}
		assert.notStrictEqual(service.getConnectionPhase().kind, 'connected');
		service.dispose();
	});

	test('connectProfile returns pairing fields without calling confirmSas', async () => {
		const profileStore = new PairingTestProfileStore(createHubDevicePairingProfile());
		let confirmCalls = 0;
		const mockOrchestrator = {
			startPairing: async () => ({
				ok: true as const,
				awaitingUserConfirm: true,
				snapshot: {
					phase: 'awaiting_sas_confirm' as const,
					profileId: PAIRING_PROFILE_ID,
					sasCode: 'ABCD-EFGH',
					engineIdentityId: 'eng-handshake-id',
					sessionTokenInstalled: false,
				},
			}),
			confirmSas: async () => {
				confirmCalls++;
				return new Promise<never>(() => { /* Desktop confirm is a second IPC */ });
			},
			confirmRecoverTrust: async () => ({ ok: false as const, code: 'unused', reason: 'unused' }),
			getSnapshot: () => undefined,
			abandonRecoverTrust: () => { },
		};
		const mockResolver = {
			resolve: async (_profileId: string, options?: { readonly forPairing?: boolean }) => {
				if (options?.forPairing) {
					return {
						ok: true as const,
						allowRelayFallback: true,
						endpoint: {
							attemptId: 'a1',
							authority: 'relay.example.com',
							port: 443,
							resolvedIp: '203.0.113.1',
							servername: 'relay.example.com',
							relayTicketId: 'ticket-1',
							tls: null,
							expiresAtMs: Date.now() + 60_000,
							path: 'hubRelay' as const,
						},
					};
				}
				return { ok: false as const, code: 'pairing_required' as const, reason: 'pairing', allowRelayFallback: true };
			},
			consumeRelayTicket: () => { },
		};
		const service = new UniverseAgentConnectionService({
			connectionProfileStore: profileStore,
			connectionResolver: mockResolver as unknown as ConnectionResolver,
			pairingOrchestrator: mockOrchestrator as unknown as PairingOrchestrator,
		});
		const result = await service.connectProfile(PAIRING_PROFILE_ID);
		assert.strictEqual(result.ok, true);
		if (result.ok) {
			assert.strictEqual(result.pairingPending, true);
			assert.strictEqual(result.sasCode, 'ABCD-EFGH');
		}
		assert.strictEqual(confirmCalls, 0);
		service.dispose();
	});

	test('connectProfile fires pairingPending snapshot before startPairing resolves', async () => {
		const profileStore = new PairingTestProfileStore(createHubDevicePairingProfile());
		let release!: () => void;
		const gate = new Promise<void>(resolve => { release = resolve; });
		const mockOrchestrator = {
			startPairing: async () => {
				await gate;
				return {
					ok: true as const,
					awaitingUserConfirm: true,
					snapshot: {
						phase: 'awaiting_sas_confirm' as const,
						profileId: PAIRING_PROFILE_ID,
						sasCode: 'ABCD-EFGH',
						engineIdentityId: 'eng-handshake-id',
						sessionTokenInstalled: false,
					},
				};
			},
			confirmSas: async () => ({ ok: false as const, code: 'unused', reason: 'unused' }),
			confirmRecoverTrust: async () => ({ ok: false as const, code: 'unused', reason: 'unused' }),
			getSnapshot: () => undefined,
			abandonRecoverTrust: () => { },
		};
		const mockResolver = {
			resolve: async (_profileId: string, options?: { readonly forPairing?: boolean }) => {
				if (options?.forPairing) {
					return {
						ok: true as const,
						allowRelayFallback: true,
						endpoint: {
							attemptId: 'a1',
							authority: 'relay.example.com',
							port: 443,
							resolvedIp: '203.0.113.1',
							servername: 'relay.example.com',
							relayTicketId: 'ticket-1',
							tls: null,
							expiresAtMs: Date.now() + 60_000,
							path: 'hubRelay' as const,
						},
					};
				}
				return { ok: false as const, code: 'pairing_required' as const, reason: 'pairing', allowRelayFallback: true };
			},
			consumeRelayTicket: () => { },
		};
		const service = new UniverseAgentConnectionService({
			connectionProfileStore: profileStore,
			connectionResolver: mockResolver as unknown as ConnectionResolver,
			pairingOrchestrator: mockOrchestrator as unknown as PairingOrchestrator,
		});
		const snapshots: boolean[] = [];
		const sub = service.onDidChangeConnection(snapshot => snapshots.push(snapshot.pairingPending));
		const pending = service.connectProfile(PAIRING_PROFILE_ID);
		await timeout(0);
		assert.ok(snapshots.includes(true), 'renderer must see pairingPending before Connect returns');
		release();
		const result = await pending;
		assert.strictEqual(result.ok, true);
		sub.dispose();
		service.dispose();
	});

	test('node idle capability snapshot is not the Web unsupported stub', () => {
		const service = new UniverseAgentConnectionService();
		const snapshot = service.getCapabilitySnapshot();
		for (const entry of Object.values(snapshot)) {
			assert.notStrictEqual(entry.reason, WEB_UNSUPPORTED_LOCAL_ENGINE_REASON);
		}
		const empty = createEmptyCapabilitySnapshot();
		for (const entry of Object.values(empty)) {
			assert.notStrictEqual(entry.reason, WEB_UNSUPPORTED_LOCAL_ENGINE_REASON);
		}
		service.dispose();
	});

	test('confirmPairing writes trust; cancelPairing leaves trust null', async () => {
		const leafDer = new Uint8Array([1, 2, 3, 4]);
		const trust = createEngineTrustRecord({
			leafDer,
			engineIdentityId: 'eng-handshake-id',
			establishedAt: Date.now(),
		});
		let profile = createHubDevicePairingProfile();
		const profileStore = new PairingTestProfileStore(profile);
		let confirmCalls = 0;
		const mockOrchestrator = {
			startPairing: async () => ({
				ok: true as const,
				awaitingUserConfirm: true,
				snapshot: {
					phase: 'awaiting_sas_confirm' as const,
					profileId: PAIRING_PROFILE_ID,
					sasCode: 'ABCD-EFGH',
					engineIdentityId: 'eng-handshake-id',
					sessionTokenInstalled: false,
				},
			}),
			confirmSas: async () => {
				confirmCalls++;
				profileStore.put({ ...profile, trust, state: 'active' });
				return {
					ok: true as const,
					snapshot: {
						phase: 'idle' as const,
						profileId: PAIRING_PROFILE_ID,
						sessionTokenInstalled: false,
					},
					trust,
					sessionToken: 'session-token',
				};
			},
			confirmRecoverTrust: async () => ({ ok: false as const, code: 'no_recover_trust', reason: 'test' }),
			getSnapshot: () => ({
				phase: 'awaiting_sas_confirm' as const,
				profileId: PAIRING_PROFILE_ID,
				sasCode: 'ABCD-EFGH',
				engineIdentityId: 'eng-handshake-id',
				sessionTokenInstalled: false,
			}),
			abandonRecoverTrust: () => { },
		};
		const mockResolver = {
			resolve: async (_profileId: string, options?: { readonly forPairing?: boolean }) => {
				if (options?.forPairing || profileStore.get(PAIRING_PROFILE_ID)?.trust) {
					return {
						ok: true as const,
						allowRelayFallback: true,
						endpoint: {
							attemptId: 'a1',
							authority: 'relay.example.com',
							port: 443,
							resolvedIp: '203.0.113.1',
							servername: 'relay.example.com',
							relayTicketId: 'ticket-1',
							tls: profileStore.get(PAIRING_PROFILE_ID)?.trust ? {
								trustAnchorLeafDer: leafDer,
								expectedLeafSha256Hex: trust.leafSha256Hex,
								hostnameVerification: 'replaced-by-pin' as const,
							} : null,
							expiresAtMs: Date.now() + 60_000,
							path: 'hubRelay' as const,
						},
					};
				}
				return {
					ok: false as const,
					code: 'pairing_required' as const,
					reason: 'pairing required',
					allowRelayFallback: true,
				};
			},
			consumeRelayTicket: () => { },
		};

		const service = new UniverseAgentConnectionService({
			connectionProfileStore: profileStore,
			connectionResolver: mockResolver as unknown as ConnectionResolver,
			pairingOrchestrator: mockOrchestrator as unknown as PairingOrchestrator,
			clientIdentityStore: {
				getState: async () => ({ kind: 'encryption_unavailable' as const }),
				getOrCreateIdentity: async () => ({ kind: 'encryption_unavailable' as const }),
				createSigner: async () => undefined,
			},
		});

		await service.connectProfile(PAIRING_PROFILE_ID);
		await service.confirmPairing();
		assert.strictEqual(confirmCalls, 1);
		assert.strictEqual(profileStore.get(PAIRING_PROFILE_ID)?.trust?.engineIdentityId, 'eng-handshake-id');

		profile = createHubDevicePairingProfile();
		const cancelStore = new PairingTestProfileStore(profile);
		const cancelService = new UniverseAgentConnectionService({
			connectionProfileStore: cancelStore,
			connectionResolver: mockResolver as unknown as ConnectionResolver,
			pairingOrchestrator: mockOrchestrator as unknown as PairingOrchestrator,
		});
		await cancelService.connectProfile(PAIRING_PROFILE_ID);
		await cancelService.cancelPairing();
		assert.strictEqual(cancelStore.get(PAIRING_PROFILE_ID)?.trust, null);
		assert.strictEqual(cancelService.getConnectionPhase().kind, 'closed');
		cancelService.dispose();
		service.dispose();
	});

	test('confirmPairing grant_pending without sas stays pending instead of pairing_required', async () => {
		const profileStore = new PairingTestProfileStore(createHubDevicePairingProfile());
		const mockOrchestrator = {
			startPairing: async () => ({
				ok: true as const,
				awaitingUserConfirm: true,
				snapshot: {
					phase: 'awaiting_sas_confirm' as const,
					profileId: PAIRING_PROFILE_ID,
					sasCode: 'ABCD-EFGH',
					engineIdentityId: 'eng-grant-wait',
					sessionTokenInstalled: false,
				},
			}),
			confirmSas: async () => ({
				ok: true as const,
				snapshot: {
					phase: 'grant_pending' as const,
					profileId: PAIRING_PROFILE_ID,
					engineIdentityId: 'eng-grant-wait',
					sessionTokenInstalled: false,
				},
			}),
			confirmRecoverTrust: async () => ({ ok: false as const, code: 'unused', reason: 'unused' }),
			getSnapshot: () => ({
				phase: 'awaiting_sas_confirm' as const,
				profileId: PAIRING_PROFILE_ID,
				sasCode: 'ABCD-EFGH',
				engineIdentityId: 'eng-grant-wait',
				sessionTokenInstalled: false,
			}),
			abandonRecoverTrust: () => { },
		};
		const mockResolver = {
			resolve: async (_profileId: string, options?: { readonly forPairing?: boolean }) => {
				if (options?.forPairing) {
					return {
						ok: true as const,
						allowRelayFallback: true,
						endpoint: {
							attemptId: 'a1',
							authority: 'relay.example.com',
							port: 443,
							resolvedIp: '203.0.113.1',
							servername: 'relay.example.com',
							relayTicketId: 'ticket-1',
							tls: null,
							expiresAtMs: Date.now() + 60_000,
							path: 'hubRelay' as const,
						},
					};
				}
				return { ok: false as const, code: 'pairing_required' as const, reason: 'pairing', allowRelayFallback: true };
			},
			consumeRelayTicket: () => { },
		};
		const service = new UniverseAgentConnectionService({
			connectionProfileStore: profileStore,
			connectionResolver: mockResolver as unknown as ConnectionResolver,
			pairingOrchestrator: mockOrchestrator as unknown as PairingOrchestrator,
		});

		await service.connectProfile(PAIRING_PROFILE_ID);
		const result = await service.confirmPairing();
		assert.strictEqual(result.ok, true);
		if (result.ok) {
			assert.strictEqual(result.pairingPending, true);
			assert.strictEqual(result.grantPending, true);
			assert.strictEqual(result.sasCode, undefined);
			assert.strictEqual(result.engineIdentityId, 'eng-grant-wait');
		}
		assert.strictEqual(service.getConnectionSnapshot().pairingPending, true);
		assert.notStrictEqual(service.getConnectionPhase().kind, 'failed');
		service.dispose();
	});

	test('confirmPairing grant_pending with new sasCode keeps sas for re-prompt', async () => {
		const profileStore = new PairingTestProfileStore(createHubDevicePairingProfile());
		const mockOrchestrator = {
			startPairing: async () => ({
				ok: true as const,
				awaitingUserConfirm: true,
				snapshot: {
					phase: 'awaiting_sas_confirm' as const,
					profileId: PAIRING_PROFILE_ID,
					sasCode: 'ABCD-EFGH',
					engineIdentityId: 'eng-grant-sas',
					sessionTokenInstalled: false,
				},
			}),
			confirmSas: async () => ({
				ok: true as const,
				snapshot: {
					phase: 'grant_pending' as const,
					profileId: PAIRING_PROFILE_ID,
					sasCode: 'WXYZ-ABCD',
					engineIdentityId: 'eng-grant-sas',
					sessionTokenInstalled: false,
				},
			}),
			confirmRecoverTrust: async () => ({ ok: false as const, code: 'unused', reason: 'unused' }),
			getSnapshot: () => ({
				phase: 'awaiting_sas_confirm' as const,
				profileId: PAIRING_PROFILE_ID,
				sasCode: 'ABCD-EFGH',
				engineIdentityId: 'eng-grant-sas',
				sessionTokenInstalled: false,
			}),
			abandonRecoverTrust: () => { },
		};
		const mockResolver = {
			resolve: async (_profileId: string, options?: { readonly forPairing?: boolean }) => {
				if (options?.forPairing) {
					return {
						ok: true as const,
						allowRelayFallback: true,
						endpoint: {
							attemptId: 'a1',
							authority: 'relay.example.com',
							port: 443,
							resolvedIp: '203.0.113.1',
							servername: 'relay.example.com',
							relayTicketId: 'ticket-1',
							tls: null,
							expiresAtMs: Date.now() + 60_000,
							path: 'hubRelay' as const,
						},
					};
				}
				return { ok: false as const, code: 'pairing_required' as const, reason: 'pairing', allowRelayFallback: true };
			},
			consumeRelayTicket: () => { },
		};
		const service = new UniverseAgentConnectionService({
			connectionProfileStore: profileStore,
			connectionResolver: mockResolver as unknown as ConnectionResolver,
			pairingOrchestrator: mockOrchestrator as unknown as PairingOrchestrator,
		});

		await service.connectProfile(PAIRING_PROFILE_ID);
		const result = await service.confirmPairing();
		assert.strictEqual(result.ok, true);
		if (result.ok) {
			assert.strictEqual(result.pairingPending, true);
			assert.strictEqual(result.sasCode, 'WXYZ-ABCD');
			assert.strictEqual(result.grantPending, undefined);
			assert.strictEqual(result.engineIdentityId, 'eng-grant-sas');
		}
		service.dispose();
	});

	test('awaiting_sas snapshot without sasCode fails closed instead of ok+pairingPending', async () => {
		const profileStore = new PairingTestProfileStore(createHubDevicePairingProfile());
		const mockOrchestrator = {
			startPairing: async () => ({
				ok: true as const,
				awaitingUserConfirm: true,
				snapshot: {
					phase: 'awaiting_sas_confirm' as const,
					profileId: PAIRING_PROFILE_ID,
					engineIdentityId: 'eng-empty-sas',
					sessionTokenInstalled: false,
				},
			}),
			confirmSas: async () => ({ ok: false as const, code: 'unused', reason: 'unused' }),
			confirmRecoverTrust: async () => ({ ok: false as const, code: 'unused', reason: 'unused' }),
			getSnapshot: () => undefined,
			abandonRecoverTrust: () => { },
		};
		const mockResolver = {
			resolve: async (_profileId: string, options?: { readonly forPairing?: boolean }) => {
				if (options?.forPairing) {
					return {
						ok: true as const,
						allowRelayFallback: true,
						endpoint: {
							attemptId: 'a1',
							authority: 'relay.example.com',
							port: 443,
							resolvedIp: '203.0.113.1',
							servername: 'relay.example.com',
							relayTicketId: 'ticket-1',
							tls: null,
							expiresAtMs: Date.now() + 60_000,
							path: 'hubRelay' as const,
						},
					};
				}
				return { ok: false as const, code: 'pairing_required' as const, reason: 'pairing', allowRelayFallback: true };
			},
			consumeRelayTicket: () => { },
		};
		const service = new UniverseAgentConnectionService({
			connectionProfileStore: profileStore,
			connectionResolver: mockResolver as unknown as ConnectionResolver,
			pairingOrchestrator: mockOrchestrator as unknown as PairingOrchestrator,
		});

		const result = await service.connectProfile(PAIRING_PROFILE_ID);
		assert.strictEqual(result.ok, false);
		if (!result.ok) {
			assert.strictEqual(result.code, 'pairing_required');
		}
		service.dispose();
	});

	test('recoverTrust snapshot without leaf fingerprint fails closed', async () => {
		const profileStore = new PairingTestProfileStore(createHubDevicePairingProfile());
		const mockOrchestrator = {
			startPairing: async () => ({
				ok: true as const,
				awaitingUserConfirm: true,
				snapshot: {
					phase: 'recover_trust' as const,
					profileId: PAIRING_PROFILE_ID,
					engineIdentityId: 'eng-recover',
					sessionTokenInstalled: false,
				},
			}),
			confirmSas: async () => ({ ok: false as const, code: 'unused', reason: 'unused' }),
			confirmRecoverTrust: async () => ({ ok: false as const, code: 'unused', reason: 'unused' }),
			getSnapshot: () => undefined,
			abandonRecoverTrust: () => { },
		};
		const mockResolver = {
			resolve: async (_profileId: string, options?: { readonly forPairing?: boolean }) => {
				if (options?.forPairing) {
					return {
						ok: true as const,
						allowRelayFallback: true,
						endpoint: {
							attemptId: 'a1',
							authority: 'relay.example.com',
							port: 443,
							resolvedIp: '203.0.113.1',
							servername: 'relay.example.com',
							relayTicketId: 'ticket-1',
							tls: null,
							expiresAtMs: Date.now() + 60_000,
							path: 'hubRelay' as const,
						},
					};
				}
				return { ok: false as const, code: 'pairing_required' as const, reason: 'pairing', allowRelayFallback: true };
			},
			consumeRelayTicket: () => { },
		};
		const service = new UniverseAgentConnectionService({
			connectionProfileStore: profileStore,
			connectionResolver: mockResolver as unknown as ConnectionResolver,
			pairingOrchestrator: mockOrchestrator as unknown as PairingOrchestrator,
		});

		const result = await service.connectProfile(PAIRING_PROFILE_ID);
		assert.strictEqual(result.ok, false);
		if (!result.ok) {
			assert.strictEqual(result.code, 'trust_missing');
		}
		service.dispose();
	});

	test('S4 recoverTrust branch does not install session token on startPairing', async () => {
		const profileStore = new PairingTestProfileStore(createHubDevicePairingProfile());
		const mockOrchestrator = {
			startPairing: async () => ({
				ok: true as const,
				awaitingUserConfirm: true,
				snapshot: {
					phase: 'recover_trust' as const,
					profileId: PAIRING_PROFILE_ID,
					engineIdentityId: 'eng-recover',
					leafSha256Hex: 'b'.repeat(64),
					sessionTokenInstalled: false,
				},
			}),
			confirmSas: async () => ({ ok: false as const, code: 'no_active_pairing', reason: 'test' }),
			confirmRecoverTrust: async () => ({ ok: true as const, snapshot: { phase: 'idle' as const, profileId: PAIRING_PROFILE_ID, sessionTokenInstalled: false } }),
			getSnapshot: () => ({
				phase: 'recover_trust' as const,
				profileId: PAIRING_PROFILE_ID,
				engineIdentityId: 'eng-recover',
				leafSha256Hex: 'b'.repeat(64),
				sessionTokenInstalled: false,
			}),
			abandonRecoverTrust: () => { },
		};
		const mockResolver = {
			resolve: async (_profileId: string, options?: { readonly forPairing?: boolean }) => {
				if (options?.forPairing) {
					return {
						ok: true as const,
						allowRelayFallback: true,
						endpoint: {
							attemptId: 'a1',
							authority: 'relay.example.com',
							port: 443,
							resolvedIp: '203.0.113.1',
							servername: 'relay.example.com',
							relayTicketId: 'ticket-1',
							tls: null,
							expiresAtMs: Date.now() + 60_000,
							path: 'hubRelay' as const,
						},
					};
				}
				return { ok: false as const, code: 'pairing_required' as const, reason: 'pairing', allowRelayFallback: true };
			},
			consumeRelayTicket: () => { },
		};
		const service = new UniverseAgentConnectionService({
			connectionProfileStore: profileStore,
			connectionResolver: mockResolver as unknown as ConnectionResolver,
			pairingOrchestrator: mockOrchestrator as unknown as PairingOrchestrator,
		});

		const started = await service.connectProfile(PAIRING_PROFILE_ID);
		assert.strictEqual(started.ok, true);
		if (started.ok) {
			assert.strictEqual(started.pairingPending, true);
			assert.strictEqual(started.recoverTrust, true);
			assert.strictEqual(started.engineIdentityId, 'eng-recover');
			assert.strictEqual(started.leafSha256Hex, 'b'.repeat(64));
			assert.strictEqual(started.authenticated, false);
			assert.strictEqual(Object.hasOwn(started, 'sessionToken'), false);
			assert.strictEqual(started.sasCode, undefined);
		}
		assert.strictEqual(service.isEngineConnected(), false);
		service.dispose();
	});

	test('startPairing throw becomes transport_failed instead of hanging reject', async () => {
		const profileStore = new PairingTestProfileStore(createHubDevicePairingProfile());
		const mockOrchestrator = {
			startPairing: async () => {
				throw new Error('Setting the TLS ServerName to an IP address is not permitted.');
			},
			confirmSas: async () => ({ ok: false as const, code: 'unused', reason: 'unused' }),
			confirmRecoverTrust: async () => ({ ok: false as const, code: 'unused', reason: 'unused' }),
			getSnapshot: () => undefined,
			abandonRecoverTrust: () => { },
		};
		const mockResolver = {
			resolve: async (_profileId: string, options?: { readonly forPairing?: boolean }) => {
				if (options?.forPairing) {
					return {
						ok: true as const,
						allowRelayFallback: true,
						endpoint: {
							attemptId: 'a1',
							authority: '127.0.0.1',
							port: 50061,
							resolvedIp: '127.0.0.1',
							servername: '127.0.0.1',
							relayTicketId: null,
							tls: null,
							expiresAtMs: Date.now() + 60_000,
							path: 'direct' as const,
						},
					};
				}
				return { ok: false as const, code: 'pairing_required' as const, reason: 'pairing', allowRelayFallback: false };
			},
			consumeRelayTicket: () => { },
		};
		const service = new UniverseAgentConnectionService({
			connectionProfileStore: profileStore,
			connectionResolver: mockResolver as unknown as ConnectionResolver,
			pairingOrchestrator: mockOrchestrator as unknown as PairingOrchestrator,
		});

		const result = await service.connectProfile(PAIRING_PROFILE_ID);
		assert.strictEqual(result.ok, false);
		if (!result.ok) {
			assert.strictEqual(result.code, 'transport_failed');
			assert.ok(result.reason.includes('TLS ServerName'));
		}
		assert.strictEqual(service.getConnectionPhase().kind, 'failed');
		service.dispose();
	});

	test('pairing consumes the resolved ticket before the orchestrator sees it', async () => {
		const order: string[] = [];
		const profileStore = new PairingTestProfileStore(createHubDevicePairingProfile());
		const service = new UniverseAgentConnectionService({
			connectionProfileStore: profileStore,
			connectionResolver: {
				resolve: async (_profileId: string, options?: { readonly forPairing?: boolean }) => {
					if (!options?.forPairing) {
						return { ok: false as const, code: 'pairing_required' as const, reason: 'need pair', allowRelayFallback: false };
					}
					order.push('resolve');
					return {
						ok: true as const,
						allowRelayFallback: true,
						endpoint: {
							attemptId: 'a1',
							authority: 'r.example',
							port: 443,
							resolvedIp: '203.0.113.20',
							servername: 'observe.example',
							relayTicketId: 'ticket-1',
							tls: null,
							expiresAtMs: 1,
							path: 'hubRelay' as const,
						},
					};
				},
				consumeRelayTicket: () => {
					order.push('consume');
				},
			} as unknown as ConnectionResolver,
			pairingOrchestrator: {
				startPairing: async (_profile: ConnectionProfile, endpoint: { relayTicketId?: string | null; servername: string }) => {
					order.push(`start:${endpoint.relayTicketId}:${endpoint.servername}`);
					return {
						ok: true as const,
						awaitingUserConfirm: true,
						snapshot: {
							phase: 'awaiting_sas_confirm' as const,
							profileId: PAIRING_PROFILE_ID,
							sasCode: 'ABCD-EFGH',
							engineIdentityId: 'engine-id',
							sessionTokenInstalled: false,
						},
					};
				},
				getSnapshot: () => undefined,
				confirmSas: async () => ({ ok: false as const, code: 'transport_failed', reason: 'n/a' }),
				confirmRecoverTrust: async () => ({ ok: false as const, code: 'transport_failed', reason: 'n/a' }),
				abandonRecoverTrust: () => undefined,
			} as unknown as PairingOrchestrator,
			clientIdentityStore: {
				getState: async () => ({ kind: 'ready' as const, identity: { clientIdentityId: 'a'.repeat(64), clientPublicKey: new Uint8Array(32), privateKeyPkcs8: new Uint8Array(32) } }),
				getOrCreateIdentity: async () => ({ kind: 'ready' as const, identity: { clientIdentityId: 'a'.repeat(64), clientPublicKey: new Uint8Array(32), privateKeyPkcs8: new Uint8Array(32) } }),
				createSigner: async () => undefined,
			},
		});
		const result = await service.connectProfile(PAIRING_PROFILE_ID);
		assert.strictEqual(result.ok, true);
		assert.deepStrictEqual(order, ['resolve', 'consume', 'start:ticket-1:observe.example']);
		service.dispose();
	});
});

class RevokeTestProfileStore implements IConnectionProfileStore {
	private profiles: ConnectionProfile[] = [];

	list(): ConnectionProfile[] {
		return [...this.profiles];
	}

	get(profileId: string): ConnectionProfile | undefined {
		return this.profiles.find(p => p.profileId === profileId);
	}

	put(profile: ConnectionProfile): void {
		this.profiles = this.profiles.filter(p => p.profileId !== profile.profileId);
		this.profiles.push(profile);
	}

	remove(profileId: string): void {
		this.profiles = this.profiles.filter(p => p.profileId !== profileId);
	}

	createDraft(input: {
		readonly displayName: string;
		readonly target: ConnectionProfile['target'];
		readonly allowPrivateNetwork?: boolean;
	}): ConnectionProfile {
		return {
			profileId: randomUUID(),
			displayName: input.displayName,
			target: input.target,
			trust: null,
			state: 'active',
			allowPrivateNetwork: input.allowPrivateNetwork ?? false,
		};
	}
}

suite('UniverseAgentConnectionService revokeDevice disconnect (GC-2)', () => {

	ensureNoDisposablesAreLeakedInTestSuite();

	const HUB_BASE = 'https://hub.example.com';
	const FIXTURE_NOW_MS = 1_700_000_000_000;
	const FIXTURE_SESSION: ParsedAuthSessionV1 = {
		accessToken: 'hub-access-token',
		expiresIn: 900,
		csrfToken: 'csrf-token',
		mustChangePassword: false,
		user: {
			id: 'usr_1',
			email: 'user@example.com',
			role: 'USER',
			status: 'ACTIVE',
		},
	};

	async function createConnectedHubDeviceService(hubDeviceId: string): Promise<{
		readonly service: UniverseAgentConnectionService;
		readonly profileId: string;
		readonly transport: MockUniverseAgentGrpcTransport;
	}> {
		const profileStore = new RevokeTestProfileStore();
		const profile = profileStore.createDraft({
			displayName: 'Studio',
			target: { kind: 'hubDevice', hubBaseUrl: HUB_BASE, accountId: 'usr_1', hubDeviceId },
		});
		profileStore.put({ ...profile, state: 'active', trust: null });
		const hubSessionStore = new InMemoryHubSessionStore();
		await hubSessionStore.applyAuthSession(HUB_BASE, FIXTURE_SESSION, FIXTURE_NOW_MS, 'refresh-token');
		const transport = new MockUniverseAgentGrpcTransport();
		const service = new UniverseAgentConnectionService({
			connectionResolver: plainFixtureResolver(),
			clientIdentityStore: plainFixtureIdentity(),
			hubSessionStore,
			connectionProfileStore: profileStore,
			nowMs: () => FIXTURE_NOW_MS,
			skipStartupRestore: true,
			createTransport: () => transport,
			http: {
				fetch: async (url: string) => {
					if (url.includes('/revoke')) {
						return { status: 200, json: async () => ({}) };
					}
					if (url.includes('/devices')) {
						return { status: 200, json: async () => ({ devices: [] }) };
					}
					throw new Error(`unexpected fetch url: ${url}`);
				},
			},
		});
		service.setActiveHubBaseUrl(HUB_BASE);
		await connectPlainFixture(service);
		(service as unknown as { _activeProfileId: string })._activeProfileId = profile.profileId;
		assert.strictEqual(service.isEngineConnected(), true);
		return { service, profileId: profile.profileId, transport };
	}

	test('revoke of connected hubDevice profile disconnects once', async () => {
		const { service, profileId, transport } = await createConnectedHubDeviceService('dev-1');
		let closeCount = 0;
		const originalClose = transport.close.bind(transport);
		(transport as { close(): void }).close = () => {
			closeCount++;
			originalClose();
		};

		const result = await service.revokeDevice('dev-1');
		assert.strictEqual(result.ok, true);
		assert.strictEqual(service.isEngineConnected(), false);
		assert.strictEqual(service.getConnectionPhase().kind, 'closed');
		assert.strictEqual(closeCount, 1);
		const stored = (service as unknown as { _connectionProfileStore: IConnectionProfileStore })._connectionProfileStore.get(profileId);
		assert.strictEqual(stored?.state, 'revoked');
		service.dispose();
	});

	test('revoke of a different hubDevice does not disconnect', async () => {
		const { service, transport } = await createConnectedHubDeviceService('dev-active');
		let closeCount = 0;
		const originalClose = transport.close.bind(transport);
		(transport as { close(): void }).close = () => {
			closeCount++;
			originalClose();
		};

		const result = await service.revokeDevice('dev-other');
		assert.strictEqual(result.ok, true);
		assert.strictEqual(service.isEngineConnected(), true);
		assert.strictEqual(closeCount, 0);
		service.dispose();
	});

	test('revoke of the same device on another hub does not disconnect', async () => {
		const otherHub = 'https://other.example.com';
		const profileStore = new RevokeTestProfileStore();
		const connected = profileStore.createDraft({
			displayName: 'Other',
			target: { kind: 'hubDevice', hubBaseUrl: otherHub, accountId: 'usr_1', hubDeviceId: 'dev-1' },
		});
		profileStore.put({ ...connected, state: 'active', trust: null });
		const activeHubProfile = profileStore.createDraft({
			displayName: 'Active',
			target: { kind: 'hubDevice', hubBaseUrl: HUB_BASE, accountId: 'usr_1', hubDeviceId: 'dev-1' },
		});
		profileStore.put({ ...activeHubProfile, state: 'active', trust: null });
		const hubSessionStore = new InMemoryHubSessionStore();
		await hubSessionStore.applyAuthSession(HUB_BASE, FIXTURE_SESSION, FIXTURE_NOW_MS, 'refresh-token');
		const transport = new MockUniverseAgentGrpcTransport();
		const service = new UniverseAgentConnectionService({
			connectionResolver: plainFixtureResolver(),
			clientIdentityStore: plainFixtureIdentity(),
			hubSessionStore,
			connectionProfileStore: profileStore,
			nowMs: () => FIXTURE_NOW_MS,
			skipStartupRestore: true,
			createTransport: () => transport,
			http: {
				fetch: async (url: string) => {
					if (url.includes('/revoke')) {
						return { status: 200, json: async () => ({}) };
					}
					if (url.includes('/devices')) {
						return { status: 200, json: async () => ({ devices: [] }) };
					}
					throw new Error(`unexpected fetch url: ${url}`);
				},
			},
		});
		service.setActiveHubBaseUrl(HUB_BASE);
		await connectPlainFixture(service);
		(service as unknown as { _activeProfileId: string })._activeProfileId = connected.profileId;
		assert.strictEqual(service.isEngineConnected(), true);
		let closeCount = 0;
		const originalClose = transport.close.bind(transport);
		(transport as { close(): void }).close = () => {
			closeCount++;
			originalClose();
		};

		const result = await service.revokeDevice('dev-1');
		assert.strictEqual(result.ok, true);
		assert.strictEqual(service.isEngineConnected(), true);
		assert.strictEqual(closeCount, 0);
		assert.strictEqual(profileStore.get(connected.profileId)?.state, 'active');
		assert.strictEqual(profileStore.get(activeHubProfile.profileId)?.state, 'revoked');
		service.dispose();
	});

	test('revoke of the same hub identity disconnects once', async () => {
		const profileStore = new RevokeTestProfileStore();
		const profile = profileStore.createDraft({
			displayName: 'Studio',
			target: { kind: 'hubDevice', hubBaseUrl: 'https://Example.com:443/', accountId: 'usr_1', hubDeviceId: 'dev-1' },
		});
		profileStore.put({ ...profile, state: 'active', trust: null });
		const hubSessionStore = new InMemoryHubSessionStore();
		await hubSessionStore.applyAuthSession('https://example.com', FIXTURE_SESSION, FIXTURE_NOW_MS, 'refresh-token');
		const transport = new MockUniverseAgentGrpcTransport();
		const service = new UniverseAgentConnectionService({
			connectionResolver: plainFixtureResolver(),
			clientIdentityStore: plainFixtureIdentity(),
			hubSessionStore,
			connectionProfileStore: profileStore,
			nowMs: () => FIXTURE_NOW_MS,
			skipStartupRestore: true,
			createTransport: () => transport,
			http: {
				fetch: async (url: string) => {
					if (url.includes('/revoke')) {
						return { status: 200, json: async () => ({}) };
					}
					if (url.includes('/devices')) {
						return { status: 200, json: async () => ({ devices: [] }) };
					}
					throw new Error(`unexpected fetch url: ${url}`);
				},
			},
		});
		service.setActiveHubBaseUrl('https://Example.com:443/');
		assert.strictEqual(service.getActiveHubBaseUrl(), 'https://example.com');
		await connectPlainFixture(service);
		(service as unknown as { _activeProfileId: string })._activeProfileId = profile.profileId;
		assert.strictEqual(service.isEngineConnected(), true);
		let closeCount = 0;
		const originalClose = transport.close.bind(transport);
		(transport as { close(): void }).close = () => {
			closeCount++;
			originalClose();
		};

		const result = await service.revokeDevice('dev-1');
		assert.strictEqual(result.ok, true);
		assert.strictEqual(service.isEngineConnected(), false);
		assert.strictEqual(service.getConnectionPhase().kind, 'closed');
		assert.strictEqual(closeCount, 1);
		assert.strictEqual(profileStore.get(profile.profileId)?.state, 'revoked');
		service.dispose();
	});
});

function createReconnectClock() {
	const delays: number[] = [];
	const pending = new Map<number, () => void>();
	let nextId = 1;
	const setTimeoutFn = (fn: () => void, delay?: number) => {
		delays.push(delay ?? 0);
		const id = nextId++;
		pending.set(id, fn);
		return id as unknown as ReturnType<typeof setTimeout>;
	};
	const clearTimeoutFn = (handle: ReturnType<typeof setTimeout>) => {
		pending.delete(handle as unknown as number);
	};
	const fireAll = (): void => {
		const jobs = [...pending.values()];
		pending.clear();
		for (const job of jobs) {
			job();
		}
	};
	return { delays, setTimeoutFn, clearTimeoutFn, fireAll, pending };
}

suite('UniverseAgentConnectionService reconnect backoff (D408)', () => {

	ensureNoDisposablesAreLeakedInTestSuite();

	const identityStore: IClientIdentityStore = {
		getState: async () => ({
			kind: 'ready',
			identity: {
				clientIdentityId: 'a'.repeat(64),
				clientPublicKey: new Uint8Array(32),
				privateKeyPkcs8: new Uint8Array(32),
			},
		}),
		getOrCreateIdentity: async () => ({
			kind: 'ready',
			identity: {
				clientIdentityId: 'a'.repeat(64),
				clientPublicKey: new Uint8Array(32),
				privateKeyPkcs8: new Uint8Array(32),
			},
		}),
		createSigner: async () => undefined,
	};

	const okEndpoint = {
		attemptId: 'a1',
		authority: '127.0.0.1',
		port: 50051,
		resolvedIp: '127.0.0.1',
		servername: '127.0.0.1',
		relayTicketId: null,
		tls: null,
		expiresAtMs: Date.now() + 60_000,
		path: 'direct' as const,
	};

	function createOkResolver(onResolve?: (options?: { readonly forceNewTicket?: boolean }) => void) {
		return {
			resolve: async (_profileId: string, options?: { readonly forceNewTicket?: boolean }) => {
				onResolve?.(options);
				return { ok: true as const, allowRelayFallback: false, endpoint: okEndpoint };
			},
			consumeRelayTicket: () => { },
		};
	}

	async function flushReconnect(): Promise<void> {
		await timeout(0);
		await timeout(0);
	}

	test('transport_lost with active profile schedules connectProfile({ reconnect: true })', async () => {
		const clock = createReconnectClock();
		const reconnectOpts: Array<boolean | undefined> = [];
		const forceTickets: Array<boolean | undefined> = [];
		let created = 0;
		const service = new UniverseAgentConnectionService({
			createTransport: () => {
				created++;
				if (created === 1) {
					return new MockUniverseAgentGrpcTransport({
						listSessions: async () => {
							throw new UniverseAgentTransportError(GrpcStatusCode.UNAVAILABLE, 'down');
						},
					});
				}
				return new MockUniverseAgentGrpcTransport();
			},
			connectionResolver: createOkResolver(options => forceTickets.push(options?.forceNewTicket)) as unknown as ConnectionResolver,
			clientIdentityStore: identityStore,
			reconnectJitterRatio: 0,
			setTimeoutFn: clock.setTimeoutFn,
			clearTimeoutFn: clock.clearTimeoutFn,
		});
		const original = service.connectProfile.bind(service);
		service.connectProfile = async (profileId, options) => {
			reconnectOpts.push(options?.reconnect);
			return original(profileId, options);
		};

		const first = await service.connectProfile('p1');
		assert.strictEqual(first.ok, true);
		await assert.rejects(() => service.listSessions({}));
		assert.strictEqual(service.getConnectionPhase().kind, 'connecting');
		assert.strictEqual((service.getConnectionPhase() as { reason?: string }).reason, 'transport_lost');
		assert.deepStrictEqual(clock.delays, [1000]);
		assert.strictEqual(clock.pending.size, 1);

		clock.fireAll();
		await flushReconnect();
		assert.ok(reconnectOpts.includes(true), 'scheduled redial must pass reconnect: true');
		assert.ok(forceTickets.includes(true), 'reconnect resolve must forceNewTicket');
		assert.strictEqual(service.getConnectionPhase().kind, 'connected');
		service.dispose();
	});

	test('backoff doubles then caps at 30000', async () => {
		const clock = createReconnectClock();
		let connects = 0;
		const service = new UniverseAgentConnectionService({
			createTransport: () => new MockUniverseAgentGrpcTransport({
				connect: async () => {
					connects++;
					if (connects === 1) {
						return { sessionToken: 'token-1', workDir: '/tmp/work', methods: [], events: [] };
					}
					throw new UniverseAgentTransportError(GrpcStatusCode.UNAVAILABLE, 'down');
				},
				listSessions: async () => {
					throw new UniverseAgentTransportError(GrpcStatusCode.UNAVAILABLE, 'down');
				},
			}),
			connectionResolver: createOkResolver() as unknown as ConnectionResolver,
			clientIdentityStore: identityStore,
			reconnectBaseMs: 10_000,
			reconnectMaxMs: 30_000,
			reconnectJitterRatio: 0,
			setTimeoutFn: clock.setTimeoutFn,
			clearTimeoutFn: clock.clearTimeoutFn,
		});

		await service.connectProfile('p1');
		await assert.rejects(() => service.listSessions({}));
		assert.deepStrictEqual(clock.delays, [10_000]);

		clock.fireAll();
		await flushReconnect();
		assert.deepStrictEqual(clock.delays, [10_000, 20_000]);

		clock.fireAll();
		await flushReconnect();
		assert.deepStrictEqual(clock.delays, [10_000, 20_000, 30_000]);

		clock.fireAll();
		await flushReconnect();
		assert.deepStrictEqual(clock.delays, [10_000, 20_000, 30_000, 30_000]);
		service.dispose();
	});

	test('jitter is ±20% of raw delay', async () => {
		const originalRandom = Math.random;
		try {
			Math.random = () => 1;
			const high = createReconnectClock();
			const highService = new UniverseAgentConnectionService({
				createTransport: () => new MockUniverseAgentGrpcTransport({
					listSessions: async () => {
						throw new UniverseAgentTransportError(GrpcStatusCode.UNAVAILABLE, 'down');
					},
				}),
				connectionResolver: createOkResolver() as unknown as ConnectionResolver,
				clientIdentityStore: identityStore,
				setTimeoutFn: high.setTimeoutFn,
				clearTimeoutFn: high.clearTimeoutFn,
			});
			await highService.connectProfile('p1');
			await assert.rejects(() => highService.listSessions({}));
			assert.deepStrictEqual(high.delays, [1200]);
			highService.dispose();

			Math.random = () => 0;
			const low = createReconnectClock();
			const lowService = new UniverseAgentConnectionService({
				createTransport: () => new MockUniverseAgentGrpcTransport({
					listSessions: async () => {
						throw new UniverseAgentTransportError(GrpcStatusCode.UNAVAILABLE, 'down');
					},
				}),
				connectionResolver: createOkResolver() as unknown as ConnectionResolver,
				clientIdentityStore: identityStore,
				setTimeoutFn: low.setTimeoutFn,
				clearTimeoutFn: low.clearTimeoutFn,
			});
			await lowService.connectProfile('p1');
			await assert.rejects(() => lowService.listSessions({}));
			assert.deepStrictEqual(low.delays, [800]);
			lowService.dispose();
		} finally {
			Math.random = originalRandom;
		}
	});

	test('successful reconnect resets attempt count', async () => {
		const clock = createReconnectClock();
		let created = 0;
		const service = new UniverseAgentConnectionService({
			createTransport: () => {
				created++;
				if (created % 2 === 1) {
					return new MockUniverseAgentGrpcTransport({
						listSessions: async () => {
							throw new UniverseAgentTransportError(GrpcStatusCode.UNAVAILABLE, 'down');
						},
					});
				}
				return new MockUniverseAgentGrpcTransport({
					listSessions: async () => {
						throw new UniverseAgentTransportError(GrpcStatusCode.UNAVAILABLE, 'down');
					},
				});
			},
			connectionResolver: createOkResolver() as unknown as ConnectionResolver,
			clientIdentityStore: identityStore,
			reconnectJitterRatio: 0,
			setTimeoutFn: clock.setTimeoutFn,
			clearTimeoutFn: clock.clearTimeoutFn,
		});

		await service.connectProfile('p1');
		await assert.rejects(() => service.listSessions({}));
		assert.deepStrictEqual(clock.delays, [1000]);
		clock.fireAll();
		await flushReconnect();
		assert.strictEqual(service.getConnectionPhase().kind, 'connected');

		await assert.rejects(() => service.listSessions({}));
		assert.deepStrictEqual(clock.delays, [1000, 1000]);
		service.dispose();
	});

	test('disconnect cancels pending reconnect', async () => {
		const clock = createReconnectClock();
		const forceTickets: Array<boolean | undefined> = [];
		const service = new UniverseAgentConnectionService({
			createTransport: () => new MockUniverseAgentGrpcTransport({
				listSessions: async () => {
					throw new UniverseAgentTransportError(GrpcStatusCode.UNAVAILABLE, 'down');
				},
			}),
			connectionResolver: createOkResolver(options => forceTickets.push(options?.forceNewTicket)) as unknown as ConnectionResolver,
			clientIdentityStore: identityStore,
			reconnectJitterRatio: 0,
			setTimeoutFn: clock.setTimeoutFn,
			clearTimeoutFn: clock.clearTimeoutFn,
		});
		await service.connectProfile('p1');
		const resolvesAfterConnect = forceTickets.length;
		await assert.rejects(() => service.listSessions({}));
		assert.strictEqual(clock.pending.size, 1);
		await service.disconnect();
		assert.strictEqual(clock.pending.size, 0);
		clock.fireAll();
		await flushReconnect();
		assert.strictEqual(forceTickets.length, resolvesAfterConnect);
		service.dispose();
	});

	test('dispose cancels pending reconnect', async () => {
		const clock = createReconnectClock();
		const forceTickets: Array<boolean | undefined> = [];
		const service = new UniverseAgentConnectionService({
			createTransport: () => new MockUniverseAgentGrpcTransport({
				listSessions: async () => {
					throw new UniverseAgentTransportError(GrpcStatusCode.UNAVAILABLE, 'down');
				},
			}),
			connectionResolver: createOkResolver(options => forceTickets.push(options?.forceNewTicket)) as unknown as ConnectionResolver,
			clientIdentityStore: identityStore,
			reconnectJitterRatio: 0,
			setTimeoutFn: clock.setTimeoutFn,
			clearTimeoutFn: clock.clearTimeoutFn,
		});
		await service.connectProfile('p1');
		const resolvesAfterConnect = forceTickets.length;
		await assert.rejects(() => service.listSessions({}));
		assert.strictEqual(clock.pending.size, 1);
		service.dispose();
		assert.strictEqual(clock.pending.size, 0);
		clock.fireAll();
		await flushReconnect();
		assert.strictEqual(forceTickets.length, resolvesAfterConnect);
	});

	test('cancelPairing cancels pending reconnect', async () => {
		const clock = createReconnectClock();
		const forceTickets: Array<boolean | undefined> = [];
		const service = new UniverseAgentConnectionService({
			createTransport: () => new MockUniverseAgentGrpcTransport({
				listSessions: async () => {
					throw new UniverseAgentTransportError(GrpcStatusCode.UNAVAILABLE, 'down');
				},
			}),
			connectionResolver: createOkResolver(options => forceTickets.push(options?.forceNewTicket)) as unknown as ConnectionResolver,
			clientIdentityStore: identityStore,
			reconnectJitterRatio: 0,
			setTimeoutFn: clock.setTimeoutFn,
			clearTimeoutFn: clock.clearTimeoutFn,
		});
		await service.connectProfile('p1');
		const resolvesAfterConnect = forceTickets.length;
		await assert.rejects(() => service.listSessions({}));
		assert.strictEqual(clock.pending.size, 1);
		await service.cancelPairing();
		assert.strictEqual(clock.pending.size, 0);
		clock.fireAll();
		await flushReconnect();
		assert.strictEqual(forceTickets.length, resolvesAfterConnect);
		service.dispose();
	});

	test('pairingPending does not schedule reconnect', async () => {
		const clock = createReconnectClock();
		const service = new UniverseAgentConnectionService({
			connectionProfileStore: new PairingTestProfileStore(directPairingPendingProfile('p1')),
			connectionResolver: pairingRequiredResolver() as unknown as ConnectionResolver,
			pairingOrchestrator: awaitingSasOrchestrator(),
			reconnectJitterRatio: 0,
			setTimeoutFn: clock.setTimeoutFn,
			clearTimeoutFn: clock.clearTimeoutFn,
		});
		await service.connectProfile('p1');
		const transport = new MockUniverseAgentGrpcTransport({
			listSessions: async () => {
				throw new UniverseAgentTransportError(GrpcStatusCode.UNAVAILABLE, 'down');
			},
		});
		const dial = service as unknown as { _transport?: MockUniverseAgentGrpcTransport; _activeProfileId?: string; _transportState?: string };
		dial._transport = transport;
		dial._activeProfileId = 'p1';
		dial._transportState = 'ok';
		assert.strictEqual(service.getConnectionSnapshot().pairingPending, true);
		await assert.rejects(() => service.listSessions({}));
		assert.strictEqual(clock.delays.length, 0);
		service.dispose();
	});

	test('pairing_required resolve does not schedule reconnect', async () => {
		const clock = createReconnectClock();
		const mockResolver = {
			resolve: async () => ({
				ok: false as const,
				code: 'pairing_required' as const,
				reason: 'pairing required',
				allowRelayFallback: true,
			}),
			consumeRelayTicket: () => { },
		};
		const service = new UniverseAgentConnectionService({
			createTransport: () => new MockUniverseAgentGrpcTransport(),
			connectionResolver: mockResolver as unknown as ConnectionResolver,
			clientIdentityStore: identityStore,
			reconnectJitterRatio: 0,
			setTimeoutFn: clock.setTimeoutFn,
			clearTimeoutFn: clock.clearTimeoutFn,
		});
		const result = await service.connectProfile('p1');
		assert.strictEqual(result.ok, false);
		if (!result.ok) {
			assert.strictEqual(result.code, 'pairing_required');
		}
		assert.strictEqual(clock.delays.length, 0);
		service.dispose();
	});

	test('unauthenticated transport error does not schedule reconnect', async () => {
		const clock = createReconnectClock();
		const service = new UniverseAgentConnectionService({
			createTransport: () => new MockUniverseAgentGrpcTransport({
				listSessions: async () => {
					throw new UniverseAgentTransportError(16, 'unauthenticated');
				},
			}),
			connectionResolver: createOkResolver() as unknown as ConnectionResolver,
			clientIdentityStore: identityStore,
			reconnectJitterRatio: 0,
			setTimeoutFn: clock.setTimeoutFn,
			clearTimeoutFn: clock.clearTimeoutFn,
		});
		await service.connectProfile('p1');
		await assert.rejects(() => service.listSessions({}));
		assert.strictEqual(clock.delays.length, 0);
		assert.notStrictEqual((service.getConnectionPhase() as { reason?: string }).reason, 'transport_lost');
		service.dispose();
	});

	test('no active profile does not schedule reconnect', async () => {
		const clock = createReconnectClock();
		const transport = new MockUniverseAgentGrpcTransport({
			listSessions: async () => {
				throw new UniverseAgentTransportError(GrpcStatusCode.UNAVAILABLE, 'down');
			},
		});
		const service = new UniverseAgentConnectionService(localEngineFixtureOptions(transport, {
			setTimeoutFn: clock.setTimeoutFn,
			clearTimeoutFn: clock.clearTimeoutFn,
		}));
		await Promise.resolve();
		await Promise.resolve();
		assert.strictEqual(clock.pending.size, 1);
		clock.fireAll();
		await settleLocalTurns();
		assert.strictEqual(service.isEngineConnected(), true);
		assert.strictEqual((service as unknown as { _activeProfileId?: string })._activeProfileId, undefined);
		const delaysAfterDial = clock.delays.length;
		await assert.rejects(() => service.listSessions({}));
		assert.strictEqual(clock.delays.length, delaysAfterDial);
		assert.strictEqual(clock.pending.size, 0);
		service.dispose();
	});

	test('reconnect transport_failed still reschedules backoff (D410)', async () => {
		const clock = createReconnectClock();
		let resolves = 0;
		const resolver = {
			resolve: async () => {
				resolves++;
				if (resolves === 1) {
					return { ok: true as const, allowRelayFallback: false, endpoint: okEndpoint };
				}
				return { ok: false as const, code: 'transport_failed' as const, reason: 'dial refused', allowRelayFallback: false };
			},
			consumeRelayTicket: () => { },
		};
		const service = new UniverseAgentConnectionService({
			createTransport: () => new MockUniverseAgentGrpcTransport({
				listSessions: async () => {
					throw new UniverseAgentTransportError(GrpcStatusCode.UNAVAILABLE, 'down');
				},
			}),
			connectionResolver: resolver as unknown as ConnectionResolver,
			clientIdentityStore: identityStore,
			reconnectJitterRatio: 0,
			setTimeoutFn: clock.setTimeoutFn,
			clearTimeoutFn: clock.clearTimeoutFn,
		});

		await service.connectProfile('p1');
		await assert.rejects(() => service.listSessions({}));
		assert.deepStrictEqual(clock.delays, [1000]);
		assert.strictEqual(clock.pending.size, 1);

		clock.fireAll();
		await flushReconnect();
		assert.deepStrictEqual(clock.delays, [1000, 2000]);
		assert.strictEqual(clock.pending.size, 1);

		clock.fireAll();
		await flushReconnect();
		assert.deepStrictEqual(clock.delays, [1000, 2000, 4000]);
		assert.strictEqual(clock.pending.size, 1);
		service.dispose();
	});

	test('reconnect non-TransportError throw still reschedules backoff (D410)', async () => {
		const clock = createReconnectClock();
		let connects = 0;
		const service = new UniverseAgentConnectionService({
			createTransport: () => new MockUniverseAgentGrpcTransport({
				connect: async () => {
					connects++;
					if (connects === 1) {
						return { sessionToken: 'token-1', workDir: '/tmp/work', methods: [], events: [] };
					}
					throw new Error('plain connect blowup');
				},
				listSessions: async () => {
					throw new UniverseAgentTransportError(GrpcStatusCode.UNAVAILABLE, 'down');
				},
			}),
			connectionResolver: createOkResolver() as unknown as ConnectionResolver,
			clientIdentityStore: identityStore,
			reconnectJitterRatio: 0,
			setTimeoutFn: clock.setTimeoutFn,
			clearTimeoutFn: clock.clearTimeoutFn,
		});

		await service.connectProfile('p1');
		await assert.rejects(() => service.listSessions({}));
		assert.deepStrictEqual(clock.delays, [1000]);

		clock.fireAll();
		await flushReconnect();
		assert.deepStrictEqual(clock.delays, [1000, 2000]);
		assert.strictEqual(clock.pending.size, 1);
		service.dispose();
	});

	test('reconnect pairing_required still does not reschedule (D410)', async () => {
		const clock = createReconnectClock();
		let resolves = 0;
		const resolver = {
			resolve: async () => {
				resolves++;
				if (resolves === 1) {
					return { ok: true as const, allowRelayFallback: false, endpoint: okEndpoint };
				}
				return { ok: false as const, code: 'pairing_required' as const, reason: 'pairing required', allowRelayFallback: true };
			},
			consumeRelayTicket: () => { },
		};
		const service = new UniverseAgentConnectionService({
			createTransport: () => new MockUniverseAgentGrpcTransport({
				listSessions: async () => {
					throw new UniverseAgentTransportError(GrpcStatusCode.UNAVAILABLE, 'down');
				},
			}),
			connectionResolver: resolver as unknown as ConnectionResolver,
			clientIdentityStore: identityStore,
			reconnectJitterRatio: 0,
			setTimeoutFn: clock.setTimeoutFn,
			clearTimeoutFn: clock.clearTimeoutFn,
		});

		await service.connectProfile('p1');
		await assert.rejects(() => service.listSessions({}));
		assert.deepStrictEqual(clock.delays, [1000]);

		clock.fireAll();
		await flushReconnect();
		assert.deepStrictEqual(clock.delays, [1000]);
		assert.strictEqual(clock.pending.size, 0);
		service.dispose();
	});

	test('plaintext reconnect connect() keeps transport_lost (D413)', async () => {
		const clock = createReconnectClock();
		let connectPhaseReason: string | undefined;
		let created = 0;
		const service = new UniverseAgentConnectionService({
			createTransport: () => {
				created++;
				if (created === 1) {
					return new MockUniverseAgentGrpcTransport({
						listSessions: async () => {
							throw new UniverseAgentTransportError(GrpcStatusCode.UNAVAILABLE, 'down');
						},
					});
				}
				return new MockUniverseAgentGrpcTransport({
					connect: async () => {
						connectPhaseReason = (service.getConnectionPhase() as { reason?: string }).reason;
						return { sessionToken: 'token-2', workDir: '/tmp/work', methods: [], events: [] };
					},
				});
			},
			connectionResolver: createOkResolver() as unknown as ConnectionResolver,
			clientIdentityStore: identityStore,
			reconnectJitterRatio: 0,
			setTimeoutFn: clock.setTimeoutFn,
			clearTimeoutFn: clock.clearTimeoutFn,
		});

		await service.connectProfile('p1');
		await assert.rejects(() => service.listSessions({}));
		assert.strictEqual((service.getConnectionPhase() as { reason?: string }).reason, 'transport_lost');

		const result = await service.connectProfile('p1', { reconnect: true });
		assert.strictEqual(result.ok, true);
		assert.strictEqual(connectPhaseReason, 'transport_lost');
		assert.strictEqual((service.getConnectionPhase() as { reason?: string }).reason, undefined);
		assert.strictEqual(service.getConnectionPhase().kind, 'connected');
		service.dispose();
	});

	test('user reconnect resolver transport_failed reschedules (D413)', async () => {
		const clock = createReconnectClock();
		let resolves = 0;
		const resolver = {
			resolve: async () => {
				resolves++;
				if (resolves === 1) {
					return { ok: true as const, allowRelayFallback: false, endpoint: okEndpoint };
				}
				return { ok: false as const, code: 'transport_failed' as const, reason: 'dial refused', allowRelayFallback: false };
			},
			consumeRelayTicket: () => { },
		};
		const service = new UniverseAgentConnectionService({
			createTransport: () => new MockUniverseAgentGrpcTransport({
				listSessions: async () => {
					throw new UniverseAgentTransportError(GrpcStatusCode.UNAVAILABLE, 'down');
				},
			}),
			connectionResolver: resolver as unknown as ConnectionResolver,
			clientIdentityStore: identityStore,
			reconnectJitterRatio: 0,
			setTimeoutFn: clock.setTimeoutFn,
			clearTimeoutFn: clock.clearTimeoutFn,
		});

		await service.connectProfile('p1');
		await assert.rejects(() => service.listSessions({}));
		assert.deepStrictEqual(clock.delays, [1000]);
		assert.strictEqual(clock.pending.size, 1);

		const result = await service.connectProfile('p1', { reconnect: true });
		assert.strictEqual(result.ok, false);
		if (!result.ok) {
			assert.strictEqual(result.code, 'transport_failed');
		}
		assert.deepStrictEqual(clock.delays, [1000, 2000]);
		assert.strictEqual(clock.pending.size, 1);
		service.dispose();
	});

	const handshakeLeafDer = new Uint8Array([1, 2, 3, 4]);
	const handshakeTrust = createEngineTrustRecord({
		leafDer: handshakeLeafDer,
		engineIdentityId: 'engine-id',
		establishedAt: Date.now(),
	});
	const handshakeTlsEndpoint = {
		...okEndpoint,
		tls: {
			trustAnchorLeafDer: handshakeLeafDer,
			expectedLeafSha256Hex: handshakeTrust.leafSha256Hex,
			hostnameVerification: 'replaced-by-pin' as const,
		},
	};
	const handshakeProfile: ConnectionProfile = {
		profileId: 'p1',
		displayName: 'Direct',
		target: { kind: 'directAddress', host: '127.0.0.1', port: 50051 },
		trust: handshakeTrust,
		state: 'active',
		allowPrivateNetwork: true,
	};
	const signingIdentityStore: IClientIdentityStore = {
		...identityStore,
		createSigner: async () => () => new Uint8Array(64),
	};

	test('user reconnect handshake transport_failed reschedules (D413)', async () => {
		const clock = createReconnectClock();
		let resolves = 0;
		const resolver = {
			resolve: async () => {
				resolves++;
				if (resolves === 1) {
					return { ok: true as const, allowRelayFallback: false, endpoint: okEndpoint };
				}
				return { ok: true as const, allowRelayFallback: false, endpoint: handshakeTlsEndpoint };
			},
			consumeRelayTicket: () => { },
		};
		class HandshakeTransportFailed extends MockUniverseAgentGrpcTransport {
			override async getAuthNonce(): Promise<UniverseAgentAuthNonceResult> {
				throw new UniverseAgentTransportError(GrpcStatusCode.UNAVAILABLE, '14 UNAVAILABLE: connect ECONNREFUSED 127.0.0.1:50051');
			}
		}
		const service = new UniverseAgentConnectionService({
			createTransport: () => new MockUniverseAgentGrpcTransport({
				listSessions: async () => {
					throw new UniverseAgentTransportError(GrpcStatusCode.UNAVAILABLE, 'down');
				},
			}),
			createPinnedTransport: () => new HandshakeTransportFailed(),
			connectionResolver: resolver as unknown as ConnectionResolver,
			connectionProfileStore: new PairingTestProfileStore(handshakeProfile),
			clientIdentityStore: signingIdentityStore,
			reconnectJitterRatio: 0,
			setTimeoutFn: clock.setTimeoutFn,
			clearTimeoutFn: clock.clearTimeoutFn,
		});

		await service.connectProfile('p1');
		await assert.rejects(() => service.listSessions({}));
		assert.deepStrictEqual(clock.delays, [1000]);

		const result = await service.connectProfile('p1', { reconnect: true });
		assert.strictEqual(result.ok, false);
		if (!result.ok) {
			assert.strictEqual(result.code, 'transport_failed');
		}
		assert.deepStrictEqual(clock.delays, [1000, 2000]);
		assert.strictEqual(clock.pending.size, 1);
		service.dispose();
	});

	test('user reconnect handshake pin_mismatch does not reschedule (D413)', async () => {
		const clock = createReconnectClock();
		let resolves = 0;
		const resolver = {
			resolve: async () => {
				resolves++;
				if (resolves === 1) {
					return { ok: true as const, allowRelayFallback: false, endpoint: okEndpoint };
				}
				return { ok: true as const, allowRelayFallback: false, endpoint: handshakeTlsEndpoint };
			},
			consumeRelayTicket: () => { },
		};
		class PinMismatchTransport extends MockUniverseAgentGrpcTransport {
			override async getAuthNonce() {
				return {
					authNonce: new Uint8Array(32),
					engineIdentityId: 'engine-id',
					engineCertFingerprint: '0'.repeat(64),
				};
			}
		}
		const service = new UniverseAgentConnectionService({
			createTransport: () => new MockUniverseAgentGrpcTransport({
				listSessions: async () => {
					throw new UniverseAgentTransportError(GrpcStatusCode.UNAVAILABLE, 'down');
				},
			}),
			createPinnedTransport: () => new PinMismatchTransport(),
			connectionResolver: resolver as unknown as ConnectionResolver,
			connectionProfileStore: new PairingTestProfileStore(handshakeProfile),
			clientIdentityStore: signingIdentityStore,
			reconnectJitterRatio: 0,
			setTimeoutFn: clock.setTimeoutFn,
			clearTimeoutFn: clock.clearTimeoutFn,
		});

		await service.connectProfile('p1');
		await assert.rejects(() => service.listSessions({}));
		assert.deepStrictEqual(clock.delays, [1000]);

		const result = await service.connectProfile('p1', { reconnect: true });
		assert.strictEqual(result.ok, false);
		if (!result.ok) {
			assert.strictEqual(result.code, 'pin_mismatch');
		}
		assert.deepStrictEqual(clock.delays, [1000]);
		assert.strictEqual(clock.pending.size, 0);
		service.dispose();
	});

	const tlsPinUnavailable = '14 UNAVAILABLE: No connection established. Last error: Engine TLS leaf fingerprint does not match pinned trust anchor';

	function lostSessionTransport(): MockUniverseAgentGrpcTransport {
		return new MockUniverseAgentGrpcTransport({
			listSessions: async () => {
				throw new UniverseAgentTransportError(GrpcStatusCode.UNAVAILABLE, 'down');
			},
		});
	}

	function handshakeReconnectService(input: {
		readonly clock: ReturnType<typeof createReconnectClock>;
		readonly pinned: MockUniverseAgentGrpcTransport;
		readonly store?: PairingTestProfileStore;
		readonly resolver?: ConnectionResolver;
		readonly pairingOrchestrator?: PairingOrchestrator;
	}): { readonly service: UniverseAgentConnectionService; readonly store: PairingTestProfileStore } {
		const store = input.store ?? new PairingTestProfileStore(handshakeProfile);
		let resolves = 0;
		const resolver = input.resolver ?? {
			resolve: async () => {
				resolves++;
				if (resolves === 1) {
					return { ok: true as const, allowRelayFallback: false as const, endpoint: okEndpoint };
				}
				return { ok: true as const, allowRelayFallback: false as const, endpoint: handshakeTlsEndpoint };
			},
			consumeRelayTicket: () => { },
		} as unknown as ConnectionResolver;
		const service = new UniverseAgentConnectionService({
			createTransport: () => lostSessionTransport(),
			createPinnedTransport: () => input.pinned,
			connectionResolver: resolver,
			connectionProfileStore: store,
			clientIdentityStore: signingIdentityStore,
			pairingOrchestrator: input.pairingOrchestrator,
			reconnectJitterRatio: 0,
			setTimeoutFn: input.clock.setTimeoutFn,
			clearTimeoutFn: input.clock.clearTimeoutFn,
		});
		return { service, store };
	}

	test('user reconnect TLS pin UNAVAILABLE is pin_mismatch and does not reschedule or clear trust', async () => {
		const clock = createReconnectClock();
		const store = new PairingTestProfileStore(handshakeProfile);
		class PinTransport extends MockUniverseAgentGrpcTransport {
			override async getAuthNonce(): Promise<UniverseAgentAuthNonceResult> {
				throw new UniverseAgentTransportError(GrpcStatusCode.UNAVAILABLE, tlsPinUnavailable);
			}
		}
		const { service } = handshakeReconnectService({ clock, pinned: new PinTransport(), store });

		await service.connectProfile('p1');
		await assert.rejects(() => service.listSessions({}));
		const result = await service.connectProfile('p1', { reconnect: true });
		assert.strictEqual(result.ok, false);
		if (!result.ok) {
			assert.strictEqual(result.code, 'pin_mismatch');
		}
		assert.deepStrictEqual(clock.delays, [1000]);
		assert.strictEqual(clock.pending.size, 0);
		assert.strictEqual(store.get('p1')?.trust, handshakeTrust);
		assert.strictEqual(store.get('p1')?.state, 'active');
		service.dispose();
	});

	test('user reconnect Connect UNAUTHENTICATED is grant_revoked and the next connect uses pairing_required', async () => {
		const clock = createReconnectClock();
		const store = new PairingTestProfileStore(handshakeProfile);
		let startPairingCalls = 0;
		const orchestrator = {
			startPairing: async () => {
				startPairingCalls++;
				return {
					ok: true as const,
					awaitingUserConfirm: true,
					snapshot: {
						phase: 'awaiting_sas_confirm' as const,
						profileId: 'p1',
						sasCode: 'ABCD-EFGH',
						engineIdentityId: 'engine-id',
						sessionTokenInstalled: false,
					},
				};
			},
			confirmSas: async () => ({ ok: false as const, code: 'unused', reason: 'unused' }),
			confirmRecoverTrust: async () => ({ ok: false as const, code: 'unused', reason: 'unused' }),
			getSnapshot: () => undefined,
			abandonRecoverTrust: () => { },
		} as unknown as PairingOrchestrator;
		let plainUsed = false;
		const resolver = {
			resolve: async (_profileId: string, options?: { readonly forPairing?: boolean }) => {
				const current = store.get('p1');
				if (!current?.trust) {
					if (options?.forPairing) {
						return { ok: true as const, allowRelayFallback: false as const, endpoint: handshakeTlsEndpoint };
					}
					return {
						ok: false as const,
						code: 'pairing_required' as const,
						reason: 'direct address dial requires pairing orchestrator when trust is missing',
						allowRelayFallback: false as const,
					};
				}
				if (!plainUsed) {
					plainUsed = true;
					return { ok: true as const, allowRelayFallback: false as const, endpoint: okEndpoint };
				}
				return { ok: true as const, allowRelayFallback: false as const, endpoint: handshakeTlsEndpoint };
			},
			consumeRelayTicket: () => { },
		} as unknown as ConnectionResolver;
		class GrantTransport extends MockUniverseAgentGrpcTransport {
			override async getAuthNonce(): Promise<UniverseAgentAuthNonceResult> {
				return {
					authNonce: new Uint8Array(32).fill(1),
					engineIdentityId: 'engine-id',
					engineCertFingerprint: handshakeTrust.leafSha256Hex,
				};
			}
			override async connectWithDeviceAuth(): Promise<UniverseAgentConnectResult> {
				throw new UniverseAgentTransportError(GrpcStatusCode.UNAUTHENTICATED, '16 UNAUTHENTICATED: grant revoked');
			}
		}
		const { service } = handshakeReconnectService({
			clock,
			pinned: new GrantTransport(),
			store,
			resolver,
			pairingOrchestrator: orchestrator,
		});

		await service.connectProfile('p1');
		await assert.rejects(() => service.listSessions({}));
		const failed = await service.connectProfile('p1', { reconnect: true });
		assert.strictEqual(failed.ok, false);
		if (!failed.ok) {
			assert.strictEqual(failed.code, 'grant_revoked');
		}
		assert.strictEqual(startPairingCalls, 0);
		assert.deepStrictEqual(clock.delays, [1000]);
		assert.strictEqual(clock.pending.size, 0);
		assert.strictEqual(store.get('p1')?.trust, null);
		assert.strictEqual(store.get('p1')?.state, 'pairingPending');

		const repaired = await service.connectProfile('p1');
		assert.strictEqual(repaired.ok, true);
		if (repaired.ok) {
			assert.strictEqual(repaired.pairingPending, true);
		}
		assert.strictEqual(startPairingCalls, 1);
		service.dispose();
	});

	test('user reconnect deadline and plain handshake errors do not reschedule and keep trust', async () => {
		for (const failure of [
			new UniverseAgentTransportError(GrpcStatusCode.DEADLINE_EXCEEDED, '4 DEADLINE_EXCEEDED: Deadline exceeded'),
			new Error('GetAuthNonce down'),
		]) {
			const clock = createReconnectClock();
			const store = new PairingTestProfileStore(handshakeProfile);
			class NonUnavailableTransport extends MockUniverseAgentGrpcTransport {
				override async getAuthNonce(): Promise<UniverseAgentAuthNonceResult> {
					throw failure;
				}
			}
			const { service } = handshakeReconnectService({ clock, pinned: new NonUnavailableTransport(), store });
			await service.connectProfile('p1');
			await assert.rejects(() => service.listSessions({}));
			const result = await service.connectProfile('p1', { reconnect: true });
			assert.strictEqual(result.ok, false);
			if (!result.ok) {
				assert.strictEqual(result.code, 'engine_not_serving');
				assert.ok(result.reason.startsWith(DEVICE_AUTH_RPC_NOT_UNAVAILABLE_PREFIX));
			}
			assert.deepStrictEqual(clock.delays, [1000]);
			assert.strictEqual(clock.pending.size, 0);
			assert.strictEqual(store.get('p1')?.trust, handshakeTrust);
			service.dispose();
		}
	});

	test('resolver engine_not_serving during reconnect still rearms', async () => {
		const clock = createReconnectClock();
		let resolves = 0;
		const service = new UniverseAgentConnectionService({
			createTransport: () => lostSessionTransport(),
			connectionResolver: {
				resolve: async () => {
					resolves++;
					if (resolves === 1) {
						return { ok: true as const, allowRelayFallback: false, endpoint: okEndpoint };
					}
					return {
						ok: false as const,
						code: 'engine_not_serving' as const,
						reason: 'directory says not serving',
						allowRelayFallback: false,
					};
				},
				consumeRelayTicket: () => { },
			} as unknown as ConnectionResolver,
			connectionProfileStore: new PairingTestProfileStore(handshakeProfile),
			clientIdentityStore: signingIdentityStore,
			reconnectJitterRatio: 0,
			setTimeoutFn: clock.setTimeoutFn,
			clearTimeoutFn: clock.clearTimeoutFn,
		});

		await service.connectProfile('p1');
		await assert.rejects(() => service.listSessions({}));
		assert.deepStrictEqual(clock.delays, [1000]);
		clock.fireAll();
		for (let i = 0; i < 8; i++) {
			await timeout(0);
		}
		const phase = service.getConnectionPhase();
		assert.strictEqual(phase.kind, 'failed');
		if (phase.kind === 'failed') {
			assert.strictEqual(phase.code, 'engine_not_serving');
			assert.strictEqual(phase.reason, 'directory says not serving');
		}
		assert.deepStrictEqual(clock.delays, [1000, 2000]);
		assert.strictEqual(clock.pending.size, 1);
		service.dispose();
	});

	test('ipv6 resolvedIp is dialed with brackets', async () => {
		const addresses: string[] = [];
		const service = new UniverseAgentConnectionService({
			createTransport: address => {
				addresses.push(address);
				return new MockUniverseAgentGrpcTransport();
			},
			connectionResolver: {
				resolve: async () => ({
					ok: true as const,
					allowRelayFallback: false,
					endpoint: { ...okEndpoint, resolvedIp: '2001:db8::10', port: 7443 },
				}),
				consumeRelayTicket: () => { },
			} as unknown as ConnectionResolver,
			clientIdentityStore: identityStore,
		});
		const result = await service.connectProfile('p1');
		assert.strictEqual(result.ok, true);
		assert.deepStrictEqual(addresses, ['[2001:db8::10]:7443']);
		service.dispose();
	});

	test('resolveHost rejection does not throw out of connectProfile', async () => {
		const store = new PairingTestProfileStore(handshakeProfile);
		const resolver = createConnectionResolver({
			connectionProfileStore: store,
			hubSessionStore: new InMemoryHubSessionStore(),
			clientIdentityStore: identityStore,
			resolveHost: async () => {
				throw new Error('dns down');
			},
		});
		const service = new UniverseAgentConnectionService({
			createTransport: () => new MockUniverseAgentGrpcTransport(),
			connectionResolver: resolver,
			connectionProfileStore: store,
			clientIdentityStore: identityStore,
		});
		const result = await service.connectProfile('p1');
		assert.strictEqual(result.ok, false);
		if (!result.ok) {
			assert.strictEqual(result.code, 'transport_failed');
		}
		assert.strictEqual(service.getConnectionPhase().kind, 'failed');
		service.dispose();
	});

	test('empty createSigner before handshake stays trust_missing', async () => {
		const clock = createReconnectClock();
		const service = new UniverseAgentConnectionService({
			createTransport: () => new MockUniverseAgentGrpcTransport(),
			createPinnedTransport: () => new MockUniverseAgentGrpcTransport(),
			connectionResolver: {
				resolve: async () => ({ ok: true as const, allowRelayFallback: false, endpoint: handshakeTlsEndpoint }),
				consumeRelayTicket: () => { },
			} as unknown as ConnectionResolver,
			connectionProfileStore: new PairingTestProfileStore(handshakeProfile),
			clientIdentityStore: identityStore,
			reconnectJitterRatio: 0,
			setTimeoutFn: clock.setTimeoutFn,
			clearTimeoutFn: clock.clearTimeoutFn,
		});
		const result = await service.connectProfile('p1');
		assert.strictEqual(result.ok, false);
		if (!result.ok) {
			assert.strictEqual(result.code, 'trust_missing');
		}
		assert.strictEqual(clock.delays.length, 0);
		assert.strictEqual(clock.pending.size, 0);
		service.dispose();
	});

	function handshakeFailureService(input: {
		readonly clock: ReturnType<typeof createReconnectClock>;
		readonly engineIdentityId: string;
		readonly engineCertFingerprint: string;
		readonly sign?: () => Uint8Array;
	}): UniverseAgentConnectionService {
		let resolves = 0;
		class HandshakeFailureTransport extends MockUniverseAgentGrpcTransport {
			override async getAuthNonce(): Promise<UniverseAgentAuthNonceResult> {
				return {
					authNonce: new Uint8Array(32),
					engineIdentityId: input.engineIdentityId,
					engineCertFingerprint: input.engineCertFingerprint,
				};
			}
		}
		return new UniverseAgentConnectionService({
			createTransport: () => new MockUniverseAgentGrpcTransport({
				listSessions: async () => {
					throw new UniverseAgentTransportError(GrpcStatusCode.UNAVAILABLE, 'down');
				},
			}),
			createPinnedTransport: () => new HandshakeFailureTransport(),
			connectionResolver: {
				resolve: async () => {
					resolves++;
					if (resolves === 1) {
						return { ok: true as const, allowRelayFallback: false, endpoint: okEndpoint };
					}
					return { ok: true as const, allowRelayFallback: false, endpoint: handshakeTlsEndpoint };
				},
				consumeRelayTicket: () => { },
			} as unknown as ConnectionResolver,
			connectionProfileStore: new PairingTestProfileStore(handshakeProfile),
			clientIdentityStore: {
				...signingIdentityStore,
				createSigner: async () => input.sign ?? (() => new Uint8Array(64)),
			},
			reconnectJitterRatio: 0,
			setTimeoutFn: input.clock.setTimeoutFn,
			clearTimeoutFn: input.clock.clearTimeoutFn,
		});
	}

	const handshakeFailureCases: ReadonlyArray<{
		readonly code: 'identity_mismatch' | 'fingerprint_malformed' | 'signer_unavailable';
		readonly engineIdentityId: string;
		readonly engineCertFingerprint: string;
		readonly sign?: () => Uint8Array;
	}> = [
		{
			code: 'identity_mismatch',
			engineIdentityId: 'other-engine',
			engineCertFingerprint: handshakeTrust.leafSha256Hex,
		},
		{
			code: 'fingerprint_malformed',
			engineIdentityId: 'engine-id',
			engineCertFingerprint: 'not-a-fingerprint',
		},
		{
			code: 'signer_unavailable',
			engineIdentityId: 'engine-id',
			engineCertFingerprint: handshakeTrust.leafSha256Hex,
			sign: () => {
				throw new Error('sign failed');
			},
		},
	];

	test('handshake failure codes stay distinct and do not arm a D408 timer', async () => {
		for (const entry of handshakeFailureCases) {
			const clock = createReconnectClock();
			const service = handshakeFailureService({ clock, ...entry });
			await service.connectProfile('p1');
			await assert.rejects(() => service.listSessions({}));
			assert.deepStrictEqual(clock.delays, [1000], entry.code);

			const result = await service.connectProfile('p1', { reconnect: true });
			assert.strictEqual(result.ok, false, entry.code);
			if (!result.ok) {
				assert.strictEqual(result.code, entry.code, entry.code);
			}
			const phase = service.getConnectionPhase();
			assert.strictEqual(phase.kind, 'failed', entry.code);
			if (phase.kind === 'failed') {
				assert.strictEqual(phase.code, entry.code, entry.code);
			}
			assert.deepStrictEqual(clock.delays, [1000], entry.code);
			assert.strictEqual(clock.pending.size, 0, entry.code);
			service.dispose();
		}
	});

	test('handshake identity, malformed fingerprint, and signer are not reconnect halt codes', async () => {
		for (const entry of handshakeFailureCases) {
			const clock = createReconnectClock();
			const service = handshakeFailureService({ clock, ...entry });
			await service.connectProfile('p1');
			await assert.rejects(() => service.listSessions({}));
			assert.deepStrictEqual(clock.delays, [1000], entry.code);

			clock.fireAll();
			await flushReconnect();
			const phase = service.getConnectionPhase();
			assert.strictEqual(phase.kind, 'failed', entry.code);
			if (phase.kind === 'failed') {
				assert.strictEqual(phase.code, entry.code, entry.code);
			}
			assert.deepStrictEqual(clock.delays, [1000, 2000], entry.code);
			assert.strictEqual(clock.pending.size, 1, entry.code);
			service.dispose();
		}
	});

	test('user reconnect pairing_required does not reschedule (D413)', async () => {
		const clock = createReconnectClock();
		let resolves = 0;
		const resolver = {
			resolve: async () => {
				resolves++;
				if (resolves === 1) {
					return { ok: true as const, allowRelayFallback: false, endpoint: okEndpoint };
				}
				return { ok: false as const, code: 'pairing_required' as const, reason: 'pairing required', allowRelayFallback: true };
			},
			consumeRelayTicket: () => { },
		};
		const service = new UniverseAgentConnectionService({
			createTransport: () => new MockUniverseAgentGrpcTransport({
				listSessions: async () => {
					throw new UniverseAgentTransportError(GrpcStatusCode.UNAVAILABLE, 'down');
				},
			}),
			connectionResolver: resolver as unknown as ConnectionResolver,
			clientIdentityStore: identityStore,
			reconnectJitterRatio: 0,
			setTimeoutFn: clock.setTimeoutFn,
			clearTimeoutFn: clock.clearTimeoutFn,
		});

		await service.connectProfile('p1');
		await assert.rejects(() => service.listSessions({}));
		assert.deepStrictEqual(clock.delays, [1000]);

		const result = await service.connectProfile('p1', { reconnect: true });
		assert.strictEqual(result.ok, false);
		if (!result.ok) {
			assert.strictEqual(result.code, 'pairing_required');
		}
		assert.deepStrictEqual(clock.delays, [1000]);
		assert.strictEqual(clock.pending.size, 0);
		service.dispose();
	});

	test('user reconnect connect() non-TransportError throw reschedules (D416)', async () => {
		const clock = createReconnectClock();
		let connects = 0;
		const service = new UniverseAgentConnectionService({
			createTransport: () => new MockUniverseAgentGrpcTransport({
				connect: async () => {
					connects++;
					if (connects === 1) {
						return { sessionToken: 'token-1', workDir: '/tmp/work', methods: [], events: [] };
					}
					throw new Error('plain connect blowup');
				},
				listSessions: async () => {
					throw new UniverseAgentTransportError(GrpcStatusCode.UNAVAILABLE, 'down');
				},
			}),
			connectionResolver: createOkResolver() as unknown as ConnectionResolver,
			clientIdentityStore: identityStore,
			reconnectJitterRatio: 0,
			setTimeoutFn: clock.setTimeoutFn,
			clearTimeoutFn: clock.clearTimeoutFn,
		});

		await service.connectProfile('p1');
		await assert.rejects(() => service.listSessions({}));
		assert.deepStrictEqual(clock.delays, [1000]);
		assert.strictEqual(clock.pending.size, 1);

		await assert.rejects(
			() => service.connectProfile('p1', { reconnect: true }),
			(error: unknown) => error instanceof Error && error.message === 'plain connect blowup',
		);
		assert.deepStrictEqual(clock.delays, [1000, 2000]);
		assert.strictEqual(clock.pending.size, 1);
		service.dispose();
	});

	test('user Connect after failed transport connect() non-TransportError throw reschedules (D416)', async () => {
		const clock = createReconnectClock();
		let connects = 0;
		const service = new UniverseAgentConnectionService({
			createTransport: () => new MockUniverseAgentGrpcTransport({
				connect: async () => {
					connects++;
					if (connects === 1) {
						return { sessionToken: 'token-1', workDir: '/tmp/work', methods: [], events: [] };
					}
					throw new Error('plain connect blowup');
				},
				listSessions: async () => {
					throw new UniverseAgentTransportError(GrpcStatusCode.UNAVAILABLE, 'down');
				},
			}),
			connectionResolver: createOkResolver() as unknown as ConnectionResolver,
			clientIdentityStore: identityStore,
			reconnectJitterRatio: 0,
			setTimeoutFn: clock.setTimeoutFn,
			clearTimeoutFn: clock.clearTimeoutFn,
		});

		await service.connectProfile('p1');
		await assert.rejects(() => service.listSessions({}));
		assert.deepStrictEqual(clock.delays, [1000]);

		await assert.rejects(
			() => service.connectProfile('p1'),
			(error: unknown) => error instanceof Error && error.message === 'plain connect blowup',
		);
		assert.deepStrictEqual(clock.delays, [1000, 2000]);
		assert.strictEqual(clock.pending.size, 1);
		service.dispose();
	});

	test('initial connect() non-TransportError throw does not schedule (D416)', async () => {
		const clock = createReconnectClock();
		const service = new UniverseAgentConnectionService({
			createTransport: () => new MockUniverseAgentGrpcTransport({
				connect: async () => {
					throw new Error('plain connect blowup');
				},
			}),
			connectionResolver: createOkResolver() as unknown as ConnectionResolver,
			clientIdentityStore: identityStore,
			reconnectJitterRatio: 0,
			setTimeoutFn: clock.setTimeoutFn,
			clearTimeoutFn: clock.clearTimeoutFn,
		});

		await assert.rejects(
			() => service.connectProfile('p1'),
			(error: unknown) => error instanceof Error && error.message === 'plain connect blowup',
		);
		assert.strictEqual(clock.delays.length, 0);
		assert.strictEqual(clock.pending.size, 0);
		service.dispose();
	});

	test('user reconnect connect() throw while pairingPending does not schedule (D416)', async () => {
		const clock = createReconnectClock();
		let dials = 0;
		const service = new UniverseAgentConnectionService({
			createTransport: () => new MockUniverseAgentGrpcTransport({
				connect: async () => {
					throw new Error('plain connect blowup');
				},
			}),
			connectionResolver: pairingRequiredResolver(() => {
				dials++;
				if (dials === 1) {
					return { ok: false as const, code: 'pairing_required' as const, reason: 'pairing required', allowRelayFallback: false as const };
				}
				return { ok: true as const, allowRelayFallback: false as const, endpoint: okEndpoint };
			}) as unknown as ConnectionResolver,
			connectionProfileStore: new PairingTestProfileStore(directPairingPendingProfile('p1')),
			pairingOrchestrator: awaitingSasOrchestrator(),
			clientIdentityStore: identityStore,
			reconnectJitterRatio: 0,
			setTimeoutFn: clock.setTimeoutFn,
			clearTimeoutFn: clock.clearTimeoutFn,
		});

		await service.connectProfile('p1');
		assert.strictEqual(service.getConnectionSnapshot().pairingPending, true);
		await assert.rejects(
			() => service.connectProfile('p1', { reconnect: true }),
			(error: unknown) => error instanceof Error && error.message === 'plain connect blowup',
		);
		assert.strictEqual(clock.delays.length, 0);
		assert.strictEqual(clock.pending.size, 0);
		service.dispose();
	});

	test('user reconnect handshake catch non-TransportError throw reschedules (D416)', async () => {
		const clock = createReconnectClock();
		let resolves = 0;
		const resolver = {
			resolve: async () => {
				resolves++;
				if (resolves === 1) {
					return { ok: true as const, allowRelayFallback: false, endpoint: okEndpoint };
				}
				return { ok: true as const, allowRelayFallback: false, endpoint: handshakeTlsEndpoint };
			},
			consumeRelayTicket: () => { },
		};
		class HandshakeThenProbeThrow extends MockUniverseAgentGrpcTransport {
			override async getAuthNonce(): Promise<UniverseAgentAuthNonceResult> {
				return {
					authNonce: new Uint8Array(32),
					engineIdentityId: 'engine-id',
					engineCertFingerprint: handshakeTrust.leafSha256Hex,
				};
			}
			override async connectWithDeviceAuth(): Promise<UniverseAgentConnectResult> {
				return {
					sessionToken: 'token-2',
					workDir: '/tmp/work',
					methods: ['ToolService.ListSkills'],
					events: [],
				};
			}
			override async probeRpc(): Promise<number> {
				throw new Error('probe boom');
			}
		}
		const service = new UniverseAgentConnectionService({
			createTransport: () => new MockUniverseAgentGrpcTransport({
				listSessions: async () => {
					throw new UniverseAgentTransportError(GrpcStatusCode.UNAVAILABLE, 'down');
				},
			}),
			createPinnedTransport: () => new HandshakeThenProbeThrow(),
			connectionResolver: resolver as unknown as ConnectionResolver,
			connectionProfileStore: new PairingTestProfileStore(handshakeProfile),
			clientIdentityStore: signingIdentityStore,
			reconnectJitterRatio: 0,
			setTimeoutFn: clock.setTimeoutFn,
			clearTimeoutFn: clock.clearTimeoutFn,
		});

		await service.connectProfile('p1');
		await assert.rejects(() => service.listSessions({}));
		assert.deepStrictEqual(clock.delays, [1000]);

		const result = await service.connectProfile('p1', { reconnect: true });
		assert.strictEqual(result.ok, false);
		if (!result.ok) {
			assert.strictEqual(result.code, 'transport_failed');
			assert.strictEqual(result.reason, 'probe boom');
		}
		assert.deepStrictEqual(clock.delays, [1000, 2000]);
		assert.strictEqual(clock.pending.size, 1);
		service.dispose();
	});

	test('user reconnect resolve() throw reschedules (D417)', async () => {
		const clock = createReconnectClock();
		let resolves = 0;
		const resolver = {
			resolve: async () => {
				resolves++;
				if (resolves === 1) {
					return { ok: true as const, allowRelayFallback: false, endpoint: okEndpoint };
				}
				throw new Error('resolve blowup');
			},
			consumeRelayTicket: () => { },
		};
		const service = new UniverseAgentConnectionService({
			createTransport: () => new MockUniverseAgentGrpcTransport({
				listSessions: async () => {
					throw new UniverseAgentTransportError(GrpcStatusCode.UNAVAILABLE, 'down');
				},
			}),
			connectionResolver: resolver as unknown as ConnectionResolver,
			clientIdentityStore: identityStore,
			reconnectJitterRatio: 0,
			setTimeoutFn: clock.setTimeoutFn,
			clearTimeoutFn: clock.clearTimeoutFn,
		});

		await service.connectProfile('p1');
		await assert.rejects(() => service.listSessions({}));
		assert.deepStrictEqual(clock.delays, [1000]);
		assert.strictEqual(clock.pending.size, 1);

		await assert.rejects(
			() => service.connectProfile('p1', { reconnect: true }),
			(error: unknown) => error instanceof Error && error.message === 'resolve blowup',
		);
		assert.deepStrictEqual(clock.delays, [1000, 2000]);
		assert.strictEqual(clock.pending.size, 1);
		service.dispose();
	});

	test('user Connect after failed transport getOrCreateIdentity throw reschedules (D417)', async () => {
		const clock = createReconnectClock();
		let identities = 0;
		const throwingIdentity: IClientIdentityStore = {
			...identityStore,
			getOrCreateIdentity: async () => {
				identities++;
				if (identities === 1) {
					return {
						kind: 'ready',
						identity: {
							clientIdentityId: 'a'.repeat(64),
							clientPublicKey: new Uint8Array(32),
							privateKeyPkcs8: new Uint8Array(32),
						},
					};
				}
				throw new Error('identity blowup');
			},
		};
		const service = new UniverseAgentConnectionService({
			createTransport: () => new MockUniverseAgentGrpcTransport({
				listSessions: async () => {
					throw new UniverseAgentTransportError(GrpcStatusCode.UNAVAILABLE, 'down');
				},
			}),
			connectionResolver: createOkResolver() as unknown as ConnectionResolver,
			clientIdentityStore: throwingIdentity,
			reconnectJitterRatio: 0,
			setTimeoutFn: clock.setTimeoutFn,
			clearTimeoutFn: clock.clearTimeoutFn,
		});

		await service.connectProfile('p1');
		await assert.rejects(() => service.listSessions({}));
		assert.deepStrictEqual(clock.delays, [1000]);

		await assert.rejects(
			() => service.connectProfile('p1'),
			(error: unknown) => error instanceof Error && error.message === 'identity blowup',
		);
		assert.deepStrictEqual(clock.delays, [1000, 2000]);
		assert.strictEqual(clock.pending.size, 1);
		service.dispose();
	});

	test('user reconnect createSigner throw reschedules (D417)', async () => {
		const clock = createReconnectClock();
		let resolves = 0;
		const resolver = {
			resolve: async () => {
				resolves++;
				if (resolves === 1) {
					return { ok: true as const, allowRelayFallback: false, endpoint: okEndpoint };
				}
				return { ok: true as const, allowRelayFallback: false, endpoint: handshakeTlsEndpoint };
			},
			consumeRelayTicket: () => { },
		};
		const throwingSigner: IClientIdentityStore = {
			...signingIdentityStore,
			createSigner: async () => {
				throw new Error('signer blowup');
			},
		};
		const service = new UniverseAgentConnectionService({
			createTransport: () => new MockUniverseAgentGrpcTransport({
				listSessions: async () => {
					throw new UniverseAgentTransportError(GrpcStatusCode.UNAVAILABLE, 'down');
				},
			}),
			createPinnedTransport: () => new MockUniverseAgentGrpcTransport(),
			connectionResolver: resolver as unknown as ConnectionResolver,
			connectionProfileStore: new PairingTestProfileStore(handshakeProfile),
			clientIdentityStore: throwingSigner,
			reconnectJitterRatio: 0,
			setTimeoutFn: clock.setTimeoutFn,
			clearTimeoutFn: clock.clearTimeoutFn,
		});

		await service.connectProfile('p1');
		await assert.rejects(() => service.listSessions({}));
		assert.deepStrictEqual(clock.delays, [1000]);

		await assert.rejects(
			() => service.connectProfile('p1', { reconnect: true }),
			(error: unknown) => error instanceof Error && error.message === 'signer blowup',
		);
		assert.deepStrictEqual(clock.delays, [1000, 2000]);
		assert.strictEqual(clock.pending.size, 1);
		service.dispose();
	});

	test('initial resolve() throw does not schedule (D417)', async () => {
		const clock = createReconnectClock();
		const resolver = {
			resolve: async () => {
				throw new Error('resolve blowup');
			},
			consumeRelayTicket: () => { },
		};
		const service = new UniverseAgentConnectionService({
			createTransport: () => new MockUniverseAgentGrpcTransport(),
			connectionResolver: resolver as unknown as ConnectionResolver,
			clientIdentityStore: identityStore,
			reconnectJitterRatio: 0,
			setTimeoutFn: clock.setTimeoutFn,
			clearTimeoutFn: clock.clearTimeoutFn,
		});

		await assert.rejects(
			() => service.connectProfile('p1'),
			(error: unknown) => error instanceof Error && error.message === 'resolve blowup',
		);
		assert.strictEqual(clock.delays.length, 0);
		assert.strictEqual(clock.pending.size, 0);
		service.dispose();
	});

	test('user reconnect resolve() throw while pairingPending does not schedule (D417)', async () => {
		const clock = createReconnectClock();
		let dials = 0;
		const service = new UniverseAgentConnectionService({
			createTransport: () => new MockUniverseAgentGrpcTransport(),
			connectionResolver: pairingRequiredResolver(() => {
				dials++;
				if (dials === 1) {
					return { ok: false as const, code: 'pairing_required' as const, reason: 'pairing required', allowRelayFallback: false as const };
				}
				throw new Error('resolve blowup');
			}) as unknown as ConnectionResolver,
			connectionProfileStore: new PairingTestProfileStore(directPairingPendingProfile('p1')),
			pairingOrchestrator: awaitingSasOrchestrator(),
			clientIdentityStore: identityStore,
			reconnectJitterRatio: 0,
			setTimeoutFn: clock.setTimeoutFn,
			clearTimeoutFn: clock.clearTimeoutFn,
		});

		await service.connectProfile('p1');
		assert.strictEqual(service.getConnectionSnapshot().pairingPending, true);
		await assert.rejects(
			() => service.connectProfile('p1', { reconnect: true }),
			(error: unknown) => error instanceof Error && error.message === 'resolve blowup',
		);
		assert.strictEqual(clock.delays.length, 0);
		assert.strictEqual(clock.pending.size, 0);
		service.dispose();
	});

	test('profile switch changes linkId and engineIdentityId and clears the previous identity first', async () => {
		const clock = createReconnectClock();
		const leafA = new Uint8Array([9]);
		const leafB = new Uint8Array([10]);
		const trustA = createEngineTrustRecord({ leafDer: leafA, engineIdentityId: 'engine-a', establishedAt: 1 });
		const trustB = createEngineTrustRecord({ leafDer: leafB, engineIdentityId: 'engine-b', establishedAt: 1 });
		const profileA: ConnectionProfile = {
			profileId: 'profile-a',
			displayName: 'Engine A',
			target: { kind: 'directAddress', host: '203.0.113.10', port: 7443 },
			trust: trustA,
			state: 'active',
			allowPrivateNetwork: true,
		};
		const profileB: ConnectionProfile = {
			...profileA,
			profileId: 'profile-b',
			displayName: 'Engine B',
			trust: trustB,
		};
		const endpointFor = (trust: typeof trustA, attemptId: string) => ({
			attemptId,
			authority: '203.0.113.10:7443',
			port: 7443,
			resolvedIp: '203.0.113.10',
			servername: 'engine.example',
			relayTicketId: null,
			tls: {
				trustAnchorLeafDer: trust === trustA ? leafA : leafB,
				expectedLeafSha256Hex: trust.leafSha256Hex,
				hostnameVerification: 'replaced-by-pin' as const,
			},
			expiresAtMs: 1,
			path: 'direct' as const,
		});
		class MapProfileStore implements IConnectionProfileStore {
			private readonly profiles = new Map<string, ConnectionProfile>([
				[profileA.profileId, profileA],
				[profileB.profileId, profileB],
			]);
			list(): ConnectionProfile[] { return [...this.profiles.values()]; }
			get(profileId: string): ConnectionProfile | undefined { return this.profiles.get(profileId); }
			put(profile: ConnectionProfile): void { this.profiles.set(profile.profileId, profile); }
			remove(profileId: string): void { this.profiles.delete(profileId); }
			createDraft(input: { readonly displayName: string; readonly target: ConnectionProfile['target']; readonly allowPrivateNetwork?: boolean }): ConnectionProfile {
				return {
					profileId: 'draft',
					displayName: input.displayName,
					target: input.target,
					trust: null,
					state: 'pairingPending',
					allowPrivateNetwork: input.allowPrivateNetwork ?? false,
				};
			}
		}
		class IdentityPinnedTransport extends MockUniverseAgentGrpcTransport {
			listSessionsUnavailable = false;
			constructor(private readonly pinnedIdentity: string, private readonly fingerprint: string) {
				super();
			}
			override async getAuthNonce(): Promise<UniverseAgentAuthNonceResult> {
				return {
					authNonce: new Uint8Array(32).fill(7),
					engineIdentityId: this.pinnedIdentity,
					engineCertFingerprint: this.fingerprint,
				};
			}
			override async connectWithDeviceAuth(): Promise<UniverseAgentConnectResult> {
				return {
					sessionToken: `token-${this.pinnedIdentity}`,
					workDir: '/tmp/work',
					methods: ['ToolService.ListSkills'],
					events: [],
				};
			}
			override async listSessions(): Promise<UniverseAgentListSessionsResult> {
				if (this.listSessionsUnavailable) {
					throw new UniverseAgentTransportError(GrpcStatusCode.UNAVAILABLE, 'down');
				}
				return { sessions: [], totalCount: 0 };
			}
		}
		const transportA = new IdentityPinnedTransport('engine-a', trustA.leafSha256Hex);
		const transportB = new IdentityPinnedTransport('engine-b', trustB.leafSha256Hex);
		const queued = [transportA, transportB];
		const service = new UniverseAgentConnectionService({
			createPinnedTransport: () => {
				const next = queued.shift();
				if (!next) {
					throw new Error('no pinned transport left');
				}
				return next;
			},
			connectionResolver: {
				resolve: async (profileId: string) => ({
					ok: true as const,
					allowRelayFallback: false as const,
					endpoint: endpointFor(profileId === 'profile-b' ? trustB : trustA, profileId),
				}),
				consumeRelayTicket: () => { },
			} as unknown as ConnectionResolver,
			connectionProfileStore: new MapProfileStore(),
			clientIdentityStore: signingIdentityStore,
			reconnectJitterRatio: 0,
			setTimeoutFn: clock.setTimeoutFn,
			clearTimeoutFn: clock.clearTimeoutFn,
		});
		const snapshots: { engineIdentityId?: string; linkId?: number; phase?: { kind: string; reason?: string } }[] = [];
		const listener = service.onDidChangeConnection(snapshot => snapshots.push(snapshot));
		try {
			const connectedA = await service.connectProfile('profile-a');
			assert.strictEqual(connectedA.ok, true);
			const publishedA = service.getConnectionSnapshot();
			assert.strictEqual(publishedA.engineIdentityId, 'engine-a');
			assert.strictEqual(typeof publishedA.linkId, 'number');
			assert.ok((publishedA.linkId ?? 0) > 0);
			assert.strictEqual(Object.hasOwn(publishedA, 'sessionToken'), false);

			transportA.listSessionsUnavailable = true;
			await assert.rejects(() => service.listSessions({}));
			const lost = service.getConnectionSnapshot();
			assert.strictEqual(lost.phase?.kind, 'connecting');
			assert.strictEqual(lost.phase && 'reason' in lost.phase ? lost.phase.reason : undefined, 'transport_lost');
			assert.strictEqual(lost.linkId, publishedA.linkId);
			assert.strictEqual(lost.engineIdentityId, 'engine-a');

			const beforeSwitch = snapshots.length;
			const connectedB = await service.connectProfile('profile-b');
			assert.strictEqual(connectedB.ok, true);
			const during = snapshots.slice(beforeSwitch);
			assert.ok(during.some(snapshot => snapshot.engineIdentityId === undefined && snapshot.linkId === undefined));
			assert.ok(during.every(snapshot => snapshot.engineIdentityId !== 'engine-a'));
			const publishedB = service.getConnectionSnapshot();
			assert.strictEqual(publishedB.engineIdentityId, 'engine-b');
			assert.notStrictEqual(publishedB.linkId, publishedA.linkId);
			assert.ok((publishedB.linkId ?? 0) > (publishedA.linkId ?? 0));
			assert.strictEqual(Object.hasOwn(publishedB, 'sessionToken'), false);

			await service.disconnect();
			const closed = service.getConnectionSnapshot();
			assert.strictEqual(Object.hasOwn(closed, 'engineIdentityId'), false);
			assert.strictEqual(Object.hasOwn(closed, 'linkId'), false);
			assert.strictEqual(Object.hasOwn(closed, 'sessionToken'), false);
		} finally {
			listener.dispose();
			service.dispose();
		}
	});
});

suite('UniverseAgentConnectionService session token link (ELR-1 S1/S2/S4)', () => {

	ensureNoDisposablesAreLeakedInTestSuite();

	const leafDer = new Uint8Array([1, 2, 3, 4]);
	const trust = createEngineTrustRecord({
		leafDer,
		engineIdentityId: 'engine-id',
		establishedAt: 1,
	});
	const profile: ConnectionProfile = {
		profileId: PAIRING_PROFILE_ID,
		displayName: 'Direct',
		target: { kind: 'directAddress', host: '203.0.113.10', port: 7443 },
		trust,
		state: 'active',
		allowPrivateNetwork: true,
	};
	const signingIdentity: IClientIdentityStore = {
		getState: async () => ({
			kind: 'ready',
			identity: {
				clientIdentityId: 'a'.repeat(64),
				clientPublicKey: new Uint8Array(32),
				privateKeyPkcs8: new Uint8Array(32),
			},
		}),
		getOrCreateIdentity: async () => ({
			kind: 'ready',
			identity: {
				clientIdentityId: 'a'.repeat(64),
				clientPublicKey: new Uint8Array(32),
				privateKeyPkcs8: new Uint8Array(32),
			},
		}),
		createSigner: async () => () => new Uint8Array(64),
	};

	function endpoint(relayTicketId: string | null) {
		return {
			attemptId: 'a1',
			authority: '203.0.113.10:7443',
			port: 7443,
			resolvedIp: '203.0.113.10',
			servername: 'engine.example',
			relayTicketId,
			tls: {
				trustAnchorLeafDer: leafDer,
				expectedLeafSha256Hex: trust.leafSha256Hex,
				hostnameVerification: 'replaced-by-pin' as const,
			},
			expiresAtMs: 1,
			path: 'direct' as const,
		};
	}

	function nonce() {
		return {
			authNonce: new Uint8Array(32),
			engineIdentityId: 'engine-id',
			engineCertFingerprint: trust.leafSha256Hex,
		};
	}

	class HandshakeTransport extends MockUniverseAgentGrpcTransport {

		constructor(
			readonly token: string,
			private readonly behavior: {
				readonly pairingNonce?: string;
				readonly failNonce?: boolean;
				readonly failNonceWith?: unknown;
				readonly failConnectWith?: unknown;
				readonly onProbe?: (transport: HandshakeTransport) => number | Promise<number>;
				readonly listSessions?: () => Promise<{ sessions: []; totalCount: 0 }>;
				readonly closeEmitsUnavailable?: boolean;
				readonly methods?: readonly string[];
			} = {},
		) {
			super();
		}

		override async getAuthNonce() {
			if (this.behavior.failNonceWith !== undefined) {
				throw this.behavior.failNonceWith;
			}
			if (this.behavior.failNonce) {
				throw new UniverseAgentTransportError(GrpcStatusCode.UNAVAILABLE, '14 UNAVAILABLE: connect ECONNREFUSED 127.0.0.1:7443');
			}
			return nonce();
		}

		override async connectWithDeviceAuth() {
			if (this.behavior.failConnectWith !== undefined) {
				throw this.behavior.failConnectWith;
			}
			if (this.behavior.pairingNonce) {
				return {
					pairingNonce: this.behavior.pairingNonce,
					methods: this.behavior.methods ?? ['ToolService.ListSkills'],
					events: [],
				};
			}
			return {
				sessionToken: this.token,
				workDir: '/tmp/work',
				methods: this.behavior.methods ?? ['ToolService.ListSkills'],
				events: [],
			};
		}

		override async probeRpc(): Promise<number> {
			if (this.behavior.onProbe) {
				return this.behavior.onProbe(this);
			}
			return GrpcStatusCode.OK;
		}

		override async listSessions() {
			if (this.behavior.listSessions) {
				return this.behavior.listSessions();
			}
			return { sessions: [], totalCount: 0 };
		}

		override close(): void {
			if (this.behavior.closeEmitsUnavailable) {
				this.observeUnavailable();
			}
			super.close();
		}
	}

	async function flush(): Promise<void> {
		for (let i = 0; i < 8; i++) {
			await timeout(0);
		}
	}

	function serviceFor(input: {
		readonly transports: HandshakeTransport[];
		readonly now?: () => number;
		readonly clock?: ReturnType<typeof createReconnectClock>;
		readonly relayTicketId?: string | null;
		readonly onResolve?: (options?: { readonly forceNewTicket?: boolean }) => void;
		readonly targets?: Array<{ readonly relay?: boolean }>;
		readonly pairingOrchestrator?: PairingOrchestrator;
	}): UniverseAgentConnectionService {
		const clock = input.clock ?? createReconnectClock();
		return new UniverseAgentConnectionService({
			createPinnedTransport: target => {
				input.targets?.push(target);
				const next = input.transports.shift();
				if (!next) {
					throw new Error('no handshake transport left');
				}
				return next;
			},
			connectionResolver: {
				resolve: async (_profileId: string, options?: { readonly forceNewTicket?: boolean; readonly forPairing?: boolean }) => {
					input.onResolve?.(options);
					return { ok: true as const, allowRelayFallback: false, endpoint: endpoint(input.relayTicketId ?? null) };
				},
				consumeRelayTicket: () => { },
			} as unknown as ConnectionResolver,
			connectionProfileStore: new PairingTestProfileStore(profile),
			clientIdentityStore: signingIdentity,
			pairingOrchestrator: input.pairingOrchestrator,
			nowMs: input.now ?? (() => 10_000),
			reconnectJitterRatio: 0,
			setTimeoutFn: clock.setTimeoutFn,
			clearTimeoutFn: clock.clearTimeoutFn,
		});
	}

	test('TLS handshake installs the token once before the first probe', async () => {
		const order: string[] = [];
		const transport = new HandshakeTransport('token-a');
		const originalInstall = transport.installSessionToken.bind(transport);
		transport.installSessionToken = token => {
			order.push(`install:${token}`);
			originalInstall(token);
		};
		const originalProbe = transport.probeRpc.bind(transport);
		let service!: UniverseAgentConnectionService;
		transport.probeRpc = async () => {
			order.push(transport.sessionTokenRejected.hasListeners() ? 'probe-subscribed' : 'probe-bare');
			assert.strictEqual((service as unknown as { _linkEvents?: unknown })._linkEvents, undefined);
			return originalProbe();
		};
		const targets: Array<{ readonly relay?: boolean }> = [];
		service = serviceFor({ transports: [transport], targets, relayTicketId: null });
		const result = await service.connectProfile(PAIRING_PROFILE_ID);
		assert.strictEqual(result.ok, true);
		assert.deepStrictEqual(order, ['install:token-a', 'probe-subscribed']);
		assert.deepStrictEqual(transport.installedSessionTokens, ['token-a']);
		assert.strictEqual(targets[0]?.relay, false);
		assert.strictEqual(service.getConnectionPhase().kind, 'connected');
		assert.ok((service as unknown as { _linkEvents?: unknown })._linkEvents);
		assert.strictEqual(transport.sessionTokenRejected.hasListeners(), true);
		service.dispose();
	});

	test('relay ticket sets the pinned relay flag', async () => {
		const targets: Array<{ readonly relay?: boolean }> = [];
		const service = serviceFor({
			transports: [new HandshakeTransport('token-a')],
			targets,
			relayTicketId: 'ticket-9',
		});
		const result = await service.connectProfile(PAIRING_PROFILE_ID);
		assert.strictEqual(result.ok, true);
		assert.strictEqual(targets[0]?.relay, true);
		service.dispose();
	});

	test('plaintext connect does not install a session token', async () => {
		const transport = new MockUniverseAgentGrpcTransport();
		const service = new UniverseAgentConnectionService({
			createTransport: () => transport,
			connectionResolver: {
				resolve: async () => ({
					ok: true as const,
					allowRelayFallback: false,
					endpoint: {
						attemptId: 'a1',
						authority: '127.0.0.1',
						port: 50051,
						resolvedIp: '127.0.0.1',
						servername: '127.0.0.1',
						relayTicketId: null,
						tls: null,
						expiresAtMs: 1,
						path: 'direct' as const,
					},
				}),
				consumeRelayTicket: () => { },
			} as unknown as ConnectionResolver,
			clientIdentityStore: signingIdentity,
		});
		const result = await service.connectProfile(PAIRING_PROFILE_ID);
		assert.strictEqual(result.ok, true);
		assert.deepStrictEqual(transport.installedSessionTokens, []);
		service.dispose();
	});

	test('pairing_pending does not install a session token', async () => {
		const transport = new HandshakeTransport('unused', { pairingNonce: 'nonce-1' });
		let started: ConnectionProfile | undefined;
		const service = serviceFor({
			transports: [transport],
			pairingOrchestrator: {
				startPairing: async (profile: ConnectionProfile) => {
					started = profile;
					return {
						ok: true as const,
						awaitingUserConfirm: true,
						snapshot: {
							phase: 'awaiting_sas_confirm' as const,
							profileId: PAIRING_PROFILE_ID,
							sasCode: 'ABCD-EFGH',
							engineIdentityId: 'engine-id',
							sessionTokenInstalled: false,
						},
					};
				},
				getSnapshot: () => undefined,
				confirmSas: async () => ({ ok: false as const, code: 'transport_failed', reason: 'n/a' }),
				confirmRecoverTrust: async () => ({ ok: false as const, code: 'transport_failed', reason: 'n/a' }),
				abandonRecoverTrust: () => undefined,
			} as unknown as PairingOrchestrator,
		});
		const result = await service.connectProfile(PAIRING_PROFILE_ID);
		assert.strictEqual(result.ok, true);
		if (result.ok) {
			assert.strictEqual(result.pairingPending, true);
		}
		assert.strictEqual(started?.trust, null);
		assert.strictEqual(started?.state, 'pairingPending');
		assert.deepStrictEqual(transport.installedSessionTokens, []);
		transport.rejectSessionToken();
		assert.strictEqual(service.getConnectionPhase().kind, 'connecting');
		assert.strictEqual((service as unknown as { _transport?: unknown })._transport, undefined);
		service.dispose();
	});

	test('profile pairing does not install a session token', async () => {
		const created: MockUniverseAgentGrpcTransport[] = [];
		const pairingProfile: ConnectionProfile = {
			...profile,
			trust: null,
			state: 'pairingPending',
		};
		const service = new UniverseAgentConnectionService({
			createPinnedTransport: () => {
				const transport = new MockUniverseAgentGrpcTransport();
				created.push(transport);
				return transport;
			},
			connectionResolver: {
				resolve: async (_profileId: string, options?: { readonly forPairing?: boolean }) => {
					if (!options?.forPairing) {
						return { ok: false as const, code: 'pairing_required' as const, reason: 'need pair', allowRelayFallback: false };
					}
					return { ok: true as const, allowRelayFallback: false, endpoint: endpoint('ticket-1') };
				},
				consumeRelayTicket: () => { },
			} as unknown as ConnectionResolver,
			connectionProfileStore: new PairingTestProfileStore(pairingProfile),
			clientIdentityStore: signingIdentity,
			pairingOrchestrator: {
				startPairing: async () => ({
					ok: true as const,
					awaitingUserConfirm: true,
					snapshot: {
						phase: 'awaiting_sas_confirm' as const,
						profileId: PAIRING_PROFILE_ID,
						sasCode: 'ABCD-EFGH',
						engineIdentityId: 'engine-id',
						sessionTokenInstalled: false,
					},
				}),
				getSnapshot: () => undefined,
				confirmSas: async () => ({ ok: false as const, code: 'transport_failed', reason: 'n/a' }),
				confirmRecoverTrust: async () => ({ ok: false as const, code: 'transport_failed', reason: 'n/a' }),
				abandonRecoverTrust: () => undefined,
			} as unknown as PairingOrchestrator,
		});
		const result = await service.connectProfile(PAIRING_PROFILE_ID);
		assert.strictEqual(result.ok, true);
		if (result.ok) {
			assert.strictEqual(result.pairingPending, true);
		}
		assert.strictEqual(created.length, 0);
		service.dispose();
	});

	test('connecting B does not install A token on B', async () => {
		const first = new HandshakeTransport('token-a');
		const second = new HandshakeTransport('token-b');
		const service = serviceFor({ transports: [first, second] });
		assert.strictEqual((await service.connectProfile(PAIRING_PROFILE_ID)).ok, true);
		assert.strictEqual((await service.connectProfile(PAIRING_PROFILE_ID)).ok, true);
		assert.deepStrictEqual(first.installedSessionTokens, ['token-a']);
		assert.deepStrictEqual(second.installedSessionTokens, ['token-b']);
		service.dispose();
	});

	test('probe UNAUTHENTICATED stays failed and does not schedule reconnect', async () => {
		const clock = createReconnectClock();
		const transport = new HandshakeTransport('token-a', {
			onProbe: current => {
				assert.strictEqual(current.sessionTokenRejected.hasListeners(), true);
				current.rejectSessionToken();
				return GrpcStatusCode.UNAUTHENTICATED;
			},
		});
		const service = serviceFor({ transports: [transport], clock, now: () => 5_000 });
		const result = await service.connectProfile(PAIRING_PROFILE_ID);
		assert.deepStrictEqual(result, {
			ok: false,
			code: 'transport_failed',
			reason: SESSION_TOKEN_REJECTED_REASON,
		});
		assert.strictEqual(service.getConnectionPhase().kind, 'failed');
		assert.strictEqual((service.getConnectionPhase() as { reason?: string }).reason, SESSION_TOKEN_REJECTED_REASON);
		assert.strictEqual((service as unknown as { _sessionToken?: string })._sessionToken, undefined);
		assert.strictEqual(service.getConnectionSnapshot().authenticated, false);
		assert.strictEqual(Object.hasOwn(service.getConnectionSnapshot(), 'sessionToken'), false);
		assert.strictEqual((service as unknown as { _transport?: unknown })._transport, undefined);
		assert.strictEqual(transport.isChannelAlive, false);
		assert.strictEqual(clock.pending.size, 0);
		service.dispose();
	});

	test('grace rejection during reconnect is not rearmed by D410', async () => {
		const clock = createReconnectClock();
		const first = new HandshakeTransport('token-a', {
			listSessions: async () => {
				throw new UniverseAgentTransportError(GrpcStatusCode.UNAVAILABLE, 'down');
			},
		});
		const second = new HandshakeTransport('token-b', {
			onProbe: current => {
				current.rejectSessionToken();
				return GrpcStatusCode.UNAUTHENTICATED;
			},
		});
		const service = serviceFor({ transports: [first, second], clock, now: () => 5_000 });
		assert.strictEqual((await service.connectProfile(PAIRING_PROFILE_ID)).ok, true);
		await assert.rejects(() => service.listSessions({}));
		assert.strictEqual(clock.pending.size, 1);

		clock.fireAll();
		await flush();
		assert.strictEqual(clock.pending.size, 0);
		assert.strictEqual(service.getConnectionPhase().kind, 'failed');
		assert.strictEqual((service.getConnectionPhase() as { reason?: string }).reason, SESSION_TOKEN_REJECTED_REASON);
		service.dispose();
	});

	test('ordinary transport_failed during reconnect still rearms D410', async () => {
		const clock = createReconnectClock();
		const first = new HandshakeTransport('token-a', {
			listSessions: async () => {
				throw new UniverseAgentTransportError(GrpcStatusCode.UNAVAILABLE, 'down');
			},
		});
		const second = new HandshakeTransport('token-b', { failNonce: true });
		const service = serviceFor({ transports: [first, second], clock, now: () => 5_000 });
		assert.strictEqual((await service.connectProfile(PAIRING_PROFILE_ID)).ok, true);
		await assert.rejects(() => service.listSessions({}));
		clock.fireAll();
		await flush();
		assert.strictEqual(clock.pending.size, 1);
		assert.notStrictEqual((service.getConnectionPhase() as { reason?: string }).reason, SESSION_TOKEN_REJECTED_REASON);
		service.dispose();
	});

	test('TLS pin UNAVAILABLE during reconnect does not rearm', async () => {
		const clock = createReconnectClock();
		const first = new HandshakeTransport('token-a', {
			listSessions: async () => {
				throw new UniverseAgentTransportError(GrpcStatusCode.UNAVAILABLE, 'down');
			},
		});
		const second = new HandshakeTransport('token-b', {
			failNonceWith: new UniverseAgentTransportError(GrpcStatusCode.UNAVAILABLE, '14 UNAVAILABLE: No connection established. Last error: Engine TLS leaf fingerprint does not match pinned trust anchor'),
		});
		const service = serviceFor({ transports: [first, second], clock, now: () => 5_000 });
		assert.strictEqual((await service.connectProfile(PAIRING_PROFILE_ID)).ok, true);
		await assert.rejects(() => service.listSessions({}));
		clock.fireAll();
		await flush();
		assert.strictEqual(clock.pending.size, 0);
		const phase = service.getConnectionPhase();
		assert.strictEqual(phase.kind, 'failed');
		if (phase.kind === 'failed') {
			assert.strictEqual(phase.code, 'pin_mismatch');
		}
		service.dispose();
	});

	test('Connect UNAUTHENTICATED during reconnect does not rearm', async () => {
		const clock = createReconnectClock();
		const first = new HandshakeTransport('token-a', {
			listSessions: async () => {
				throw new UniverseAgentTransportError(GrpcStatusCode.UNAVAILABLE, 'down');
			},
		});
		const second = new HandshakeTransport('token-b', {
			failConnectWith: new UniverseAgentTransportError(GrpcStatusCode.UNAUTHENTICATED, '16 UNAUTHENTICATED: grant revoked'),
		});
		const service = serviceFor({ transports: [first, second], clock, now: () => 5_000 });
		assert.strictEqual((await service.connectProfile(PAIRING_PROFILE_ID)).ok, true);
		await assert.rejects(() => service.listSessions({}));
		clock.fireAll();
		await flush();
		assert.strictEqual(clock.pending.size, 0);
		const phase = service.getConnectionPhase();
		assert.strictEqual(phase.kind, 'failed');
		if (phase.kind === 'failed') {
			assert.strictEqual(phase.code, 'grant_revoked');
		}
		service.dispose();
	});

	test('non-UNAVAILABLE handshake throw during reconnect does not rearm', async () => {
		const clock = createReconnectClock();
		const first = new HandshakeTransport('token-a', {
			listSessions: async () => {
				throw new UniverseAgentTransportError(GrpcStatusCode.UNAVAILABLE, 'down');
			},
		});
		const second = new HandshakeTransport('token-b', {
			failNonceWith: new UniverseAgentTransportError(GrpcStatusCode.DEADLINE_EXCEEDED, '4 DEADLINE_EXCEEDED: Deadline exceeded'),
		});
		const service = serviceFor({ transports: [first, second], clock, now: () => 5_000 });
		assert.strictEqual((await service.connectProfile(PAIRING_PROFILE_ID)).ok, true);
		await assert.rejects(() => service.listSessions({}));
		clock.fireAll();
		await flush();
		assert.strictEqual(clock.pending.size, 0);
		const phase = service.getConnectionPhase();
		assert.strictEqual(phase.kind, 'failed');
		if (phase.kind === 'failed') {
			assert.strictEqual(phase.code, 'engine_not_serving');
			assert.ok(phase.reason.startsWith(DEVICE_AUTH_RPC_NOT_UNAVAILABLE_PREFIX));
		}
		service.dispose();
	});

	test('rejection after the grace window detaches and redials with forceNewTicket', async () => {
		const clock = createReconnectClock();
		let now = 1_000;
		const tickets: Array<boolean | undefined> = [];
		const first = new HandshakeTransport('token-a');
		const second = new HandshakeTransport('token-b');
		const service = serviceFor({
			transports: [first, second],
			clock,
			now: () => now,
			onResolve: options => tickets.push(options?.forceNewTicket),
		});
		assert.strictEqual((await service.connectProfile(PAIRING_PROFILE_ID)).ok, true);
		now = 1_000 + SESSION_TOKEN_REJECT_GRACE_MS + 1;
		first.rejectSessionToken();
		assert.strictEqual(service.getConnectionPhase().kind, 'connecting');
		assert.strictEqual((service.getConnectionPhase() as { reason?: string }).reason, 'transport_lost');
		assert.strictEqual((service as unknown as { _transport?: unknown })._transport, undefined);
		assert.strictEqual(first.isChannelAlive, false);
		assert.strictEqual(clock.pending.size, 1);

		clock.fireAll();
		await flush();
		assert.ok(tickets.includes(true));
		assert.deepStrictEqual(second.installedSessionTokens, ['token-b']);
		assert.strictEqual(service.getConnectionPhase().kind, 'connected');
		service.dispose();
	});

	test('grace rejection ignores UNAVAILABLE emitted by close', async () => {
		const clock = createReconnectClock();
		const transport = new HandshakeTransport('token-a', { closeEmitsUnavailable: true });
		const service = serviceFor({ transports: [transport], clock, now: () => 5_000 });
		assert.strictEqual((await service.connectProfile(PAIRING_PROFILE_ID)).ok, true);
		transport.rejectSessionToken();
		assert.strictEqual(service.getConnectionPhase().kind, 'failed');
		assert.strictEqual((service.getConnectionPhase() as { reason?: string }).reason, SESSION_TOKEN_REJECTED_REASON);
		assert.strictEqual((service as unknown as { _sessionToken?: string })._sessionToken, undefined);
		assert.strictEqual(service.getConnectionSnapshot().authenticated, false);
		assert.strictEqual(Object.hasOwn(service.getConnectionSnapshot(), 'sessionToken'), false);
		assert.strictEqual(clock.pending.size, 0);
		assert.strictEqual(transport.isChannelAlive, false);
		service.dispose();
	});

	test('condemn and closeoutAuthenticatedLink resets capability snapshot to UNKNOWN (B1, G17)', async () => {
		const clock = createReconnectClock();
		let now = 1_000;
		const transportA = new HandshakeTransport('token-a', {
			methods: ['AgentService.Tree', 'ToolService.ListSkills'],
		});
		const transportB = new HandshakeTransport('token-b', {
			methods: ['ToolService.ListSkills'],
		});
		const service = serviceFor({
			transports: [transportA, transportB],
			clock,
			now: () => now,
		});
		const connected = await service.connectProfile(PAIRING_PROFILE_ID);
		assert.strictEqual(connected.ok, true);

		// Connected: capabilities should reflect engine A
		const connectedSnapshot = service.getConnectionSnapshot();
		assert.strictEqual(connectedSnapshot.capabilities.agentTree.support, 'SUPPORTED');
		assert.strictEqual(connectedSnapshot.capabilities.skills.support, 'SUPPORTED');

		// Condemn after grace window so it triggers reconnect closeout
		now = 1_000 + SESSION_TOKEN_REJECT_GRACE_MS + 1;
		transportA.rejectSessionToken();

		// Immediately after condemnation and before next commit, capabilities must be UNKNOWN
		const condemnedSnapshot = service.getConnectionSnapshot();
		assert.strictEqual(condemnedSnapshot.capabilities.agentTree.support, 'UNKNOWN');
		assert.strictEqual(condemnedSnapshot.capabilities.skills.support, 'UNKNOWN');
		assert.strictEqual(condemnedSnapshot.sessionListCapability, 'UNKNOWN');
		assert.strictEqual(condemnedSnapshot.listFilesCapability, 'UNKNOWN');
		assert.strictEqual(condemnedSnapshot.gitWriteCapability?.writeGitCommit, 'UNKNOWN');
		assert.strictEqual(condemnedSnapshot.conversationEntryCapability?.setPermissionMode, 'UNKNOWN');
		assert.strictEqual(service.getCapabilitySnapshot().agentTree.support, 'UNKNOWN');
		assert.strictEqual(service.isAgentTreeUnsupported(), false);

		// Allow reconnect to settle to clean up timer
		clock.fireAll();
		await flush();
		service.dispose();
	});

	test('grace condemn and closeoutAuthenticatedLink resets capability snapshot to UNKNOWN (B1, G17)', async () => {
		const clock = createReconnectClock();
		const transport = new HandshakeTransport('token-a', {
			methods: ['AgentService.Tree', 'ToolService.ListSkills'],
		});
		const service = serviceFor({ transports: [transport], clock, now: () => 5_000 });
		const connected = await service.connectProfile(PAIRING_PROFILE_ID);
		assert.strictEqual(connected.ok, true);

		assert.strictEqual(service.getConnectionSnapshot().capabilities.agentTree.support, 'SUPPORTED');

		transport.rejectSessionToken();
		assert.strictEqual(service.getConnectionPhase().kind, 'failed');

		const snapshot = service.getConnectionSnapshot();
		assert.strictEqual(snapshot.capabilities.agentTree.support, 'UNKNOWN');
		assert.strictEqual(snapshot.capabilities.skills.support, 'UNKNOWN');
		assert.strictEqual(snapshot.sessionListCapability, 'UNKNOWN');
		assert.strictEqual(snapshot.listFilesCapability, 'UNKNOWN');
		assert.strictEqual(snapshot.gitWriteCapability?.writeGitCommit, 'UNKNOWN');
		assert.strictEqual(snapshot.conversationEntryCapability?.setPermissionMode, 'UNKNOWN');
		assert.strictEqual(service.getCapabilitySnapshot().agentTree.support, 'UNKNOWN');
		assert.strictEqual(service.isAgentTreeUnsupported(), false);

		service.dispose();
	});

	test('probe UNAVAILABLE redials with forceNewTicket and is not a grace failure', async () => {
		const clock = createReconnectClock();
		const tickets: Array<boolean | undefined> = [];
		const first = new HandshakeTransport('token-a', {
			onProbe: current => {
				current.observeUnavailable();
				return GrpcStatusCode.UNAVAILABLE;
			},
		});
		const second = new HandshakeTransport('token-b');
		const service = serviceFor({
			transports: [first, second],
			clock,
			now: () => 5_000,
			onResolve: options => tickets.push(options?.forceNewTicket),
		});
		const result = await service.connectProfile(PAIRING_PROFILE_ID);
		assert.strictEqual(result.ok, false);
		if (!result.ok) {
			assert.strictEqual(result.code, 'transport_failed');
			assert.strictEqual(result.reason, TRANSPORT_UNAVAILABLE_REASON);
			assert.notStrictEqual(result.reason, SESSION_TOKEN_REJECTED_REASON);
		}
		assert.strictEqual(service.getConnectionPhase().kind, 'connecting');
		assert.strictEqual((service.getConnectionPhase() as { reason?: string }).reason, 'transport_lost');
		assert.strictEqual(clock.pending.size, 1);

		clock.fireAll();
		await flush();
		assert.ok(tickets.includes(true));
		assert.strictEqual(service.getConnectionPhase().kind, 'connected');
		service.dispose();
	});

	test('committed UNAVAILABLE detaches before a late success can restore the link', async () => {
		const clock = createReconnectClock();
		let release: ((value: { sessions: []; totalCount: 0 }) => void) | undefined;
		const transport = new HandshakeTransport('token-a', {
			listSessions: () => new Promise(resolve => {
				release = resolve;
			}),
		});
		const service = serviceFor({ transports: [transport], clock, now: () => 5_000 });
		assert.strictEqual((await service.connectProfile(PAIRING_PROFILE_ID)).ok, true);
		const pending = service.listSessions({});
		transport.observeUnavailable();
		assert.strictEqual(service.getTransportState(), 'failed');
		assert.strictEqual(service.getConnectionPhase().kind, 'connecting');
		assert.strictEqual(clock.pending.size, 1);
		release?.({ sessions: [], totalCount: 0 });
		await pending;
		assert.strictEqual(service.getTransportState(), 'failed');
		assert.strictEqual(service.getConnectionPhase().kind, 'connecting');
		assert.strictEqual((service.getConnectionPhase() as { reason?: string }).reason, 'transport_lost');
		assert.strictEqual(clock.pending.size, 1);
		service.dispose();
	});

	test('late UNAVAILABLE from the detached transport does not fail the new link', async () => {
		const clock = createReconnectClock();
		let rejectCall: ((error: Error) => void) | undefined;
		const first = new HandshakeTransport('token-a', {
			listSessions: () => new Promise((_resolve, reject) => {
				rejectCall = reject;
			}),
		});
		const second = new HandshakeTransport('token-b');
		const service = serviceFor({ transports: [first, second], clock, now: () => 5_000 });
		assert.strictEqual((await service.connectProfile(PAIRING_PROFILE_ID)).ok, true);
		const pending = service.listSessions({});
		first.observeUnavailable();
		clock.fireAll();
		await flush();
		assert.strictEqual(service.getConnectionPhase().kind, 'connected');
		assert.deepStrictEqual(second.installedSessionTokens, ['token-b']);
		assert.strictEqual(clock.pending.size, 0);

		rejectCall?.(new UniverseAgentTransportError(GrpcStatusCode.UNAVAILABLE, 'late'));
		await assert.rejects(() => pending);
		assert.strictEqual(service.getConnectionPhase().kind, 'connected');
		assert.strictEqual(service.getTransportState(), 'ok');
		assert.strictEqual(clock.pending.size, 0);
		assert.strictEqual((service as unknown as { _sessionToken?: string })._sessionToken, 'token-b');
		assert.strictEqual(service.getConnectionSnapshot().authenticated, true);
		assert.strictEqual(Object.hasOwn(service.getConnectionSnapshot(), 'sessionToken'), false);
		service.dispose();
	});

	test('an event from a transport that is no longer current is ignored', async () => {
		const clock = createReconnectClock();
		const current = new HandshakeTransport('token-a');
		const service = serviceFor({ transports: [current], clock, now: () => 5_000 });
		assert.strictEqual((await service.connectProfile(PAIRING_PROFILE_ID)).ok, true);
		const decoy = new MockUniverseAgentGrpcTransport();
		const phase = service.getConnectionPhase();
		(service as unknown as { _transport: MockUniverseAgentGrpcTransport })._transport = decoy;
		current.rejectSessionToken();
		current.observeUnavailable();
		assert.strictEqual(service.getConnectionPhase(), phase);
		assert.strictEqual(service.getTransportState(), 'ok');
		assert.strictEqual(clock.pending.size, 0);
		assert.strictEqual(decoy.isChannelAlive, true);
		current.close();
		service.dispose();
	});

	test('renew pairing dial forces a fresh uncached ticket', async () => {
		const calls: Array<{ readonly forPairing?: boolean; readonly forceNewTicket?: boolean; readonly useRelayTicketCache?: boolean } | undefined> = [];
		const service = new UniverseAgentConnectionService({
			connectionResolver: {
				resolve: async (_profileId: string, options?: { readonly forPairing?: boolean; readonly forceNewTicket?: boolean; readonly useRelayTicketCache?: boolean }) => {
					calls.push(options);
					return { ok: true as const, allowRelayFallback: true, endpoint: endpoint('ticket-new') };
				},
				consumeRelayTicket: () => { },
			} as unknown as ConnectionResolver,
			clientIdentityStore: signingIdentity,
		});
		const renewed = await (service as unknown as {
			_renewPairingDialEndpoint(profile: ConnectionProfile): Promise<{ ok: true; endpoint: { host: string; port: number; servername: string; relayTicketId?: string | null } } | { ok: false; code: string }>;
		})._renewPairingDialEndpoint(profile);
		assert.deepStrictEqual(calls, [{ forPairing: true, forceNewTicket: true, useRelayTicketCache: false }]);
		assert.strictEqual(renewed.ok, true);
		if (renewed.ok) {
			assert.strictEqual(renewed.endpoint.host, '203.0.113.10');
			assert.strictEqual(renewed.endpoint.port, 7443);
			assert.strictEqual(renewed.endpoint.servername, 'engine.example');
			assert.strictEqual(renewed.endpoint.relayTicketId, 'ticket-new');
		}
		service.dispose();
	});

	test('pinned dial consumes the relay ticket before opening TLS', async () => {
		let cached: string | null = 'ticket-1';
		let issued = 1;
		const order: string[] = [];
		const resolver = {
			resolve: async () => {
				if (!cached) {
					issued++;
					cached = `ticket-${issued}`;
				}
				return { ok: true as const, allowRelayFallback: false, endpoint: endpoint(cached) };
			},
			consumeRelayTicket: () => {
				order.push('consume');
				cached = null;
			},
		};
		const service = new UniverseAgentConnectionService({
			createPinnedTransport: () => {
				order.push('tls');
				return new HandshakeTransport('token-a');
			},
			connectionResolver: resolver as unknown as ConnectionResolver,
			connectionProfileStore: new PairingTestProfileStore(profile),
			clientIdentityStore: signingIdentity,
			nowMs: () => 10_000,
		});
		const result = await service.connectProfile(PAIRING_PROFILE_ID);
		assert.strictEqual(result.ok, true);
		assert.deepStrictEqual(order, ['consume', 'tls']);
		const next = await resolver.resolve();
		assert.strictEqual(next.endpoint.relayTicketId, 'ticket-2');
		service.dispose();
	});

	test('in-flight local discovery does not steal a profile dial subscription', async () => {
		const clock = createReconnectClock();
		let releaseLocal: (() => void) | undefined;
		let markHung: (() => void) | undefined;
		const untilHung = new Promise<void>(resolve => { markHung = resolve; });
		const local = new MockUniverseAgentGrpcTransport();
		let localClosed = false;
		const originalClose = local.close.bind(local);
		local.close = () => {
			localClosed = true;
			originalClose();
		};
		(local as MockUniverseAgentGrpcTransport & {
			connectWithoutDeviceAuth(): Promise<{ workDir: string; methods: []; events: [] }>;
		}).connectWithoutDeviceAuth = async () => {
			markHung?.();
			await new Promise<void>(resolve => { releaseLocal = resolve; });
			return { workDir: '/engine', methods: [], events: [] };
		};
		let service!: UniverseAgentConnectionService;
		const user = new HandshakeTransport('token-user', {
			onProbe: async current => {
				releaseLocal?.();
				await flush();
				const dial = service as unknown as { _transport?: unknown; _linkEvents?: unknown };
				assert.strictEqual(service.getConnectionSnapshot().channelAlive, false);
				assert.strictEqual(service.getConnectionPhase().kind, 'connecting');
				assert.notStrictEqual(dial._transport, local);
				assert.strictEqual(dial._linkEvents, undefined);
				assert.strictEqual(current.sessionTokenRejected.hasListeners(), true);
				return GrpcStatusCode.OK;
			},
		});
		service = new UniverseAgentConnectionService({
			autoConnectLocalEngine: true,
			storageReady: Promise.resolve(),
			findLocalEngine: async () => ({ kind: 'uds' as const, path: '/tmp/universe-agent-local.sock' }),
			openLocalEngineTransport: () => local as never,
			createPinnedTransport: () => user,
			connectionResolver: {
				resolve: async () => ({ ok: true as const, allowRelayFallback: false, endpoint: endpoint(null) }),
				consumeRelayTicket: () => { },
			} as unknown as ConnectionResolver,
			connectionProfileStore: new PairingTestProfileStore(profile),
			clientIdentityStore: signingIdentity,
			nowMs: () => 10_000,
			reconnectJitterRatio: 0,
			setTimeoutFn: clock.setTimeoutFn,
			clearTimeoutFn: clock.clearTimeoutFn,
		});
		await flush();
		assert.strictEqual(clock.pending.size, 1);
		clock.fireAll();
		await untilHung;
		const result = await service.connectProfile(PAIRING_PROFILE_ID);
		assert.strictEqual(result.ok, true);
		if (result.ok) {
			assert.strictEqual(result.path, 'direct');
		}
		assert.strictEqual(localClosed, true);
		assert.deepStrictEqual(service.getConnectionPhase(), { kind: 'connected', path: 'direct' });
		assert.strictEqual((service as unknown as { _loopbackSkipAuth?: boolean })._loopbackSkipAuth, false);
		assert.strictEqual((service as unknown as { _transport?: unknown })._transport, user);
		assert.ok((service as unknown as { _linkEvents?: unknown })._linkEvents);
		assert.strictEqual(user.sessionTokenRejected.hasListeners(), true);
		user.observeUnavailable();
		assert.strictEqual(service.getConnectionPhase().kind, 'connecting');
		assert.strictEqual((service.getConnectionPhase() as { reason?: string }).reason, 'transport_lost');
		assert.strictEqual(clock.pending.size, 1);
		service.dispose();
	});
});

suite('UniverseAgentConnectionService dial generation', () => {

	ensureNoDisposablesAreLeakedInTestSuite();

	const readyIdentity: IClientIdentityStore = {
		getState: async () => ({
			kind: 'ready',
			identity: {
				clientIdentityId: 'a'.repeat(64),
				clientPublicKey: new Uint8Array(32),
				privateKeyPkcs8: new Uint8Array(32),
			},
		}),
		getOrCreateIdentity: async () => ({
			kind: 'ready',
			identity: {
				clientIdentityId: 'a'.repeat(64),
				clientPublicKey: new Uint8Array(32),
				privateKeyPkcs8: new Uint8Array(32),
			},
		}),
		createSigner: async () => () => new Uint8Array(64),
	};

	function dialOf(service: UniverseAgentConnectionService) {
		return service as unknown as {
			_transport?: MockUniverseAgentGrpcTransport;
			_activeProfileId?: string;
			_pairingContextProfileId?: string;
			_connectEpoch: number;
			_capabilities: object;
			saveSkillContent?: unknown;
		};
	}

	function okResolve() {
		return { ok: true as const, allowRelayFallback: false as const, endpoint: plainDialEndpoint };
	}

	test('stale resolve does not close the later user dial', async () => {
		let releaseFirst: (() => void) | undefined;
		let resolves = 0;
		let created = 0;
		const service = new UniverseAgentConnectionService({
			createTransport: () => {
				created++;
				return new MockUniverseAgentGrpcTransport({
					connect: async () => ({
						sessionToken: `token-${created}`,
						workDir: '/tmp/work',
						methods: ['ToolService.ListSkills'],
						events: [],
					}),
				});
			},
			connectionResolver: {
				resolve: async () => {
					resolves++;
					if (resolves === 1) {
						await new Promise<void>(resolve => { releaseFirst = resolve; });
					}
					return okResolve();
				},
				consumeRelayTicket: () => { },
			} as unknown as ConnectionResolver,
			clientIdentityStore: readyIdentity,
		});

		const first = service.connectProfile('A');
		const second = await service.connectProfile('B');
		assert.strictEqual(second.ok, true);
		const winner = dialOf(service)._transport;
		const token = (service as unknown as { _sessionToken?: string })._sessionToken;
		const phase = service.getConnectionPhase();
		const transportState = service.getTransportState();
		const pairingPending = service.getConnectionSnapshot().pairingPending;
		releaseFirst?.();
		const firstResult = await first;
		assert.strictEqual(firstResult.ok, false);
		if (!firstResult.ok) {
			assert.strictEqual(firstResult.reason, 'dial superseded');
		}
		assert.strictEqual(dialOf(service)._transport, winner);
		assert.strictEqual(winner?.isChannelAlive, true);
		assert.strictEqual((service as unknown as { _sessionToken?: string })._sessionToken, token);
		assert.strictEqual(service.getConnectionSnapshot().authenticated, !!token);
		assert.strictEqual(Object.hasOwn(service.getConnectionSnapshot(), 'sessionToken'), false);
		assert.deepStrictEqual(service.getConnectionPhase(), phase);
		assert.strictEqual(service.getTransportState(), transportState);
		assert.strictEqual(service.getConnectionSnapshot().pairingPending, pairingPending);
		assert.strictEqual(dialOf(service)._activeProfileId, 'B');
		assert.strictEqual(created, 1);
		service.dispose();
	});

	test('stale probe does not rewrite the winner capability, session list, or save-skill binding', async () => {
		let releaseProbe: (() => void) | undefined;
		let markStuck: (() => void) | undefined;
		const stuck = new Promise<void>(resolve => { markStuck = resolve; });
		const transports: MockUniverseAgentGrpcTransport[] = [];
		const probeCounts: number[] = [];
		const closed: boolean[] = [];
		let created = 0;
		const service = new UniverseAgentConnectionService({
			createTransport: () => {
				const index = created++;
				probeCounts[index] = 0;
				const transport = new MockUniverseAgentGrpcTransport({
					connect: async () => ({
						sessionToken: `token-${index}`,
						workDir: '/tmp/work',
						methods: ['ToolService.ListSkills', UniverseAgentSessionListMethodKey, UniverseAgentSaveSkillContentMethodKey],
						events: [],
					}),
					probeRpc: async () => {
						probeCounts[index]++;
						if (index === 0 && probeCounts[index] === 1) {
							markStuck?.();
							await new Promise<void>(resolve => { releaseProbe = resolve; });
						}
						return GrpcStatusCode.OK;
					},
				});
				const originalClose = transport.close.bind(transport);
				transport.close = () => {
					closed[index] = true;
					originalClose();
				};
				transports[index] = transport;
				return transport;
			},
			connectionResolver: {
				resolve: async () => okResolve(),
				consumeRelayTicket: () => { },
			} as unknown as ConnectionResolver,
			clientIdentityStore: readyIdentity,
		});

		const first = service.connectProfile('A');
		await stuck;
		const second = await service.connectProfile('B');
		assert.strictEqual(second.ok, true);
		const capabilities = service.getCapabilitySnapshot();
		const sessionList = service.getNavigatorCapability('sessionList');
		const saveSkill = typeof dialOf(service).saveSkillContent === 'function';
		const winnerProbes = probeCounts[1];
		const winner = dialOf(service)._transport;
		releaseProbe?.();
		const firstResult = await first;
		assert.strictEqual(firstResult.ok, false);
		if (!firstResult.ok) {
			assert.strictEqual(firstResult.reason, 'dial superseded');
		}
		assert.strictEqual(service.getCapabilitySnapshot(), capabilities);
		assert.strictEqual(service.getNavigatorCapability('sessionList'), sessionList);
		assert.strictEqual(sessionList, 'SUPPORTED');
		assert.strictEqual(typeof dialOf(service).saveSkillContent === 'function', saveSkill);
		assert.strictEqual(saveSkill, true);
		assert.strictEqual(probeCounts[1], winnerProbes);
		assert.strictEqual(closed[0], true);
		assert.strictEqual(winner?.isChannelAlive, true);
		assert.strictEqual(dialOf(service)._transport, winner);
		assert.strictEqual((service as unknown as { _sessionToken?: string })._sessionToken, 'token-1');
		assert.strictEqual(service.getConnectionSnapshot().authenticated, true);
		assert.strictEqual(Object.hasOwn(service.getConnectionSnapshot(), 'sessionToken'), false);
		service.dispose();
	});

	test('disconnect during probe leaves phase closed and writes no token', async () => {
		let releaseProbe: (() => void) | undefined;
		let markStuck: (() => void) | undefined;
		const stuck = new Promise<void>(resolve => { markStuck = resolve; });
		const service = new UniverseAgentConnectionService({
			createTransport: () => new MockUniverseAgentGrpcTransport({
				connect: async () => ({
					sessionToken: 'token-stale',
					workDir: '/tmp/work',
					methods: ['ToolService.ListSkills'],
					events: [],
				}),
				probeRpc: async () => {
					markStuck?.();
					await new Promise<void>(resolve => { releaseProbe = resolve; });
					return GrpcStatusCode.OK;
				},
			}),
			connectionResolver: {
				resolve: async () => okResolve(),
				consumeRelayTicket: () => { },
			} as unknown as ConnectionResolver,
			clientIdentityStore: readyIdentity,
		});
		const first = service.connectProfile('A');
		await stuck;
		await service.disconnect();
		releaseProbe?.();
		const result = await first;
		assert.strictEqual(result.ok, false);
		assert.strictEqual(service.getConnectionPhase().kind, 'closed');
		assert.strictEqual((service as unknown as { _sessionToken?: string })._sessionToken, undefined);
		assert.strictEqual(service.getConnectionSnapshot().authenticated, false);
		assert.strictEqual(Object.hasOwn(service.getConnectionSnapshot(), 'sessionToken'), false);
		assert.strictEqual(service.isEngineConnected(), false);
		service.dispose();
	});

	test('dispose during probe does not publish a connected commit', async () => {
		let releaseProbe: (() => void) | undefined;
		let markStuck: (() => void) | undefined;
		const stuck = new Promise<void>(resolve => { markStuck = resolve; });
		const service = new UniverseAgentConnectionService({
			createTransport: () => new MockUniverseAgentGrpcTransport({
				connect: async () => ({
					sessionToken: 'token-stale',
					workDir: '/tmp/work',
					methods: ['ToolService.ListSkills'],
					events: [],
				}),
				probeRpc: async () => {
					markStuck?.();
					await new Promise<void>(resolve => { releaseProbe = resolve; });
					return GrpcStatusCode.OK;
				},
			}),
			connectionResolver: {
				resolve: async () => okResolve(),
				consumeRelayTicket: () => { },
			} as unknown as ConnectionResolver,
			clientIdentityStore: readyIdentity,
		});
		const first = service.connectProfile('A');
		await stuck;
		service.dispose();
		releaseProbe?.();
		const result = await first;
		assert.strictEqual(result.ok, false);
		assert.notStrictEqual(service.getConnectionPhase().kind, 'connected');
		assert.strictEqual((service as unknown as { _sessionToken?: string })._sessionToken, undefined);
		assert.strictEqual(service.getConnectionSnapshot().authenticated, false);
		assert.strictEqual(Object.hasOwn(service.getConnectionSnapshot(), 'sessionToken'), false);
	});

	test('reconnect is a no-op while a user dial is in resolve and does not bump epoch', async () => {
		const clock = createReconnectClock();
		let resolves = 0;
		let release: (() => void) | undefined;
		let markWaiting: (() => void) | undefined;
		const waiting = new Promise<void>(resolve => { markWaiting = resolve; });
		const service = new UniverseAgentConnectionService({
			createTransport: () => new MockUniverseAgentGrpcTransport({
				listSessions: async () => {
					throw new UniverseAgentTransportError(GrpcStatusCode.UNAVAILABLE, 'down');
				},
			}),
			connectionResolver: {
				resolve: async () => {
					resolves++;
					if (resolves === 2) {
						markWaiting?.();
						await new Promise<void>(done => { release = done; });
					}
					return okResolve();
				},
				consumeRelayTicket: () => { },
			} as unknown as ConnectionResolver,
			clientIdentityStore: readyIdentity,
			reconnectJitterRatio: 0,
			setTimeoutFn: clock.setTimeoutFn,
			clearTimeoutFn: clock.clearTimeoutFn,
		});
		await service.connectProfile('A');
		await assert.rejects(() => service.listSessions({}));
		assert.deepStrictEqual(clock.delays, [1000]);
		const user = service.connectProfile('A');
		await waiting;
		const epoch = dialOf(service)._connectEpoch;
		clock.fireAll();
		await timeout(0);
		await timeout(0);
		assert.strictEqual(dialOf(service)._connectEpoch, epoch);
		assert.strictEqual(resolves, 2);
		release?.();
		const result = await user;
		assert.strictEqual(result.ok, true);
		service.dispose();
	});

	test('superseded reconnect does not schedule after the user dial commits', async () => {
		const clock = createReconnectClock();
		let created = 0;
		let releaseProbe: (() => void) | undefined;
		let markStuck: (() => void) | undefined;
		const stuck = new Promise<void>(resolve => { markStuck = resolve; });
		const service = new UniverseAgentConnectionService({
			createTransport: () => {
				const index = created++;
				return new MockUniverseAgentGrpcTransport({
					connect: async () => ({
						sessionToken: `token-${index}`,
						workDir: '/tmp/work',
						methods: ['ToolService.ListSkills'],
						events: [],
					}),
					probeRpc: async () => {
						if (index === 1) {
							markStuck?.();
							await new Promise<void>(resolve => { releaseProbe = resolve; });
						}
						return GrpcStatusCode.OK;
					},
					listSessions: async () => {
						if (index === 0) {
							throw new UniverseAgentTransportError(GrpcStatusCode.UNAVAILABLE, 'down');
						}
						return { sessions: [], totalCount: 0 };
					},
				});
			},
			connectionResolver: {
				resolve: async () => okResolve(),
				consumeRelayTicket: () => { },
			} as unknown as ConnectionResolver,
			clientIdentityStore: readyIdentity,
			reconnectJitterRatio: 0,
			setTimeoutFn: clock.setTimeoutFn,
			clearTimeoutFn: clock.clearTimeoutFn,
		});
		await service.connectProfile('A');
		await assert.rejects(() => service.listSessions({}));
		assert.deepStrictEqual(clock.delays, [1000]);
		clock.fireAll();
		await stuck;
		const user = await service.connectProfile('A');
		assert.strictEqual(user.ok, true);
		releaseProbe?.();
		await timeout(0);
		await timeout(0);
		await timeout(0);
		assert.strictEqual(clock.pending.size, 0);
		assert.strictEqual(service.getConnectionPhase().kind, 'connected');
		assert.strictEqual((service as unknown as { _sessionToken?: string })._sessionToken, 'token-2');
		assert.strictEqual(service.getConnectionSnapshot().authenticated, true);
		assert.strictEqual(Object.hasOwn(service.getConnectionSnapshot(), 'sessionToken'), false);
		assert.strictEqual(service.getTransportState(), 'ok');
		service.dispose();
	});

	test('failed resolve for B leaves A id, token, phase, and transport', async () => {
		const service = new UniverseAgentConnectionService({
			createTransport: () => new MockUniverseAgentGrpcTransport(),
			connectionResolver: {
				resolve: async (profileId: string) => {
					if (profileId === 'B') {
						return { ok: false as const, code: 'transport_failed' as const, reason: 'b down', allowRelayFallback: false };
					}
					return okResolve();
				},
				consumeRelayTicket: () => { },
			} as unknown as ConnectionResolver,
			clientIdentityStore: readyIdentity,
		});
		const first = await service.connectProfile('A');
		assert.strictEqual(first.ok, true);
		const transport = dialOf(service)._transport;
		const token = (service as unknown as { _sessionToken?: string })._sessionToken;
		const phase = service.getConnectionPhase();
		const second = await service.connectProfile('B');
		assert.strictEqual(second.ok, false);
		if (!second.ok) {
			assert.strictEqual(second.reason, 'b down');
		}
		assert.strictEqual(dialOf(service)._activeProfileId, 'A');
		assert.strictEqual(dialOf(service)._transport, transport);
		assert.strictEqual(transport?.isChannelAlive, true);
		assert.strictEqual((service as unknown as { _sessionToken?: string })._sessionToken, token);
		assert.strictEqual(service.getConnectionSnapshot().authenticated, !!token);
		assert.strictEqual(Object.hasOwn(service.getConnectionSnapshot(), 'sessionToken'), false);
		assert.deepStrictEqual(service.getConnectionPhase(), phase);
		assert.strictEqual(service.getTransportState(), 'ok');
		assert.strictEqual(phase.kind, 'connected');
		service.dispose();
	});

	test('same-epoch reconnect into pairing stops before forPairing and leaves the winner', async () => {
		let forPairing = 0;
		let starts = 0;
		let dials = 0;
		const service = new UniverseAgentConnectionService({
			createTransport: () => new MockUniverseAgentGrpcTransport(),
			connectionProfileStore: new PairingTestProfileStore(directPairingPendingProfile('A')),
			connectionResolver: {
				resolve: async (_profileId: string, options?: { readonly forPairing?: boolean }) => {
					if (options?.forPairing) {
						forPairing++;
						return okResolve();
					}
					dials++;
					if (dials === 1) {
						return okResolve();
					}
					return { ok: false as const, code: 'pairing_required' as const, reason: 'pairing required', allowRelayFallback: false };
				},
				consumeRelayTicket: () => { },
			} as unknown as ConnectionResolver,
			pairingOrchestrator: {
				startPairing: async () => {
					starts++;
					return {
						ok: true as const,
						awaitingUserConfirm: true,
						snapshot: {
							phase: 'awaiting_sas_confirm' as const,
							profileId: 'A',
							sasCode: 'ABCD-EFGH',
							engineIdentityId: 'engine-id',
							sessionTokenInstalled: false,
						},
					};
				},
				confirmSas: async () => ({ ok: false as const, code: 'unused', reason: 'unused' }),
				confirmRecoverTrust: async () => ({ ok: false as const, code: 'unused', reason: 'unused' }),
				getSnapshot: () => undefined,
				abandonRecoverTrust: () => { },
			} as unknown as PairingOrchestrator,
			clientIdentityStore: readyIdentity,
		});
		const connected = await service.connectProfile('A');
		assert.strictEqual(connected.ok, true);
		const epoch = dialOf(service)._connectEpoch;
		const transport = dialOf(service)._transport;
		const token = (service as unknown as { _sessionToken?: string })._sessionToken;
		const phase = service.getConnectionPhase();
		const transportState = service.getTransportState();
		const pairingPending = service.getConnectionSnapshot().pairingPending;
		const again = await service.connectProfile('A', { reconnect: true });
		assert.strictEqual(again.ok, false);
		if (!again.ok) {
			assert.strictEqual(again.reason, 'dial superseded');
		}
		assert.strictEqual(forPairing, 0);
		assert.strictEqual(starts, 0);
		assert.strictEqual(dialOf(service)._connectEpoch, epoch);
		assert.strictEqual(dialOf(service)._transport, transport);
		assert.strictEqual(transport?.isChannelAlive, true);
		assert.strictEqual((service as unknown as { _sessionToken?: string })._sessionToken, token);
		assert.strictEqual(service.getConnectionSnapshot().authenticated, !!token);
		assert.strictEqual(Object.hasOwn(service.getConnectionSnapshot(), 'sessionToken'), false);
		assert.deepStrictEqual(service.getConnectionPhase(), phase);
		assert.strictEqual(service.getTransportState(), transportState);
		assert.strictEqual(service.getConnectionSnapshot().pairingPending, pairingPending);
		assert.strictEqual(pairingPending, false);
		service.dispose();
	});

	test('profile plaintext dial opens one transport and probes', async () => {
		let created = 0;
		let probed = 0;
		const service = new UniverseAgentConnectionService({
			createTransport: () => {
				created++;
				return new MockUniverseAgentGrpcTransport({
					probeRpc: async () => {
						probed++;
						return GrpcStatusCode.OK;
					},
				});
			},
			connectionResolver: {
				resolve: async () => okResolve(),
				consumeRelayTicket: () => { },
			} as unknown as ConnectionResolver,
			clientIdentityStore: readyIdentity,
		});
		const result = await service.connectProfile('A');
		assert.strictEqual(result.ok, true);
		assert.strictEqual(created, 1);
		assert.ok(probed > 0);
		assert.strictEqual(dialOf(service)._transport?.isChannelAlive, true);
		service.dispose();
	});

	test('plaintext response without a session token fails and does not go pending', async () => {
		const clock = createReconnectClock();
		const service = new UniverseAgentConnectionService({
			createTransport: () => new MockUniverseAgentGrpcTransport({
				connect: async () => ({
					pairingNonce: 'nonce-1',
					sasCode: 'ABCD-EFGH',
					methods: [],
					events: [],
				}),
			}),
			connectionResolver: {
				resolve: async () => okResolve(),
				consumeRelayTicket: () => { },
			} as unknown as ConnectionResolver,
			clientIdentityStore: readyIdentity,
			reconnectJitterRatio: 0,
			setTimeoutFn: clock.setTimeoutFn,
			clearTimeoutFn: clock.clearTimeoutFn,
		});
		const result = await service.connectProfile('A');
		assert.strictEqual(result.ok, false);
		if (!result.ok) {
			assert.strictEqual(result.code, 'transport_failed');
			assert.strictEqual(result.reason, 'connect response missing session token');
		}
		assert.notStrictEqual(service.getConnectionPhase().kind, 'connected');
		assert.strictEqual(service.getConnectionSnapshot().pairingPending, false);
		assert.strictEqual(service.isEngineConnected(), false);
		assert.strictEqual(clock.delays.length, 0);
		service.dispose();
	});

	test('startPairing sas_mismatch stays a sas_mismatch failure', async () => {
		const service = new UniverseAgentConnectionService({
			connectionProfileStore: new PairingTestProfileStore(directPairingPendingProfile()),
			connectionResolver: pairingRequiredResolver() as unknown as ConnectionResolver,
			pairingOrchestrator: {
				startPairing: async () => ({ ok: false as const, code: 'sas_mismatch', reason: 'sas mismatch' }),
				confirmSas: async () => ({ ok: false as const, code: 'unused', reason: 'unused' }),
				confirmRecoverTrust: async () => ({ ok: false as const, code: 'unused', reason: 'unused' }),
				getSnapshot: () => undefined,
				abandonRecoverTrust: () => { },
			} as unknown as PairingOrchestrator,
		});
		const result = await service.connectProfile(PAIRING_PROFILE_ID);
		assert.strictEqual(result.ok, false);
		if (!result.ok) {
			assert.strictEqual(result.code, 'sas_mismatch');
		}
		assert.strictEqual(service.getConnectionPhase().kind, 'failed');
		service.dispose();
	});

	test('startPairing keeps handshake codes that are already ConnectionFailureCode', async () => {
		for (const code of ['signer_unavailable', 'identity_mismatch', 'fingerprint_malformed'] as const) {
			const service = new UniverseAgentConnectionService({
				connectionProfileStore: new PairingTestProfileStore(directPairingPendingProfile()),
				connectionResolver: pairingRequiredResolver() as unknown as ConnectionResolver,
				pairingOrchestrator: {
					startPairing: async () => ({ ok: false as const, code, reason: code }),
					confirmSas: async () => ({ ok: false as const, code: 'unused', reason: 'unused' }),
					confirmRecoverTrust: async () => ({ ok: false as const, code: 'unused', reason: 'unused' }),
					getSnapshot: () => undefined,
					abandonRecoverTrust: () => { },
				} as unknown as PairingOrchestrator,
			});
			const result = await service.connectProfile(PAIRING_PROFILE_ID);
			assert.strictEqual(result.ok, false, code);
			if (!result.ok) {
				assert.strictEqual(result.code, code, code);
			}
			const phase = service.getConnectionPhase();
			assert.strictEqual(phase.kind, 'failed', code);
			if (phase.kind === 'failed') {
				assert.strictEqual(phase.code, code, code);
			}
			service.dispose();
		}
	});

	test('confirmSas during disconnect does not call connectProfile again', async () => {
		let dials = 0;
		let releaseConfirm: (() => void) | undefined;
		let markEntered: (() => void) | undefined;
		const entered = new Promise<void>(resolve => { markEntered = resolve; });
		const service = new UniverseAgentConnectionService({
			connectionProfileStore: new PairingTestProfileStore(directPairingPendingProfile()),
			connectionResolver: {
				resolve: async (_profileId: string, options?: { readonly forPairing?: boolean }) => {
					if (!options?.forPairing) {
						dials++;
					}
					return options?.forPairing
						? okResolve()
						: { ok: false as const, code: 'pairing_required' as const, reason: 'pairing required', allowRelayFallback: false };
				},
				consumeRelayTicket: () => { },
			} as unknown as ConnectionResolver,
			pairingOrchestrator: {
				startPairing: async () => ({
					ok: true as const,
					awaitingUserConfirm: true,
					snapshot: {
						phase: 'awaiting_sas_confirm' as const,
						profileId: PAIRING_PROFILE_ID,
						sasCode: 'ABCD-EFGH',
						engineIdentityId: 'engine-id',
						sessionTokenInstalled: false,
					},
				}),
				confirmSas: async () => {
					markEntered?.();
					await new Promise<void>(resolve => { releaseConfirm = resolve; });
					return {
						ok: true as const,
						snapshot: {
							phase: 'idle' as const,
							profileId: PAIRING_PROFILE_ID,
							sessionTokenInstalled: false,
						},
					};
				},
				confirmRecoverTrust: async () => ({ ok: false as const, code: 'unused', reason: 'unused' }),
				getSnapshot: () => ({
					phase: 'awaiting_sas_confirm' as const,
					profileId: PAIRING_PROFILE_ID,
					sasCode: 'ABCD-EFGH',
					engineIdentityId: 'engine-id',
					sessionTokenInstalled: false,
				}),
				abandonRecoverTrust: () => { },
			} as unknown as PairingOrchestrator,
		});
		await service.connectProfile(PAIRING_PROFILE_ID);
		const confirming = service.confirmPairing();
		await entered;
		const dialsAtConfirm = dials;
		await service.disconnect();
		releaseConfirm?.();
		const confirmed = await confirming;
		assert.strictEqual(confirmed.ok, false);
		if (!confirmed.ok) {
			assert.strictEqual(confirmed.reason, 'no pairing awaiting confirmation');
		}
		assert.strictEqual(dials, dialsAtConfirm);
		service.dispose();
	});

	test('formal pairing_pending clears trust and confirmSas is reachable', async () => {
		const leafDer = new Uint8Array([1, 2, 3, 4]);
		const trust = createEngineTrustRecord({
			leafDer,
			engineIdentityId: 'engine-id',
			establishedAt: 1,
		});
		const profile: ConnectionProfile = {
			profileId: PAIRING_PROFILE_ID,
			displayName: 'Direct',
			target: { kind: 'directAddress', host: '203.0.113.10', port: 7443 },
			trust,
			state: 'active',
			allowPrivateNetwork: true,
		};
		const tlsEndpoint = {
			...plainDialEndpoint,
			authority: '203.0.113.10:7443',
			port: 7443,
			resolvedIp: '203.0.113.10',
			servername: 'engine.example',
			tls: {
				trustAnchorLeafDer: leafDer,
				expectedLeafSha256Hex: trust.leafSha256Hex,
				hostnameVerification: 'replaced-by-pin' as const,
			},
		};
		let started: ConnectionProfile | undefined;
		let confirmCalls = 0;
		const service = new UniverseAgentConnectionService({
			createPinnedTransport: () => new class extends MockUniverseAgentGrpcTransport {
				override async getAuthNonce(): Promise<UniverseAgentAuthNonceResult> {
					return {
						authNonce: new Uint8Array(32),
						engineIdentityId: 'engine-id',
						engineCertFingerprint: trust.leafSha256Hex,
					};
				}
				override async connectWithDeviceAuth(): Promise<UniverseAgentConnectResult> {
					return { pairingNonce: 'nonce-1', methods: ['ToolService.ListSkills'], events: [] };
				}
			}(),
			connectionProfileStore: new PairingTestProfileStore(profile),
			connectionResolver: {
				resolve: async () => ({ ok: true as const, allowRelayFallback: false as const, endpoint: tlsEndpoint }),
				consumeRelayTicket: () => { },
			} as unknown as ConnectionResolver,
			clientIdentityStore: readyIdentity,
			pairingOrchestrator: {
				startPairing: async (next: ConnectionProfile) => {
					started = next;
					return {
						ok: true as const,
						awaitingUserConfirm: true,
						snapshot: {
							phase: 'awaiting_sas_confirm' as const,
							profileId: PAIRING_PROFILE_ID,
							sasCode: 'ABCD-EFGH',
							engineIdentityId: 'engine-id',
							sessionTokenInstalled: false,
						},
					};
				},
				confirmSas: async () => {
					confirmCalls++;
					return { ok: false as const, code: 'sas_mismatch', reason: 'sas mismatch' };
				},
				confirmRecoverTrust: async () => ({ ok: false as const, code: 'unused', reason: 'unused' }),
				getSnapshot: () => ({
					phase: 'awaiting_sas_confirm' as const,
					profileId: PAIRING_PROFILE_ID,
					sasCode: 'ABCD-EFGH',
					engineIdentityId: 'engine-id',
					sessionTokenInstalled: false,
				}),
				abandonRecoverTrust: () => { },
			} as unknown as PairingOrchestrator,
		});
		const result = await service.connectProfile(PAIRING_PROFILE_ID);
		assert.strictEqual(result.ok, true);
		if (result.ok) {
			assert.strictEqual(result.pairingPending, true);
		}
		assert.strictEqual(started?.trust, null);
		assert.strictEqual(started?.state, 'pairingPending');
		assert.strictEqual(dialOf(service)._transport, undefined);
		assert.notStrictEqual(dialOf(service)._activeProfileId, PAIRING_PROFILE_ID);
		const confirmed = await service.confirmPairing();
		assert.strictEqual(confirmCalls, 1);
		assert.strictEqual(confirmed.ok, false);
		if (!confirmed.ok) {
			assert.strictEqual(confirmed.code, 'sas_mismatch');
			assert.notStrictEqual(confirmed.reason, 'no pairing awaiting confirmation');
		}
		service.dispose();
	});
});

suite('UniverseAgentConnectionService dispose snapshot', () => {

	ensureNoDisposablesAreLeakedInTestSuite();

	test('dispose broadcasts the disconnected snapshot when leaving connected', async () => {
		const service = new UniverseAgentConnectionService({
			connectionResolver: plainFixtureResolver(),
			clientIdentityStore: plainFixtureIdentity(),
			createTransport: () => new MockUniverseAgentGrpcTransport(),
		});
		await connectPlainFixture(service);
		assert.deepStrictEqual(service.getConnectionPhase(), { kind: 'connected', path: 'direct' });
		const snapshots: Array<{ readonly phase?: { readonly kind: string }; readonly authenticated?: boolean; readonly channelAlive: boolean }> = [];
		const sub = service.onDidChangeConnection(snapshot => snapshots.push(snapshot));
		service.dispose();
		sub.dispose();
		assert.strictEqual(snapshots.length, 1);
		assert.deepStrictEqual(snapshots[0].phase, { kind: 'disconnected' });
		assert.strictEqual(snapshots[0].authenticated, false);
		assert.strictEqual(snapshots[0].channelAlive, false);
		assert.deepStrictEqual(service.getConnectionPhase(), { kind: 'disconnected' });
	});

	test('dispose broadcasts when leaving connecting', () => {
		const service = new UniverseAgentConnectionService();
		(service as unknown as { _connectionPhase: { kind: 'connecting'; reason: 'initial' } })._connectionPhase = { kind: 'connecting', reason: 'initial' };
		const snapshots: Array<{ readonly phase?: { readonly kind: string } }> = [];
		const sub = service.onDidChangeConnection(snapshot => snapshots.push(snapshot));
		service.dispose();
		sub.dispose();
		assert.strictEqual(snapshots.length, 1);
		assert.deepStrictEqual(snapshots[0].phase, { kind: 'disconnected' });
	});

	test('dispose does not broadcast when the phase stays put', () => {
		const phases = [
			{ kind: 'disconnected' as const },
			{ kind: 'failed' as const, code: 'transport_failed' as const, reason: 'down' },
			{ kind: 'closed' as const },
		];
		for (const phase of phases) {
			const service = new UniverseAgentConnectionService();
			(service as unknown as { _connectionPhase: typeof phase; _sessionToken?: string })._connectionPhase = phase;
			(service as unknown as { _sessionToken?: string })._sessionToken = 'token-1';
			const snapshots: unknown[] = [];
			const sub = service.onDidChangeConnection(snapshot => snapshots.push(snapshot));
			service.dispose();
			sub.dispose();
			assert.strictEqual(snapshots.length, 0, phase.kind);
			assert.deepStrictEqual(service.getConnectionPhase(), phase);
		}
	});
});

type PairingDialogBoxCall = {
	readonly type?: string;
	readonly message: string;
	readonly detail?: string;
	readonly buttons?: readonly string[];
	readonly cancelId?: number;
	readonly defaultId?: number;
};

function stubPairingMainDialog(response: number, calls: PairingDialogBoxCall[]) {
	return {
		showMessageBox: async (options: PairingDialogBoxCall) => {
			calls.push(options);
			return { response };
		},
	};
}

function assertPairingDialogButtons(buttons: readonly string[] | undefined): void {
	assert.ok(buttons);
	assert.strictEqual(buttons.length, 2);
	for (const button of buttons) {
		const visible = button.replaceAll('&&', '').trim();
		assert.ok(!/^skip(\s|$)/i.test(visible), visible);
		assert.ok(!/^trust(\s|$)/i.test(visible), visible);
	}
}

function productionPairingService(dialog?: { showMessageBox: (options: PairingDialogBoxCall) => Promise<{ response: number }> }) {
	const profileStore = new PairingTestProfileStore(directPairingPendingProfile());
	let trustPuts = 0;
	const service = new UniverseAgentConnectionService({
		clientIdentityStore: {
			getState: async () => ({ kind: 'encryption_unavailable' }),
			getOrCreateIdentity: async () => ({ kind: 'encryption_unavailable' }),
			createSigner: async () => undefined,
		},
		connectionProfileStore: profileStore,
		engineTrustStore: {
			get: () => undefined,
			list: () => [],
			put: () => { trustPuts++; },
			remove: () => { },
		},
		...(dialog ? { dialogMainService: dialog } : {}),
	});
	const orchestrator = (service as unknown as { _pairingOrchestrator?: PairingOrchestrator })._pairingOrchestrator;
	assert.ok(orchestrator);
	return {
		service,
		profileStore,
		orchestrator,
		trustPuts: () => trustPuts,
	};
}

function seedAwaitingSas(orchestrator: PairingOrchestrator): void {
	(orchestrator as unknown as { activeContext: object }).activeContext = {
		profile: directPairingPendingProfile(),
		endpoint: { host: '127.0.0.1', port: 50051, servername: '127.0.0.1' },
		leafDer: Uint8Array.from([1, 2, 3]),
		leafSha256Hex: 'ab'.repeat(32),
		engineIdentityId: 'engine-identity-1',
		pairingNonce: Uint8Array.from([4]),
		sasCode: 'ABCD-EFGH',
		sasLocal: 'ABCD-EFGH',
	};
}

function seedRecoverTrust(orchestrator: PairingOrchestrator): void {
	(orchestrator as unknown as { recoverContext: object }).recoverContext = {
		profile: directPairingPendingProfile(),
		endpoint: { host: '127.0.0.1', port: 50051, servername: '127.0.0.1' },
		leafDer: Uint8Array.from([1, 2, 3]),
		leafSha256Hex: 'cd'.repeat(32),
		engineIdentityId: 'engine-identity-1',
	};
}

suite('UniverseAgentConnectionService pairing main dialog', () => {

	ensureNoDisposablesAreLeakedInTestSuite();

	test('confirmSas asks the stubbed dialog and cancel is not approval', async () => {
		const calls: PairingDialogBoxCall[] = [];
		const { service, orchestrator } = productionPairingService(stubPairingMainDialog(1, calls));
		seedAwaitingSas(orchestrator);
		const result = await orchestrator.confirmSas();
		assert.strictEqual(result.ok, false);
		if (!result.ok) {
			assert.strictEqual(result.code, 'sas_cancelled');
		}
		assert.strictEqual(calls.length, 1);
		assert.strictEqual(calls[0].type, 'warning');
		assert.strictEqual(calls[0].cancelId, 1);
		assert.strictEqual(calls[0].defaultId, 0);
		assert.match(calls[0].detail ?? '', /ABCD-EFGH/);
		assert.match(calls[0].detail ?? '', /Direct/);
		assertPairingDialogButtons(calls[0].buttons);
		assert.match(calls[0].buttons?.[0] ?? '', /Verified on Engine/);
		service.dispose();
	});

	test('confirmSas treats only the first dialog button as approval', async () => {
		const calls: PairingDialogBoxCall[] = [];
		const { service, orchestrator } = productionPairingService(stubPairingMainDialog(0, calls));
		const confirmSas = (orchestrator as unknown as {
			deps: { confirmSas: (input: { readonly sasCode: string; readonly engineIdentityId: string; readonly leafSha256Hex: string; readonly displayName: string }) => Promise<boolean> };
		}).deps.confirmSas;
		const approved = await confirmSas({
			sasCode: 'ABCD-EFGH',
			engineIdentityId: 'engine-identity-1',
			leafSha256Hex: 'ab'.repeat(32),
			displayName: 'Direct',
		});
		assert.strictEqual(approved, true);
		assert.strictEqual(calls.length, 1);
		service.dispose();
	});

	test('confirmSas without a dialog does not auto-approve', async () => {
		const { service, orchestrator } = productionPairingService();
		seedAwaitingSas(orchestrator);
		await assert.rejects(
			() => orchestrator.confirmSas(),
			/Pairing confirmation dialog is not available/,
		);
		service.dispose();
	});

	test('a thrown pairing dialog is not user cancellation', async () => {
		const { service, orchestrator } = productionPairingService({
			showMessageBox: async () => {
				throw new Error('dialog failed');
			},
		});
		seedAwaitingSas(orchestrator);
		await assert.rejects(() => orchestrator.confirmSas(), /dialog failed/);
		service.dispose();
	});

	test('confirmRecoverTrust writes trust only when the stubbed dialog approves', async () => {
		const approvedCalls: PairingDialogBoxCall[] = [];
		const approvedHost = productionPairingService(stubPairingMainDialog(0, approvedCalls));
		seedRecoverTrust(approvedHost.orchestrator);
		const approved = await approvedHost.orchestrator.confirmRecoverTrust();
		assert.strictEqual(approved.ok, true);
		assert.strictEqual(approvedHost.trustPuts(), 1);
		assert.ok(approvedHost.profileStore.get(PAIRING_PROFILE_ID)?.trust);
		assert.strictEqual(approvedCalls.length, 1);
		assert.match(approvedCalls[0].detail ?? '', /engine-identity-1/);
		assert.match(approvedCalls[0].detail ?? '', new RegExp('cd'.repeat(32)));
		assertPairingDialogButtons(approvedCalls[0].buttons);
		assert.match(approvedCalls[0].buttons?.[0] ?? '', /Recover trust/);
		approvedHost.service.dispose();

		const refusedCalls: PairingDialogBoxCall[] = [];
		const refusedHost = productionPairingService(stubPairingMainDialog(1, refusedCalls));
		seedRecoverTrust(refusedHost.orchestrator);
		const refused = await refusedHost.orchestrator.confirmRecoverTrust();
		assert.strictEqual(refused.ok, false);
		if (!refused.ok) {
			assert.strictEqual(refused.code, 'recover_cancelled');
		}
		assert.strictEqual(refusedHost.trustPuts(), 0);
		assert.strictEqual(refusedHost.profileStore.get(PAIRING_PROFILE_ID)?.trust, null);
		assert.strictEqual(refusedCalls.length, 1);
		refusedHost.service.dispose();
	});

	test('confirmRecoverTrust without a dialog does not auto-approve', async () => {
		const host = productionPairingService();
		seedRecoverTrust(host.orchestrator);
		await assert.rejects(
			() => host.orchestrator.confirmRecoverTrust(),
			/Pairing confirmation dialog is not available/,
		);
		assert.strictEqual(host.trustPuts(), 0);
		assert.strictEqual(host.profileStore.get(PAIRING_PROFILE_ID)?.trust, null);
		host.service.dispose();
	});

	test('confirmPairing without in-pane approval still opens the main dialog', async () => {
		const calls: PairingDialogBoxCall[] = [];
		const host = productionPairingService(stubPairingMainDialog(1, calls));
		seedAwaitingSas(host.orchestrator);
		(host.orchestrator as unknown as { lastSnapshot: object }).lastSnapshot = {
			phase: 'awaiting_sas_confirm',
			profileId: PAIRING_PROFILE_ID,
			sasCode: 'ABCD-EFGH',
			engineIdentityId: 'engine-identity-1',
			sessionTokenInstalled: false,
		};
		(host.service as unknown as { _pairingContextProfileId?: string })._pairingContextProfileId = PAIRING_PROFILE_ID;
		const result = await host.service.confirmPairing();
		assert.strictEqual(calls.length, 1);
		assert.strictEqual(result.ok, false);
		if (!result.ok) {
			assert.strictEqual(result.code, 'sas_cancelled');
		}
		assert.strictEqual(host.trustPuts(), 0);
		host.service.dispose();
	});

	test('confirmPairing userConfirmed skips the main SAS dialog', async () => {
		const calls: PairingDialogBoxCall[] = [];
		const host = productionPairingService(stubPairingMainDialog(1, calls));
		seedAwaitingSas(host.orchestrator);
		(host.orchestrator as unknown as { lastSnapshot: object }).lastSnapshot = {
			phase: 'awaiting_sas_confirm',
			profileId: PAIRING_PROFILE_ID,
			sasCode: 'ABCD-EFGH',
			engineIdentityId: 'engine-identity-1',
			sessionTokenInstalled: false,
		};
		(host.service as unknown as { _pairingContextProfileId?: string })._pairingContextProfileId = PAIRING_PROFILE_ID;
		const result = await host.service.confirmPairing({ userConfirmed: true });
		assert.strictEqual(calls.length, 0);
		assert.strictEqual(result.ok, false);
		if (!result.ok) {
			assert.notStrictEqual(result.code, 'sas_cancelled');
			assert.match(result.reason, /client identity unavailable/);
		}
		assert.strictEqual(host.trustPuts(), 0);
		host.service.dispose();
	});

	test('confirmPairing userConfirmed writes recover trust without the main dialog', async () => {
		const calls: PairingDialogBoxCall[] = [];
		const host = productionPairingService(stubPairingMainDialog(1, calls));
		seedRecoverTrust(host.orchestrator);
		(host.orchestrator as unknown as { lastSnapshot: object }).lastSnapshot = {
			phase: 'recover_trust',
			profileId: PAIRING_PROFILE_ID,
			engineIdentityId: 'engine-identity-1',
			leafSha256Hex: 'cd'.repeat(32),
			sessionTokenInstalled: false,
		};
		(host.service as unknown as { _pairingContextProfileId?: string })._pairingContextProfileId = PAIRING_PROFILE_ID;
		const result = await host.service.confirmPairing({ userConfirmed: true });
		assert.strictEqual(calls.length, 0);
		assert.strictEqual(host.trustPuts(), 1);
		assert.ok(host.profileStore.get(PAIRING_PROFILE_ID)?.trust);
		assert.strictEqual(result.ok, false);
		if (!result.ok) {
			assert.strictEqual(result.reason, 'connection resolver is not configured');
		}
		host.service.dispose();
	});
});
