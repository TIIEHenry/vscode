from pathlib import Path
import json, subprocess, sys, time

base = Path(__file__).resolve().parent
kind, outcome, request_id, number = sys.argv[1:]
number = int(number)
session = 'D-E-after-controlled-session'
prefix = f'[data-session-key="{session}"] '
selectors = {
    'permission': prefix + '.conversation-lens-confirmation-seat [role="button"]',
    'question': prefix + '.conversation-lens-question-actions [role="button"]',
    'clientTool': prefix + '.conversation-process-fold-tool-respond',
}
selector = selectors[kind]
records = []

def control(value):
    with (base / 'fake-control.jsonl').open('a') as target:
        target.write(json.dumps(value) + '\n')
    time.sleep(.18)

def held():
    return [value for value in map(json.loads, (base / 'fake-io.jsonl').read_text().splitlines()) if value.get('type') == 'response-held' and value.get('id') == request_id]

def step(stage, **action):
    global number
    label = f'{number:02}-{request_id.removeprefix("D-E-")}-{stage}'
    number += 1
    action['label'] = label
    run = subprocess.run(['rtk', 'proxy', 'node', str(base / 'driver.cjs'), json.dumps(action)], capture_output=True, text=True)
    with (base / 'driver-stdout.jsonl').open('a') as target:
        target.write(json.dumps({'action': action, 'exit': run.returncode, 'stdout': run.stdout, 'stderr': run.stderr}) + '\n')
    if run.returncode:
        print(run.stdout, run.stderr)
        raise RuntimeError(f'actual runtime driver failed: {label}')
    record = json.loads((base / 'steps' / (label + '.json')).read_text())
    records.append(label)
    print(json.dumps({'label': label, 'seats': len(record['state']['seats']), 'result': record.get('result')}), flush=True)
    return record

def target_seats(record):
    return [seat for seat in record['state']['seats'] if seat.get('sessionKey') == session]

try:
    if not (kind == 'permission' and outcome == 'reject' and request_id == 'D-E-permission-reject'):
        control({'op': 'emit', 'kind': kind, 'id': request_id, **({'itemId': 'choose'} if kind == 'question' else {})})
    pending = step('pending', type='inspect')
    assert len(target_seats(pending)) == 2, 'two actual seats required'
    if kind == 'question':
        step('choose-Alpha', type='click', selector=prefix + '.conversation-lens-question-seat [role="checkbox"]', index=0)
        step('type-custom', type='fill', selector=prefix + '.conversation-lens-question-custom', value='D E retained custom text', index=0)
    busy = step('first-click-busy', type='click', selector=selector, index=0)
    assert all(seat['busy'] == 'true' for seat in target_seats(busy))
    pane_ids = [pane['groupId'] for pane in busy['state']['actualPaneDiagnostics'] if pane.get('leaseSessionId') == session]
    assert sorted(pane_ids) == [11, 13]
    assert all(pane['paneDistinctFromOtherGroups'] for pane in busy['state']['actualPaneDiagnostics'])
    repeat = step('normal-duplicate-second-pane-blocked', type='attemptDisabledClick', selector=selector, index=2 if kind == 'permission' else 1)
    assert repeat['result']['blocked'] is True and repeat['result']['normalClick'] is True
    assert len(held()) == 1, 'one response unary while two panes busy'
    control({'op': 'settle', 'token': held()[0]['token'], 'outcome': outcome})
    failure = step('inline-failure-retry-enabled', type='inspect')
    seats = target_seats(failure)
    assert len(seats) == 2 and all('Couldn\'t send this response:' in seat['text'] for seat in seats)
    assert all(seat['busy'] != 'true' for seat in seats)
    assert all(any(control.get('ariaDisabled') == 'false' for control in seat['controls']) for seat in seats)
    if kind == 'question':
        original = next(seat for seat in seats if seat['groupId'] == 11)
        assert any(control['text'] == 'Alpha' and control['checked'] == 'true' for control in original['controls'])
        assert any(control['value'] == 'D E retained custom text' for control in original['controls'])
    step('unchanged-retry-click', type='click', selector=selector, index=0)
    attempts = held()
    assert len(attempts) == 2 and attempts[0]['requestHex'] == attempts[1]['requestHex']
    control({'op': 'settle', 'token': attempts[-1]['token'], 'outcome': 'success'})
    success = step('local-success-before-authority-publish', type='inspect')
    assert not target_seats(success), 'local cleanup must happen before fake authority publishes'
    assert all(not pane['snapshot']['pendingActions'] for pane in success['state']['actualPaneDiagnostics'])
    assert success['state']['uiErrors'] == []
    control({'op': 'publish'})
    summary = {'kind': kind, 'firstOutcome': outcome, 'requestId': request_id, 'state': 'PASS', 'normalDuplicateBlocked': True, 'heldUnaryCountDuringBusy': 1, 'attemptCount': 2, 'payloadsEqual': True, 'steps': records, 'requestHex': attempts[0]['requestHex'], 'nextNumber': number}
    with (base / 'case-results.jsonl').open('a') as target:
        target.write(json.dumps(summary) + '\n')
    print(json.dumps(summary), flush=True)
except Exception as error:
    (base / ('case-' + request_id + '.failure.json')).write_text(json.dumps({'kind': kind, 'outcome': outcome, 'requestId': request_id, 'steps': records, 'error': str(error)}, indent=2) + '\n')
    raise
