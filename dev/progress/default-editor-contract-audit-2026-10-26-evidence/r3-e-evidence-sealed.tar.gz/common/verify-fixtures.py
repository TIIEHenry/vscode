from pathlib import Path
import json,sys,importlib.util
sys.dont_write_bytecode=True
root=Path(__file__).resolve().parent.parent;phase=sys.argv[1];assert phase in ['J','E'];sys.path.insert(0,str(root/'common'));from gates import verify
verify(phase,native=False,require_launch=True)
base=root/phase;j=root/'J';spec=importlib.util.spec_from_file_location('readonly_r3_prepare',j/'prepare.py');module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module);expected=json.loads((j/'fixture-baseline.json').read_text());current=[module.snapshot(Path(row['root'])) for row in expected];assert current==expected;target=base/'fixture-after.json';assert not target.exists();target.write_text(json.dumps({'matchesBaseline':True,'current':current,'runtimeCheck':(base/'launch.json').exists(),'noOldFixtureArtifactWritten':True},indent=2)+'\n');print(json.dumps({'matchesBaseline':True,'phase':phase}))
